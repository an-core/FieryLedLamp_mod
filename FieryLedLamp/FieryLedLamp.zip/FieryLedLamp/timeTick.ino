// ******************************************************************************* timeTick.ino *********************************************************
#include <time.h>
#include "Prototypes.h"
#include "Extern.h"
//--------------------------

void timeTick() {
  static uint32_t secsTimer = 0UL;
  if (millis() - secsTimer < 1000UL) return;
  secsTimer = millis();

  if (!myTime.isTimeSet()) {
    return;
  }

  // для ST7789
  if (!timeSynched) {
    timeSynched = true;
  }

  time_t t = getCurrentLocalTime();
  struct tm *ti = localtime(&t);
  uint8_t currentHour = ti->tm_hour;
  uint8_t currentMinute = ti->tm_min;
  uint8_t currentSecond = ti->tm_sec;
  uint32_t currentSeconds = currentHour * 3600UL + currentMinute * 60UL + currentSecond;
  uint16_t currentMinutes = currentHour * 60 + currentMinute;
  uint8_t thisDay = (ti->tm_wday == 0) ? 6 : ti->tm_wday - 1;
  thisTime = currentMinutes;

#if USE_DAWN
  static uint16_t lastDawnDay = 0xFFFF;
  if (thisDay != lastDawnDay) {
    lastDawnDay = thisDay;
    manualOff = false;
  }
#endif

#if USE_SUNSET
  static uint16_t lastSunsetDay = 0xFFFF;
  if (thisDay != lastSunsetDay) {
    lastSunsetDay = thisDay;
    manualsOff = false;
  }
#endif

#if USE_SCHEDULE
  static uint16_t lastExecutedMinute[MAX_SCHEDULE_ENTRIES] = {0};
  static uint16_t lastYearDay = 0xFFFF;
  static time_t lastEpoch = 0;

  uint16_t currentYearDay = ti->tm_yday;
  time_t nowEpoch = t;

  bool needReset = false;

  if (currentYearDay != lastYearDay) {
    needReset = true;
    lastYearDay = currentYearDay;
  }

  if (lastEpoch != 0 && nowEpoch > lastEpoch + 120) {
    needReset = true;
  }

  if (needReset) {
    for (uint8_t i = 0; i < MAX_SCHEDULE_ENTRIES; i++) {
      lastExecutedMinute[i] = 0xFFFF;
    }
  }

  lastEpoch = nowEpoch;
#endif

  // ============================================================================= РАССВЕТ ===============================================================

#if USE_DAWN
  const uint8_t dawnOffsets[] PROGMEM = {5, 10, 15, 20, 25, 30, 40, 50, 60}; // Длительность рассвета
  uint16_t dawnStartMin = alarms[thisDay].Time - pgm_read_byte(&dawnOffsets[dawnMode]);
  bool dawnActive = alarms[thisDay].State && currentMinutes >= dawnStartMin && currentMinutes < alarms[thisDay].Time + DAWN_TIMEOUT;

  static uint16_t lastDawnWindowDay = 0xFFFF;
  if (dawnActive && thisDay != lastDawnWindowDay) {
    lastDawnWindowDay = thisDay;
    manualOff = false;
  }

  static uint32_t lastDawnLog = 0;
  if (millis() - lastDawnLog > 10000) {
    lastDawnLog = millis();
  }

  if (dawnActive && !manualOff) {
    uint32_t dawnStartSec = dawnStartMin * 60UL;
    dawnPosition = map(currentSeconds - dawnStartSec, 0, pgm_read_byte(&dawnOffsets[dawnMode]) * 60UL, 0, 255);
    dawnPosition = constrain(dawnPosition, 0, 255);

    for (uint8_t j = 5; j > 0; j--) {
      if (dawnCounter >= j) dawnColor[j] = dawnColor[j - 1];
    }

    dawnColor[0] = CHSV(map(dawnPosition, 0, 255, 10, 35), map(dawnPosition, 0, 255, 255, 170), map(dawnPosition, 0, 255, 2, DAWN_BRIGHT));
    if (dawnCounter < 5) dawnCounter++;
    dawnFlag = 1;
    ONflag = false;
#if USE_TM1637
    DisplayFlag = 0;
#endif
    for (uint16_t i = 0; i < usedLeds; i++) {
      leds[i] = dawnColor[i % 6];
    }
    FastLED.setBrightness(255);
    FastLED.show();
    yield();
#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
    digitalWrite(MOSFET_PIN, MOSFET_LEVEL);
#endif
#if defined(ALARM_PIN) && defined(ALARM_LEVEL)
    if (currentMinutes == alarms[thisDay].Time) {
      digitalWrite(ALARM_PIN, manualOff ? !ALARM_LEVEL : ALARM_LEVEL);
    }
#endif
  }
  else if (dawnFlag == 1) {
    dawnFlag = 0;
    dawnCounter = 0;
    dawnPosition = 0;
#if USE_TM1637
    DisplayFlag = 0;
#endif
    for (uint8_t j = 0; j < 6; j++) dawnColor[j] = CRGB(0, 0, 0);
    ONflag = false;
    jsonWrite(configSetup, "Power", 0);
    FastLED.clear();
    FastLED.setBrightness(0);
    FastLED.show();
    yield();
#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
    digitalWrite(MOSFET_PIN, !MOSFET_LEVEL);
#endif
#if defined(ALARM_PIN) && defined(ALARM_LEVEL)
    digitalWrite(ALARM_PIN, !ALARM_LEVEL);
#endif
  }
#endif // USE_DAWN

  // ============================================================================= ЗАКАТ =================================================================

#if USE_SUNSET
  const uint8_t sunsetOffsets[] PROGMEM = {5, 10, 15, 20, 25, 30, 40, 50, 60};
  uint16_t sunsetStartMin = sunsets[thisDay].Time;
  uint16_t sunsetEndMin = sunsetStartMin + pgm_read_byte(&sunsetOffsets[sunsetMode]);
  bool sunsetActive = sunsets[thisDay].State && currentMinutes >= sunsetStartMin && currentMinutes < sunsetEndMin;

  static uint16_t lastSunsetWindowDay = 0xFFFF;
  if (sunsetActive && thisDay != lastSunsetWindowDay) {
    lastSunsetWindowDay = thisDay;
    manualsOff = false;
  }

  if (sunsetActive && !manualsOff) {
    uint32_t sunsetStartSec = sunsetStartMin * 60UL;
    uint32_t elapsedSec = currentSeconds - sunsetStartSec;
    uint32_t durationSec = pgm_read_byte(&sunsetOffsets[sunsetMode]) * 60UL;
    sunsetPosition = map(elapsedSec, 0, durationSec, 255, 0);
    sunsetPosition = constrain(sunsetPosition, 0, 255);

    for (uint8_t j = 5; j > 0; j--) {
      if (sunsetCounter >= j) sunsetColor[j] = sunsetColor[j - 1];
    }
    sunsetColor[0] = CHSV(map(sunsetPosition, 255, 0, 30, 0),
                          map(sunsetPosition, 255, 0, 180, 255),
                          map(sunsetPosition, 255, 0, SUNSET_BRIGHT, 5));
    if (sunsetCounter < 5) sunsetCounter++;

    sunsetFlag = 1;
    ONflag = false;

#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
    digitalWrite(MOSFET_PIN, MOSFET_LEVEL);
#endif

#if USE_TM1637
    DisplayFlag = 0;
#endif
    for (uint16_t i = 0; i < usedLeds; i++) {
      leds[i] = sunsetColor[i % 6];
    }
    FastLED.setBrightness(255);
    FastLED.show();
    yield();

#if USE_MP3_PLAYER
    if (mp3Enabled && sunset_sound_on && !sunset_sound_flag) {
      sunset_sound_flag = true;
      CurrentFolder = SunsetFolder;
      send_command(0x17, FEEDBACK, 0, CurrentFolder);
    }
#endif
  }
  else if (sunsetFlag == 1) {
    sunsetFlag = 0;
    sunsetCounter = 0;
#if USE_TM1637
    DisplayFlag = 0;
#endif
    for (uint8_t j = 0; j < 6; j++) sunsetColor[j] = CRGB(0, 0, 0);
    yield();

#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
    digitalWrite(MOSFET_PIN, !MOSFET_LEVEL);
#endif
#if defined(ALARM_PIN) && defined(ALARM_LEVEL)
    digitalWrite(ALARM_PIN, !ALARM_LEVEL);
#endif

#if USE_MP3_PLAYER
    if (ONflag && mp3Enabled && mp3_player_connect == 4 && eff_sound_on) {
      send_command(0x0E, 0, 0, 0);
      delay(20);
      mp3_stop = true;
      pause_on = true;
    }
    sunset_sound_flag = false;
#endif

    loadingFlag = false;
  }
#endif // USE_SUNSET

  // ========================================================================= РАСПИСАНИЕ ЛАМПЫ ==========================================================

#if USE_SCHEDULE
  static uint32_t lastScheduleCheck = 0;
  if (millis() - lastScheduleCheck >= 1000UL) {
    lastScheduleCheck = millis();

    static bool scheduleInitialized = false;
    if (!scheduleInitialized) {
      scheduleInitialized = true;
      uint16_t currentMinutes = myTime.hour() * 60 + myTime.minute();
      for (uint8_t i = 0; i < MAX_SCHEDULE_ENTRIES; i++) {
        if (schedule[i].State == 0) continue;
        if (currentMinutes >= schedule[i].Time) {
          lastExecutedMinute[i] = schedule[i].Time;
#if SCHEDULE_LOG
          SYSLOG.add("Расписание: пропуск прошедшего задания i=%u (time=%u, now=%u)", i, schedule[i].Time, currentMinutes);
#endif
        }
      }
    }

    uint16_t currentMinutes = myTime.hour() * 60 + myTime.minute();

    if (manualOverride && millis() < manualOverrideUntil) {
      goto sched_end;
    }

    if (isPrintingMessage) {
      goto sched_end;
    }

    for (uint8_t i = 0; i < MAX_SCHEDULE_ENTRIES; i++) {
      if (schedule[i].State == 0) continue;

      int16_t diff = currentMinutes - schedule[i].Time;
      if (diff < 0) continue;
      if (lastExecutedMinute[i] == schedule[i].Time) continue;

      switch (schedule[i].Action) {
        case 0:
          break;

        case 1:
          if (!ONflag) {
            ONflag = true;
            jsonWrite(configSetup, "Power", 1);
            changePower();
            sendCurrent(udpBuffer);
#if USE_MQTT
            Mqtt::instance().needToPublish = true;
#endif
            timeout_save_file_changes = millis();
            bitSet(save_file_changes, 0);
          } break;

        case 2:
          if (ONflag) {
            ONflag = false;
            jsonWrite(configSetup, "Power", 0);
            changePower();
            sendCurrent(udpBuffer);
#if USE_MQTT
            Mqtt::instance().needToPublish = true;
#endif
            timeout_save_file_changes = millis();
            bitSet(save_file_changes, 0);
          } break;

        case 3: // включить эффект
          {
            if (Favorites::instance().FavoritesRunning == 1) {
              Favorites::instance().FavoritesRunning = 0;
              Favorites::instance().nextModeAt = 0;
              jsonWrite(configSetup, "cycle_on", "0");
              timeout_save_file_changes = millis();
              bitSet(save_file_changes, 0);
#if USE_MQTT
              Mqtt::instance().needToPublish = true;
#endif
            }

            ONflag = true;
            jsonWrite(configSetup, "Power", 1);

            uint8_t newEff = eff_num_correct[schedule[i].EffectNum];

            bool effectChanged = (currentMode != newEff);
            if (effectChanged && newEff < MODE_AMOUNT) {
              currentMode = newEff;
              loadingFlag = true;

              uint8_t ui_index = 0;
              for (ui_index = 0; ui_index < MODE_AMOUNT; ui_index++) {
                if (eff_num_correct[ui_index] == currentMode) break;
              }
              jsonWrite(configSetup, "eff_sel", ui_index);

              timeout_save_file_changes = millis();
              bitSet(save_file_changes, 0);
            }

            effectsTick();
            FastLED.show();
            changePower();
            sendCurrent(udpBuffer);
#if USE_MQTT
            Mqtt::instance().needToPublish = true;
#endif
          } break;

        case 4: { // включить Часы
            nightClockEnabled = false;
            jsonWrite(configSetup, "night_clock_enabled", "0");
            timeout_save_file_changes = millis();
            bitSet(save_file_changes, 0);
            if (Favorites::instance().FavoritesRunning == 1) {
              Favorites::instance().FavoritesRunning = 0;
              Favorites::instance().nextModeAt = 0;
              jsonWrite(configSetup, "cycle_on", "0");
              timeout_save_file_changes = millis();
              bitSet(save_file_changes, 0);
#if USE_MQTT
              Mqtt::instance().needToPublish = true;
#endif
            }

            ONflag = true;
            jsonWrite(configSetup, "Power", 1);

            uint8_t newEff = eff_num_correct[EFF_CLOCK];

            if (newEff < MODE_AMOUNT) {
              currentMode = newEff;
              loadingFlag = true;

              uint8_t ui_index = 0;
              for (ui_index = 0; ui_index < MODE_AMOUNT; ui_index++) {
                if (eff_num_correct[ui_index] == currentMode) break;
              }
              jsonWrite(configSetup, "eff_sel", ui_index);

              timeout_save_file_changes = millis();
              bitSet(save_file_changes, 0);
            }

            nightModeBrightness = 0;

            if (userClockBrightness == 0) {
              userClockBrightness = jsonReadtoInt(configSetup, "brightness");
              if (userClockBrightness < 10) userClockBrightness = 30;
            }

            modes[currentMode].Brightness = userClockBrightness;
            jsonWrite(configSetup, "brightness", userClockBrightness);
            timeout_save_file_changes = millis();
            bitSet(save_file_changes, 0);

            FastLED.setBrightness(userClockBrightness);

            effectsTick();
            FastLED.show();
            changePower();
            sendCurrent(udpBuffer);
#if USE_MQTT
            Mqtt::instance().needToPublish = true;
#endif
          } break;

        case 5:
          if (Favorites::instance().FavoritesRunning == 0) {
            Favorites::instance().FavoritesRunning = 1;
            Favorites::instance().nextModeAt = 0;
            if (!ONflag) {
              ONflag = true;
              jsonWrite(configSetup, "Power", 1);
              changePower();
              sendCurrent(udpBuffer);
            }
            jsonWrite(configSetup, "cycle_on", "1");
            timeout_save_file_changes = millis();
            bitSet(save_file_changes, 0);
#if USE_MQTT
            Mqtt::instance().needToPublish = true;
#endif
          } break;

        case 6:
          if (Favorites::instance().FavoritesRunning == 1) {
            Favorites::instance().FavoritesRunning = 0;
            Favorites::instance().nextModeAt = 0;
            jsonWrite(configSetup, "cycle_on", "0");
            timeout_save_file_changes = millis();
            bitSet(save_file_changes, 0);
#if USE_MQTT
            Mqtt::instance().needToPublish = true;
#endif
          } break;

        case 7: { // включить Ночные часы
            nightClockEnabled = true;
            jsonWrite(configSetup, "night_clock_enabled", "1");
            timeout_save_file_changes = millis();
            bitSet(save_file_changes, 0);

            if (Favorites::instance().FavoritesRunning == 1) {
              Favorites::instance().FavoritesRunning = 0;
              Favorites::instance().nextModeAt = 0;
              jsonWrite(configSetup, "cycle_on", "0");
              timeout_save_file_changes = millis();
              bitSet(save_file_changes, 0);
#if USE_MQTT
              Mqtt::instance().needToPublish = true;
#endif
            }

            ONflag = true;
            jsonWrite(configSetup, "Power", 1);

            uint8_t newEff = eff_num_correct[EFF_CLOCK];

            if (newEff < MODE_AMOUNT) {
              currentMode = newEff;
              loadingFlag = true;

              uint8_t ui_index = 0;
              for (ui_index = 0; ui_index < MODE_AMOUNT; ui_index++) {
                if (eff_num_correct[ui_index] == currentMode) break;
              }
              jsonWrite(configSetup, "eff_sel", ui_index);

              timeout_save_file_changes = millis();
              bitSet(save_file_changes, 0);
            }

            if (userClockBrightness == 0) {
              userClockBrightness = jsonReadtoInt(configSetup, "brightness");
              if (userClockBrightness < 10) userClockBrightness = 30;
            }

            nightModeBrightness = nightClockBrightness;
            modes[currentMode].Brightness = nightModeBrightness;
            jsonWrite(configSetup, "brightness", nightModeBrightness);
            timeout_save_file_changes = millis();
            bitSet(save_file_changes, 0);

            FastLED.setBrightness(nightModeBrightness);

            effectsTick();
            FastLED.show();
            changePower();
            sendCurrent(udpBuffer);
#if USE_MQTT
            Mqtt::instance().needToPublish = true;
#endif
          } break;
      }

      lastExecutedMinute[i] = schedule[i].Time;
    }
  }
sched_end:;
#endif // USE_SCHEDULE

  // -----------------------------------------------------------------------
  char timeBuf[9];
  sprintf_P(timeBuf, PSTR("%02u:%02u:00"), currentHour, currentMinute);
  jsonWrite(configSetup, "time", String(timeBuf));
  Save_File_Changes();

  // ------------------------------------------------------------------------
} // void timeTick()

// ******************************************************************************************************************************************************
