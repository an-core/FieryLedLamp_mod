// **************************************************************************** PinManager.ino **********************************************************

#include "Extern.h"
#include "Prototypes.h"
// ----------------------

PinConfig pins;

static PinConfig defaultPins() {
  PinConfig p = {};
  p.ledPin = LED_PIN;
  p.clkPin = CLK_PIN;
  p.btnPin = BTN_PIN;
  p.mosfetPin = MOSFET_PIN;
#if USE_TM1637
  p.tmDio = DIO; p.tmClk = CLK;
#endif
#if USE_ST7789
  p.tftSclk = TFT_SCLK; p.tftMosi = TFT_MOSI;
  p.tftCs = TFT_CS; p.tftDc = TFT_DC;
  p.tftRst = TFT_RST; p.tftBl = TFT_BL;
#endif
#if USE_SD
  p.sdCs = SD_CS_PIN; p.sdSck = SD_SCK_PIN;
  p.sdMosi = SD_MOSI_PIN; p.sdMiso = SD_MISO_PIN;
#endif
#if USE_MP3_PLAYER
  p.mp3Tx = MP3_TX_PIN; p.mp3Rx = MP3_RX_PIN;
#endif
#if USE_RADIO
  p.i2sBclk = I2S_BCLK; p.i2sLrck = I2S_LRCK; p.i2sDout = I2S_DOUT;
#endif
#if USE_IR_RECEIVER
  p.irPin = IR_RECEIVER_PIN;
#endif
#if USE_RF_RECEIVER
  p.rfPin = RF_RECEIVER_PIN;
#endif
  return p;
}

void ensurePinsFileExists() {
  String cfg = readFile("config_pins.json", 1024);
  bool needWrite = false;
  if (cfg.isEmpty() || cfg == "Failed" || cfg == "Large" || cfg == "{}") {
    cfg = "{}";
    needWrite = true;
  }

  PJsonDoc doc(1024);
  if (deserializeJson(doc, cfg)) {
    doc.clear();
    doc.to<JsonObject>();
    needWrite = true;
  }

  PinConfig p = defaultPins();
  auto ensure = [&](const char* key, int value) {
    if (!doc.containsKey(key)) {
      doc[key] = value;
      needWrite = true;
    }
  };

  ensure("led_pin", p.ledPin);
  ensure("clk_pin", p.clkPin);
  ensure("btn_pin", p.btnPin);
  ensure("mosfet_pin", p.mosfetPin);
#if USE_TM1637
  ensure("tm1637_dio", p.tmDio);
  ensure("tm1637_clk", p.tmClk);
#endif
#if USE_ST7789
  ensure("tft_sclk", p.tftSclk);
  ensure("tft_mosi", p.tftMosi);
  ensure("tft_cs", p.tftCs);
  ensure("tft_dc", p.tftDc);
  ensure("tft_rst", p.tftRst);
  ensure("tft_bl", p.tftBl);
#endif
#if USE_SD
  ensure("sd_cs", p.sdCs);
  ensure("sd_sck", p.sdSck);
  ensure("sd_mosi", p.sdMosi);
  ensure("sd_miso", p.sdMiso);
#endif
#if USE_MP3_PLAYER
  ensure("mp3_tx", p.mp3Tx);
  ensure("mp3_rx", p.mp3Rx);
#endif
#if USE_RADIO
  ensure("i2s_bclk", p.i2sBclk);
  ensure("i2s_lrck", p.i2sLrck);
  ensure("i2s_dout", p.i2sDout);
#endif
#if USE_IR_RECEIVER
  ensure("ir_pin", p.irPin);
#endif
#if USE_RF_RECEIVER
  ensure("rf_pin", p.rfPin);
#endif

  if (needWrite) {
    String out;
    serializeJson(doc, out);
    writeFile(F("config_pins.json"), out);
  }
}

void loadPinConfig() {
  pins = defaultPins();

  String cfg = readFile("config_pins.json", 1024);
  if (cfg.isEmpty() || cfg == "Failed" || cfg == "Large" || cfg == "{}") {
    return;
  }

  auto readInt = [&](const char* key, int fallback) -> int {
    String v = jsonRead(cfg, key);
    if (v.isEmpty() || v == "null") return fallback;
    int val = v.toInt();
    return (val >= -1 && val <= 63) ? val : fallback;
  };

  pins.ledPin = readInt("led_pin", pins.ledPin);
  pins.clkPin = readInt("clk_pin", pins.clkPin);
  pins.btnPin = readInt("btn_pin", pins.btnPin);
  pins.mosfetPin = readInt("mosfet_pin", pins.mosfetPin);
#if USE_TM1637
  pins.tmDio = readInt("tm1637_dio", pins.tmDio);
  pins.tmClk = readInt("tm1637_clk", pins.tmClk);
#endif
#if USE_ST7789
  pins.tftSclk = readInt("tft_sclk", pins.tftSclk);
  pins.tftMosi = readInt("tft_mosi", pins.tftMosi);
  pins.tftCs = readInt("tft_cs", pins.tftCs);
  pins.tftDc = readInt("tft_dc", pins.tftDc);
  pins.tftRst = readInt("tft_rst", pins.tftRst);
  pins.tftBl = readInt("tft_bl", pins.tftBl);
#endif
#if USE_SD
  pins.sdCs = readInt("sd_cs", pins.sdCs);
  pins.sdSck = readInt("sd_sck", pins.sdSck);
  pins.sdMosi = readInt("sd_mosi", pins.sdMosi);
  pins.sdMiso = readInt("sd_miso", pins.sdMiso);
#endif
#if USE_MP3_PLAYER
  pins.mp3Tx = readInt("mp3_tx", pins.mp3Tx);
  pins.mp3Rx = readInt("mp3_rx", pins.mp3Rx);
#endif
#if USE_RADIO
  pins.i2sBclk = readInt("i2s_bclk", pins.i2sBclk);
  pins.i2sLrck = readInt("i2s_lrck", pins.i2sLrck);
  pins.i2sDout = readInt("i2s_dout", pins.i2sDout);
#endif
#if USE_IR_RECEIVER
  pins.irPin = readInt("ir_pin", pins.irPin);
#endif
#if USE_RF_RECEIVER
  pins.rfPin = readInt("rf_pin", pins.rfPin);
#endif
}

static bool isDangerousPin(int8_t pin) {
  if (pin < 0) return false;
#ifdef ESP32_S3_USED
  if (pin >= 22 && pin <= 48) return true;   // FastLED 3.5.0 просто не поддерживает их на S3
  if (pin >= 26 && pin <= 37) return true;   // PSRAM/flash
  if (pin == 19 || pin == 20) return true;   // USB
  if (pin == 0 || pin == 3) return true;     // strapping
#endif
  return false;
}

bool validatePinConfig() {
  int8_t arr[32];
  int n = 0;
  auto push = [&](int8_t v) {
    if (v >= 0) arr[n++] = v;
  };

  push(pins.ledPin); push(pins.clkPin);
  push(pins.btnPin); push(pins.mosfetPin);
#if USE_TM1637
  push(pins.tmDio); push(pins.tmClk);
#endif
#if USE_ST7789
  push(pins.tftSclk); push(pins.tftMosi); push(pins.tftCs);
  push(pins.tftDc); push(pins.tftRst);  push(pins.tftBl);
#endif
#if USE_SD
  push(pins.sdCs); push(pins.sdSck); push(pins.sdMosi); push(pins.sdMiso);
#endif
#if USE_MP3_PLAYER
  push(pins.mp3Tx); push(pins.mp3Rx);
#endif
#if USE_RADIO
  push(pins.i2sBclk); push(pins.i2sLrck); push(pins.i2sDout);
#endif
#if USE_IR_RECEIVER
  push(pins.irPin);
#endif
#if USE_RF_RECEIVER
  push(pins.rfPin);
#endif

  for (int i = 0; i < n; i++) {
    if (isDangerousPin(arr[i])) return false;
    for (int j = i + 1; j < n; j++) {
      if (arr[i] == arr[j]) return false;
    }
  }
  return true;
}

void resetPinsToDefault() {
  pins = defaultPins();
  ensurePinsFileExists();
  writeFile(F("config_pins.json"), "{}");
}

bool checkPinSafeMode() {
#if USE_BUTTON
  int8_t pin = -1;
  String cfg = readFile("config_pins.json", 1024);
  if (!cfg.isEmpty() && cfg != "Failed" && cfg != "Large" && cfg != "{}") {
    String v = jsonRead(cfg, "btn_pin");
    if (v.length() > 0 && v != "null") {
      int val = v.toInt();
      if (val >= 0 && val <= 48) pin = (int8_t)val;
    }
  }
  if (pin < 0) pin = BTN_PIN;

  pinMode(pin, INPUT_PULLUP);

  int activeLevel = (button_type == 1) ? HIGH : LOW;
  if (digitalRead(pin) == activeLevel) {
    uint32_t t0 = millis();
    while (digitalRead(pin) == activeLevel && millis() - t0 < 5000) delay(50);
    if (millis() - t0 >= 5000) {
      LittleFS.remove("/config_pins.json");
      return true;
    }
  }
#endif
  return false;
}

// ******************************************************************************************************************************************************
