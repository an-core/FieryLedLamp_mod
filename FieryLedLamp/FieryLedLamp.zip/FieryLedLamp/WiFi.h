// **************************************************************************** WiFi.h ******************************************************************

#pragma once
#include <WiFi.h>
#include <WiFiMulti.h>
#include <IPAddress.h>
#include "Extern.h"
#include "Prototypes.h"
// -------------------------

class Wifi {
  public:

    static Wifi& instance() {
      static Wifi instance;
      return instance;
    }

    void begin();
    void loop();
    bool isConnected() const;
    IPAddress localIP() const;
    IPAddress apIP() const;
    String getSSID() const;
    int32_t getRSSI() const;

    void setAPAlways(bool enable);

    bool isAPAlways() const {
      return apAlways;
    }

    void requestRestartAP() {
      needRestartAP = true;
    }

    String mainSsid;
    String mainPass;
    void setStaticIP(const IPAddress& ip, const IPAddress& gw, const IPAddress& subnet, const IPAddress& dns = IPAddress(8, 8, 8, 8));
    void disableStaticIP();
    void addNetwork(const char* ssid, const char* password);
    void clearNetworks();
    void clearWiFiCache();
    void setWiFiTimeout(uint32_t timeoutSec);
    void setReconnectInterval(uint32_t intervalSec);
    void setCheckInterval(uint32_t intervalSec);
    void setForcedAPTimeout(uint32_t timeoutSec);
    void setAPSettings(const String& ssid, const String& password);
    void restartAP();
    void reconnect();
    bool hasInternet();
    void forceReconnect();
    void startForcedAP();
    void stopForcedAP();
    void ensureAP();
    bool hasAnyNetworks();
    int networkCount;
    IPAddress getCurrentIP() const;

  private:
    Wifi();
    ~Wifi();
    Wifi(const Wifi&) = delete;
    Wifi& operator=(const Wifi&) = delete;

    volatile bool connected;
    volatile uint8_t fastRetryCount = 0;
    volatile bool timeEnabled = false;
    static constexpr uint32_t FAST_RETRY_INTERVAL_MS = 5000;
    static constexpr uint8_t MAX_FAST_RETRIES = 12;

    enum WiFiState {
      STA_IDLE,
      STA_CONNECTING,
      STA_CONNECTED,
      STA_FAILED
    };

    void wifiManagerTask();
    TaskHandle_t wifiManagerTaskHandle = nullptr;

    volatile bool wifiRunActive = false;
    volatile bool needRestartAP = false;
    volatile bool needSetAPAlways = false;
    volatile bool apAlwaysNewValue = false;
    volatile bool needStartForcedAP = false;
    volatile bool needStopForcedAP = false;
    volatile bool needInitSTA = false;

    void initAP();
    void initSTA();
    void manageConnection();

    WiFiMulti wifiMulti;
    WiFiState staState;

    bool apAlways;
    bool useStaticIP;
    bool forcedAPActive;
    bool apActive;
    bool internetAvailable;
    unsigned long noInternetStartTime;

    IPAddress staticIP, gateway, subnet, dns1;
    uint32_t wifiTimeoutMs;
    uint32_t reconnectIntervalMs;
    uint32_t checkIntervalMs;
    uint32_t forcedApTimeoutMs;

    unsigned long lastReconnectAttempt;
    unsigned long lastInternetCheck;
    unsigned long lastQuickCheck;
    unsigned long unconnectedSince = 0;

    IPAddress apIPAddr, apGateway, apSubnet;
    String apSSID, apPassword;

    unsigned long connectStartTime;
    bool connectInProgress;
};

// ******************************************************************************************************************************************************
