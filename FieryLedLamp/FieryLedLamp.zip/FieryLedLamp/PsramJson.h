// **************************************************************************** PsramJson.h **************************************************************
// PSRAM-аллокатор для ArduinoJson 6.19.4
// ---------------------------------------
#pragma once
#include <Arduino.h>
#include <esp_heap_caps.h>
#include <ArduinoJson.hpp>

struct SpiRamAllocator {
  void* allocate(size_t size) {
    void* p = heap_caps_malloc(size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    // внутренняя RAM (если PSRAM не инициализирована или забита)
    if (!p) p = heap_caps_malloc(size, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    return p;
  }

  void deallocate(void* p) {
    // для любого heap (PSRAM + internal)
    if (p) heap_caps_free(p);
  }

  void* reallocate(void* p, size_t n) {
    void* np = heap_caps_realloc(p, n, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!np) np = heap_caps_realloc(p, n, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    return np;
  }
};

using PJsonDoc = ArduinoJson::BasicJsonDocument<SpiRamAllocator>;

// *******************************************************************************************************************************************************
