// ********************************************************************** user_settings.ino ****************************************************************
#include "Constants.h"
#include "Extern.h"
#include "Prototypes.h"
#include "Time.h"
#include "IRManager.h"
#include "Types.h"
// ---------------------------

// ==================================================================== РЕГИСТРАЦИЯ МАРШРУТОВ =========================================================
void User_settings() {

  // ----------------------------------------------------------------------------------------------------------------------------------------------------
  HTTP.on("/debug_pins", HTTP_GET, []() {
    String out = "{";

    // 1) Что в памяти
    out += "\"mem_led\":"    + String(pins.ledPin);
    out += ",\"mem_clk\":"   + String(pins.clkPin);
    out += ",\"mem_btn\":"   + String(pins.btnPin);
    out += ",\"mem_mosfet\":" + String(pins.mosfetPin);

    // 2) Что в файле
    String cfg = readFile("config_pins.json", 1024);
    String cfgEscaped = cfg;
    cfgEscaped.replace("\\", "\\\\");
    cfgEscaped.replace("\"", "\\\"");
    out += ",\"file_exists\":" + String(cfg.length() > 0 && cfg != "Failed" ? "true" : "false");
    out += ",\"file_raw\":\"" + cfgEscaped + "\"";

    // 3) Валидация
    out += ",\"valid\":" + String(validatePinConfig() ? "true" : "false");

    out += "}";
    HTTP.send(200, "application/json", out);
  });

  HTTP.on("/get_settings", HTTP_GET, []() {
    if (configSetup.length() == 0) {
      HTTP.send(200, "application/json", "{}");
      return;
    }
    PJsonDoc doc(4096);
    if (deserializeJson(doc, configSetup)) {
      HTTP.send(500, "text/plain", "config error");
      return;
    }
    String output;
    output.reserve(measureJson(doc) + 1);
    serializeJson(doc, output);
    HTTP.send(200, "application/json", output);
  });

  HTTP.on("/rename", HTTP_POST, []() {
    if (!requireFileManagerAuth(true)) return;

    if (!HTTP.hasArg("old") || !HTTP.hasArg("new")) {
      HTTP.send(400, "text/plain", "Missing old or new path");
      return;
    }

    String oldPath = HTTP.arg("old");
    String newPath = HTTP.arg("new");
    oldPath.trim();
    newPath.trim();

    if (oldPath.length() == 0 || newPath.length() == 0) {
      HTTP.send(400, "text/plain", "Empty path");
      return;
    }

    if (!oldPath.startsWith("/")) oldPath = "/" + oldPath;
    if (!newPath.startsWith("/")) newPath = "/" + newPath;

    if (isDangerousPath(oldPath) || isDangerousPath(newPath)) {
      HTTP.send(400, "text/plain", "Invalid path");
      return;
    }

    bool isDir = oldPath.endsWith("/");
    String cleanOld = isDir ? oldPath.substring(0, oldPath.length() - 1) : oldPath;
    String cleanNew = newPath.endsWith("/") ? newPath.substring(0, newPath.length() - 1) : newPath;

    // рантайм-выбор FS
    auto fsExists = [](const String & p) -> bool {
      return (sdType == 1) ? LittleFS.exists(p) : SD.exists(p);
    };
    auto fsRename = [](const String & a, const String & b) -> bool {
      return (sdType == 1) ? LittleFS.rename(a, b) : SD.rename(a, b);
    };
    auto fsOpen = [](const String & p) -> File {
      return (sdType == 1) ? LittleFS.open(p) : SD.open(p);
    };

    if (!fsExists(cleanOld)) {
      HTTP.send(404, "text/plain", "Source not found");
      return;
    }
    if (fsExists(cleanNew)) {
      HTTP.send(409, "text/plain", "Destination already exists");
      return;
    }

    bool ok = false;

    if (isDir) {
      File f = fsOpen(cleanOld);
      bool oldIsDir = f && f.isDirectory();
      if (f) f.close();

      if (oldIsDir) {
        if (copyDirRecursive(cleanOld, cleanNew)) {
          ok = removeRecursive(cleanOld);
        } else {
          ok = false;
        }
      } else {
        ok = fsRename(cleanOld, cleanNew);
      }
    } else {
      ok = fsRename(cleanOld, cleanNew);
    }

    if (ok) {
      HTTP.send(200, "text/plain", "Renamed");
    } else {
      HTTP.send(500, "text/plain", "Rename failed");
    }
  });

  // ----------------------------------------------------------------------------------------------------------------------------------------------------

  HTTP.on("/PassOn", handle_PassOn);                         // Пароль на страницу настроек
  HTTP.on("/Power", handle_Power);                           // Управление питанием
  HTTP.on("/index", handle_index);                           // Переключение на финальную страницу
  HTTP.on("/lang", handle_lang);                             // Язык

  // ------------------------------------------------------------ РЕГУЛИРОВКА НАСТРОЕК ЭФФЕКТОВ ---------------------------------------------------------

  HTTP.on("/all_br", handle_all_br);                         // Общая яркость всех эффектов
  HTTP.on("/br", handle_br);                                 // Яркость эффекта
  HTTP.on("/brm", handle_brm);                               // Уменьшение яркости (-1)
  HTTP.on("/brp", handle_brp);                               // Увеличение яркости (+1)
  HTTP.on("/sp", handle_sp);                                 // Скорость эффекта
  HTTP.on("/spm", handle_spm);                               // Уменьшение скорости (-1)
  HTTP.on("/spp", handle_spp);                               // Увеличение скорости (+1)
  HTTP.on("/sc", handle_sc);                                 // Масштаб / Цвет эффекта
  HTTP.on("/scm", handle_scm);                               // Уменьшение масштаба (-1)
  HTTP.on("/scp", handle_scp);                               // Увеличение масштаба (+1)
  HTTP.on("/auto_bri", handle_auto_bri);                     // Автояркость по времени суток
  HTTP.on("/eff_sel", handle_eff_sel);                       // Выбор эффекта из списка
  HTTP.on("/eff", handle_eff);                               // Следующий / Предыдущий эффект
  HTTP.on("/eff_all", handle_eff_all);                       // Выбрать все
  HTTP.on("/eff_clr", handle_eff_clr);                       // Сбросить выбор
  HTTP.on("/time_eff", handle_time_eff);                     // Время переключения
  HTTP.on("/eff_save", handle_eff_save);                     // Сохранить настройки эффектов в файл
  HTTP.on("/eff_read", handle_eff_read);                     // Загрузить настройки из файла
  HTTP.on("/def", handle_def);                               // Настройки текущего эффекта по умолчанию
  HTTP.on("/eff_reset", handle_eff_reset);                   // Сброс настроек всех эффектов по умолчанию
  HTTP.on("/favorit", handle_favorit);                       // Включить / Выключить переход кнопкой только по эффектам из избранного
  HTTP.on("/random_on", handle_random);                      // Случайные настройки эффектов в режиме цикл
  HTTP.on("/effect_always", handle_effect_always);           // Не возобновлять эффекты после обесточивания лампы

  // -------------------------------------------------------------------------- ЦИКЛ --------------------------------------------------------------------

  HTTP.on("/cycle_on", handle_cycle_on);                     // Вкл/Выкл режим Цикл
  HTTP.on("/rnd_cycle", handle_rnd_cycle);                   // Перемешивать или по порядку
  HTTP.on("/cycle_always", handle_cycle_always);             // Запускать цикл после включения
  HTTP.on("/cycle_set", handle_cycle_set);                   // Выбор эффектов для цикла

  // ------------------------------------------------------- ВКЛЮЧЕНИЕ/ВЫКЛЮЧЕНИЕ МОДУЛЕЙ В ВЭБ-ИНТЕРФЕЙС -----------------------------------------------

  HTTP.on("/button_enable", handle_button_enable);
  HTTP.on("/ir_enable", handle_ir_enable);
  HTTP.on("/rf_enable", handle_rf_enable);
  HTTP.on("/tm1637_enable", handle_tm1637_enable);
  HTTP.on("/st7789_enable", handle_st7789_enable);
  HTTP.on("/mp3_enable", handle_mp3_enable);
  HTTP.on("/sd_enable", handle_sd_enable);
  HTTP.on("/sd_type", handle_sd_type);

  HTTP.on("/get_module_states", HTTP_GET, []() {
    PJsonDoc doc(2048);
    doc["button_enable"] = buttonEnabled ? "1" : "0";
#if USE_BUTTON
    doc["button_type"] = String(button_type);
#endif
    doc["ir_enable"] = irEnabled ? "1" : "0";
    doc["rf_enable"] = rfEnabled ? "1" : "0";
    doc["tm1637_enable"] = tm1637Enabled ? "1" : "0";
    doc["st7789_enable"] = st7789Enabled ? "1" : "0";
    doc["mp3_enable"] = mp3Enabled ? "1" : "0";
    doc["radio_enable"] = radioEnabled ? "1" : "0";
    doc["sd_enable"] = sdEnabled ? "1" : "0";
    doc["sd_type"] = String(sdType);
#if MULTI_MATRIX
    doc["multi_matrix_enable"] = multiMatrixEnabled ? "1" : "0";
    doc["multi_matrix"] = "1";
#else
    doc["multi_matrix_enable"] = "0";
    doc["multi_matrix"] = "0";
#endif
#if LED_PANEL
    doc["night_clock_enabled"] = nightClockEnabled ? "1" : "0";
#endif

    JsonObject ft = doc.createNestedObject("features");
    ft["mqtt"] = !!USE_MQTT;
    ft["mp3"] = !!USE_MP3_PLAYER;
    ft["sound"] = !!USE_MP3_PLAYER;
    ft["radio"] = !!USE_RADIO;
    ft["sd"] = !!USE_SD;
    ft["ota"] = !!USE_OTA;
    ft["update_check"] = !!USE_UPDATE_CHECK;
    ft["tm1637"] = !!USE_TM1637;
    ft["st7789"] = !!USE_ST7789;
    ft["button"] = !!USE_BUTTON;
    ft["ir"] = !!USE_IR_RECEIVER;
    ft["rf"] = !!USE_RF_RECEIVER;
    ft["weather"] = !!USE_WEATHER;
    ft["multilamp"] = !!USE_MULTILAMP;
    ft["status_modal"] = !!STATUS_DEVICE;
    ft["software_modal"] = !!SOFT_INFO;
    ft["memory_info"] = !!USE_MEMORY_INFO;
    ft["led_panel"] = !!LED_PANEL;
    ft["syslog"] = !!DEBUG_ENABLED;
    ft["logs"]   = !!DEBUG_ENABLED;
#if defined(ESP32S3) || defined(CONFIG_IDF_TARGET_ESP32S3) || defined(ARDUINO_ESP32S3_DEV)
    ft["hardware_menu"] = true;
#else
    ft["hardware_menu"] = false;
#endif

    String response;
    response.reserve(measureJson(doc) + 1);
    serializeJson(doc, response);
    HTTP.send(200, "application/json", response);
  });

  // ----------------------------------------------------------------------------------------------------------------------------------------------------

#if USE_BUTTON
  HTTP.on("/button_type", handle_button_type);         // Сенсорная / механическая кнопка
  HTTP.on("/save_btn_clicks", handle_save_btn_clicks); // Настройки действий по количеству нажатий на кнопку
#endif

#if USE_SUNSET
  HTTP.on("/sunset", handle_sunset); // Закат
  HTTP.on("/config_sunset.json", HTTP_GET, []() {
    HTTP.send(200, "application/json", configSunset);
  });
#endif

#if USE_DAWN
  HTTP.on("/alarm", handle_alarm); // Рассвет
  HTTP.on("/config_alarm.json", HTTP_GET, []() {
    HTTP.send(200, "application/json", configAlarm);
  });
#endif

#if USE_SCHEDULE
  HTTP.on("/schedule", handle_schedule); // Расписание
  HTTP.on("/config_schedule.json", HTTP_GET, []() {
    HTTP.send(200, "application/json", configSchedule);
  });
#endif

  // -------------------------------------------------------------- УПРАВЛЕНИЕ НЕСКОЛЬКИМИ ЛАМПАМИ ------------------------------------------------------

#if USE_MULTILAMP
  HTTP.on("/multi", HTTP_GET, handle_multiple_lamp);
  HTTP.on("/config_multilamp.json", HTTP_GET, []() {
    HTTP.send(200, "application/json", configMultilamp);
  });
#endif

  HTTP.on("/setup_multilamp", HTTP_GET, []() {
#ifndef USE_MULTILAMP
    HTTP.send(404, "text/plain", "Управление несколькими лампами отключено в прошивке");
#else
    handleFileRead("/setup_multilamp.htm");
#endif
  });

  // --------------------------------------------------------------------- ДИСПЛЕЙ ST7789 ----------------------------------------------------------------

#if USE_ST7789
  HTTP.on("/tft_clock_color", handle_tft_clock_color);
  HTTP.on("/tft_weather_color", handle_tft_weather_color);
  HTTP.on("/tft_ticker_on", handle_tft_ticker_on);
  HTTP.on("/tft_ticker_color", handle_tft_ticker_color);
  HTTP.on("/tft_ticker_speed", handle_tft_ticker_speed);
  HTTP.on("/tft_ticker_period", handle_tft_ticker_period);
  HTTP.on("/tft_ticker_text", handle_tft_ticker_text);
  HTTP.on("/tft_brightness", handle_tft_brightness);
  HTTP.on("/tft_auto_brightness", handle_tft_auto_brightness);
  HTTP.on("/tft_date_color", HTTP_GET, handle_tft_date_color);
#endif

  // --------------------------------------------------------------------- ДИСПЛЕЙ TM1637 ----------------------------------------------------------------

#if USE_TM1637
  HTTP.on("/tm1637_brightness", handle_tm1637_brightness);
  HTTP.on("/tm1637_auto_brightness", handle_tm1637_auto_brightness);
#endif

  // -------------------------------------------------------------------------- ВРЕМЯ -------------------------------------------------------------------

  HTTP.on("/save_brightness", handle_save_brightness);
  HTTP.on("/night_time", handle_night_time);
  HTTP.on("/print_time", handle_print_time);
  HTTP.on("/clock_vert", handle_clock_vert);
  HTTP.on("/clock_leading_zero", handle_clock_leading_zero);
  HTTP.on("/auto_move_clock", handle_auto_move_clock);
  HTTP.on("/night_clock_enabled", handle_night_clock_enabled);
  HTTP.on("/night_clock_brightness", handle_night_clock_brightness);

  HTTP.on("/get_time", HTTP_GET, []() {
    PJsonDoc doc(256);

    if (!myTime.isTimeSet()) {
      doc["time"] = "--:--:--";
      doc["city"] = "";
      doc["date"] = "";
      String out;
      serializeJson(doc, out);
      HTTP.send(200, "application/json", out);
      return;
    }

    time_t now_time = myTime.now();
    struct tm tm;
    localtime_r(&now_time, &tm);
    char buf[9];
    snprintf(buf, sizeof(buf), "%02d:%02d:%02d", tm.tm_hour, tm.tm_min, tm.tm_sec);

    char dateBuf[20];
    strftime(dateBuf, sizeof(dateBuf), "%d %B %Y", &tm);
    String dateStr = String(dateBuf);

    dateStr.replace("January", "января");
    dateStr.replace("February", "февраля");
    dateStr.replace("March", "марта");
    dateStr.replace("April", "апреля");
    dateStr.replace("May", "мая");
    dateStr.replace("June", "июня");
    dateStr.replace("July", "июля");
    dateStr.replace("August", "августа");
    dateStr.replace("September", "сентября");
    dateStr.replace("October", "октября");
    dateStr.replace("November", "ноября");
    dateStr.replace("December", "декабря");

    String cityName = "";
    PJsonDoc cfg(JSON_BUFFER_SIZE);
    bool cfgOk = !deserializeJson(cfg, configSetup);
    String tz = cfgOk ? String((const char*)(cfg["tz"] | "")) : String("");

    if (cfgOk && ((int)(cfg["geo_tz_enabled"] | 0)) == 1) {
      String geoName = cfg["geo_tz_name"] | "";
      if (geoName.length() > 0) cityName = geoName;
    }

    if (cityName.length() == 0) {
      if (tz == "MSK-3") cityName = "Москва";
      else if (tz == "MSK-3_SPB") cityName = "Санкт-Петербург";
      else if (tz == "MSK-3_RND") cityName = "Ростов-на-Дону";
      else if (tz == "MSK-3_NN") cityName = "Нижний Новгород";
      else if (tz == "MSK-3_Kazan") cityName = "Казань";
      else if (tz == "MSK-3_Voronezh") cityName = "Воронеж";
      else if (tz == "MSK-3_Krasnodar") cityName = "Краснодар";
      else if (tz == "MSK-3_Sochi") cityName = "Сочи";
      else if (tz == "MSK-3_Kirov") cityName = "Киров";
      else if (tz == "MSK-3_Tula") cityName = "Тула";
      else if (tz == "MSK-3_Tver") cityName = "Тверь";
      else if (tz == "MSK-3_Ryazan") cityName = "Рязань";
      else if (tz == "MSK-3_Yaroslavl") cityName = "Ярославль";
      else if (tz == "MSK-3_Vladimir") cityName = "Владимир";
      else if (tz == "MSK-3_Bryansk") cityName = "Брянск";
      else if (tz == "MSK-3_Belgorod") cityName = "Белгород";
      else if (tz == "MSK-3_Kursk") cityName = "Курск";
      else if (tz == "MSK-3_Lipetsk") cityName = "Липецк";
      else if (tz == "MSK-3_Orel") cityName = "Орёл";
      else if (tz == "MSK-3_Smolensk") cityName = "Смоленск";
      else if (tz == "MSK-3_Tambov") cityName = "Тамбов";
      else if (tz == "MSK-3_Ivanovo") cityName = "Иваново";
      else if (tz == "MSK-3_Kostroma") cityName = "Кострома";
      else if (tz == "MSK-3_Arkhangelsk") cityName = "Архангельск";
      else if (tz == "MSK-3_Vologda") cityName = "Вологда";
      else if (tz == "MSK-3_Murmansk") cityName = "Мурманск";
      else if (tz == "MSK-3_VelikyNovgorod") cityName = "Великий Новгород";
      else if (tz == "MSK-3_Pskov") cityName = "Псков";
      else if (tz == "MSK-3_Makhachkala") cityName = "Махачкала";
      else if (tz == "MSK-3_Nalchik") cityName = "Нальчик";
      else if (tz == "MSK-3_Vladikavkaz") cityName = "Владикавказ";
      else if (tz == "MSK-3_Stavropol") cityName = "Ставрополь";
      else if (tz == "MSK-3_Volgograd") cityName = "Волгоград";
      else if (tz == "MSK-3_YoshkarOla") cityName = "Йошкар-Ола";
      else if (tz == "MSK-3_Saransk") cityName = "Саранск";
      else if (tz == "MSK-3_Cheboksary") cityName = "Чебоксары";
      else if (tz == "MSK-3_Orenburg") cityName = "Оренбург";
      else if (tz == "MSK-3_Penza") cityName = "Пенза";
      else if (tz == "MSK-3_Ulyanovsk") cityName = "Ульяновск";
      else if (tz == "MSK-3_Simferopol") cityName = "Симферополь";
      else if (tz == "MSK-3_Minsk") cityName = "Минск";

      else if (tz == "MSK-3_Zelenodolsk") cityName = "Зеленодольск";
      else if (tz == "MSK-3_Podolsk") cityName = "Подольск";
      else if (tz == "MSK-3_Lubertsy") cityName = "Люберцы";
      else if (tz == "MSK-3_Mytishchi") cityName = "Мытищи";
      else if (tz == "MSK-3_Balashikha") cityName = "Балашиха";
      else if (tz == "MSK-3_Khimki") cityName = "Химки";
      else if (tz == "MSK-3_Korolev") cityName = "Королёв";
      else if (tz == "MSK-3_Elektrostal") cityName = "Электросталь";
      else if (tz == "MSK-3_Kolomna") cityName = "Коломна";
      else if (tz == "MSK-3_Odintsovo") cityName = "Одинцово";
      else if (tz == "MSK-3_Domodedovo") cityName = "Домодедово";
      else if (tz == "MSK-3_SergievPosad") cityName = "Сергиев Посад";
      else if (tz == "MSK-3_Pushkino") cityName = "Пушкино";
      else if (tz == "MSK-3_Zhukovsky") cityName = "Жуковский";
      else if (tz == "MSK-3_Reutov") cityName = "Реутов";
      else if (tz == "MSK-3_Dolgoprudny") cityName = "Долгопрудный";
      else if (tz == "MSK-3_Shchelkovo") cityName = "Щёлково";
      else if (tz == "MSK-3_OrekhovoZuevo") cityName = "Орехово-Зуево";
      else if (tz == "MSK-3_Serpukhov") cityName = "Серпухов";
      else if (tz == "MSK-3_Voskresensk") cityName = "Воскресенск";
      else if (tz == "MSK-3_Lobnya") cityName = "Лобня";
      else if (tz == "MSK-3_Ivanteevka") cityName = "Ивантеевка";
      else if (tz == "MSK-3_Dubna") cityName = "Дубна";
      else if (tz == "MSK-3_Egoryevsk") cityName = "Егорьевск";
      else if (tz == "MSK-3_Chekhov") cityName = "Чехов";
      else if (tz == "MSK-3_Stupino") cityName = "Ступино";
      else if (tz == "MSK-3_PavlovskyPosad") cityName = "Павловский Посад";
      else if (tz == "MSK-3_NaroFominsk") cityName = "Наро-Фоминск";
      else if (tz == "MSK-3_Klin") cityName = "Клин";
      else if (tz == "MSK-3_Krasnogorsk") cityName = "Красногорск";

      else if (tz == "EET-2") cityName = "Калининград";

      else if (tz == "SAMT-4") cityName = "Самара";
      else if (tz == "SAMT-4_Astrakhan") cityName = "Астрахань";
      else if (tz == "SAMT-4_Saratov") cityName = "Саратов";
      else if (tz == "SAMT-4_Tolyatti") cityName = "Тольятти";

      else if (tz == "YEKT-5") cityName = "Екатеринбург";
      else if (tz == "YEKT-5_Chelyabinsk") cityName = "Челябинск";
      else if (tz == "YEKT-5_Perm") cityName = "Пермь";
      else if (tz == "YEKT-5_Ufa") cityName = "Уфа";
      else if (tz == "YEKT-5_Orenburg") cityName = "Оренбург";
      else if (tz == "YEKT-5_Kurgan") cityName = "Курган";
      else if (tz == "YEKT-5_Tyumen") cityName = "Тюмень";

      else if (tz == "OMST-6") cityName = "Омск";

      else if (tz == "KRAT-7") cityName = "Красноярск";
      else if (tz == "KRAT-7_Novosibirsk") cityName = "Новосибирск";
      else if (tz == "KRAT-7_Tomsk") cityName = "Томск";
      else if (tz == "KRAT-7_Barnaul") cityName = "Барнаул";
      else if (tz == "KRAT-7_Kemerovo") cityName = "Кемерово";
      else if (tz == "KRAT-7_Novokuznetsk") cityName = "Новокузнецк";
      else if (tz == "KRAT-7_Sayanogorsk") cityName = "Саяногорск";

      else if (tz == "IRKT-8") cityName = "Иркутск";
      else if (tz == "IRKT-8_UlanUde") cityName = "Улан-Удэ";

      else if (tz == "YAKT-9") cityName = "Якутск";
      else if (tz == "YAKT-9_Chita") cityName = "Чита";
      else if (tz == "YAKT-9_Blagoveshchensk") cityName = "Благовещенск";
      else if (tz == "YAKT-9_Khandyga") cityName = "Хандыга";

      else if (tz == "VLAT-10") cityName = "Владивосток";
      else if (tz == "VLAT-10_Khabarovsk") cityName = "Хабаровск";
      else if (tz == "VLAT-10_Ussuriysk") cityName = "Уссурийск";
      else if (tz == "VLAT-10_Komsomolsk") cityName = "Комсомольск-на-Амуре";
      else if (tz == "VLAT-10_UstNera") cityName = "Усть-Нера";

      else if (tz == "MAGT-11") cityName = "Магадан";
      else if (tz == "MAGT-11_Sakhalin") cityName = "Сахалин";
      else if (tz == "MAGT-11_YuzhnoSakhalinsk") cityName = "Южно-Сахалинск";
      else if (tz == "MAGT-11_Srednekolymsk") cityName = "Среднеколымск";

      else if (tz == "PETT-12") cityName = "Камчатка";
      else if (tz == "PETT-12_Anadyr") cityName = "Анадырь";
      else if (tz == "PETT-12_Petropavlovsk") cityName = "Петропавловск-Камчатский";

      else if (tz == "ALMT-5") cityName = "Алматы";
      else if (tz == "ALMT-5_Astana") cityName = "Астана";
      else if (tz == "ALMT-5_Karaganda") cityName = "Караганда";
      else if (tz == "ALMT-5_Shymkent") cityName = "Шымкент";
      else if (tz == "ALMT-5_Pavlodar") cityName = "Павлодар";
      else if (tz == "ALMT-5_Prz") cityName = "Приозёрск";
      else if (tz == "ALMT-5_Kostanay") cityName = "Костанай";
      else if (tz == "ALMT-5_Aktau") cityName = "Актау";
      else if (tz == "ALMT-5_Aktobe") cityName = "Актобе";

      // IANA-форматы
      else if (tz == "Europe/Moscow") cityName = "Москва";
      else if (tz == "Europe/Volgograd") cityName = "Волгоград";
      else if (tz == "Europe/Simferopol") cityName = "Симферополь";
      else if (tz == "Europe/Minsk") cityName = "Минск";
      else if (tz == "Europe/Kirov") cityName = "Киров";
      else if (tz == "Europe/Kaliningrad") cityName = "Калининград";
      else if (tz == "Europe/Samara") cityName = "Самара";
      else if (tz == "Europe/Ulyanovsk") cityName = "Ульяновск";
      else if (tz == "Europe/Astrakhan") cityName = "Астрахань";
      else if (tz == "Europe/Saratov") cityName = "Саратов";
      else if (tz == "Asia/Yekaterinburg") cityName = "Екатеринбург";
      else if (tz == "Asia/Orenburg") cityName = "Оренбург";
      else if (tz == "Asia/Omsk") cityName = "Омск";
      else if (tz == "Asia/Novosibirsk") cityName = "Новосибирск";
      else if (tz == "Asia/Barnaul") cityName = "Барнаул";
      else if (tz == "Asia/Krasnoyarsk") cityName = "Красноярск";
      else if (tz == "Asia/Tomsk") cityName = "Томск";
      else if (tz == "Asia/Irkutsk") cityName = "Иркутск";
      else if (tz == "Asia/Yakutsk") cityName = "Якутск";
      else if (tz == "Asia/Khandyga") cityName = "Хандыга";
      else if (tz == "Asia/Vladivostok") cityName = "Владивосток";
      else if (tz == "Asia/Ust-Nera") cityName = "Усть-Нера";
      else if (tz == "Asia/Magadan") cityName = "Магадан";
      else if (tz == "Asia/Srednekolymsk") cityName = "Среднеколымск";
      else if (tz == "Asia/Kamchatka") cityName = "Камчатка";
      else if (tz == "Asia/Anadyr") cityName = "Анадырь";
      else if (tz == "Asia/Almaty") cityName = "Алматы";
      else if (tz == "Asia/Qostanay") cityName = "Костанай";
      else if (tz == "Asia/Aqtau") cityName = "Актау";
      else if (tz == "Asia/Aqtobe") cityName = "Актобе";
      else if (tz == "Asia/Chita") cityName = "Чита";
      else if (tz == "Asia/Sakhalin") cityName = "Сахалин";
      else if (tz == "Asia/Blagoveshchensk") cityName = "Благовещенск";
      else if (tz == "Asia/Kemerovo") cityName = "Кемерово";
      else if (tz == "Asia/Kurgan") cityName = "Курган";
      else if (tz == "Asia/Perm") cityName = "Пермь";
      else if (tz == "Asia/Chelyabinsk") cityName = "Челябинск";
    }

    doc["time"] = String(buf);
    doc["city"] = cityName;
    doc["date"] = dateStr;

    String out;
    serializeJson(doc, out);
    HTTP.send(200, "application/json", out);
  });

  // сохранение времени
  HTTP.on("/save_time", HTTP_GET, []() {
    PJsonDoc cfg(JSON_BUFFER_SIZE);
    if (configSetup.length() == 0 || deserializeJson(cfg, configSetup)) {
      cfg.clear();
      cfg.to<JsonObject>();
    }

    bool changed = false;

    // Часовой пояс
    String tz = HTTP.arg("tz");
    tz.trim();
    if (tz.length() > 0) {
      String currentTz = cfg["tz"].as<String>();
      currentTz.trim();

      if (currentTz != tz) {
        bool isPreset = false;
        const char* presets[] = {"MSK-3", "SAMT-4", "YEKT-5", "OMST-6", "KRAT-7", "IRKT-8", "YAKT-9", "VLAT-10", "MAGT-11", "PETT-12", "ALMT-5"};
        for (int i = 0; i < 11; i++) {
          if (tz == presets[i]) {
            isPreset = true;
            break;
          }
        }

        if (isPreset) {
          cfg["tz"] = tz;
          cfg["tz_custom"] = tz;
          cfg["tz_is_custom"] = "0";
          cfg["use_auto_tz"] = "0";
        } else {
          String posixTz = ianaToPosix(tz);
          if (posixTz != tz || isValidPosixFormat(tz)) {
            cfg["tz"] = (posixTz != tz) ? posixTz : tz;
            cfg["tz_custom"] = tz;
            cfg["tz_is_custom"] = "1";
            cfg["use_auto_tz"] = "0";
          } else {
            HTTP.send(400, "text/plain", "INVALID_TZ");
            return;
          }
        }
        changed = true;
      }
    }

    // NTP-серверы
    String ntp1_arg = HTTP.arg("ntp1"); ntp1_arg.trim();
    String ntp2_arg = HTTP.arg("ntp2"); ntp2_arg.trim();
    String ntp3_arg = HTTP.arg("ntp3"); ntp3_arg.trim();

    if (ntp1_arg.length() > 0 && cfg["ntp1"].as<String>() != ntp1_arg) {
      cfg["ntp1"] = ntp1_arg;
      changed = true;
    }
    if (ntp2_arg.length() > 0 && cfg["ntp2"].as<String>() != ntp2_arg) {
      cfg["ntp2"] = ntp2_arg;
      changed = true;
    }
    if (ntp3_arg.length() > 0 && cfg["ntp3"].as<String>() != ntp3_arg) {
      cfg["ntp3"] = ntp3_arg;
      changed = true;
    }

    if (!changed) {
      HTTP.send(200, "text/plain", "NO_CHANGE");
      return;
    }

    configSetup = "";
    configSetup.reserve(measureJson(cfg) + 1);
    serializeJson(cfg, configSetup);
    saveConfig();

    // если tz пустой то будет MSK-3
    String current_tz = cfg["tz"].as<String>();
    current_tz.trim();
    if (current_tz.length() == 0) {
      current_tz = "MSK-3";
      cfg["tz"] = current_tz;

      configSetup = "";
      configSetup.reserve(measureJson(cfg) + 1);
      serializeJson(cfg, configSetup);
      saveConfig();
    }

    String new_ntp1 = cfg["ntp1"].as<String>();
    if (new_ntp1.length() == 0) new_ntp1 = "ntp3.vniiftri.ru";

    String new_ntp2 = cfg["ntp2"].as<String>();
    if (new_ntp2.length() == 0) new_ntp2 = "ru.pool.ntp.org";

    String new_ntp3 = cfg["ntp3"].as<String>();

    NTP_SERVER1 = new_ntp1;
    NTP_SERVER2 = new_ntp2;

    myTime.ntpodhcp(false);

    if (new_ntp3.length() > 0) {
      myTime.setcustomntp(new_ntp3.c_str());
    }

    myTime.tzsetup(current_tz.c_str());

    HTTP.send(200, "text/plain", "OK");
  });

  HTTP.on("/force_time_sync", HTTP_GET, []() {
    if (Wifi::instance().isConnected()) {
      myTime.forcesync();
      HTTP.send(200, "text/plain", "SYNC_STARTED");
    } else {
      HTTP.send(503, "text/plain", "Нет подключения к интернету.\nИспользуйте ручную установку времени.");
    }
  });

  // автоопределение часового пояса
  HTTP.on("/auto_tz", HTTP_GET, []() {
    jsonWrite(configSetup, "tz", "");
    jsonWrite(configSetup, "use_auto_tz", "1");
    saveConfig();
    g_flagAutoTz = true;
    HTTP.send(200, "text/plain", "AUTO_OK");
  });

  // установка времени с клиента
  HTTP.on("/set_client_time", HTTP_GET, []() {
    bool timeChanged = false;
    bool tzChanged = false;

    if (HTTP.hasArg("time")) {
      unsigned long clientTime = HTTP.arg("time").toInt();
      if (clientTime > 946684800UL) {
        myTime.disable();
        struct timeval tv = { (time_t)clientTime, 0 };
        settimeofday(&tv, nullptr);
        timeChanged = true;
      }
    }

    if (HTTP.hasArg("tz")) {
      String tzStr = urldecode(HTTP.arg("tz"));
      tzStr.trim();

      if (tzStr.length() > 0 && tzStr != "undefined" && tzStr != "null") {
        String posixTz = ianaToPosix(tzStr);
        if (posixTz.length() == 0) posixTz = tzStr;

        if (isValidPosixFormat(posixTz) || posixTz != tzStr) {
          jsonWrite(configSetup, "tz", posixTz);
          jsonWrite(configSetup, "tz_custom", tzStr);
          jsonWrite(configSetup, "tz_is_custom", "1");
          jsonWrite(configSetup, "use_auto_tz", "0");
          saveConfig();
          myTime.tzsetup(posixTz.c_str());
          tzChanged = true;
        }
      }
    }

    if (!tzChanged) {
      String currentTz = jsonRead(configSetup, "tz");
      if (currentTz.length() == 0 || currentTz == "auto") {
        jsonWrite(configSetup, "tz", "MSK-3");
        jsonWrite(configSetup, "use_auto_tz", "0");
        saveConfig();
        myTime.tzsetup("MSK-3");
      }
    }

    myTime.enable();
    if (!timeChanged && !tzChanged) {
      HTTP.send(400, "text/plain", "Missing parameters");
      return;
    }

    HTTP.send(200, "text/plain", "OK_TIME_SET");
  });

  // установка часового пояса
  HTTP.on("/tz", HTTP_GET, []() {
    if (!HTTP.hasArg("tz")) {
      HTTP.send(400, "text/plain", "Missing tz parameter");
      return;
    }

    String newTz = HTTP.arg("tz");
    newTz.trim();

    if (newTz.length() == 0 || newTz == "auto") {
      jsonWrite(configSetup, "tz", "");
      jsonWrite(configSetup, "use_auto_tz", "1");
      saveConfig();
      g_flagAutoTz = true;
      HTTP.send(200, "text/plain", "OK_TZ_SET");
      return;
    }

    bool isPreset = false;
    const char* presets[] = {"MSK-3", "SAMT-4", "YEKT-5", "OMST-6", "KRAT-7", "IRKT-8", "YAKT-9", "VLAT-10", "MAGT-11", "PETT-12", "ALMT-5"};
    for (int i = 0; i < 11; i++) {
      if (newTz == presets[i]) {
        isPreset = true;
        break;
      }
    }

    String posixTz = newTz;
    if (!isPreset) {
      posixTz = ianaToPosix(newTz);
      if (posixTz == newTz && !isValidPosixFormat(newTz)) {
        HTTP.send(400, "text/plain", "INVALID_TZ_FORMAT");
        return;
      }
    }

    jsonWrite(configSetup, "tz", posixTz);
    jsonWrite(configSetup, "tz_custom", newTz);
    jsonWrite(configSetup, "tz_is_custom", isPreset ? "0" : "1");
    jsonWrite(configSetup, "use_auto_tz", "0");
    saveConfig();
    myTime.tzsetup(posixTz.c_str());

    HTTP.send(200, "text/plain", "OK_TZ_SET");
  });

  // установка пользовательского часового пояса
  HTTP.on("/set_custom_tz", HTTP_GET, []() {
    if (!HTTP.hasArg("tz")) {
      HTTP.send(400, "text/plain", "Missing tz parameter");
      return;
    }

    String customTz = urldecode(HTTP.arg("tz"));
    customTz.trim();

    if (customTz.length() == 0) {
      HTTP.send(400, "text/plain", "Empty timezone");
      return;
    }

    String posixTz = russianCityToPosix(customTz);

    if (posixTz == customTz) {
      bool isPreset = false;
      const char* presets[] = {"MSK-3", "SAMT-4", "YEKT-5", "OMST-6", "KRAT-7", "IRKT-8", "YAKT-9", "VLAT-10", "MAGT-11", "PETT-12", "ALMT-5"};
      for (int i = 0; i < 11; i++) {
        if (customTz == presets[i]) {
          isPreset = true;
          break;
        }
      }

      if (!isPreset) {
        posixTz = ianaToPosix(customTz);
        if (posixTz == customTz && !isValidPosixFormat(customTz)) {
          HTTP.send(400, "text/plain", "Invalid timezone format");
          return;
        }
      }
    }

    jsonWrite(configSetup, "tz", posixTz);
    jsonWrite(configSetup, "tz_custom", customTz);
    jsonWrite(configSetup, "tz_is_custom", "1");
    jsonWrite(configSetup, "use_auto_tz", "0");
    saveConfig();

    myTime.tzsetup(posixTz.c_str());

    HTTP.send(200, "text/plain", "OK_TZ_SET");
  });

  // установка часового пояса по координатам
  HTTP.on("/set_geo_tz", HTTP_GET, []() {
    PJsonDoc cfg(JSON_BUFFER_SIZE);
    if (configSetup.length() == 0 || deserializeJson(cfg, configSetup)) {
      cfg.clear(); cfg.to<JsonObject>();
    }

    bool changed = false;

    if (HTTP.hasArg("enabled")) {
      String v = HTTP.arg("enabled");
      if ((cfg["geo_tz_enabled"].as<String>()) != v) {
        cfg["geo_tz_enabled"] = v;
        changed = true;
      }
    }
    if (HTTP.hasArg("lat")) {
      String v = HTTP.arg("lat"); v.replace(",", "."); v.trim();
      if ((cfg["geo_tz_lat"].as<String>()) != v) {
        cfg["geo_tz_lat"] = v;
        changed = true;
      }
    }
    if (HTTP.hasArg("lon")) {
      String v = HTTP.arg("lon"); v.replace(",", "."); v.trim();
      if ((cfg["geo_tz_lon"].as<String>()) != v) {
        cfg["geo_tz_lon"] = v;
        changed = true;
      }
    }

    // применение TZ по координатам
    if (((int)(cfg["geo_tz_enabled"] | 0)) == 1) {
      String latS = cfg["geo_tz_lat"].as<String>();  latS.trim();
      String lonS = cfg["geo_tz_lon"].as<String>();  lonS.trim();
      if (latS.length() > 0 && lonS.length() > 0) {
        String posixTz = "";
        if (Wifi::instance().isConnected()) {
          posixTz = geoToTimezoneOnline(latS.toFloat(), lonS.toFloat());
        }
        if (posixTz.length() == 0) posixTz = geoToTimezone(latS.toFloat(), lonS.toFloat());

        String savedTz = cfg["tz"].as<String>(); savedTz.trim();

        if (posixTz == "MSK-3" && savedTz.length() > 0 && savedTz != "MSK-3" && savedTz != "auto") {
          posixTz = savedTz;
        } else {
          cfg["tz"] = posixTz;
          configSetup = "";
          configSetup.reserve(measureJson(cfg) + 1);
          serializeJson(cfg, configSetup);
          saveConfig();
        }

        myTime.tzsetup(posixTz.c_str());

        PJsonDoc resp(256);
        resp["should_refresh"] = "true";
        resp["title"] = cfg["geo_tz_name"].as<String>();
        resp["tz"] = posixTz;
        String out;
        out.reserve(measureJson(resp) + 1);
        serializeJson(resp, out);
        HTTP.send(200, "application/json", out);
        return;
      }
    }

    if (changed) {
      configSetup = "";
      configSetup.reserve(measureJson(cfg) + 1);
      serializeJson(cfg, configSetup);
      saveConfig();
    }

    PJsonDoc resp(256);
    resp["should_refresh"] = "true";
    resp["title"] = cfg["geo_tz_name"].as<String>();
    resp["tz"] = cfg["tz"].as<String>();
    String out;
    out.reserve(measureJson(resp) + 1);
    serializeJson(resp, out);
    HTTP.send(200, "application/json", out);
  });

  // определение города по координатам
  HTTP.on("/resolve_city", HTTP_GET, []() {
    if (!HTTP.hasArg("lat") || !HTTP.hasArg("lon")) {
      HTTP.send(400, "text/plain", "Missing lat or lon");
      return;
    }

    float lat = HTTP.arg("lat").toFloat();
    float lon = HTTP.arg("lon").toFloat();

    String city = getCityNameFromCoords(lat, lon);
    HTTP.send(200, "text/plain", city);
  });

  // получить текущие настройки geo TZ
  HTTP.on("/get_geo_tz", HTTP_GET, []() {
    PJsonDoc doc(512);
    doc["enabled"] = jsonReadtoInt(configSetup, "geo_tz_enabled") == 1;
    doc["lat"] = jsonRead(configSetup, "geo_tz_lat");
    doc["lon"] = jsonRead(configSetup, "geo_tz_lon");
    doc["name"] = jsonRead(configSetup, "geo_tz_name");
    doc["tz"] = jsonRead(configSetup, "tz");
    String out;
    serializeJson(doc, out);
    HTTP.send(200, "application/json", out);
  });

  HTTP.on("/get_tz_info", HTTP_GET, []() {
    String info = getTimezoneInfo();
    HTTP.send(200, "application/json", info);
  });

  // разноцветные часы на матрице (которые EFF_CLOCK)
  HTTP.on("/rainbow_clock", HTTP_GET, []() {
    if (HTTP.hasArg("value")) {
      rainbowClock = (HTTP.arg("value") == "1" || HTTP.arg("value") == "true");
      jsonWrite(configLedPanel, "rainbow_clock", rainbowClock ? "1" : "0");
      saveConfig();
      loadingFlag = true;
    }
    HTTP.send(200, "text/plain", rainbowClock ? "1" : "0");
  });

  HTTP.on("/save_geo_tz_param", HTTP_GET, []() {
    if (!HTTP.hasArg("key") || !HTTP.hasArg("value")) {
      HTTP.send(400, "text/plain", "Missing key or value");
      return;
    }
    String key = HTTP.arg("key");
    String value = HTTP.arg("value");
    if (jsonRead(configSetup, key) != value) {
      jsonWrite(configSetup, key, value);
      saveConfig();
    }
    HTTP.send(200, "text/plain", "OK");
  });

  // --------------------------------------------------------------- ПОГОДА (ЯНДЕКС, OPENWEATHER) --------------------------------------------------------

#if USE_WEATHER
  HTTP.on("/print_weather", handle_print_weather); // Интервал вывода погоды
  HTTP.on("/run_weather_text_enabled", handle_run_weather_text_enabled); // Включение/выключение погоды бегущей строкой

  HTTP.on("/get_weather", HTTP_GET, []() {
    PJsonDoc doc(1024);

    PJsonDoc cfg(JSON_BUFFER_SIZE);
    DeserializationError cfgErr = deserializeJson(cfg, configWeather);
    bool cfgOk = !cfgErr && cfg.is<JsonObject>();

    auto& weather = Weather::instance();
    if (weather.isAvailable()) {
      String source = weather.isUsingYandex() ? "Яндекс" : "OpenWeather";

      String condition = weather.getCondition();
      String text = source + ": " + String((int)round(weather.getTemperature())) + "°C";
      if (condition.length() > 0) text += ", " + condition;

      String cityName = "";
      int weatherSource = cfgOk ? cfg["weather_source"].as<int>() : 0;

      if (weatherSource == 0) { // Яндекс
        String yandexGeo = cfgOk ? cfg["yandex_geo"].as<String>() : String("");
        String customYandexGeo = cfgOk ? cfg["custom_yandex_geo"].as<String>() : String("");
        String yandexApiKey = cfgOk ? cfg["yandex_api_key"].as<String>() : String("");
        String lat = cfgOk ? cfg["custom_lat"].as<String>() : String("");
        String lon = cfgOk ? cfg["custom_lon"].as<String>() : String("");
        String coordName = cfgOk ? cfg["custom_coord_name"].as<String>() : String("");

        yandexGeo.trim();
        customYandexGeo.trim();
        lat.trim(); lon.trim();

        bool useYandexGraphQL = yandexGeo.length() == 0 && customYandexGeo.length() == 0 && lat.length() > 0 && lon.length() > 0 && yandexApiKey.length() > 10;

        if (useYandexGraphQL) {
          cityName = (coordName.length() > 0) ? coordName : ("(" + lat + ", " + lon + ")");
        } else if (customYandexGeo.length() > 0) {
          cityName = getCityNameByGeo(customYandexGeo);
          if (cityName.length() == 0) cityName = "Город " + customYandexGeo;
        } else if (yandexGeo.length() > 0) {
          cityName = getCityNameByGeo(yandexGeo);
        } else {
          cityName = "Москва";
        }
      } else { // OpenWeather
        String city = cfgOk ? cfg["city"].as<String>() : String("");
        String customCity = cfgOk ? cfg["custom_city"].as<String>() : String("");
        String coordName  = cfgOk ? cfg["custom_coord_name"].as<String>() : String("");
        String lat = cfgOk ? cfg["custom_lat"].as<String>() : String("");
        String lon = cfgOk ? cfg["custom_lon"].as<String>() : String("");

        city.trim(); customCity.trim(); lat.trim(); lon.trim();

        if (lat.length() > 0 && lon.length() > 0) {
          cityName = (coordName.length() > 0) ? coordName : ("(" + lat + ", " + lon + ")");
        } else if (customCity.length() > 0) {
          cityName = getRussianCityNameForOpenWeather(customCity);
        } else if (city.length() > 0) {
          cityName = getRussianCityNameForOpenWeather(city);
        } else {
          cityName = "Moscow";
        }
      }

      doc["text"] = text;
      doc["temp"] = round(weather.getTemperature());
      doc["condition"] = condition;

      int showCond = 1;
      if (cfgOk && cfg.containsKey("show_weather_condition")) {
        showCond = cfg["show_weather_condition"].as<int>();
      }
      doc["show_condition"] = (showCond == 1);
      doc["city"] = cityName;
    } else {
      doc["text"] = "—";
      doc["city"] = "";
    }

    doc["init"] = inClockWeatherMode;
    doc["provider"] = weather.isUsingYandex() ? "yandex" : "openweather";
    doc["method"] = weather.isUsingYandex() ? (weather.isUsingYandexGraphQL() ? "graphql" : "sync") : "openweather";

    String out;
    out.reserve(measureJson(doc) + 1);
    serializeJson(doc, out);
    HTTP.send(200, "application/json", out);
  });

  HTTP.on("/save_weather_param", HTTP_GET, []() {
    if (!HTTP.hasArg("key") || !HTTP.hasArg("value")) {
      HTTP.send(400, "text/plain", "Missing key or value");
      return;
    }

    String key = HTTP.arg("key");
    String value = HTTP.arg("value");
    bool needForceUpdate = false;
    bool configChanged = false;

    PJsonDoc cfg(JSON_BUFFER_SIZE);
    DeserializationError err = deserializeJson(cfg, configWeather);

    if (err == DeserializationError::InvalidInput || err == DeserializationError::NoMemory) {
      HTTP.send(500, "text/plain", "Config corrupted");
      return;
    }
    if (err || !cfg.is<JsonObject>()) {
      cfg.clear();
      cfg.to<JsonObject>();
    }

    String oldValue = cfg[key].as<String>();
    if (oldValue != value) {
      cfg[key] = value;
      configChanged = true;
    }

    if (key == "show_weather") {
      inClockWeatherMode = (value == "1");
      if (inClockWeatherMode && Wifi::instance().isConnected()) {
        needForceUpdate = true;
      }
    }

    if (configChanged) {
      configWeather = "";
      configWeather.reserve(measureJson(cfg) + 1);
      serializeJson(cfg, configWeather);

      saveConfig();
      Weather::instance().requestReload();
    }

    if (needForceUpdate && Wifi::instance().isConnected()) {
      Weather::instance().forceUpdate();
    }

    HTTP.send(200, "text/plain", "OK");
  });

  // кнопка "Применить"
  HTTP.on("/save_weather_params", HTTP_GET, []() {
    PJsonDoc cfg(JSON_BUFFER_SIZE);
    DeserializationError err = deserializeJson(cfg, configWeather);

    if (err == DeserializationError::InvalidInput || err == DeserializationError::NoMemory) {
      HTTP.send(500, "text/plain", "Config corrupted");
      return;
    }
    if (err || !cfg.is<JsonObject>()) {
      cfg.clear();
      cfg.to<JsonObject>();
    }

    bool configChanged = false;

    String oldLat = cfg["custom_lat"].as<String>();
    String oldLon = cfg["custom_lon"].as<String>();
    oldLat.trim(); oldLon.trim();

    auto saveIfChanged = [&](const char* key, String value, bool trimVal = false, bool dotComma = false) {
      if (trimVal) value.trim();
      if (dotComma) {
        value.replace(",", ".");
        value.trim();
      }
      String oldValue = cfg[key].as<String>();
      if (oldValue != value) {
        cfg[key] = value;
        configChanged = true;
      }
    };

    if (HTTP.hasArg("weather_source")) saveIfChanged("weather_source", HTTP.arg("weather_source"));

    // взаимоисключающие поля: город и координаты
    if (HTTP.hasArg("custom_lat") || HTTP.hasArg("custom_lon")) {
      cfg.remove("city");
      cfg.remove("custom_city");
    } else if (HTTP.hasArg("city") || HTTP.hasArg("custom_city")) {
      cfg.remove("custom_lat");
      cfg.remove("custom_lon");
      cfg.remove("custom_coord_name");
    }

    if (HTTP.hasArg("yandex_geo")) saveIfChanged("yandex_geo", HTTP.arg("yandex_geo"));
    if (HTTP.hasArg("custom_yandex_geo")) saveIfChanged("custom_yandex_geo", HTTP.arg("custom_yandex_geo"), true);
    if (HTTP.hasArg("city")) saveIfChanged("city", HTTP.arg("city"));
    if (HTTP.hasArg("custom_city")) saveIfChanged("custom_city", HTTP.arg("custom_city"), true);
    if (HTTP.hasArg("custom_lat")) saveIfChanged("custom_lat", HTTP.arg("custom_lat"), true, true);
    if (HTTP.hasArg("custom_lon")) saveIfChanged("custom_lon", HTTP.arg("custom_lon"), true, true);
    if (HTTP.hasArg("yandex_api_key")) saveIfChanged("yandex_api_key", HTTP.arg("yandex_api_key"), true);

    String latNow = cfg["custom_lat"].as<String>();
    String lonNow = cfg["custom_lon"].as<String>();
    latNow.trim(); lonNow.trim();

    bool coordsChanged = (oldLat != latNow) || (oldLon != lonNow);

    if (coordsChanged) {
      if (cfg["custom_coord_name"].as<String>().length() > 0) {
        cfg["custom_coord_name"] = "";
        configChanged = true;
      }
    } else {
      if (HTTP.hasArg("custom_coord_name")) {
        String value = HTTP.arg("custom_coord_name");
        value.trim();
        String cur = cfg["custom_coord_name"].as<String>();
        if (cur != value) {
          cfg["custom_coord_name"] = value;
          configChanged = true;
        }
      }
    }

    String nameNow = cfg["custom_coord_name"].as<String>();
    nameNow.trim();

    // парсинг координат
    auto parseCoord = [](const String & s, float & out) -> bool {
      if (s.length() == 0) return false;
      char* end = nullptr;
      out = strtof(s.c_str(), &end);
      if (end == s.c_str() || *end != '\0' || !isfinite(out)) return false;
      return true;
    };

    if (nameNow.length() == 0 && latNow.length() > 0 && lonNow.length() > 0 && Wifi::instance().isConnected()) {

      float latF = 0.0f, lonF = 0.0f;
      bool latOk = parseCoord(latNow, latF);
      bool lonOk = parseCoord(lonNow, lonF);

      if (latOk && lonOk && latF >= -90.0f  && latF <= 90.0f && lonF >= -180.0f && lonF <= 180.0f && !(latF == 0.0f && lonF == 0.0f)) {

        String cityResolved = getCityNameFromCoords(latF, lonF);
        cityResolved.trim();
        if (cityResolved.length() > 0) {
          cfg["custom_coord_name"] = cityResolved;
          configChanged = true;
        }
      }
    }

    if (configChanged) {
      configWeather = "";
      configWeather.reserve(measureJson(cfg) + 1);
      serializeJson(cfg, configWeather);

      saveConfig();
      Weather::instance().requestReload();
      if (Wifi::instance().isConnected()) {
        Weather::instance().forceUpdate();
      }
    }

    HTTP.send(200, "text/plain", "OK");
  });

  // текущие настройки
  HTTP.on("/get_weather_settings", HTTP_GET, []() {
    PJsonDoc cfg(JSON_BUFFER_SIZE);
    if (deserializeJson(cfg, configWeather)) {
      HTTP.send(500, "text/plain", "config error");
      return;
    }

    PJsonDoc doc(2048);
    String weather_source = cfg["weather_source"] | "";
    String yandex_geo = cfg["yandex_geo"] | "";
    String custom_yandex_geo = cfg["custom_yandex_geo"] | "";
    String city = cfg["city"] | "";
    String custom_city = cfg["custom_city"] | "";
    String custom_lat = cfg["custom_lat"] | "";
    String custom_lon = cfg["custom_lon"] | "";
    String custom_coord_name = cfg["custom_coord_name"] | "";
    String yandex_api_key = cfg["yandex_api_key"] | "";

    doc["yandex_api_key"] = yandex_api_key;
    doc["weather_source"] = weather_source.length()  > 0 ? weather_source  : "0";
    doc["yandex_geo"] = yandex_geo;
    doc["custom_yandex_geo"] = custom_yandex_geo;
    doc["city"] = city;
    doc["custom_city"] = custom_city;
    doc["custom_lat"] = custom_lat;
    doc["custom_lon"] = custom_lon;
    doc["custom_coord_name"] = custom_coord_name;
    doc["show_condition"] = ((int)(cfg["show_weather_condition"] | 1)) == 1;

    String out;
    out.reserve(measureJson(doc) + 1);
    serializeJson(doc, out);
    HTTP.send(200, "application/json", out);
  });

#else
  // заглушки
  // возвращает статус "ОТКЛЮЧЕНО В ПРОШИВКЕ"
  HTTP.on("/get_weather", HTTP_GET, []() {
    PJsonDoc  doc(128);
    auto& weather = Weather::instance();
    doc["enabled"] = false;
    doc["text"] = "ОТКЛЮЧЕНО В ПРОШИВКЕ";
    doc["temp"] = 0;
    doc["init"] = false;
    doc["city"] = "";
    doc["provider"] = "";
    String out;
    serializeJson(doc, out);
    HTTP.send(200, "application/json", out);
  });

  HTTP.on("/save_weather_param", HTTP_GET, []() {
    HTTP.send(200, "text/plain", "OK (weather disabled)");
  });

  HTTP.on("/save_weather_params", HTTP_GET, []() {
    HTTP.send(200, "text/plain", "OK (weather disabled)");
  });

  HTTP.on("/get_weather_settings", HTTP_GET, []() {
    PJsonDoc doc(128);
    doc["weather_source"] = "0";
    doc["yandex_geo"] = "";
    doc["custom_yandex_geo"] = "";
    doc["city"] = "";
    doc["custom_city"] = "";
    String out;
    serializeJson(doc, out);
    HTTP.send(200, "application/json", out);
  });
#endif

  // ------------------------------------------------------------------------ НАСТРОЙКИ МАТРИЦЫ ---------------------------------------------------------

  HTTP.on("/m_t", handle_matrix_tipe);
  HTTP.on("/m_o", handle_matrix_orientation);
#if MULTI_MATRIX
  HTTP.on("/multi_matrix_enable", HTTP_GET, handle_multi_matrix_enable);
#endif

  // чип светодиодов, порядок цветов
  HTTP.on("/save_led_settings", HTTP_GET, []() {
    String configLED = readFile(F("config_led_matrix.json"), 2048);
    if (configLED == "Failed" || configLED == "Large" || configLED.isEmpty()) {
      configLED = "{}";
    }

    PJsonDoc cfg(2048);
    if (deserializeJson(cfg, configLED)) {
      cfg.clear();
      cfg.to<JsonObject>();
    }

    bool changed = false;

    if (HTTP.hasArg("led_chip")) {
      String val = HTTP.arg("led_chip");
      if (cfg["led_chip"].as<String>() != val) {
        cfg["led_chip"] = val;
        changed = true;
      }
    }

    if (HTTP.hasArg("color_order")) {
      String val = HTTP.arg("color_order");
      if (cfg["color_order"].as<String>() != val) {
        cfg["color_order"] = val;
        changed = true;
      }
    }

    if (changed) {
      configLED = "";
      configLED.reserve(measureJson(cfg) + 1);
      serializeJson(cfg, configLED);
      writeFile(F("config_led_matrix.json"), configLED);
      HTTP.send(200, "text/plain", "OK_REBOOT");
      pendingRestart = true;
    } else {
      HTTP.send(200, "text/plain", "NO_CHANGE");
    }
  });

  HTTP.on("/save_matrix", HTTP_GET, []() {
    String configLED = readFile(F("config_led_matrix.json"), 2048);
    if (configLED == "Failed" || configLED == "Large") configLED = "{}";

    PJsonDoc cfg(2048);
    if (deserializeJson(cfg, configLED)) {
      cfg.clear();
      cfg.to<JsonObject>();
    }

    bool changed = false;
    bool needReboot = false;

    // с перезагрузкой
    if (HTTP.hasArg("led_chip")) {
      String val = HTTP.arg("led_chip");
      if (cfg["led_chip"].as<String>() != val) {
        cfg["led_chip"] = val;
        changed = true;
        needReboot = true;
      }
    }

    if (HTTP.hasArg("color_order")) {
      String val = HTTP.arg("color_order");
      if (cfg["color_order"].as<String>() != val) {
        cfg["color_order"] = val;
        changed = true;
        needReboot = true;
      }
    }

    if (HTTP.hasArg("width")) {
      String val = HTTP.arg("width");
      if (cfg["width"].as<String>() != val) {
        uint16_t newW = val.toInt();
        if (newW >= 1 && newW <= 128) {
          cfg["width"] = String(newW);
          changed = true;
          needReboot = true;
        }
      }
    }

    if (HTTP.hasArg("height")) {
      String val = HTTP.arg("height");
      if (cfg["height"].as<String>() != val) {
        uint16_t newH = val.toInt();
        if (newH >= 1 && newH <= 128) {
          cfg["height"] = String(newH);
          changed = true;
          needReboot = true;
        }
      }
    }

#if MULTI_MATRIX
    if (HTTP.hasArg("segMatrix_w")) {
      String val = HTTP.arg("segMatrix_w");
      if (cfg["segMatrix_w"].as<String>() != val) {
        uint8_t newW = val.toInt();
        if (newW >= 1 && newW <= 8) {
          cfg["segMatrix_w"] = String(newW);
          changed = true;
          needReboot = true;
        }
      }
    }

    if (HTTP.hasArg("segMatrix_h")) {
      String val = HTTP.arg("segMatrix_h");
      if (cfg["segMatrix_h"].as<String>() != val) {
        uint8_t newH = val.toInt();
        if (newH >= 1 && newH <= 8) {
          cfg["segMatrix_h"] = String(newH);
          changed = true;
          needReboot = true;
        }
      }
    }

    if (HTTP.hasArg("panel_flip")) {
      String val = HTTP.arg("panel_flip");
      if (cfg["panel_flip"].as<String>() != val) {
        cfg["panel_flip"] = val;
        changed = true;
        needReboot = true;
        panelFlip = (val == "1");
      }
    }
#endif

    // без перезагрузки
    if (HTTP.hasArg("m_t")) {
      String val = HTTP.arg("m_t");
      if (cfg["m_t"].as<String>() != val) {
        cfg["m_t"] = val;
        changed = true;
        MatrixType = val.toInt();
        loadingFlag = true;
        needFullRedraw = true;
      }
    }

    if (HTTP.hasArg("m_o")) {
      String val = HTTP.arg("m_o");
      if (cfg["m_o"].as<String>() != val) {
        cfg["m_o"] = val;
        changed = true;
        MatrixOrientation = val.toInt();
        loadingFlag = true;
        needFullRedraw = true;
      }
    }

    if (HTTP.hasArg("cur_lim")) {
      String val = HTTP.arg("cur_lim");
      if (cfg["cur_lim"].as<String>() != val) {
        cfg["cur_lim"] = val;
        changed = true;
        current_limit = val.toInt();
        if (current_limit > CURRENT_LIMIT) current_limit = CURRENT_LIMIT;
        if (current_limit == 0) current_limit = 0xFFFF;
        FastLED.setMaxPowerInVoltsAndMilliamps(5, current_limit);
      }
    }

    if (changed) {
      configLED = "";
      configLED.reserve(measureJson(cfg) + 1);
      serializeJson(cfg, configLED);
      writeFile(F("config_led_matrix.json"), configLED);

      if (needReboot) {
        HTTP.send(200, "text/plain", "OK_REBOOT");
        pendingRestart = true;
      } else {
        HTTP.send(200, "text/plain", "OK");
      }
    } else {
      HTTP.send(200, "text/plain", "NO_CHANGE");
    }
  });

  // --------------------------------------------------------------------- АНИМАЦИОННЫЕ ЭФФЕКТЫ ---------------------------------------------------------

#if USE_ANIMATIONS
  HTTP.on("/get_anim_list", HTTP_GET, []() {
    PJsonDoc doc(1024);
    JsonArray array = doc.to<JsonArray>();

    String list = animations_list;
    if (list.length() == 0) {
      HTTP.send(200, "application/json; charset=utf-8", "[]");
      return;
    }
    int start = 0;
    while (true) {
      int comma = list.indexOf(',', start);
      String item;
      if (comma == -1) {
        item = list.substring(start);
        if (item.length() > 0) {
          item.trim();
          array.add(item);
        }
        break;
      } else {
        item = list.substring(start, comma);
        if (item.length() > 0) {
          item.trim();
          array.add(item);
        }
        start = comma + 1;
      }
    }
    String response;
    serializeJson(doc, response);
    HTTP.send(200, "application/json; charset=utf-8", response);
  });

  HTTP.on("/set_anim", HTTP_GET, []() {
#if USE_SD
    if (outFile) {
      outFile.close();
      outAnimationActive = false;
    }
#endif
    outEffectActive = false;
    if (!HTTP.hasArg("anim")) {
      HTTP.send(400, "text/plain", "Missing anim parameter");
      return;
    }

    int idx = HTTP.arg("anim").toInt();
    if (idx < 0 || idx > max_image_num) {
      HTTP.send(400, "text/plain", "Invalid animation index");
      return;
    }

    uint8_t currentEffSel = jsonReadtoInt(configSetup, "eff_sel");
    if (currentMode != EFF_ANIMATION) {
      lastNonAnimSel = currentEffSel;
    }

    if (idx == 0) {
      specialTextEffectParam = 1;
    } else {
      specialTextEffectParam = idx;
    }

    jsonWrite(configSetup, "anim_sel", idx);

    if (currentMode != EFF_ANIMATION) {
      currentMode = EFF_ANIMATION;
      uint8_t ui_index = 0;
      for (ui_index = 0; ui_index < MODE_AMOUNT; ui_index++) {
        if (eff_num_correct[ui_index] == currentMode) break;
      }
      jsonWrite(configSetup, "eff_sel", ui_index);
    }

    loadingFlag = true;
    saveConfig();

    String response = "{\"anim_sel\":" + String(idx) + ",\"eff_sel\":0}";
    HTTP.send(200, "application/json", response);

#if USE_MULTILAMP
    repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
    if (Wifi::instance().isConnected()) {
      Mqtt::instance().needToPublish = true;
    }
#endif

  });

#endif // USE_ANIMATIONS

  // -------------------------------------------------------------------- ЭФФЕКТЫ С SD формата .out -----------------------------------------------------

#if USE_SD

  HTTP.on("/list_sd", HTTP_GET, []() {
    String path = "/";
    if (HTTP.hasArg("dir")) path = HTTP.arg("dir");

    auto openDir = [](const String & p) -> File {
      if (sdType == 1) return LittleFS.open(p);
      else return SD.open(p);
    };

    File root = openDir(path);
    if (!root || !root.isDirectory()) {
      if (root) root.close();
      HTTP.send(404, "text/plain", "SD dir not found: " + path);
      return;
    }

    String output = "[";
    File file = root.openNextFile();
    bool first = true;
    while (file) {
      if (!first) output += ",";
      first = false;
      output += "{\"type\":\"";
      output += file.isDirectory() ? "dir" : "file";
      output += "\",\"name\":\"";
      output += file.name();
      output += "\"}";
      file.close();
      file = root.openNextFile();
    }
    root.close();
    output += "]";
    HTTP.send(200, "application/json", output);
  });

  HTTP.on("/list_out_files", handle_list_out_files);

  HTTP.on("/set_out_effect", HTTP_GET, []() {
    if (!HTTP.hasArg("file")) {
      HTTP.send(400, "text/plain", "Missing file parameter");
      return;
    }
    if (!ONflag) {
      HTTP.send(403, "text/plain", "Lamp is off");
      return;
    }

    String fileName = HTTP.arg("file");
    fileName.trim();
    if (fileName.length() == 0 || fileName.indexOf('/')  >= 0 || fileName.indexOf('\\') >= 0 || fileName.indexOf("..") >= 0) {
      HTTP.send(400, "text/plain", "Invalid filename");
      return;
    }
    String sizeFolder = String(matrixWidth) + "x" + String(matrixHeight);
    String path = "/effects/" + sizeFolder + "/" + fileName;

    if (!sdFileExists(path)) {
      HTTP.send(404, "text/plain", "File not found");
      return;
    }

    if (outFile) {
      outFile.close();
    }
    outAnimationActive = false;

    uint8_t currentEffSel = jsonReadtoInt(configSetup, "eff_sel");
    if (currentMode != EFF_SD) {
      jsonWrite(configSetup, "last_non_sd_eff_sel", currentEffSel);
    }

    lastOutFileName = fileName;
    currentMode = EFF_SD;

    jsonWrite(configSetup, "eff_sel", effSdIndex);
    jsonWrite(configSetup, "out_sel", fileName);
    jsonWrite(configSetup, "anim_sel", "0");

    writeFile(F("config.json"), configSetup);

    if (startOutAnimation(fileName)) {
      outAnimationActive = true;
      outEffectActive = true;
      FastLED.show();

      HTTP.send(200, "text/plain", "OK");
    } else {
      HTTP.send(500, "text/plain", "Failed to start");
    }
  });
#else // !USE_SD
  HTTP.on("/set_out_effect", []() {
    HTTP.send(404, F("text/plain"), F("SD card not enabled"));
  });
#endif // USE_SD

  HTTP.on("/get_eff_sd_index", HTTP_GET, []() {
    HTTP.send(200, "text/plain", String(effSdIndex));
  });

  // --------------------------------------------------------------------
  HTTP.on("/debug.log", HTTP_GET, []() {
    File logFile = LittleFS.open("/debug.log", "r");
    if (!logFile) {
      HTTP.send(404, "text/plain", "Log file not found");
      return;
    }
    HTTP.send(200, "text/plain", logFile.readString());
    logFile.close();
  });

  // ------------------------------------------------------------------------- LED ПАНЕЛЬ ---------------------------------------------------------------

  // бегущая строка
#if LED_PANEL
  HTTP.on("/spt", handle_spt);                                     // Скорость бегущей строки
  HTTP.on("/sct", handle_sct);                                     // Цвет бегущей строки
  HTTP.on("/font_size", handle_font_size);                         // Шрифт текста
  HTTP.on("/run_text", handle_run_text);                           // Текст бегущей строки
  HTTP.on("/run_text_enabled", handle_run_text_enabled);           // Чекбокс "Включить бегущую строку"
  HTTP.on("/run_text_over", handle_run_text_over);                 // Чекбокс "Бегущая строка поерх эффекта"
  HTTP.on("/interval_run_text", handle_interval_run_text);         // Интервал вывода текста бегущей строкой"
  HTTP.on("/run_time_text_enabled", handle_run_time_text_enabled); // Включение/выключение часов бегущей строкой

  HTTP.on("/word_space", HTTP_GET, []() {
    if (!HTTP.hasArg("word_space")) {
      HTTP.send(400, "text/plain", "missing");
      return;
    }
    uint8_t v = constrain(HTTP.arg("word_space").toInt(), 1, 10);
    jsonWrite(configLedPanel, "word_space", String(v));
    wordSpacePixels = v;
    saveConfig("ledpanel");
    HTTP.send(200, "text/plain", "OK");
  });

  HTTP.on("/letter_space", HTTP_GET, []() {
    if (!HTTP.hasArg("letter_space")) {
      HTTP.send(400, "text/plain", "missing");
      return;
    }
    uint8_t v = constrain(HTTP.arg("letter_space").toInt(), 0, 10);
    jsonWrite(configLedPanel, "letter_space", String(v));
    letterSpacePx = v;
    saveConfig("ledpanel");
    HTTP.send(200, "text/plain", "OK");
  });

  HTTP.on("/rainbow_text", HTTP_GET, []() {  // Чекбокс "Разноцветный текст"
    if (HTTP.hasArg("value")) {
      rainbowText = (HTTP.arg("value") == "1" || HTTP.arg("value") == "true");
      if (rainbowText) {
        runTextColorCycle = false;
        autoRunTextHue = false;
        jsonWrite(configLedPanel, "run_text_cycle", "0");
      }
      jsonWrite(configLedPanel, "rainbow_text", rainbowText ? "1" : "0");
      saveConfig();
      loadingFlag = true;
      textIsRunning = true;
      offset = matrixWidth + 10;
      scrollTimer = millis();
    }
    HTTP.send(200, "text/plain", rainbowText ? "1" : "0");
  });

  // оттенок текста
  HTTP.on("/run_text_hue", []() {
    if (HTTP.hasArg("value")) {
      int val = HTTP.arg("value").toInt();
      if (val >= 253) {
        runTextColorCycle = true;
        runTextHue = 0;
        jsonWrite(configLedPanel, "run_text_cycle", "1");
      } else {
        runTextColorCycle = false;
        runTextHue = (uint8_t)val;
        jsonWrite(configLedPanel, "run_text_cycle", "0");
      }
      jsonWrite(configLedPanel, "run_text_hue", String(runTextHue));
      saveConfig();
      loadingFlag = true;
    }
    HTTP.send(200, "text/plain", String(runTextHue));
  });

  // если интервал вывода бегущей строки установлен 0, то текст будет бежать непрерывно
  HTTP.on("/run_text_cycle", []() {
    if (HTTP.hasArg("value")) {
      runTextColorCycle = (HTTP.arg("value") == "1");
      jsonWrite(configLedPanel, "run_text_cycle", runTextColorCycle ? "1" : "0");
      saveConfig();
      loadingFlag = true;
    }
    HTTP.send(200, "text/plain", runTextColorCycle ? "1" : "0");
  });
  HTTP.on("/text_y_offset", handle_text_y_offset);               // Смещение текста по Y (по высоте)
  // часы
  HTTP.on("/clock_x_offset", handle_clock_x_offset);             // Смещение текста по X (по ширине)
  HTTP.on("/clock_y_offset", handle_clock_y_offset);             // Смещение текста по Y (по высоте)
  HTTP.on("/clock_hue", handle_clock_hue); // Оттенок часов
  // дата
  HTTP.on("/date_enabled", handle_date_enabled);                 // Чекбокс "Включить дату"
  HTTP.on("/date_y_offset", handle_date_y_offset);               // Смещение даиы по Y (по ширине)
  HTTP.on("/date_x_offset", handle_date_x_offset);               // Смещение даты по X (по ширине)
  HTTP.on("/date_hue", handle_date_hue);                         // Оттенок даты
  HTTP.on("/date_full_year", handle_date_full_year);             // Показывать 4 цифры года
  HTTP.on("/date_separator_blink", handle_date_separator_blink); // Плавное мигание разделительных точек
  HTTP.on("/date_show_year", handle_date_show_year);             // Показывать год

  HTTP.on("/rainbow_date", HTTP_GET, []() {
    if (HTTP.hasArg("value")) {
      String val = HTTP.arg("value");
      rainbowDate = (val == "1" || val.equalsIgnoreCase("true") || val == "on");
      jsonWrite(configLedPanel, "rainbow_date", rainbowDate ? "1" : "0");
      saveConfig();
      dateNeedRedraw = true;
      loadingFlag = true;
    }
    HTTP.send(200, "text/plain", rainbowDate ? "1" : "0");
  });

  // погода
#if USE_WEATHER
  HTTP.on("/weather_enabled", handle_weather_enabled);   // Чекбокс "Включить погоду"
  HTTP.on("/weather_hue", handle_weather_hue);           // Регулировка цвета
  HTTP.on("/weather_x_offset", handle_weather_x_offset); // Смещение по X
  HTTP.on("/weather_y_offset", handle_weather_y_offset); // Смещение по Y
  HTTP.on("/degree_blink", handle_degree_blink);         // Мигание знака градуса (маленький кружок)
  // таймеры и интервалы
  HTTP.on("/timer_c_d_w", handle_timer_c_d_w);                   // таймер часы/дата/погоды
  HTTP.on("/timer_clock_fixed", handle_timer_clock_fixed);       // таймер часы + дата/погоды
  HTTP.on("/interval_c_d_w", handle_interval_c_d_w);             // интервал часы/дата/погоды
  HTTP.on("/interval_clock_fixed", handle_interval_clock_fixed); // интервал часы + дата/погоды
  HTTP.on("/timer_d_w", handle_timer_d_w);                       // таймер дата/погода
  HTTP.on("/interval_d_w", handle_interval_d_w);                 // интервал дата/погода
  HTTP.on("/timer_c_w", handle_timer_c_w);                       // таймер часы/погода
  HTTP.on("/interval_c_w", handle_interval_c_w);                 // интервал часы/погода

  HTTP.on("/rainbow_weather", HTTP_GET, []() {
    if (HTTP.hasArg("value")) {
      rainbowWeather = (HTTP.arg("value") == "1" || HTTP.arg("value") == "true");
      jsonWrite(configLedPanel, "rainbow_weather", rainbowWeather ? "1" : "0");
      saveConfig();
      weatherNeedRedraw = true;
      loadingFlag = true;
    }
    HTTP.send(200, "text/plain", rainbowWeather ? "1" : "0");
  });
#endif // USE_WEATHER
  // таймер и интервал часы/дата
  HTTP.on("/timer_c_d",  handle_timer_c_d);
  HTTP.on("/interval_c_d", handle_interval_c_d);
#endif // LED_PANEL

  // --------------------------------------------------------------- ДИНАМИЧЕСКИЕ ПИНЫ -------------------------------------------------------

  HTTP.on("/save_pins", HTTP_GET, []() {
    String cfg = readFile("config_pins.json", 1024);
    if (cfg == "Failed" || cfg == "Large" || cfg.isEmpty()) cfg = "{}";

    auto saveIfChanged = [&](const char* key) {
      if (!HTTP.hasArg(key)) return false;
      String v = HTTP.arg(key);
      if (jsonRead(cfg, key) != v) {
        jsonWrite(cfg, key, v);
        return true;
      }
      return false;
    };

    bool changed = false;
    changed |= saveIfChanged("led_pin");
    changed |= saveIfChanged("clk_pin");
    changed |= saveIfChanged("btn_pin");
    changed |= saveIfChanged("mosfet_pin");
#if USE_TM1637
    changed |= saveIfChanged("tm1637_dio");
    changed |= saveIfChanged("tm1637_clk");
#endif
#if USE_ST7789
    changed |= saveIfChanged("tft_sclk");
    changed |= saveIfChanged("tft_mosi");
    changed |= saveIfChanged("tft_cs");
    changed |= saveIfChanged("tft_dc");
    changed |= saveIfChanged("tft_rst");
    changed |= saveIfChanged("tft_bl");
#endif
#if USE_SD
    changed |= saveIfChanged("sd_cs");
    changed |= saveIfChanged("sd_sck");
    changed |= saveIfChanged("sd_mosi");
    changed |= saveIfChanged("sd_miso");
#endif
#if USE_MP3_PLAYER
    changed |= saveIfChanged("mp3_tx");
    changed |= saveIfChanged("mp3_rx");
#endif
#if USE_RADIO
    changed |= saveIfChanged("i2s_bclk");
    changed |= saveIfChanged("i2s_lrck");
    changed |= saveIfChanged("i2s_dout");
#endif
#if USE_IR_RECEIVER
    changed |= saveIfChanged("ir_pin");
#endif
#if USE_RF_RECEIVER
    changed |= saveIfChanged("rf_pin");
#endif

    if (!changed) {
      HTTP.send(200, "text/plain", "NO_CHANGE");
      return;
    }

    PinConfig backup = pins;
    loadPinConfig();
    if (!validatePinConfig()) {
      pins = backup;
      HTTP.send(400, "text/plain", "INVALID_PINS");
      return;
    }

    writeFile(F("config_pins.json"), cfg);
    HTTP.send(200, "text/plain", "OK_REBOOT");
    pendingRestart = true;
  });

  HTTP.on("/get_pins", HTTP_GET, []() {
    PJsonDoc doc(1024);
    doc["led_pin"]    = pins.ledPin;
    doc["clk_pin"]    = pins.clkPin;
    doc["btn_pin"]    = pins.btnPin;
    doc["mosfet_pin"] = pins.mosfetPin;
#if USE_TM1637
    doc["tm1637_dio"] = pins.tmDio;
    doc["tm1637_clk"] = pins.tmClk;
#endif
#if USE_ST7789
    doc["tft_sclk"] = pins.tftSclk; doc["tft_mosi"] = pins.tftMosi;
    doc["tft_cs"]   = pins.tftCs;   doc["tft_dc"]   = pins.tftDc;
    doc["tft_rst"]  = pins.tftRst;  doc["tft_bl"]   = pins.tftBl;
#endif
#if USE_SD
    doc["sd_cs"] = pins.sdCs; doc["sd_sck"] = pins.sdSck;
    doc["sd_mosi"] = pins.sdMosi; doc["sd_miso"] = pins.sdMiso;
#endif
#if USE_MP3_PLAYER
    doc["mp3_tx"] = pins.mp3Tx; doc["mp3_rx"] = pins.mp3Rx;
#endif
#if USE_RADIO
    doc["i2s_bclk"] = pins.i2sBclk; doc["i2s_lrck"] = pins.i2sLrck;
    doc["i2s_dout"] = pins.i2sDout;
#endif
#if USE_IR_RECEIVER
    doc["ir_pin"] = pins.irPin;
#endif
#if USE_RF_RECEIVER
    doc["rf_pin"] = pins.rfPin;
#endif
    String out;
    serializeJson(doc, out);
    HTTP.send(200, "application/json", out);
  });

  HTTP.on("/save_pins", HTTP_GET, []() {
    String cfg = readFile("config_pins.json", 1024);
    if (cfg == "Failed" || cfg == "Large" || cfg.isEmpty()) cfg = "{}";

    auto saveIfChanged = [&](const char* key) -> bool {
      if (!HTTP.hasArg(key)) return false;
      String v = HTTP.arg(key);
      if (v.length() == 0) return false;
      if (jsonRead(cfg, key) != v) {
        jsonWrite(cfg, key, v);
        return true;
      }
      return false;
    };

    bool changed = false;
    changed |= saveIfChanged("led_pin");
    changed |= saveIfChanged("clk_pin");
    changed |= saveIfChanged("btn_pin");
    changed |= saveIfChanged("mosfet_pin");
#if USE_TM1637
    changed |= saveIfChanged("tm1637_dio");
    changed |= saveIfChanged("tm1637_clk");
#endif
#if USE_ST7789
    changed |= saveIfChanged("tft_sclk");
    changed |= saveIfChanged("tft_mosi");
    changed |= saveIfChanged("tft_cs");
    changed |= saveIfChanged("tft_dc");
    changed |= saveIfChanged("tft_rst");
    changed |= saveIfChanged("tft_bl");
#endif
#if USE_SD
    changed |= saveIfChanged("sd_cs");
    changed |= saveIfChanged("sd_sck");
    changed |= saveIfChanged("sd_mosi");
    changed |= saveIfChanged("sd_miso");
#endif
#if USE_MP3_PLAYER
    changed |= saveIfChanged("mp3_tx");
    changed |= saveIfChanged("mp3_rx");
#endif
#if USE_RADIO
    changed |= saveIfChanged("i2s_bclk");
    changed |= saveIfChanged("i2s_lrck");
    changed |= saveIfChanged("i2s_dout");
#endif
#if USE_IR_RECEIVER
    changed |= saveIfChanged("ir_pin");
#endif
#if USE_RF_RECEIVER
    changed |= saveIfChanged("rf_pin");
#endif

    if (!changed) {
      HTTP.send(200, "text/plain", "NO_CHANGE");
      return;
    }

    PinConfig backup = pins;
    writeFile(F("config_pins.json"), cfg);
    loadPinConfig();
    if (!validatePinConfig()) {
      pins = backup;
      writeFile(F("config_pins.json"), "{}");
      loadPinConfig();
      HTTP.send(400, "text/plain", "INVALID_PINS");
      return;
    }

    HTTP.send(200, "text/plain", "OK_REBOOT");
    pendingRestart = true;
  });

  // ------------------------------------------------------------------------- МП3 ПЛЕЕР ----------------------------------------------------------------

#if USE_MP3_PLAYER
  HTTP.on("/save_sound_settings", HTTP_GET, handle_save_sound_settings);
  HTTP.on("/on_sound", handle_on_sound);
  HTTP.on("/on_day_adv", handle_day_advert_on_sound);
  HTTP.on("/on_night_adv", handle_night_advert_on_sound);
  HTTP.on("/on_alm_adv", handle_alarm_advert_sound_on);
  HTTP.on("/vol", handle_volume);
  HTTP.on("/alm_vol", handle_alarm_volume);
  HTTP.on("/sun_vol", handle_sunset_volume);
  HTTP.on("/day_vol", handle_day_advert_volume);
  HTTP.on("/night_vol", handle_night_advert_volume);
  HTTP.on("/tim_h", handle_tim_h);
  HTTP.on("/tim_m", handle_tim_m);
  HTTP.on("/delay", handle_delay);
  HTTP.on("/on_alm_snd", handle_alarm_on_sound);
  HTTP.on("/on_sun_snd", handle_sunset_on_sound);
  HTTP.on("/alm_fold_sel", handle_alarm_fold_sel);
  HTTP.on("/sun_fold_sel", handle_sunset_fold_sel);
  HTTP.on("/sound_set", handle_sound_set);
  HTTP.on("/track_down", handle_folder_down);
  HTTP.on("/track_up", handle_folder_up);
  HTTP.on("/fold_sel", handle_folder_select);
  HTTP.on("/eq", handle_equalizer);
  HTTP.on("/play_time", HTTP_GET, handle_play_time);
  HTTP.on("/play_weather", HTTP_GET, handle_play_weather);
  HTTP.on("/weather_speak", HTTP_GET, handle_weather_speak);
  HTTP.on("/time_speak", HTTP_GET, handle_time_speak);
  HTTP.on("/weather_temp_delay", HTTP_GET, handle_weather_temp_delay);
  HTTP.on("/weather_desc_delay", HTTP_GET, handle_weather_desc_delay);
  HTTP.on("/weather_day_vol", handle_weather_day_volume);
  HTTP.on("/weather_night_vol", handle_weather_night_volume);
  HTTP.on("/day_weather_adv", handle_day_weather_adv);
  HTTP.on("/day_weather_desc", handle_day_weather_desc);
  HTTP.on("/night_weather_adv", handle_night_weather_adv);
  HTTP.on("/night_weather_desc", handle_night_weather_desc);
  HTTP.on("/show_weather_desc", handle_show_weather_desc);
  HTTP.on("/time_always", handle_time_always);
  HTTP.on("/weather_always", handle_weather_always);

  HTTP.on("/stop_weather_sound", HTTP_GET, []() {
    if (mp3_player_connect == 4) {
      mp3SendCmd(0x0E, 0x01, 0, 0);
      mp3_stop = true;
      pause_on = false;
      HTTP.send(200, "text/plain", "OK");
    } else {
      HTTP.send(503, "text/plain", "MP3 player not ready");
    }
  });
#endif // USE_MP3_PLAYER

  HTTP.on("/setup_sound", HTTP_GET, []() {
#ifndef USE_MP3_PLAYER
    HTTP.send(404, "text/plain", "Настройки звука отключены в прошивке");
#else
    handleFileRead("/setup_sound.htm");
#endif
  });

  // ------------------------------------------------------------------- ИНТЕРНЕТ-РАДИО ---------------------------------------------------------

#if USE_RADIO
  HTTP.on("/radio_enable", handle_radio_enable);
  HTTP.on("/radio_volume", handle_radio_volume);
  HTTP.on("/get_radio_stations", HTTP_GET, handle_get_radio_stations);
  HTTP.on("/save_radio_stations", HTTP_POST, handle_save_radio_stations);
  HTTP.on("/radio_map_batch", HTTP_POST, handle_radio_map_batch);
  HTTP.on("/setup_radio", HTTP_GET, []() {
#ifndef USE_RADIO
    HTTP.send(404, "text/plain", "Radio disabled");
#else
    handleFileRead("/setup_radio.json");
#endif
  });
#endif

  // ------------------------------------------------------------------- УПРАВЛЕНИЕ ИК ПУЛЬТАМИ ---------------------------------------------------------

#if USE_IR_RECEIVER
  // список всех пультов
  HTTP.on("/api/ir/remotes", HTTP_GET, []() {
    String remotes = irManager.getRemotesList();
    HTTP.send(200, "application/json; charset=utf-8", remotes);
  });

  // страница настройки ИК пульта
  HTTP.on("/setup_ir", HTTP_GET, []() {
    if (!handleFileRead("/setup_ir.htm")) {
      HTTP.send(404, "text/plain; charset=utf-8", "Страница не найдена");
    }
  });

  // текущий пульт
  HTTP.on("/api/ir/current", HTTP_GET, []() {
    PJsonDoc doc(256);
    doc["id"] = irManager.getCurrentRemoteId();
    doc["name"] = irManager.getCurrentRemoteName();
    String response;
    serializeJson(doc, response);
    HTTP.send(200, "application/json; charset=utf-8", response);
  });

  // установка пульта
  HTTP.on("/api/ir/set", HTTP_POST, []() {
    PJsonDoc doc(256);
    DeserializationError error = deserializeJson(doc, HTTP.arg("plain"));

    if (error) {
      HTTP.send(400, "application/json; charset=utf-8", "{\"success\":false,\"message\":\"Invalid JSON\"}");
      return;
    }

    String remoteId = doc["remote_id"];
    if (irManager.loadRemote(remoteId)) {
      PJsonDoc response(256);
      response["success"] = true;
      response["name"] = irManager.getCurrentRemoteName();
      response["id"] = irManager.getCurrentRemoteId();
      String resp;
      serializeJson(response, resp);
      HTTP.send(200, "application/json; charset=utf-8", resp);
    } else {
      HTTP.send(400, "application/json; charset=utf-8", "{\"success\":false,\"message\":\"Remote not found\"}");
    }
  });

  // обучение пульта
  String learningRemoteName = "";
  PJsonDoc learningDoc(4096);
  bool isLearning = false;

  HTTP.on("/api/ir/learn/save", HTTP_POST, []() {
    PJsonDoc doc(2048);
    DeserializationError error = deserializeJson(doc, HTTP.arg("plain"));

    if (error) {
      HTTP.send(400, "application/json; charset=utf-8", "{\"success\":false,\"message\":\"Invalid JSON\"}");
      return;
    }

    String remoteName = doc["name"].as<String>();
    if (remoteName.length() == 0) remoteName = "Мой пульт";

    File file = LittleFS.open("/ir_codes.json", "r");
    PJsonDoc jsonDoc(8192);
    if (file) {
      deserializeJson(jsonDoc, file);
      file.close();
    } else {
      jsonDoc["remotes"] = JsonArray();
    }

    String remoteId = "custom_" + String(millis());

    // новый пульт
    JsonObject newRemote = jsonDoc["remotes"].createNestedObject();
    newRemote["id"] = remoteId;
    newRemote["name"] = remoteName;
    JsonObject codes = newRemote.createNestedObject("codes");
    JsonObject learnedCodes = doc["codes"];
    for (JsonPair kv : learnedCodes) {
      codes[kv.key()] = kv.value().as<String>();
    }

    file = LittleFS.open("/ir_codes.json", "w");
    if (!file) {
      HTTP.send(500, "application/json; charset=utf-8", "{\"success\":false,\"message\":\"Cannot save file\"}");
      return;
    }
    serializeJson(jsonDoc, file);
    file.close();

    irManager.loadRemote(remoteId);

    HTTP.send(200, "application/json; charset=utf-8", "{\"success\":true,\"id\":\"" + remoteId + "\",\"name\":\"" + remoteName + "\"}");
  });

  // получение последнего ИК кода
  HTTP.on("/api/ir/last_code", HTTP_GET, []() {
    PJsonDoc doc(64);
    doc["code"] = String(lastIRCode, HEX);
    String response;
    serializeJson(doc, response);
    HTTP.send(200, "application/json; charset=utf-8", response);
    lastIRCode = 0;
  });

#endif // USE_IR_RECEIVER

  // ----------------------------------------------------------------------- НАСТРОЙКА ШРИФТА -----------------------------------------------------------

  HTTP.on("/static_font", HTTP_GET, []() {
    if (!HTTP.hasArg("static_font")) {
      HTTP.send(400, "text/plain", "Missing static_font parameter");
      return;
    }
    String arg = HTTP.arg("static_font");
    int val = arg.toInt();
    if (val < 0 || val > 3) {
      HTTP.send(400, "text/plain", "Invalid static_font value (must be 0-3)");
      return;
    }
    if (staticFont == val) {
      HTTP.send(200, "text/plain", "OK (no change)");
      return;
    }
    staticFont = val;
    jsonWrite(configLedPanel, "static_font", String(staticFont));
    saveConfig();
    loadingFlag = true;
    clockNeedRedraw = true;
    dateNeedRedraw = true;
    weatherNeedRedraw = true;
    needFullRedraw = true;
    HTTP.send(200, "text/plain", "OK");
  });

  // -------------------------------------------------------------- МОДАЛЬНЫЕ ОКНА МЕНЮ ВЭБ-ИНТЕРФЕЙСА --------------------------------------------------

#if STATUS_DEVICE
  HTTP.on("/sd_status", HTTP_GET, handle_sd_status);
  HTTP.on("/ota_status", HTTP_GET, handle_ota_status);
  HTTP.on("/mqtt_status", HTTP_GET, handle_mqtt_status);
  HTTP.on("/multilamp_status", HTTP_GET, handle_multilamp_status);
  HTTP.on("/mp3_status", HTTP_GET, handle_mp3_status);
  HTTP.on("/radio_status", HTTP_GET, handle_radio_status);
  HTTP.on("/tm1637_status", HTTP_GET, handle_tm1637_status);
  HTTP.on("/button_status", HTTP_GET, handle_button_status);
  HTTP.on("/ir_rf_status", HTTP_GET, handle_ir_rf_status);
  HTTP.on("/st7789_status", HTTP_GET, handle_st7789_status);
  HTTP.on("/show_weather", HTTP_GET, handle_show_weather);

  HTTP.on("/version", HTTP_GET, []() { // Инфа о прошивке
    PJsonDoc doc(1024);
#ifdef VERSION
    doc["version"] = VERSION;
#else
    doc["version"] = "";
#endif
    doc["build_date"] = __DATE__ " " __TIME__;

#ifdef ESP32_S3_USED
    doc["chip"] = "ESP32-S3";
#else
    doc["chip"] = "ESP32";
#endif

    doc["cpu_freq"] = ESP.getCpuFreqMHz();
    doc["flash_size"] = ESP.getFlashChipSize() / 1024 / 1024;
    doc["free_heap"] = ESP.getFreeHeap();
    doc["uptime"] = millis() / 1000UL;
    doc["welcome_page"] = Eeprom::instance().IsWelcomePageActive() ? "АКТИВНА" : "ОТКЛЮЧЕНА";
    doc["t_flag"] = T_flag;
    doc["direct_to_main"] = (T_flag == 1);

    // Wi-Fi режим
    wifi_mode_t mode = WiFi.getMode();
    String wifiModeStr;
    if (mode == WIFI_AP_STA)  wifiModeStr = "AP + Station";
    else if (mode == WIFI_AP) wifiModeStr = "AP only";
    else if (mode == WIFI_STA) wifiModeStr = "Station only";
    else                        wifiModeStr = "WiFi выключен";
    doc["wifi_mode"] = wifiModeStr;

    auto& wifi = Wifi::instance();
    bool staConnected = wifi.isConnected();
    String currentIP = staConnected ? wifi.localIP().toString() : wifi.apIP().toString();
    if (currentIP == "0.0.0.0") currentIP = "192.168.4.1";
    doc["ip_address"] = currentIP;
    doc["sta_connected"] = staConnected;
    doc["sta_ssid"] = staConnected ? wifi.getSSID() : "";
    doc["sta_rssi"] = staConnected ? wifi.getRSSI() : 0;
    doc["lamp_on"] = ONflag;
    doc["current_effect"] = currentMode;
    doc["effect_count"] = MODE_AMOUNT;

    // Статус модулей
#if USE_MP3_PLAYER
    doc["mp3_enabled"] = true;
#else
    doc["mp3_enabled"] = false;
#endif
#if USE_TM1637
    doc["tm1637_enabled"] = true;
#else
    doc["tm1637_enabled"] = false;
#endif
#if USE_ST7789
    doc["st7789_enabled"] = true;
#else
    doc["st7789_enabled"] = false;
#endif
#if USE_MQTT
    doc["mqtt_enabled"] = true;
#else
    doc["mqtt_enabled"] = false;
#endif

    String response;
    serializeJson(doc, response);
    HTTP.send(200, "application/json; charset=utf-8", response);
  });

  // IP адрес
  HTTP.on("/wifi_ip", HTTP_GET, []() {
    PJsonDoc doc(512);
    auto& wifi = Wifi::instance();
    bool staConnected = wifi.isConnected();
    doc["connected"] = staConnected;
    doc["sta_ip"] = staConnected ? wifi.localIP().toString() : "Не подключён";
    doc["ap_ip"] = wifi.apIP().toString();
    doc["ssid"] = staConnected ? wifi.getSSID() : "";
    doc["rssi"] = staConnected ? wifi.getRSSI() : 0;
    String ap = doc["ap_ip"].as<String>();
    if (ap == "0.0.0.0") doc["ap_ip"] = "192.168.4.1";
    String response;
    serializeJson(doc, response);
    HTTP.send(200, "application/json; charset=utf-8", response);
  });

#endif // STATUS_DEVICE

  // ------------------------------------------------------------
#if SOFT_INFO
  HTTP.on("/get_version", HTTP_GET, []() {
    StaticJsonDocument<512> doc;
    String resp;

    doc["mod_author"] = "AnCore";
    doc["current_version"] = String(VERSION);
    doc["build_datetime"] = buildDateTimeString();
    doc["folder_url"] = "https://github.com/an-core/FieryLedLamp_mod/tree/main/FieryLedLamp_mod";

    serializeJson(doc, resp);
    HTTP.send(200, "application/json; charset=utf-8", resp);
  });

#if USE_UPDATE_CHECK
  HTTP.on("/check_update", HTTP_GET, []() {
    if (updateCache.valid && (millis() - updateCache.timestamp < 600000)) {
      HTTP.send(200, "application/json; charset=utf-8", updateCache.response);
      return;
    }

    if (updateCheckInProgress) {
      PJsonDoc doc(256);
      doc["has_update"] = false;
      doc["message"] = "Проверка обновлений уже выполняется, попробуйте позже";
      String resp;
      serializeJson(doc, resp);
      HTTP.send(200, "application/json; charset=utf-8", resp);
      return;
    }

    if (!updateCheckPending) {
      updateCheckPending = true;
      PJsonDoc doc(256);
      doc["has_update"] = false;
      doc["message"] = "Проверка обновлений запущена, обновите страницу через минуту";
      String resp;
      serializeJson(doc, resp);
      HTTP.send(200, "application/json; charset=utf-8", resp);
      return;
    }

    HTTP.send(200, "application/json; charset=utf-8", "{\"has_update\":false,\"message\":\"Попробуйте позже\"}");
  });
#endif

#endif // SOFT_INFO

  // --------------------------------------------------------------------

  // информация о памяти
#if USE_MEMORY_INFO
  HTTP.on("/heap", HTTP_GET, []() {
    PJsonDoc doc(1536);

    // DRAM (внутренняя память)
    uint32_t freeDram = heap_caps_get_free_size(MALLOC_CAP_INTERNAL);
    uint32_t totalDram = heap_caps_get_total_size(MALLOC_CAP_INTERNAL);
    uint32_t largestDram = heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL);
    uint32_t minFreeDram = heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL);

    // PSRAM
    uint32_t freePsram  = 0;
    uint32_t totalPsram = 0;
    bool hasPsram = false;
    String chip = "ESP32";

#ifdef ESP32_S3_USED
    totalPsram = ESP.getPsramSize();
    freePsram = ESP.getFreePsram();
    hasPsram = true;
    chip = "ESP32-S3";
#else
    if (psramFound()) {
      totalPsram = ESP.getPsramSize();
      freePsram = ESP.getFreePsram();
      hasPsram = true;
    }
#endif

    doc["chip"] = chip;
    doc["free"] = freeDram;
    doc["largest"] = largestDram;
    doc["min_free"] = minFreeDram;
    doc["total_dram"] = totalDram;
    doc["free_psram"] = freePsram;
    doc["total_psram"] = totalPsram;
    doc["total"] = totalDram + totalPsram;
    doc["free_total"] = freeDram + freePsram;
    doc["psram"] = hasPsram;
    doc["uptime"] = millis() / 1000UL;

    String response;
    serializeJson(doc, response);
    HTTP.send(200, "application/json", response);
  });
#endif // USE_MEMORY_INFO

  // ---------------------------------------------------------------------- СКРЫТИЕ ПУНКТОВ МЕНЮ --------------------------------------------------------

  HTTP.on("/features", HTTP_GET, []() {
    PJsonDoc doc(512);
    doc["mqtt"]           = !!USE_MQTT;
    doc["mp3"]            = !!USE_MP3_PLAYER;
    doc["sound"]          = !!USE_MP3_PLAYER;
    doc["radio"]          = !!USE_RADIO;
    doc["sd"]             = !!USE_SD;
    doc["ota"]            = !!USE_OTA;
    doc["update_check"]   = !!USE_UPDATE_CHECK;
    doc["tm1637"]         = !!USE_TM1637;
    doc["st7789"]         = !!USE_ST7789;
    doc["button"]         = !!USE_BUTTON;
    doc["ir"]             = !!USE_IR_RECEIVER;
    doc["ir_settings"]    = !!USE_IR_RECEIVER;
    doc["rf"]             = !!USE_RF_RECEIVER;
    doc["weather"]        = !!USE_WEATHER;
    doc["multilamp"]      = !!USE_MULTILAMP;
    doc["out_files"]      = (USE_SD && sdType == 0);
    doc["dawn"]           = !!USE_DAWN;
    doc["sunset"]         = !!USE_SUNSET;
    doc["schedule"]       = !!USE_SCHEDULE;
    doc["status_modal"]   = !!STATUS_DEVICE;
    doc["software_modal"] = !!SOFT_INFO;
    doc["memory_info"]    = !!USE_MEMORY_INFO;
    doc["led_panel"]      = !!LED_PANEL;
    doc["backup"]         = !!BACKUP_CFG_FILES;
    doc["logs"]           = !!DEBUG_ENABLED;
    doc["syslog"]         = !!DEBUG_ENABLED;
#if defined(ESP32S3) || defined(CONFIG_IDF_TARGET_ESP32S3) || defined(ARDUINO_ESP32S3_DEV)
    doc["hardware_menu"] = true;
#else
    doc["hardware_menu"] = false;
#endif

    String response;
    serializeJson(doc, response);
    HTTP.send(200, "application/json", response);
  });

  // ------------------------------------------------------------------------ MQTT ПОДКЛЮЧЕНИЕ ----------------------------------------------------------

#if USE_MQTT
  HTTP.on("/mqtt_set", handle_mqtt_set);
  HTTP.on("/mqtt_on", handle_mqtt_on);
  HTTP.on("/mqtt_prd", handle_mqtt_period);
#endif

  HTTP.on("/setup_mqtt.json.gz", HTTP_GET, []() {
    File file = LittleFS.open("/setup_mqtt.json.gz", "r");
    if (!file) { HTTP.send(404, "text/plain", "File not found"); return; }
    HTTP.sendHeader(F("Content-Disposition"), F("attachment; filename=\"setup_mqtt.json.gz\""));
    HTTP.streamFile(file, F("application/octet-stream"));
    file.close();
});

  // ------------------------------------------------------------- ОБНОВЛЕНИЕ ПРОШИВКИ ПО ВОЗДУХУ (OTA) -------------------------------------------------

#if USE_OTA
  // страница OTA ОБНОВЛЕНИЕ
  HTTP.on("/update", HTTP_GET, []() {
    if (!Wifi::instance().isConnected()) {
      HTTP.send(403, "text/plain; charset=utf-8", "WiFi не подключён");
      return;
    }
    if (!handleFileRead("/update.htm")) {
      HTTP.send(404, "text/plain; charset=utf-8", "Страница обновления не найдена");
    }
  });

  HTTP.on("/ota_ip", HTTP_GET, []() {
    auto& wifi = Wifi::instance();
    String ip = wifi.isConnected() ? wifi.localIP().toString() : wifi.apIP().toString();
    if (ip == "0.0.0.0") ip = "192.168.4.1";
    HTTP.send(200, "text/plain", ip);
  });

  // обновление прошивки
  HTTP.on("/update_upload", HTTP_POST, []() {
    HTTP.send(200, "text/plain", "OK");
  }, []() {
    static bool updateStarted = false;
    static uint32_t expectedSize = 0;
    static uint32_t totalReceived = 0;

    HTTPUpload& upload = HTTP.upload();

    if (upload.status == UPLOAD_FILE_START) {
      if (!requireFileManagerAuth(false)) {
        upload.status = UPLOAD_FILE_ABORTED;
        return;
      }

      updateStarted = false;
      expectedSize = upload.totalSize;
      totalReceived = 0;

      if (expectedSize == 0) {
        uint32_t maxSketchSpace = (ESP.getFreeSketchSpace() - 0x1000) & 0xFFFFF000;
        if (!Update.begin(maxSketchSpace, U_FLASH)) {
          upload.status = UPLOAD_FILE_ABORTED;
          return;
        }
        updateStarted = true;
      } else {
        uint32_t maxSketchSpace = (ESP.getFreeSketchSpace() - 0x1000) & 0xFFFFF000;

        if (expectedSize > maxSketchSpace) {
          upload.status = UPLOAD_FILE_ABORTED;
          return;
        }

        if (!Update.begin(expectedSize, U_FLASH)) {
          upload.status = UPLOAD_FILE_ABORTED;
          return;
        }
        updateStarted = true;
      }
    } else if (upload.status == UPLOAD_FILE_WRITE) {
      if (updateStarted) {
        size_t written = Update.write(upload.buf, upload.currentSize);
        if (written != upload.currentSize) {
          Update.abort();
          upload.status = UPLOAD_FILE_ABORTED;
        } else {
          totalReceived += written;
        }
      }
    } else if (upload.status == UPLOAD_FILE_END) {

      if (updateStarted && Update.end(true)) {

        HTTP.send(200, "text/plain", "SUCCESS");
        delay(100);
        delay(1000);
        ESP.restart();
      } else {
        HTTP.send(500, "text/plain", "Update failed");
      }
      updateStarted = false;
    } else if (upload.status == UPLOAD_FILE_ABORTED) {
      if (updateStarted) {
        Update.abort();
      }
      updateStarted = false;
    }
  });

  // обновление файловой системы
  HTTP.on("/update_fs", HTTP_POST, []() {}, []() {
    static bool updateStarted = false;
    static uint32_t expectedSize = 0;
    static uint32_t totalReceived = 0;

    HTTPUpload& upload = HTTP.upload();

    if (upload.status == UPLOAD_FILE_START) {
      if (!requireFileManagerAuth(false)) {
        upload.status = UPLOAD_FILE_ABORTED;
        return;
      }

      updateStarted = false;
      expectedSize = upload.totalSize;
      totalReceived = 0;

      LittleFS.end();

      delay(200);

      uint32_t maxFSSize = 0;

      const esp_partition_t* partition = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_SPIFFS, NULL);

      if (partition) {
        maxFSSize = partition->size;
      } else {
        partition = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_ANY, "littlefs");
        if (partition) {
          maxFSSize = partition->size;
        }
      }

      if (maxFSSize == 0) {
        maxFSSize = 4 * 1024 * 1024;
      }

      if (expectedSize > 0 && expectedSize > maxFSSize) {
        upload.status = UPLOAD_FILE_ABORTED;
        LittleFS.begin();
        return;
      }

      if (!Update.begin(maxFSSize, U_SPIFFS)) {
        upload.status = UPLOAD_FILE_ABORTED;
        LittleFS.begin();
        return;
      }

      updateStarted = true;
    } else if (upload.status == UPLOAD_FILE_WRITE) {
      if (updateStarted) {
        size_t written = Update.write(upload.buf, upload.currentSize);
        if (written != upload.currentSize) {
          Update.abort();
          upload.status = UPLOAD_FILE_ABORTED;
        } else {
          totalReceived += written;
          if (expectedSize > 0) {
          }
        }
      }
    } else if (upload.status == UPLOAD_FILE_END) {
      if (updateStarted && Update.end(true)) {
        HTTP.send(200, "text/plain", "FS_UPDATE_SUCCESS");
        delay(100);
        delay(1000);
        ESP.restart();
      } else {
        HTTP.send(500, "text/plain", "FS update failed");
        LittleFS.begin();
      }
      updateStarted = false;
    } else if (upload.status == UPLOAD_FILE_ABORTED) {
      if (updateStarted) {
        Update.abort();
      }
      LittleFS.begin();
      updateStarted = false;
    }
  });

  // OTA обновление из Arduino IDE
  HTTP.on("/ota_request", HTTP_GET, []() {
    if (!Wifi::instance().isConnected()) {
      HTTP.send(403, "text/plain; charset=utf-8", "WiFi не подключён");
      return;
    }

    if (Ota::instance().RequestOtaUpdate()) {
      HTTP.send(200, "text/plain", "OK");
    } else {
      HTTP.send(400, "text/plain", "Не удалось запустить OTA. Возможно обновление уже выполняется?");
    }
  });

#endif // USE_OTA

  // -------------------------------------------------- ПЕРЕКЛЮЧЕНИЕ "ЧАСЫ / ПОГОДА" НА ДИСПЛЕЯХ TM1637 и ST7789 ----------------------------------------

#if (USE_TM1637 || USE_ST7789)
  HTTP.on("/save_display_switch", HTTP_GET, []() {
    int interval = HTTP.arg("value").toInt();
    if (interval >= 5 && interval <= 60) {
      jsonWrite(configSetup, "disp_switch", interval);
      saveConfig();
      DISPLAY_SWITCH_INTERVAL = (uint32_t)interval * 1000UL;
      displaySwitchTimer = millis();
      HTTP.send(200, "text/plain", "OK");
    } else if (interval == 0) {
      jsonWrite(configSetup, "disp_switch", 0);
      saveConfig();
      DISPLAY_SWITCH_INTERVAL = 0;
      HTTP.send(200, "text/plain", "OK");
    } else {
      HTTP.send(400, "text/plain", "Invalid value. Use 0 or 5-60 seconds");
    }
  });

  HTTP.on("/date_switch", HTTP_GET, []() {
    int value = HTTP.arg("value").toInt();
    dateSwitchEnabled = (value != 0);
    jsonWrite(configSetup, "date_switch", dateSwitchEnabled ? 1 : 0);
    saveConfig();
    rebuildActiveModes();
    HTTP.send(200, "text/plain", "OK");
  });

  HTTP.on("/weather_switch", HTTP_GET, []() {
    int value = HTTP.arg("value").toInt();
    weatherSwitchEnabled = (value != 0);
    jsonWrite(configSetup, "weather_switch", weatherSwitchEnabled ? 1 : 0);
    saveConfig();
    rebuildActiveModes();
    HTTP.send(200, "text/plain", "OK");
  });

#endif // (USE_TM1637 || USE_ST7789)

  // ---------------------------------------------------------------------- ПАРОЛЬ ДЛЯ РЕДАКТОРА --------------------------------------------------------

  HTTP.on("/set_local_auth", HTTP_GET, []() {
    if (!HTTP.hasArg("value")) {
      HTTP.send(400, "text/plain", "Missing value");
      return;
    }
    String val = HTTP.arg("value");
    bool newState = (val == "1" || val.equalsIgnoreCase("true") || val.equalsIgnoreCase("on"));

    if (ONflag) changePower();
    delay(200);

    jsonWrite(configSetup, "local_auth", newState ? "1" : "0");
    saveConfig();

    if (LittleFS.exists("/auth_local.txt")) LittleFS.remove("/auth_local.txt");

    HTTP.send(200, "text/html", "<html><body>OK, restart...</body></html>");
    pendingRestart = true;
  });

  // ----------------------------------------------------------------------- СИСТЕМНЫЕ ЛОГИ -------------------------------------------------------------

#if DEBUG_ENABLED
  // Чекбокс "Включить получение новых логов"
  HTTP.on("/set_syslog", HTTP_GET, []() {
    if (!HTTP.hasArg("value")) {
      HTTP.send(400, "text/plain", "Missing value");
      return;
    }

    bool newState = (HTTP.arg("value") == "1");

    SystemLog::instance().setEnabled(newState);

    jsonWrite(configSetup, "syslog_enabled", newState ? "1" : "0");
    saveConfig();

    HTTP.send(200, "text/plain", newState ? "1" : "0");
  });

  HTTP.on("/logs", HTTP_GET, []() {
    String logs = SystemLog::instance().getAll();
    HTTP.send(200, "text/plain; charset=utf-8", logs);
  });

  HTTP.on("/logs_clear", HTTP_GET, []() {
    SystemLog::instance().clear();
    HTTP.send(200, "text/plain", "OK");
  });

  HTTP.on("/logs_page", HTTP_GET, []() {
    if (!handleFileRead("/logs.htm")) {
      HTTP.send(404, "text/plain; charset=utf-8", "logs.htm not found");
    }
  });
#else
  // Заглушки, если логи отключены
  HTTP.on("/set_syslog", HTTP_GET, []() {
    HTTP.send(404, "text/plain", "Logs disabled");
  });
  HTTP.on("/logs", HTTP_GET, []() {
    HTTP.send(404, "text/plain", "Logs disabled");
  });
  HTTP.on("/logs_clear", HTTP_GET, []() {
    HTTP.send(404, "text/plain", "Logs disabled");
  });
  HTTP.on("/logs_page", HTTP_GET, []() {
    HTTP.send(404, "text/plain", "Logs disabled");
  });
#endif // DEBUG_ENABLED

  // --------------------------------------------------------------------- Wi-Fi ПОДКЛЮЧЕНИЕ ------------------------------------------------------------

  HTTP.on("/ssdp", handle_ssdp);
  HTTP.on("/save_wifi", HTTP_GET, handle_save_wifi);
  HTTP.on("/wifi_reconnect_interval", handle_wifi_reconnect_interval);
  HTTP.on("/wifi_check_interval", handle_wifi_check_interval);
  HTTP.on("/ap_always", handle_ap_always); // Чекбокс "Показывать точку доступа"
  HTTP.on("/res_to_def", handle_reset_to_default);
  HTTP.on("/reset_to_default", handle_reset_to_default);
  HTTP.on("/s_IP", handle_use_static_ip);
  HTTP.on("/set_ip", handle_set_static_ip);

  HTTP.on("/restart", HTTP_GET, []() {
    HTTP.send(200, "text/plain", "OK");
    pendingRestart = true;
  });

  HTTP.on("/display_ip", HTTP_GET, []() {  // Чекбокс "Показывать IP адрес при старте"
    int value = HTTP.arg("value").toInt();
    displayIpAtStart = (value != 0);
    jsonWrite(configSetup, "display_ip", displayIpAtStart ? 1 : 0);
    saveConfig();
    HTTP.send(200, "text/plain", displayIpAtStart ? "1" : "0");
  });


  HTTP.on("/wifi_multi", HTTP_GET, []() {
    if (HTTP.hasArg("wifi_multi")) {
      int val = HTTP.arg("wifi_multi").toInt();
      jsonWrite(configWiFi, "wifi_multi", val);
      saveConfig();
      wifi_multi_enabled = val;
      HTTP.send(200, "text/plain", "OK");
    } else {
      HTTP.send(400, "text/plain", "Missing parameter");
    }
  });

  // Точка доступа
  HTTP.on("/ssidap", HTTP_GET, []() {
    String newSSID = HTTP.arg("ssidAP");
    String newPass = HTTP.arg("passwordAP");
    if (newSSID.length() == 0) newSSID = jsonRead(configWiFi, "ssidAP");
    if (newPass.length() == 0) newPass = jsonRead(configWiFi, "passwordAP");

    jsonWrite(configWiFi, "ssidAP", newSSID);
    jsonWrite(configWiFi, "passwordAP", newPass);
    saveConfig();

    Wifi::instance().setAPSettings(newSSID, newPass);
    Wifi::instance().requestRestartAP();

    HTTP.send(200, "text/plain", "OK");
  });

} // User_settings()

// ========================================================================== ОБРАБОТЧИКИ =============================================================

// Имя лампы
void handle_ssdp() {
  if (!HTTP.hasArg("ssdp")) {
    HTTP.send(400, "text/plain", "Missing ssdp");
    return;
  }
  jsonWrite(configSetup, "ssdp", HTTP.arg("ssdp"));
  SSDP.setName(jsonRead(configSetup, "ssdp"));
  saveConfig();
  LAMP_NAME = jsonRead(configSetup, "ssdp");
  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

// ----------------------------------------------------------------------------- WI-FI ----------------------------------------------------------------

// Показывать точку доступа всегда
void handle_ap_always() {
  if (!HTTP.hasArg("ap_always")) {
    HTTP.send(400, "text/plain", "Missing parameter");
    return;
  }

  bool newVal = (HTTP.arg("ap_always") == "1" || HTTP.arg("ap_always").toInt() == 1);
  bool oldVal = Always_ap;

  if (newVal == oldVal) {
    HTTP.send(200, "text/plain", newVal ? "1" : "0");
    return;
  }

  Wifi::instance().setAPAlways(newVal);
  Always_ap = newVal;

  HTTP.send(200, "text/plain", newVal ? "1" : "0");
}

void handle_wifi_reconnect_interval() {
  if (!HTTP.hasArg("interval")) {
    HTTP.send(400, "text/plain", "Parameter missing");
    return;
  }

  uint32_t interval = HTTP.arg("interval").toInt();
  interval = constrain(interval, 10, 300);
  Wifi::instance().setReconnectInterval(interval);

  jsonWrite(configWiFi, "wifi_reconnect_interval", String(interval));
  saveConfig();

  HTTP.send(200, "text/plain", "OK");
}

void handle_wifi_check_interval() {
  if (!HTTP.hasArg("interval")) {
    HTTP.send(400, "text/plain", "Parameter missing");
    return;
  }

  uint32_t interval = HTTP.arg("interval").toInt();
  interval = constrain(interval, 1, 30); // минуты
  Wifi::instance().setCheckInterval(interval);

  jsonWrite(configWiFi, "wifi_check_interval", String(interval));
  saveConfig();

  HTTP.send(200, "text/plain", "OK");
}

void handle_save_wifi() {
  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configWiFi.length() == 0 || deserializeJson(cfg, configWiFi)) {
    cfg.clear(); cfg.to<JsonObject>();
  }

  if (HTTP.hasArg("ssid"))     cfg["ssid"]     = HTTP.arg("ssid");
  if (HTTP.hasArg("password")) cfg["password"] = HTTP.arg("password");

  for (int i = 2; i <= 5; i++) {
    String ssidKey = "ssid" + String(i);
    String passKey = "password" + String(i);
    if (HTTP.hasArg(ssidKey)) cfg[ssidKey] = HTTP.arg(ssidKey);
    if (HTTP.hasArg(passKey)) cfg[passKey] = HTTP.arg(passKey);
  }

  if (HTTP.hasArg("wifi_timeout")) {
    int to = HTTP.arg("wifi_timeout").toInt();
    if (to < 10 || to > 600) to = 30;
    cfg["wifi_timeout"] = to;
    Wifi::instance().setWiFiTimeout(to);
  }
  if (HTTP.hasArg("forced_ap_after")) {
    int minutes = HTTP.arg("forced_ap_after").toInt();
    if (minutes >= 1 && minutes <= 30) {
      cfg["forced_ap_after"] = minutes;
      Wifi::instance().setForcedAPTimeout(minutes);
    }
  }
  if (HTTP.hasArg("wifi_reconnect_interval")) {
    int ri = constrain(HTTP.arg("wifi_reconnect_interval").toInt(), 30, 300);
    cfg["wifi_reconnect_interval"] = ri;
    Wifi::instance().setReconnectInterval(ri);
  }
  if (HTTP.hasArg("wifi_check_interval")) {
    int ci = constrain(HTTP.arg("wifi_check_interval").toInt(), 1, 30);
    cfg["wifi_check_interval"] = ci;
    Wifi::instance().setCheckInterval(ci);
  }
  if (HTTP.hasArg("wifi_multi")) {
    cfg["wifi_multi"] = HTTP.arg("wifi_multi").toInt();
  }
  if (HTTP.hasArg("ap_always")) {
    int apAlways = HTTP.arg("ap_always").toInt();
    cfg["ap_always"] = apAlways;
    Wifi::instance().setAPAlways(apAlways);
    Always_ap = apAlways;
  }

  configWiFi = "";
  configWiFi.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configWiFi);
  saveConfig();

  HTTP.send(200, "text/plain", "OK_REBOOT");
  pendingRestart = true;
}

void handle_use_static_ip() {
  if (!HTTP.hasArg("s_IP")) {
    HTTP.send(400, "text/plain", "Missing s_IP");
    return;
  }

  int val = HTTP.arg("s_IP").toInt();
  if (val != 0 && val != 1) {
    HTTP.send(400, "text/plain", "Invalid s_IP (must be 0 or 1)");
    return;
  }

  bool enable = (val == 1);
  jsonWrite(configWiFi, "s_IP", enable ? "1" : "0");
  saveConfig();

  HTTP.send(200, "text/plain", "OK_REBOOT");
  pendingRestart = true;
}

void handle_set_static_ip() {
  IPAddress ip, gateway, subnet, dns;

  bool dnsOk = dns.fromString(HTTP.arg("dns"));
  if (!dnsOk) dns = IPAddress(8, 8, 8, 8);

  if (ip.fromString(HTTP.arg("ip")) && gateway.fromString(HTTP.arg("gateway")) && subnet.fromString(HTTP.arg("subnet"))) {
    Wifi::instance().setStaticIP(ip, gateway, subnet, dns);
    saveConfig();
    pendingRestart = true;
    HTTP.send(200, "application/json", "{\"should_refresh\": \"true\"}");
  } else {
    HTTP.send(400, "text/plain", "Invalid IP format");
  }
}

// ----------------------------------------------------------------------- НАСТРОЙКИ КНОПКИ -----------------------------------------------------------

#if USE_BUTTON
void handle_button_type() {
  if (!HTTP.hasArg("button_type")) {
    HTTP.send(400, "text/plain", "Missing button_type");
    return;
  }
  configButton = readFile(F("config_button.json"), 1024);
  if (configButton == "Failed" || configButton == "Large" || configButton.isEmpty()) {
    configButton = "{}";
  }
  button_type = HTTP.arg("button_type").toInt();
  if (button_type > 1) button_type = 1;
  jsonWrite(configButton, "button_type", button_type);
  writeFile(F("config_button.json"), configButton);

  jsonWrite(configSetup, "button_type", button_type);
  saveConfig();

  if (button_type) {
    touch.setType(LOW_PULL);
    touch.setDebounce(BUTTON_SET_DEBOUNCE_SENSORY);
  } else {
    touch.setType(HIGH_PULL);
    touch.setDebounce(BUTTON_SET_DEBOUNCE_MECHANICAL);
  }
  touch.setDirection(NORM_OPEN);
  touch.setTimeout(BUTTON_CLICK_TIMEOUT);
  touch.setStepTimeout(BUTTON_STEP_TIMEOUT);

  HTTP.send(200, "application/json", "{\"should_refresh\": \"true\"}");
}

void handle_save_btn_clicks() {
  const char* required[] = {"btn_click_power", "btn_click_next", "btn_click_prev", "btn_click_action4", "btn_click_ip", "btn_click_time", "btn_click_sound", "btn_click_weather"};
  for (const char* arg : required) {
    if (!HTTP.hasArg(arg)) {
      HTTP.send(400, "text/plain", String("Missing ") + arg);
      return;
    }
  }

  configButton = readFile(F("config_button.json"), 1024);
  if (configButton == "Failed" || configButton == "Large" || configButton.isEmpty()) {
    configButton = "{}";
  }

  PJsonDoc cfg(1024);
  if (deserializeJson(cfg, readFile(F("config_button.json"), 1024))) {
    cfg.clear(); cfg.to<JsonObject>();
  }

  btn_click_power = HTTP.arg("btn_click_power").toInt();
  btn_click_next = HTTP.arg("btn_click_next").toInt();
  btn_click_prev = HTTP.arg("btn_click_prev").toInt();
  btn_click_action4 = HTTP.arg("btn_click_action4").toInt();
  btn_click_ip = HTTP.arg("btn_click_ip").toInt();
  btn_click_time = HTTP.arg("btn_click_time").toInt();
  btn_click_sound = HTTP.arg("btn_click_sound").toInt();
  btn_click_weather = HTTP.arg("btn_click_weather").toInt();

  cfg["btn_click_power"] = btn_click_power;
  cfg["btn_click_next"] = btn_click_next;
  cfg["btn_click_prev"] = btn_click_prev;
  cfg["btn_click_action4"] = btn_click_action4;
  cfg["btn_click_ip"] = btn_click_ip;
  cfg["btn_click_time"] = btn_click_time;
  cfg["btn_click_sound"] = btn_click_sound;
  cfg["btn_click_weather"] = btn_click_weather;

  String out;
  out.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, out);
  writeFile(F("config_button.json"), out);

  HTTP.send(200, "application/json", "{\"should_refresh\": \"true\"}");
}

#endif // USE_BUTTON

// ----------------------------------------------------------------------- НАСТРОЙКИ МП3 ПЛЕЕРА -------------------------------------------------------

#if USE_MP3_PLAYER
// Сохранение настроек
void handle_save_sound_settings() {
  uint8_t tmp;
  if (HTTP.hasArg("tim_h")) {
    tmp = constrain(HTTP.arg("tim_h").toInt(), 8, 40);
    ADVERT_TIMER_H = 100UL * tmp;
    jsonWrite(configMP3, "tim_h", tmp);
  }
  if (HTTP.hasArg("tim_m")) {
    tmp = constrain(HTTP.arg("tim_m").toInt(), 8, 45);
    ADVERT_TIMER_M = 100UL * tmp;
    jsonWrite(configMP3, "tim_m", tmp);
  }
  if (HTTP.hasArg("delay")) {
    tmp = constrain(HTTP.arg("delay").toInt(), 3, 23);
    mp3_delay = 10UL * tmp;
    jsonWrite(configMP3, "delay", tmp);
  }
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// --------------------- Чекбоксы ------------------------
// Чекбокс "Включить звук"
void handle_on_sound() {
  eff_sound_on = HTTP.arg("on_sound").toInt();
  jsonWrite(configMP3, "on_sound", eff_sound_on);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Озвучивание времени днём"
void handle_day_advert_on_sound() {
  day_advert_sound_on = HTTP.arg("on_day_adv").toInt();
  jsonWrite(configMP3, "on_day_adv", day_advert_sound_on);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Озвучивание времени ночью"
void handle_night_advert_on_sound() {
  night_advert_sound_on = HTTP.arg("on_night_adv").toInt();
  jsonWrite(configMP3, "on_night_adv", night_advert_sound_on);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Озвучивать время на выключенной лампе"
void handle_time_always() {
  time_always = HTTP.arg("time_always").toInt();
  jsonWrite(configMP3, "time_always", time_always);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Озвучивать погоду на выключенной лампе"
void handle_weather_always() {
  weather_always = HTTP.arg("weather_always").toInt();
  jsonWrite(configMP3, "weather_always", weather_always);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Озвучивать температуру погоды днём"
void handle_day_weather_adv() {
  day_weather_temp_on = HTTP.arg("on_day_wadv").toInt();
  jsonWrite(configMP3, "on_day_wadv", day_weather_temp_on);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Озвучивать описание погоды днём"
void handle_day_weather_desc() {
  day_weather_desc_on = HTTP.arg("on_day_wdesc").toInt();
  jsonWrite(configMP3, "on_day_wdesc", day_weather_desc_on);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Озвучивать температуру погоды ночью"
void handle_night_weather_adv() {
  night_weather_temp_on = HTTP.arg("on_night_wadv").toInt();
  jsonWrite(configMP3, "on_night_wadv", night_weather_temp_on);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Озвучивать описание погоды ночью"
void handle_night_weather_desc() {
  night_weather_desc_on = HTTP.arg("on_night_wdesc").toInt();
  jsonWrite(configMP3, "on_night_wdesc", night_weather_desc_on);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Озвучивать время будильником"
void handle_alarm_advert_sound_on() {
  alarm_advert_sound_on = HTTP.arg("on_alm_adv").toInt();
  jsonWrite(configMP3, "on_alm_adv", alarm_advert_sound_on);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Озвучивать погоду" (аналог времени: отключает автоматическое озвучивание, но кнопка всегда работает)
void handle_weather_speak() {
  if (HTTP.hasArg("value")) {
    weatherSpeakEnabled = (HTTP.arg("value") == "1");
    jsonWrite(configMP3, "weather_speak", weatherSpeakEnabled ? "1" : "0");
    writeFile(F("config_mp3.json"), configMP3);
  }
  HTTP.send(200, "text/plain", weatherSpeakEnabled ? "1" : "0");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Озвучивать время" (аналог погоды: отключает автоматическое озвучивание, но кнопка всегда работает)
void handle_time_speak() {
  if (HTTP.hasArg("value")) {
    timeAnnounceEnabled = (HTTP.arg("value") == "1");
    jsonWrite(configMP3, "time_speak", timeAnnounceEnabled ? "1" : "0");
    writeFile(F("config_mp3.json"), configMP3);
  }
  HTTP.send(200, "text/plain", timeAnnounceEnabled ? "1" : "0");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Включить звук будильника"
void handle_alarm_on_sound() {
  alarm_sound_on = HTTP.arg("on_alm_snd").toInt();
  jsonWrite(configMP3, "on_alm_snd", alarm_sound_on);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Включить звук режима Закат"
void handle_sunset_on_sound() {
  sunset_sound_on = HTTP.arg("on_sun_snd").toInt();
  jsonWrite(configMP3, "on_sun_snd", sunset_sound_on);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Показывать описание погоды"
void handle_show_weather_desc() {
  if (HTTP.hasArg("value")) {
    show_weather_desc = HTTP.arg("value").toInt();
    jsonWrite(configMP3, "show_weather_desc", show_weather_desc);
    writeFile(F("config_mp3.json"), configMP3);
  }
  HTTP.send(200, F("text/plain"), show_weather_desc ? "1" : "0");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// --------------------- Регулировка ------------------------
// Общая гроикость
void handle_volume() {
  eff_volume = constrain(HTTP.arg("vol").toInt(), 0, 30);
  jsonWrite(configMP3, "vol", eff_volume);
  if (mp3Enabled && !dawnflag_sound && !sunsetflag_sound && !isAnnouncing)
    mp3SendCmd(0x06, FEEDBACK, 0, eff_volume);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, "text/plain", String(eff_volume));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Громкость будильника Рассвет
void handle_alarm_volume() {
  alarm_volume = constrain(HTTP.arg("alm_vol").toInt(), 0, 30);
  jsonWrite(configMP3, "alm_vol", alarm_volume);
  if (mp3Enabled && dawnflag_sound) mp3SendCmd(0x06, FEEDBACK, 0, alarm_volume);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, "text/plain", String(alarm_volume));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Громкость режима Закат
void handle_sunset_volume() {
  sunset_volume = constrain(HTTP.arg("sun_vol").toInt(), 0, 30);
  jsonWrite(configMP3, "sun_vol", sunset_volume);
  if (mp3Enabled && sunsetflag_sound) mp3SendCmd(0x06, FEEDBACK, 0, sunset_volume);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, "text/plain", String(sunset_volume));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Громкость озвучивания времени днём
void handle_day_advert_volume() {
  day_advert_volume = constrain(HTTP.arg("day_vol").toInt(), 0, 30);
  jsonWrite(configMP3, "day_vol", day_advert_volume);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, "text/plain", String(day_advert_volume));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Громкость озвучивания времени ночью
void handle_night_advert_volume() {
  night_advert_volume = constrain(HTTP.arg("night_vol").toInt(), 0, 30);
  jsonWrite(configMP3, "night_vol", night_advert_volume);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, "text/plain", String(night_advert_volume));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Длительность звучания часов
void handle_tim_h() {
  uint8_t tmp = constrain(HTTP.arg("tim_h").toInt(), 8, 40);
  ADVERT_TIMER_H = 100UL * tmp;
  jsonWrite(configMP3, "tim_h", tmp);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, "text/plain", String(tmp));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Длительность звучания минут
void handle_tim_m() {
  uint8_t tmp = constrain(HTTP.arg("tim_m").toInt(), 8, 45);
  ADVERT_TIMER_M = 100UL * tmp;
  jsonWrite(configMP3, "tim_m", tmp);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, "text/plain", String(tmp));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Задержка между командами
void handle_delay() {
  uint8_t tmp = constrain(HTTP.arg("delay").toInt(), 3, 23);
  mp3_delay = 10UL * tmp;
  jsonWrite(configMP3, "delay", tmp);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, "text/plain", String(tmp));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Громкость погоды днём
void handle_weather_day_volume() {
  weather_day_volume = constrain(HTTP.arg("val").toInt(), 0, 30);
  jsonWrite(configMP3, "weather_day_vol", weather_day_volume);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, "text/plain", String(weather_day_volume));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Громкость погоды ночью
void handle_weather_night_volume() {
  weather_night_volume = constrain(HTTP.arg("val").toInt(), 0, 30);
  jsonWrite(configMP3, "weather_night_vol", weather_night_volume);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, "text/plain", String(weather_night_volume));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Пауза после температуры (перед описанием)
void handle_weather_temp_delay() {
  uint8_t tmp = constrain(HTTP.arg("weather_temp_delay").toInt(), 5, 60);
  ADVERT_TIMER_1 = 100UL * tmp; // 500 - 6000 мс
  jsonWrite(configMP3, "weather_temp_delay", tmp);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, "text/plain", String(tmp));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Пауза после описания (перед завершением озвучки)
void handle_weather_desc_delay() {
  uint8_t tmp = constrain(HTTP.arg("weather_desc_delay").toInt(), 10, 80);
  ADVERT_TIMER_2 = 100UL * tmp; // 1000 - 8000 мс
  jsonWrite(configMP3, "weather_desc_delay", tmp);
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, "text/plain", String(tmp));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// --------------------- Озвучка ------------------------
// Озвучка времени (по кнопке)
void handle_play_time() {
  if (mp3Enabled && mp3_player_connect == 4 && !isAnnouncing && !alarm_sound_flag && !sunset_sound_flag) {
    Time::instance().forcesync();
    previous_folder = mp3_folder;
    mp3_pending_time_advert = true;
    mp3_pending_time_force = true;
    HTTP.send(200, "text/plain", "OK");
  } else {
    HTTP.send(503, "text/plain", "MP3 not ready, sound off or already speaking");
  }
}

// Озвучка погоды (по кнопке)
void handle_play_weather() {
#if USE_WEATHER
  if (mp3Enabled && mp3_player_connect == 4 && !isAnnouncing && !alarm_sound_flag && !sunset_sound_flag) {
    mp3_pending_weather_advert = true;
    mp3_pending_weather_force = true;
    HTTP.send(200, "text/plain", "OK");
  }
  else {
    HTTP.send(503, "text/plain", "MP3 not ready, sound off or already speaking");
  }
#else
  HTTP.send(503, "text/plain", "Weather disabled in firmware");
#endif
}

// ----------------------------------------------------------------------
// Папка будильника
void handle_alarm_fold_sel() {
  AlarmFolder = HTTP.arg("alm_fold").toInt();
  jsonWrite(configMP3, "alm_fold", AlarmFolder);
  writeFile(F("config_mp3.json"), configMP3);
  if (mp3Enabled && alarm_sound_flag) {
    mp3_folder = AlarmFolder;
    mp3_folder_last = mp3_folder;
    mp3SendPlayFolder(mp3_folder);
  }
  HTTP.send(200, F("text/plain"), F("OK"));
}

// Папка Заката
void handle_sunset_fold_sel() {
  SunsetFolder = HTTP.arg("sun_fold").toInt();
  jsonWrite(configMP3, "sun_fold", SunsetFolder);
  writeFile(F("config_mp3.json"), configMP3);
  if (mp3Enabled && sunset_sound_flag) {
    mp3_folder = SunsetFolder;
    mp3_folder_last = mp3_folder;
    mp3SendPlayFolder(mp3_folder);
  }
  HTTP.send(200, F("text/plain"), F("OK"));
}

void handle_sound_set() {
  PJsonDoc cfg(2048);
  if (deserializeJson(cfg, readFile(F("sound_list.json"), 2048))) {
    cfg.clear(); cfg.to<JsonObject>();
  }
  for (uint8_t k = 0; k < MODE_AMOUNT; k++) {
    String e = "e" + String(k);
    if (!first_entry) cfg[e] = HTTP.arg(e).toInt();
    effects_folders[k] = cfg[e] | 0;
  }
  if (!first_entry) {
    String out;
    out.reserve(measureJson(cfg) + 1);
    serializeJson(cfg, out);
    writeFile(F("sound_list.json"), out);
  }
  HTTP.send(200, F("text/plain"), F("OK"));
}

void handle_folder_down() {
  CurrentFolder = constrain(CurrentFolder - 1, 0, 99);
  jsonWrite(configMP3, "fold_sel", CurrentFolder);
  writeFile(F("config_mp3.json"), configMP3);
  if (mp3Enabled && !pause_on && !mp3_stop && eff_sound_on && !isAnnouncing) {
    mp3SendCmd(0x17, FEEDBACK, 0, CurrentFolder);
  }
  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
}

void handle_folder_up() {
  CurrentFolder = constrain(CurrentFolder + 1, 0, 99);
  jsonWrite(configMP3, "fold_sel", CurrentFolder);
  writeFile(F("config_mp3.json"), configMP3);
  if (mp3Enabled && !pause_on && !mp3_stop && eff_sound_on && !isAnnouncing) {
    mp3SendCmd(0x17, FEEDBACK, 0, CurrentFolder);
  }
  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
}

void handle_folder_select() {
  CurrentFolder = constrain(HTTP.arg("fold_sel").toInt(), 0, 99);
  jsonWrite(configMP3, "fold_sel", CurrentFolder);
  writeFile(F("config_mp3.json"), configMP3);
  if (mp3Enabled && !pause_on && !mp3_stop && eff_sound_on && !isAnnouncing) {
    mp3SendCmd(0x17, FEEDBACK, 0, CurrentFolder);
  }
  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
}

// ----------------------------------------------------------------------
// Эквалайзер
void handle_equalizer() {
  Equalizer = constrain(HTTP.arg("eq").toInt(), 0, 5);
  jsonWrite(configMP3, "eq", Equalizer);
  if (mp3Enabled) {
    mp3SendCmd(0x07, FEEDBACK, 0, Equalizer);
  }
  writeFile(F("config_mp3.json"), configMP3);
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

#endif // USE_MP3_PLAYER

// ------------------------------------------------------------------------ ИНТЕРНЕТ-РАДИО ------------------------------------------------------------

#if USE_RADIO
void handle_get_radio_stations() {
  PJsonDoc doc(8192);
  if (deserializeJson(doc, configRadio) != DeserializationError::Ok) doc.clear();

  JsonObject src = doc.as<JsonObject>();
  PJsonDoc out(8192);
  JsonObject o = out.to<JsonObject>();

  JsonArray stations = o.createNestedArray("stations");
  JsonArray srcStations = src["stations"].as<JsonArray>();

  if (srcStations) {
    for (JsonObject st : srcStations) {
      JsonObject copy = stations.createNestedObject();
      copy["name"] = st["name"].as<String>();
      copy["url"] = st["url"].as<String>();
    }
  }

  JsonObject map = o.createNestedObject("map");
  JsonObject eff = src["effects"].as<JsonObject>();
  if (!eff) eff = src["map"].as<JsonObject>();

  if (eff) {
    for (JsonPair kv : eff) {
      int v = kv.value().as<int>();
      if (v > 0 && v <= 255) {
        map[kv.key()] = v;
      }
    }
  }

  o["volume"] = src["volume"] | radioVolume;
  o["enabled"] = radioEnabled ? 1 : 0;

  uint8_t currentUiIndex = 0;
  for (uint8_t i = 0; i < MODE_AMOUNT; i++) {
    if (eff_num_correct[i] == currentMode) {
      currentUiIndex = i;
      break;
    }
  }
  o["current_effect"] = currentUiIndex;

  uint8_t currentStationId = 0;
  if (currentUiIndex < MODE_AMOUNT) {
    currentStationId = effects_stations[currentUiIndex];
  }
  o["current_station"] = currentStationId;

  size_t need = measureJson(out) + 1;
  if (need > 16384) {
    HTTP.send(500, "text/plain", "response too large");
    return;
  }
  // PSRAM, если доступна (иначе обычная куча)
  char* buf = (char*)heap_caps_malloc(need, MALLOC_CAP_SPIRAM);
  if (!buf) buf = (char*)heap_caps_malloc(need, MALLOC_CAP_8BIT);
  if (!buf) {
    HTTP.send(503, "text/plain", "low memory");
    return;
  }
  serializeJson(out, buf, need);
  String response(buf);
  heap_caps_free(buf);
  HTTP.send(200, "application/json; charset=utf-8", response);
}

void handle_radio_volume() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  radioVolume = constrain(HTTP.arg("value").toInt(), 0, 21);
  radioSetVolume(radioVolume);

  PJsonDoc doc(8192);
  if (configRadio.length() == 0 || deserializeJson(doc, configRadio) != DeserializationError::Ok) {
    doc.clear();
    doc.to<JsonObject>();
  }
  doc["volume"] = radioVolume;

  configRadio = "";
  serializeJson(doc, configRadio);
  writeFile(F("config_radio.json"), configRadio);

  HTTP.send(200, "text/plain", "OK");
}

void handle_save_radio_stations() {
  if (!HTTP.hasArg("plain")) {
    HTTP.send(400, "text/plain", "Missing body");
    return;
  }
  PJsonDoc req(8192);
  if (deserializeJson(req, HTTP.arg("plain")) != DeserializationError::Ok) {
    HTTP.send(400, "text/plain", "Invalid JSON");
    return;
  }
  JsonArray stations = req["stations"].as<JsonArray>();
  if (!stations) {
    HTTP.send(400, "text/plain", "No stations array");
    return;
  }

  PJsonDoc doc(8192);
  if (deserializeJson(doc, configRadio) != DeserializationError::Ok) doc.clear();

  // пересборка станции
  JsonArray dst = doc.createNestedArray("stations");
  for (JsonObject st : stations) {
    JsonObject o = dst.createNestedObject();
    o["name"] = st["name"].as<String>();
    o["url"] = st["url"].as<String>();
  }

  // привязки эффектов
  JsonObject eff = doc["effects"].as<JsonObject>();
  if (!eff) eff = doc["map"].as<JsonObject>();
  if (!eff) eff = doc.createNestedObject("effects");

  size_t newCount = stations.size();
  for (JsonPair kv : eff) {
    int stId = kv.value().as<int>();
    if (stId > (int)newCount) {
      eff[kv.key()] = 0;
    }
  }

  if (doc["volume"].isNull()) doc["volume"] = radioVolume;

  configRadio = "";
  serializeJson(doc, configRadio);
  writeFile(F("config_radio.json"), configRadio);

  for (uint8_t i = 0; i < MODE_AMOUNT; i++) {
    effects_stations[i] = eff[String(i)] | 0;
  }

  HTTP.send(200, "text/plain", "OK");
}

void handle_radio_map_batch() {
  if (!HTTP.hasArg("plain")) {
    HTTP.send(400, "text/plain", "Missing body");
    return;
  }

  PJsonDoc req(8192);
  if (deserializeJson(req, HTTP.arg("plain")) != DeserializationError::Ok) {
    HTTP.send(400, "text/plain", "Invalid JSON");
    return;
  }

  PJsonDoc doc(8192);
  if (deserializeJson(doc, configRadio) != DeserializationError::Ok) doc.clear();

  JsonObject eff = doc["effects"].as<JsonObject>();
  if (!eff) eff = doc["map"].as<JsonObject>();
  if (!eff) eff = doc.createNestedObject("effects");

  eff.clear();

  for (JsonPair kv : req.as<JsonObject>()) {
    uint8_t effectId = constrain(atoi(kv.key().c_str()), 0, MODE_AMOUNT - 1);
    int rawStationId = kv.value().as<int>();
    if (rawStationId < 1 || rawStationId > 255) continue;
    eff[String(effectId)] = (uint8_t)rawStationId;
  }

  for (uint8_t i = 0; i < MODE_AMOUNT; i++) {
    effects_stations[i] = eff[String(i)] | 0;
  }

  if (doc["volume"].isNull()) doc["volume"] = radioVolume;
  configRadio = "";
  serializeJson(doc, configRadio);
  writeFile(F("config_radio.json"), configRadio);

  HTTP.send(200, "text/plain", "OK");
}
#endif

// ------------------------------------------------------ РЕГУЛИРОВКА НАСТРОЕК ЭФФЕКТОВ НА ГЛАВНОЙ СТРАНИЦЕ -------------------------------------------

// Общая яркость
void handle_all_br() {
  int val = constrain(HTTP.arg("all_br").toInt(), 1, 255);
  jsonWrite(configSetup, "all_br", val);
  uint8_t ALLbri = (uint8_t)val;

  for (uint8_t i = 0; i < MODE_AMOUNT; i++) {
    modes[i].Brightness = ALLbri;      // в т.ч. modes[EFF_CLOCK]
  }

  jsonWrite(configSetup, "br", ALLbri);

  // === ДОБАВИТЬ ===
  // Если ночные часы НЕ активны — ALLbri это и есть нормальная яркость часов.
  // Если активны — не трогаем userClockBrightness, чтобы не затереть дневную.
  if (nightModeBrightness == 0) {
    userClockBrightness = ALLbri;
    jsonWrite(configSetup, "user_clock_br", userClockBrightness);
  }
  // ===============

  SetBrightness(ALLbri);
  saveConfig();
  loadingFlag = true;

  HTTP.send(200, "text/plain", String(ALLbri));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
}

// Яркость
void handle_br() {
  if (!ONflag) {
    HTTP.send(403, F("application/json"), F("{\"error\": \"Lamp is off\"}"));
    return;
  }
  if (!HTTP.hasArg("br")) {
    HTTP.send(400, "text/plain", "Missing br");
    return;
  }
  int newBri = constrain(HTTP.arg("br").toInt(), 1, 255);
  modes[currentMode].Brightness = newBri;
  jsonWrite(configSetup, "br", newBri);
  if (currentMode == eff_num_correct[EFF_CLOCK] && nightModeBrightness == 0) {
    userClockBrightness = newBri;
    jsonWrite(configSetup, "user_clock_br", userClockBrightness);
  }
  SetBrightness(newBri);
  loadingFlag = true;

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  HTTP.send(200, "text/plain", String(newBri));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Скорость
void handle_sp() {
  if (!ONflag) {
    HTTP.send(403, F("application/json"), F("{\"error\": \"Lamp is off\"}"));
    return;
  }
  if (!HTTP.hasArg("sp")) {
    HTTP.send(400, "text/plain", "Missing sp");
    return;
  }
  uint8_t newSpeed = constrain(HTTP.arg("sp").toInt(), 1, 255);
  modes[currentMode].Speed = newSpeed;
  jsonWrite(configSetup, "sp", newSpeed);
  loadingFlag = true;

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  HTTP.send(200, "text/plain", String(newSpeed));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Масштаб
void handle_sc() {
  if (!ONflag) {
    HTTP.send(403, F("application/json"), F("{\"error\": \"Lamp is off\"}"));
    return;
  }
  if (!HTTP.hasArg("sc")) {
    HTTP.send(400, "text/plain", "Missing sc");
    return;
  }
  uint8_t newScale = constrain(HTTP.arg("sc").toInt(), 1, 100);
  modes[currentMode].Scale = newScale;
  jsonWrite(configSetup, "sc", newScale);
  loadingFlag = true;

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  HTTP.send(200, "text/plain", String(newScale));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Яркость -1
void handle_brm() {
  if (!ONflag) {
    HTTP.send(403, F("application/json"), F("{\"error\": \"Lamp is off\"}"));
    return;
  }
  modes[currentMode].Brightness = constrain(modes[currentMode].Brightness - 1, 1, 255);

  if (currentMode == eff_num_correct[EFF_CLOCK] && nightModeBrightness == 0) {
    userClockBrightness = modes[currentMode].Brightness;
    jsonWrite(configSetup, "user_clock_br", userClockBrightness);
  }

  jsonWrite(configSetup, "br", modes[currentMode].Brightness);
  SetBrightness(modes[currentMode].Brightness);

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Яркость +1
void handle_brp() {
  if (!ONflag) {
    HTTP.send(403, F("application/json"), F("{\"error\": \"Lamp is off\"}"));
    return;
  }
  modes[currentMode].Brightness = constrain(modes[currentMode].Brightness + 1, 1, 255);

  if (currentMode == eff_num_correct[EFF_CLOCK] && nightModeBrightness == 0) {
    userClockBrightness = modes[currentMode].Brightness;
    jsonWrite(configSetup, "user_clock_br", userClockBrightness);
  }

  jsonWrite(configSetup, "br", modes[currentMode].Brightness);
  SetBrightness(modes[currentMode].Brightness);

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Скорость -1
void handle_spm() {
  if (!ONflag) {
    HTTP.send(403, F("application/json"), F("{\"error\": \"Lamp is off\"}"));
    return;
  }
  modes[currentMode].Speed = constrain(modes[currentMode].Speed - 1, 1, 255);
  jsonWrite(configSetup, "sp", modes[currentMode].Speed);
  loadingFlag = true;

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Скорость +1
void handle_spp() {
  if (!ONflag) {
    HTTP.send(403, F("application/json"), F("{\"error\": \"Lamp is off\"}"));
    return;
  }
  modes[currentMode].Speed = constrain(modes[currentMode].Speed + 1, 1, 255);
  jsonWrite(configSetup, "sp", modes[currentMode].Speed);
  loadingFlag = true;

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Масштаб -1
void handle_scm() {
  if (!ONflag) {
    HTTP.send(403, F("application/json"), F("{\"error\": \"Lamp is off\"}"));
    return;
  }
  modes[currentMode].Scale = constrain(modes[currentMode].Scale - 1, 1, 100);
  jsonWrite(configSetup, "sc", modes[currentMode].Scale);
  loadingFlag = true;

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Масштаб +1
void handle_scp() {
  if (!ONflag) {
    HTTP.send(403, F("application/json"), F("{\"error\": \"Lamp is off\"}"));
    return;
  }
  modes[currentMode].Scale = constrain(modes[currentMode].Scale + 1, 1, 100);
  jsonWrite(configSetup, "sc", modes[currentMode].Scale);
  loadingFlag = true;

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

void handle_eff_sel() {
  systemShuttingDown = false;
#if USE_SD
  if (outFile) {
    outFile.close();
    outAnimationActive = false;
  }
#endif
  outEffectActive = false;

  if (!HTTP.hasArg("eff_sel")) {
    HTTP.send(400, "text/plain", "Missing eff_sel");
    return;
  }
  int tempInt = HTTP.arg("eff_sel").toInt();
  if (tempInt < 0 || tempInt >= MODE_AMOUNT) {
    HTTP.send(400, "text/plain", "Invalid eff_sel");
    return;
  }
  uint8_t temp = (uint8_t)tempInt;
  uint8_t newMode = eff_num_correct[temp];

  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configSetup.length() == 0 || deserializeJson(cfg, configSetup)) {
    cfg.clear();
    cfg.to<JsonObject>();
  }

#if USE_SD
  if (newMode == EFF_SD) {
    uint8_t sdIndex = 255;
    for (uint8_t i = 0; i < MODE_AMOUNT; i++) {
      if (eff_num_correct[i] == EFF_SD) {
        sdIndex = i;
        break;
      }
    }
    if (sdIndex == 255) {
      HTTP.send(500, "text/plain", "EFF_SD not in effect list");
      return;
    }

    if (lastOutFileName.length() > 0 && startOutAnimation(lastOutFileName)) {
      currentMode = EFF_SD;
      outAnimationActive = true;
      outEffectActive = true;

      cfg["eff_sel"]  = (int)sdIndex;
      cfg["anim_sel"] = "0";

      configSetup = "";
      configSetup.reserve(measureJson(cfg) + 1);
      serializeJson(cfg, configSetup);
      saveConfig();

      loadingFlag = false;
      effectsTick();
      FastLED.show();

      HTTP.send(200, "application/json", "{\"should_refresh\": \"true\"}");
    } else {
      HTTP.send(400, "text/plain", "No .out file selected or start failed");
    }
    return;
  }
#endif

  // обычная ветка (не SD)
  cfg["eff_sel"] = (int)temp;
  specialTextEffectParam = -1;
  cfg["anim_sel"] = "0";

#if USE_ANIMATIONS
  if (newMode == EFF_ANIMATION) {
    if (HTTP.hasArg("anim")) {
      int animIdx = HTTP.arg("anim").toInt();
      if (animIdx >= 1 && animIdx <= max_image_num) {
        specialTextEffectParam = animIdx;
        cfg["anim_sel"] = animIdx;
      } else {
        if (specialTextEffectParam < 1 || specialTextEffectParam > max_image_num) {
          specialTextEffectParam = 1;
        }
      }
    } else {
      if (specialTextEffectParam < 1 || specialTextEffectParam > max_image_num) {
        int saved = cfg["anim_sel"].as<int>();
        specialTextEffectParam = (saved >= 1 && saved <= max_image_num) ? saved : 1;
      }
    }
  }
#endif

  currentMode = newMode;

  SetBrightness(modes[currentMode].Brightness);
  cfg["br"] = (int)modes[currentMode].Brightness;
  cfg["sp"] = (int)modes[currentMode].Speed;
  cfg["sc"] = (int)modes[currentMode].Scale;

  configSetup = "";
  configSetup.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configSetup);

  loadingFlag = true;
  effTimer = millis() - 1000;

#if USE_MP3_PLAYER
  if (mp3Enabled && mp3Initialized && !mp3_stop) {
    mp3SendCmd(0x0E, 0, 0, 0);
    mp3_stop = true;
    pause_on = true;
  }
#endif

  effectsTick();
  effTimer = millis() - 1000;
  effectsTick();
  FastLED.show();

#if USE_RADIO
  if (radioEnabled && ONflag) {
    uint8_t stId = radioGetStationForMode(currentMode);
    if (stId > 0) {
      radioPlayStation(stId);
    } else {
      radioStop();
    }
  } else
#endif

#if USE_MP3_PLAYER
    if (ONflag && eff_sound_on && mp3Enabled && mp3Initialized && !isAnnouncing && !advert_flag && !weather_advert_flag) {
      if (effects_folders[currentMode] != 0) {
        mp3SendPlayFolder(effects_folders[currentMode]);
      }
    }
#endif

  if (random_on && Favorites::instance().FavoritesRunning) {
    selectedSettings = 1U;
  }

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif

#if USE_BLYNK
  updateRemoteBlynkParams();
#endif

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  HTTP.send(200, "application/json", "{\"should_refresh\": \"true\"}");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
}

// ----------------------------------------------------------------------------------------------------------------------------------------------------

void handle_night_time() {
  String day_hour_str = HTTP.arg("day_time_hour");
  String day_min_str = HTTP.arg("day_time_minute");
  String night_hour_str = HTTP.arg("night_time_hour");
  String night_min_str = HTTP.arg("night_time_minute");

  int day_hour = constrain(day_hour_str.toInt(), 0, 23);
  int day_min = constrain(day_min_str.toInt(), 0, 59);
  int night_hour = constrain(night_hour_str.toInt(), 0, 23);
  int night_min = constrain(night_min_str.toInt(), 0, 59);

  char buf[3];
  snprintf(buf, sizeof(buf), "%02d", day_hour); day_hour_str = buf;
  snprintf(buf, sizeof(buf), "%02d", day_min); day_min_str = buf;
  snprintf(buf, sizeof(buf), "%02d", night_hour); night_hour_str = buf;
  snprintf(buf, sizeof(buf), "%02d", night_min); night_min_str = buf;

  uint16_t day_time_minutes = day_hour * 60 + day_min;
  uint16_t night_time_minutes = night_hour * 60 + night_min;

  uint8_t day_bright = constrain(HTTP.arg("day_bright").toInt(), 0, 255);
  uint8_t night_bright = constrain(HTTP.arg("night_bright").toInt(), 0, 255);

  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configSetup.length() == 0 || deserializeJson(cfg, configSetup)) {
    cfg.clear();
    cfg.to<JsonObject>();
  }

  cfg["day_time_hour"] = day_hour_str;
  cfg["day_time_minute"] = day_min_str;
  cfg["night_time_hour"] = night_hour_str;
  cfg["night_time_minute"] = night_min_str;
  cfg["day_time"] = (int)day_time_minutes;
  cfg["night_time"] = (int)night_time_minutes;
  cfg["day_bright"] = (int)day_bright;
  cfg["night_bright"] = (int)night_bright;

  configSetup = "";
  configSetup.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configSetup);
  saveConfig();

  NIGHT_HOURS_START = night_time_minutes;
  NIGHT_HOURS_STOP = day_time_minutes;
  NIGHT_HOURS_BRIGHTNESS = night_bright;
  DAY_HOURS_BRIGHTNESS = day_bright;

  getBrightnessForPrintTime();

#if USE_DAWN
  if (ONflag && !dawnFlag)
#else
  if (ONflag)
#endif
    SetBrightness(modes[currentMode].Brightness);

#if USE_TM1637
  if (tm1637Enabled) clockTicker_blink();
#endif
#if USE_ST7789
  TFT_ApplyBrightnessNow();
#endif

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  HTTP.send(200, F("text/plain"), F("OK"));
}

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// Чекбокс "Включать лампу после обесточивания" (изменённая логика, было наоборот)
void handle_effect_always () {
  int value = HTTP.arg("effect_always").toInt();
  jsonWrite(configSetup, "effect_always", value);
  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);
  HTTP.send(200, F("text/plain"), F("OK"));
}

// --------------------------------------------------------------------------- ИЗБРАННОЕ --------------------------------------------------------------

void handle_favorit() {
  jsonWrite(configSetup, "favorit", HTTP.arg("favorit").toInt());
  timeout_save_file_changes = millis();
  bitSet (save_file_changes, 0);
  Favorit_only = jsonReadtoInt(configSetup, "favorit");
  HTTP.send(200, F("text/plain"), F("OK"));
}

void handle_random() {
  jsonWrite(configSetup, "random_on", HTTP.arg("random_on").toInt());
  timeout_save_file_changes = millis();
  bitSet (save_file_changes, 0);
  random_on = jsonReadtoInt(configSetup, "random_on");
  HTTP.send(200, F("text/plain"), F("OK"));
}

// ----------------------------------------------------------------------- УПРАВЛЕНИЕ ПИТАНИЕМ ---------------------------------------------------------

void handle_Power() {
  static uint32_t lastPowerCommandMs = 0;
  uint32_t nowMs = millis();
  if (nowMs - lastPowerCommandMs < 500UL) {
    HTTP.send(200, "application/json", "{\"should_refresh\":\"false\"}");
    return;
  }
  lastPowerCommandMs = nowMs;

#if USE_DAWN
  if (dawnFlag == 1) {
    manualOff = true;
    dawnFlag = 0;
#if USE_TM1637
    if (tm1637Enabled) clockTicker_blink();
#endif

    ONflag = false;

    PJsonDoc cfg(JSON_BUFFER_SIZE);
    if (configSetup.length() == 0 || deserializeJson(cfg, configSetup)) {
      cfg.clear(); cfg.to<JsonObject>();
    }
    cfg["Power"] = (int)ONflag;
    configSetup = "";
    configSetup.reserve(measureJson(cfg) + 1);
    serializeJson(cfg, configSetup);
    saveConfig("setup");

    FastLED.clear();
    FastLED.setBrightness(0);
    FastLED.show();

#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
    digitalWrite(MOSFET_PIN, !MOSFET_LEVEL);
#endif
#if defined(ALARM_PIN) && defined(ALARM_LEVEL)
    digitalWrite(ALARM_PIN, !ALARM_LEVEL);
#endif

    loadingFlag = false;
    HTTP.send(200, "application/json", "{\"should_refresh\":\"true\"}");
    return;
  }
#endif // USE_DAWN

#if USE_SUNSET
  if (sunsetFlag == 1) {
    manualsOff = true;
    sunsetFlag = 0;

    ONflag = false;

    PJsonDoc cfg(JSON_BUFFER_SIZE);
    if (configSetup.length() == 0 || deserializeJson(cfg, configSetup)) {
      cfg.clear(); cfg.to<JsonObject>();
    }
    cfg["Power"] = (int)ONflag;
    configSetup = "";
    configSetup.reserve(measureJson(cfg) + 1);
    serializeJson(cfg, configSetup);
    saveConfig("setup");

    FastLED.clear();
    FastLED.setBrightness(0);
    FastLED.show();

#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
    digitalWrite(MOSFET_PIN, !MOSFET_LEVEL);
#endif
#if defined(ALARM_PIN) && defined(ALARM_LEVEL)
    digitalWrite(ALARM_PIN, !ALARM_LEVEL);
#endif

    loadingFlag = false;
    HTTP.send(200, "application/json", "{\"should_refresh\":\"true\"}");
    return;
  }
#endif

  // ночные часы (меняются ДВА конфига: configLedPanel и configSetup)
  if (ONflag && nightModeBrightness > 0 && currentMode == EFF_CLOCK) {
    nightClockEnabled = false;
    nightModeBrightness = 0;
    ONflag = false;

    PJsonDoc cfgPanel(JSON_BUFFER_SIZE);
    if (configLedPanel.length() == 0 || deserializeJson(cfgPanel, configLedPanel)) {
      cfgPanel.clear(); cfgPanel.to<JsonObject>();
    }
    cfgPanel["night_clock_enabled"] = "0";
    configLedPanel = "";
    configLedPanel.reserve(measureJson(cfgPanel) + 1);
    serializeJson(cfgPanel, configLedPanel);

    PJsonDoc cfg(JSON_BUFFER_SIZE);
    if (configSetup.length() == 0 || deserializeJson(cfg, configSetup)) {
      cfg.clear(); cfg.to<JsonObject>();
    }
    cfg["Power"] = (int)ONflag;
    configSetup = "";
    configSetup.reserve(measureJson(cfg) + 1);
    serializeJson(cfg, configSetup);

    writeFile(F("config.json"), configSetup);
    writeFile(F("config_led_panel.json"), configLedPanel);

    FastLED.setBrightness(0);
    FastLED.clear();
    FastLED.show();
#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
    digitalWrite(MOSFET_PIN, !MOSFET_LEVEL);
#endif

    systemShuttingDown = false;
    justPoweredOn = false;
    loadingFlag = false;

    uint8_t normalBrightness = userClockBrightness;
    if (normalBrightness == 0) normalBrightness = 30;
    modes[EFF_CLOCK].Brightness = normalBrightness;
    Eeprom::instance().EepromPut(modes);

    HTTP.send(200, "application/json", "{\"should_refresh\":\"true\"}");

#if USE_MULTILAMP
    multiple_lamp_control();
#endif
#if USE_MQTT
    if (Wifi::instance().isConnected()) Mqtt::instance().needToPublish = true;
#endif
    return;
  }

  // обычная логика включения/выключения
  uint8_t requestedState = HTTP.arg("Power").toInt();
  if (requestedState == 2) requestedState = ONflag ? 0 : 1;

  bool wasOn = ONflag;

  if (!wasOn && requestedState == 1) {
#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
    digitalWrite(MOSFET_PIN, MOSFET_LEVEL);
#endif
  }

  ONflag = requestedState;

  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configSetup.length() == 0 || deserializeJson(cfg, configSetup)) {
    cfg.clear(); cfg.to<JsonObject>();
  }
  cfg["Power"] = (int)ONflag;

  if (!ONflag && leds != nullptr) {
    FastLED.setBrightness(0);
    FastLED.clear();
    FastLED.show();
#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
    digitalWrite(MOSFET_PIN, !MOSFET_LEVEL);
#endif
  }

  if (wasOn && !ONflag) {
    manualOverrideOff = true;
  } else if (!wasOn && ONflag) {
    manualOverrideOff = false;
  }

  manualControlTimer = millis() + 60000UL;

  if (ONflag) {
    Eeprom::instance().EepromGet(modes);
    loadingFlag = true;
    if (currentMode == EFF_CLOCK && nightModeBrightness == 0) {
      uint8_t normalBrightness = userClockBrightness;
      if (normalBrightness < 2) normalBrightness = 30;
      modes[currentMode].Brightness = normalBrightness;
      cfg["br"] = (int)normalBrightness;
    }
    changePower();
  } else {
    changePower();
  }

  configSetup = "";
  configSetup.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configSetup);
  saveConfig("setup");

  HTTP.send(200, "application/json", "{\"should_refresh\":\"true\"}");

#if USE_MULTILAMP
  if (ONflag) repeat_multiple_lamp_control = true;
  else multiple_lamp_control();
#endif
#if USE_MQTT
  if (Wifi::instance().isConnected()) Mqtt::instance().needToPublish = true;
#endif
}

// ----------------------------------------------------------------------------- РАССВЕТ ---------------------------------------------------------------

#if USE_DAWN
bool firstStartAlarm = true;

void handle_alarm() {
  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configAlarm.length() == 0 || deserializeJson(cfg, configAlarm)) {
    cfg.clear();
    cfg.to<JsonObject>();
  }

  bool saveNeeded = false;

  for (uint8_t k = 0; k < 7; k++) {
    char idx[2];
    itoa(k + 1, idx, 10);

    String key_a = "a" + String(idx);
    String key_h = "h" + String(idx);
    String key_m = "m" + String(idx);

    String hoursStr = HTTP.arg(key_h);
    String minutesStr = HTTP.arg(key_m);
    String stateArg = HTTP.arg(key_a);

    if (hoursStr.length() == 0) {
      hoursStr = cfg[key_h].as<String>();
      if (hoursStr.length() == 0) hoursStr = "07";
    }
    if (minutesStr.length() == 0) {
      minutesStr = cfg[key_m].as<String>();
      if (minutesStr.length() == 0) minutesStr = "00";
    }

    uint8_t state;
    if (stateArg.length() == 0) {
      state = (uint8_t)cfg[key_a].as<int>();
    } else {
      state = (uint8_t)stateArg.toInt();
    }

    uint8_t hh = constrain(hoursStr.toInt(), 0, 23);
    uint8_t mm = constrain(minutesStr.toInt(), 0, 59);
    char hbuf[3], mbuf[3];
    snprintf(hbuf, sizeof(hbuf), "%02u", hh);
    snprintf(mbuf, sizeof(mbuf), "%02u", mm);
    hoursStr = hbuf;
    minutesStr = mbuf;

    if (cfg[key_h].as<String>() != hoursStr) {
      cfg[key_h] = hoursStr;
      saveNeeded = true;
    }
    if (cfg[key_m].as<String>() != minutesStr) {
      cfg[key_m] = minutesStr;
      saveNeeded = true;
    }
    if ((uint8_t)cfg[key_a].as<int>() != state) {
      cfg[key_a] = (int)state;
      saveNeeded = true;
    }

    alarms[k].State = state;
    alarms[k].Time = hoursStr.toInt() * 60 + minutesStr.toInt();
  }

  uint8_t dawnModeNew = (uint8_t)HTTP.arg("t").toInt();
  if (dawnModeNew == 0) dawnModeNew = (uint8_t)cfg["t"].as<int>();
  if (dawnModeNew < 1 || dawnModeNew > 7) dawnModeNew = 1;
  uint8_t dawnTimeoutNew = (uint8_t)HTTP.arg("after").toInt();
  uint8_t dawnBrightNew = (uint8_t)HTTP.arg("a_br").toInt();

  if (dawnModeNew == 0) dawnModeNew = (uint8_t)cfg["t"].as<int>();
  if (dawnTimeoutNew == 0) dawnTimeoutNew = (uint8_t)cfg["after"].as<int>();
  if (dawnBrightNew == 0) dawnBrightNew = (uint8_t)cfg["a_br"].as<int>();

  if ((uint8_t)cfg["t"].as<int>() != dawnModeNew) {
    cfg["t"] = (int)dawnModeNew;
    saveNeeded = true;
  }
  if ((uint8_t)cfg["after"].as<int>() != dawnTimeoutNew) {
    cfg["after"] = (int)dawnTimeoutNew;
    saveNeeded = true;
  }
  if ((uint8_t)cfg["a_br"].as<int>() != dawnBrightNew)  {
    cfg["a_br"] = (int)dawnBrightNew;
    saveNeeded = true;
  }

  dawnMode = dawnModeNew - 1;
  DAWN_TIMEOUT = dawnTimeoutNew;
  DAWN_BRIGHT = dawnBrightNew;

  if (saveNeeded || firstStartAlarm) {
    configAlarm = "";
    configAlarm.reserve(measureJson(cfg) + 1);
    serializeJson(cfg, configAlarm);
    save_file_changes |= SAVE_ALARMS_BIT;
    timeout_save_file_changes = millis();
    firstStartAlarm = false;
  }

  HTTP.send(200, F("application/json"), F("{\"should_refresh\":\"true\"}"));
}
#endif // USE_DAWN

// ------------------------------------------------------------------------------ ЗАКАТ ---------------------------------------------------------------

#if USE_SUNSET
bool firstStartSunset = true;
void saveSunsetConfig(const String & data) {
  writeFile(F("config_sunset.json"), data);
}

void handle_sunset() {
  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configSunset.length() == 0 || deserializeJson(cfg, configSunset)) {
    cfg.clear();
    cfg.to<JsonObject>();
  }

  bool saveNeeded = false;

  for (uint8_t k = 0; k < 7; k++) {
    char idx[2];
    itoa(k + 1, idx, 10);

    String key_a = "a" + String(idx);
    String key_h = "h" + String(idx);
    String key_m = "m" + String(idx);

    String hoursStr = HTTP.arg(key_h);
    String minutesStr = HTTP.arg(key_m);
    String stateArg = HTTP.arg(key_a);

    if (hoursStr.length() == 0) {
      hoursStr = cfg[key_h].as<String>();
      if (hoursStr.length() == 0) hoursStr = "21";
    }
    if (minutesStr.length() == 0) {
      minutesStr = cfg[key_m].as<String>();
      if (minutesStr.length() == 0) minutesStr = "00";
    }

    uint8_t state;
    if (stateArg.length() == 0) {
      state = (uint8_t)cfg[key_a].as<int>();
    } else {
      state = (uint8_t)stateArg.toInt();
    }

    hoursStr = zeroPad(hoursStr, 2);
    minutesStr = zeroPad(minutesStr, 2);

    if (cfg[key_h].as<String>() != hoursStr) {
      cfg[key_h] = hoursStr;
      saveNeeded = true;
    }
    if (cfg[key_m].as<String>() != minutesStr) {
      cfg[key_m] = minutesStr;
      saveNeeded = true;
    }
    if ((uint8_t)cfg[key_a].as<int>() != state) {
      cfg[key_a] = (int)state;
      saveNeeded = true;
    }

    sunsets[k].State = state;
    sunsets[k].Time = hoursStr.toInt() * 60 + minutesStr.toInt();
  }

  uint8_t sunsetModeNew = (uint8_t)HTTP.arg("t").toInt();
  uint8_t sunsetBrightNew = (uint8_t)HTTP.arg("s_br").toInt();

  if (sunsetModeNew == 0) sunsetModeNew = (uint8_t)cfg["t"].as<int>();
  if (sunsetBrightNew == 0) sunsetBrightNew = (uint8_t)cfg["s_br"].as<int>();

  if ((uint8_t)cfg["t"].as<int>() != sunsetModeNew) {
    cfg["t"] = (int)sunsetModeNew;
    saveNeeded = true;
  }
  if ((uint8_t)cfg["s_br"].as<int>() != sunsetBrightNew) {
    cfg["s_br"] = (int)sunsetBrightNew;
    saveNeeded = true;
  }

  sunsetMode = sunsetModeNew - 1;
  SUNSET_BRIGHT = sunsetBrightNew;

  if (saveNeeded || firstStartSunset) {
    configSunset = "";
    configSunset.reserve(measureJson(cfg) + 1);
    serializeJson(cfg, configSunset);
    save_file_changes |= SAVE_ALARMS_BIT;
    timeout_save_file_changes = millis();
    firstStartSunset = false;
  }

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}
#endif // USE_SUNSET

// ----------------------------------------------------------------------------- РАСПИСАНИЕ ------------------------------------------------------------

#if USE_SCHEDULE
void handle_schedule() {
  PJsonDoc cfg(4096);
  if (configSchedule.length() == 0 || deserializeJson(cfg, configSchedule)) {
    cfg.clear();
    cfg.to<JsonObject>();
  }

  bool changed = false;

  for (uint8_t i = 0; i < MAX_SCHEDULE_ENTRIES; i++) {
    schedule[i].State = 0;
    schedule[i].Day = 0;
    schedule[i].Time = 0;
    schedule[i].Action = 0;
    schedule[i].EffectNum = 255;
  }

  String oldEnable = cfg["schedule_enabled"] | "";
  String enableVal = HTTP.hasArg("schedule_enabled") ? HTTP.arg("schedule_enabled") : oldEnable;
  if (enableVal != "1") enableVal = "0";
  if (enableVal != oldEnable) {
    cfg["schedule_enabled"] = enableVal;
    changed = true;
  }

  uint8_t timerIndex = 0;

  for (uint8_t slot = 1; slot <= 6; slot++) {
    String aKey = "a" + String(slot);
    String hKey = "h" + String(slot);
    String mKey = "m" + String(slot);
    String effKey = (slot == 3) ? "eff3" : "";

    String actionStr = HTTP.hasArg(aKey) ? HTTP.arg(aKey) : String((const char*)(cfg[aKey] | ""));
    if (actionStr == "" || actionStr == "null") actionStr = "0";
    uint8_t action = actionStr.toInt();

    String hStr = HTTP.hasArg(hKey) ? HTTP.arg(hKey) : String((const char*)(cfg[hKey] | ""));
    if (hStr == "" || hStr == "null" || hStr == "0") hStr = "00";
    String mStr = HTTP.hasArg(mKey) ? HTTP.arg(mKey) : String((const char*)(cfg[mKey] | ""));
    if (mStr == "" || mStr == "null" || mStr == "0") mStr = "00";

    uint8_t h = constrain(hStr.toInt(), 0, 23);
    uint8_t m = constrain(mStr.toInt(), 0, 59);
    char buf[3];
    sprintf(buf, "%02d", h); String hFormatted = buf;
    sprintf(buf, "%02d", m); String mFormatted = buf;

    uint8_t effect = 255;

    if (slot == 3 && action == 3) {
      String effStr = HTTP.hasArg(effKey) ? HTTP.arg(effKey) : String((const char*)(cfg[effKey] | ""));
      if (effStr != "" && effStr != "null") {
        effect = constrain(effStr.toInt(), 0, MODE_AMOUNT - 1);
      }
    }

    if (HTTP.hasArg(aKey)) {
      cfg[aKey] = actionStr;
      changed = true;
    }
    if (HTTP.hasArg(hKey)) {
      cfg[hKey] = hFormatted;
      changed = true;
    }
    if (HTTP.hasArg(mKey)) {
      cfg[mKey] = mFormatted;
      changed = true;
    }
    if (slot == 3 && HTTP.hasArg(effKey)) {
      cfg[effKey] = String(effect);
      changed = true;
    }

    if (action != 0 && timerIndex < MAX_SCHEDULE_ENTRIES) {
      schedule[timerIndex].State = 1;
      schedule[timerIndex].Day = 0;
      schedule[timerIndex].Time = h * 60 + m;

      if (slot == 4) {
        schedule[timerIndex].Action = action;
        schedule[timerIndex].EffectNum = 255;
      }
      else if (slot == 5) {
        schedule[timerIndex].Action = 4;
        schedule[timerIndex].EffectNum = EFF_CLOCK;
      }
      else if (slot == 6) {
        schedule[timerIndex].Action = 7;
        schedule[timerIndex].EffectNum = EFF_CLOCK;
      }
      else {
        schedule[timerIndex].Action = action;
        schedule[timerIndex].EffectNum = (slot == 3 && action == 3) ? effect : 255;
      }
      timerIndex++;
    }
  }

  if (changed) {
    configSchedule = "";
    configSchedule.reserve(measureJson(cfg) + 1);
    serializeJson(cfg, configSchedule);
    save_file_changes |= SAVE_SCHEDULE_BIT;
    timeout_save_file_changes = millis();
  }

  PJsonDoc resp(4096);
  resp["should_refresh"] = "true";
  resp["schedule_enabled"] = String((const char*)(cfg["schedule_enabled"] | "0"));

  for (uint8_t slot = 1; slot <= 6; slot++) {
    String aKey = "a" + String(slot);
    String hKey = "h" + String(slot);
    String mKey = "m" + String(slot);
    resp[aKey] = String((const char*)(cfg[aKey] | ""));
    resp[hKey] = String((const char*)(cfg[hKey] | ""));
    resp[mKey] = String((const char*)(cfg[mKey] | ""));
    if (slot == 3) {
      String effVal = cfg["eff3"] | "";
      if (effVal == "" || effVal == "null") effVal = "255";
      resp["eff3"] = effVal;
    }
  }
  String respStr;
  respStr.reserve(measureJson(resp) + 1);
  serializeJson(resp, respStr);
  HTTP.send(200, "application/json", respStr);
}
#endif // USE_SCHEDULE

// --------------------------------------------------------------- УПРАВЛЕНИЕ НЕСКОЛЬКИМИ ЛАМПАМИ ------------------------------------------------------

#if USE_MULTILAMP
void handle_multiple_lamp() {
  PJsonDoc cfg(2048);
  if (configMultilamp.length() == 0 || deserializeJson(cfg, configMultilamp)) {
    cfg.clear(); cfg.to<JsonObject>();
  }

  auto saveInt = [&](const char* key) {
    if (HTTP.hasArg(key)) cfg[key] = HTTP.arg(key).toInt();
  };
  auto saveStr = [&](const char* key) {
    if (HTTP.hasArg(key)) cfg[key] = HTTP.arg(key);
  };

  saveInt("ml1"); saveInt("ml2"); saveInt("ml3"); saveInt("ml4"); saveInt("ml5");
  saveStr("host1"); saveStr("host2"); saveStr("host3"); saveStr("host4"); saveStr("host5");
  saveStr("comment1"); saveStr("comment2"); saveStr("comment3"); saveStr("comment4"); saveStr("comment5");

  configMultilamp = "";
  configMultilamp.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configMultilamp);
  writeFile(F("config_multilamp.json"), configMultilamp);

  ml1 = cfg["ml1"] | 0;
  ml2 = cfg["ml2"] | 0;
  ml3 = cfg["ml3"] | 0;
  ml4 = cfg["ml4"] | 0;
  ml5 = cfg["ml5"] | 0;

  String str = cfg["host1"] | ""; str.toCharArray(Host1, sizeof(Host1));
  str = cfg["host2"] | ""; str.toCharArray(Host2, sizeof(Host2));
  str = cfg["host3"] | ""; str.toCharArray(Host3, sizeof(Host3));
  str = cfg["host4"] | ""; str.toCharArray(Host4, sizeof(Host4));
  str = cfg["host5"] | ""; str.toCharArray(Host5, sizeof(Host5));

#if USE_MP3_PLAYER
  PJsonDoc cfgMp3(JSON_BUFFER_SIZE);
  if (configMP3.length() == 0 || deserializeJson(cfgMp3, configMP3)) {
    cfgMp3.clear(); cfgMp3.to<JsonObject>();
  }
  if (HTTP.hasArg("s_s")) send_sound = HTTP.arg("s_s").toInt();
  if (HTTP.hasArg("s_e_v")) send_eff_volume = HTTP.arg("s_e_v").toInt();
  if (!send_sound) send_eff_volume = 0;
  cfgMp3["s_s"] = send_sound;
  cfgMp3["s_e_v"] = send_eff_volume;
  configMP3 = "";
  configMP3.reserve(measureJson(cfgMp3) + 1);
  serializeJson(cfgMp3, configMP3);
  writeFile(F("config_mp3.json"), configMP3);
#endif

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

void multilamp_get() {
  PJsonDoc cfg(2048);
  if (deserializeJson(cfg, configMultilamp)) return;

  ml1 = cfg["ml1"] | 0;
  ml2 = cfg["ml2"] | 0;
  ml3 = cfg["ml3"] | 0;
  ml4 = cfg["ml4"] | 0;
  ml5 = cfg["ml5"] | 0;

  String str = cfg["host1"] | ""; str.toCharArray(Host1, sizeof(Host1));
  str = cfg["host2"] | ""; str.toCharArray(Host2, sizeof(Host2));
  str = cfg["host3"] | ""; str.toCharArray(Host3, sizeof(Host3));
  str = cfg["host4"] | ""; str.toCharArray(Host4, sizeof(Host4));
  str = cfg["host5"] | ""; str.toCharArray(Host5, sizeof(Host5));
}

void multiple_lamp_control() {
  char outputBuffer[64];
  if (connect) {
#if USE_MP3_PLAYER
    if (send_sound && !send_eff_volume) {
      snprintf_P(outputBuffer, sizeof(outputBuffer), PSTR("MULTI,%u,%u,%u,%u,%u,%u"), (uint8_t)ONflag, currentMode, modes[currentMode].Brightness, modes[currentMode].Speed, modes[currentMode].Scale, CurrentFolder);
    }
    else if (send_sound && send_eff_volume) {
      snprintf_P(outputBuffer, sizeof(outputBuffer), PSTR("MULTI,%u,%u,%u,%u,%u,%u,%u,%u"), (uint8_t)ONflag, currentMode, modes[currentMode].Brightness, modes[currentMode].Speed, modes[currentMode].Scale, eff_sound_on, eff_volume, CurrentFolder);
    }
    else {
      snprintf_P(outputBuffer, sizeof(outputBuffer), PSTR("MULTI,%u,%u,%u,%u,%u"), (uint8_t)ONflag, currentMode, modes[currentMode].Brightness, modes[currentMode].Speed, modes[currentMode].Scale);
    }
#else
    snprintf_P(outputBuffer, sizeof(outputBuffer), PSTR("MULTI,%u,%u,%u,%u,%u"), (uint8_t)ONflag, currentMode, modes[currentMode].Brightness, modes[currentMode].Speed, modes[currentMode].Scale);
#endif // USE_MP3_PLAYER

    if (ml1) {
      Udp.beginPacket(Host1, localPort);
      Udp.print(outputBuffer);
      Udp.endPacket();
    }
    if (ml2) {
      Udp.beginPacket(Host2, localPort);
      Udp.print(outputBuffer);
      Udp.endPacket();
    }
    if ( ml3 ) {
      Udp.beginPacket(Host3, localPort);
      Udp.print(outputBuffer);
      Udp.endPacket();
    }
    if ( ml4 ) {
      Udp.beginPacket(Host4, localPort);
      Udp.print(outputBuffer);
      Udp.endPacket();
    }
    if ( ml5 ) {
      Udp.beginPacket(Host5, localPort);
      Udp.print(outputBuffer);
      Udp.endPacket();
    }
    outputBuffer[0] = '\0';
  }
}

#endif // USE_MULTILAMP

// ------------------------------------------------------------------------ РЕЖИМ ЦИКЛ -----------------------------------------------------------------

// Включение/выключение режима Цикл
void handle_cycle_on() {
#if USE_SD
  if (outFile) {
    outFile.close();
    outAnimationActive = false;
  }
#endif
  outEffectActive = false;
  uint8_t tmp;
  tmp = HTTP.arg("cycle_on").toInt();
  if (tmp == 2) tmp = (jsonReadtoInt(configSetup, "cycle_on") == 0) ? 1 : 0;

  if (ONflag && tmp)   {
    jsonWrite(configSetup, "cycle_on", 1);
    Favorites::instance().FavoritesRunning = 1;
    Eeprom::instance().EepromPut(modes);
  } else {
    Favorites::instance().FavoritesRunning = 0;
    Favorites::instance().nextModeAt = 0;
    jsonWrite(configSetup, "cycle_on", 0);
  }

  saveConfig();
  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Время переключения цикла
void handle_time_eff () {
  jsonWrite(configSetup, "time_eff", HTTP.arg("time_eff").toInt());
  Favorites::instance().Interval = jsonReadtoInt(configSetup, "time_eff");
  jsonWrite(configSetup, "disp", HTTP.arg("disp").toInt());
  Favorites::instance().Dispersion = jsonReadtoInt(configSetup, "disp");
  timeout_save_file_changes = millis();
  bitSet (save_file_changes, 0);
  HTTP.send(200, F("text/plain"), F("OK"));
}

// Перемешать выбранные или по порядку
void handle_rnd_cycle () {
  jsonWrite(configSetup, "rnd_cycle", HTTP.arg("rnd_cycle").toInt());
  Favorites::instance().rndCycle = jsonReadtoInt(configSetup, "rnd_cycle");
  timeout_save_file_changes = millis();
  bitSet (save_file_changes, 0);
  HTTP.send(200, F("text/plain"), F("OK"));
}

// Запускать режим цикл после выкл/вкл лампы или нет
void handle_cycle_always () {
  jsonWrite(configSetup, "cycle_always", HTTP.arg("cycle_always").toInt());
  Favorites::instance().UseSavedFavoritesRunning = jsonReadtoInt(configSetup, "cycle_always");

  if (!ONflag && !Favorites::instance().UseSavedFavoritesRunning)   {
    Favorites::instance().FavoritesRunning = 0;
    jsonWrite(configSetup, "cycle_on", 0);
  }

  timeout_save_file_changes = millis();
  bitSet (save_file_changes, 0);
  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

// Выбор эффектов для Цикла
void handle_cycle_set() {
  PJsonDoc cfg(2048);
  if (deserializeJson(cfg, readFile(F("config_cycle.json"), 2048))) {
    cfg.clear(); cfg.to<JsonObject>();
  }
  for (uint8_t k = 0; k < MODE_AMOUNT; k++) {
    String e = "e" + String(k);
    if (!first_entry) cfg[e] = HTTP.arg(e).toInt();
    Favorites::instance().FavoriteModes[k] = cfg[e] | 0;
  }
  if (!first_entry) {
    configCycle = "";
    configCycle.reserve(measureJson(cfg) + 1);
    serializeJson(cfg, configCycle);
    writeFile(F("config_cycle.json"), configCycle);
  }
  HTTP.send(200, F("text/plain"), F("OK"));
}

// следующий/предыдущий эффект
void handle_eff() {
#if USE_SD
  if (outFile) {
    outFile.close();
    outAnimationActive = false;
  }
#endif
  outEffectActive = false;

  int temp = jsonReadtoInt(configSetup, "eff_sel");
  bool next = HTTP.arg("eff").toInt();
  if (!HTTP.hasArg("eff")) {
    HTTP.send(400, "text/plain", "Missing eff");
    return;
  }

  if (Favorit_only) {
    uint8_t lastMode = currentMode;
    do {
      next ? temp++ : temp--;
      if (temp >= MODE_AMOUNT) temp = 0;
      if (temp < 0) temp = MODE_AMOUNT - 1;
      currentMode = eff_num_correct[temp];
    }
    while (Favorites::instance().FavoriteModes[currentMode] == 0 && currentMode != lastMode);

    if (currentMode == lastMode) {  // ни один не избранный - всё равно переключимся
      next ? temp++ : temp--;
      if (temp >= MODE_AMOUNT) temp = 0;
      if (temp < 0) temp = MODE_AMOUNT - 1;
      currentMode = eff_num_correct[temp];
    }
  } else {
    next ? temp++ : temp--;
    if (temp >= MODE_AMOUNT) temp = 0;
    if (temp < 0) temp = MODE_AMOUNT - 1;
    currentMode = eff_num_correct[temp];
  }

  jsonWrite(configSetup, "eff_sel", temp);
  jsonWrite(configSetup, "br", modes[currentMode].Brightness);
  jsonWrite(configSetup, "sp", modes[currentMode].Speed);
  jsonWrite(configSetup, "sc", modes[currentMode].Scale);
  SetBrightness(modes[currentMode].Brightness);
  loadingFlag = true;

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  effTimer = millis() - 1000;

#if USE_MP3_PLAYER
  if (mp3Enabled && mp3Initialized && !mp3_stop) {
    mp3SendCmd(0x0E, 0, 0, 0);
    mp3_stop = true;
    pause_on = true;
  }
#endif

  effectsTick();
  effTimer = millis() - 1000;
  effectsTick();
  FastLED.show();

#if USE_RADIO
  if (radioEnabled && ONflag) {
    uint8_t stId = radioGetStationForMode(currentMode);
    if (stId > 0) {
      radioPlayStation(stId);
    } else {
      radioStop();
    }
  } else
#endif

#if USE_MP3_PLAYER
    if (ONflag && eff_sound_on && mp3Enabled && mp3Initialized && !isAnnouncing && !advert_flag && !weather_advert_flag) {
      if (effects_folders[currentMode] != 0) {
        mp3SendPlayFolder(effects_folders[currentMode]);
      }
    }
#endif

  if (random_on && Favorites::instance().FavoritesRunning) selectedSettings = 1U;

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif

#if USE_BLYNK
  updateRemoteBlynkParams();
#endif

  HTTP.send(200, "application/json", "{\"should_refresh\": \"true\"}");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
}

// Выбрать все эффекты
void handle_eff_all() {
  PJsonDoc cfg(2048);
  if (deserializeJson(cfg, readFile(F("config_cycle.json"), 2048))) {
    cfg.clear(); cfg.to<JsonObject>();
  }
  for (uint8_t k = 0; k < MODE_AMOUNT; k++) {
    cfg["e" + String(k)] = 1;
    Favorites::instance().FavoriteModes[k] = 1;
  }
  configCycle = "";
  configCycle.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configCycle);
  writeFile(F("config_cycle.json"), configCycle);
  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

// Очистить все эффекты
void handle_eff_clr () {
  PJsonDoc cfg(2048);
  if (deserializeJson(cfg, readFile(F("config_cycle.json"), 2048))) {
    cfg.clear(); cfg.to<JsonObject>();
  }
  for (uint8_t k = 0; k < MODE_AMOUNT; k++) {
    cfg["e" + String(k)] = 0;
    Favorites::instance().FavoriteModes[k] = 0;
  }
  configCycle = "";
  configCycle.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configCycle);
  writeFile(F("config_cycle.json"), configCycle);
  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

// --------------------------------------------------------- СОХРАНЕНИЕ, СБРОС И ЗАГРУЗКА НАСТРОЕК ЭФФЕКТОВ --------------------------------------------

// Сброс настроек текущего эффекта по умолчанию
void handle_def() {
  outEffectActive = false;
  setModeSettings();
  updateSets();

  ONflag = false;
  jsonWrite(configSetup, "Power", 0);
  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  systemShuttingDown = true;
  loadingFlag = false;

#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
  digitalWrite(MOSFET_PIN, !MOSFET_LEVEL);
#endif

  if (leds != nullptr) {
    FastLED.clear();
    loadingFlag = true;
    effTimer = millis() - 1000;
    effectsTick();
    effTimer = millis() - 1000;
    effectsTick();
    FastLED.show();
  }
#if USE_WEATHER
  Weather::instance().forceUpdate();
#endif
  resetTimerState();
  manualOverride = true;
  manualOverrideUntil = millis() + 300000UL;

  showWarning(CRGB::Blue, 2000U, 500U);

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
}

// Сброс настроек всех эффектов по умолчанию
void handle_eff_reset() {
#if USE_SD
  if (outFile) {
    outFile.close();
    outAnimationActive = false;
  }
#endif
  outEffectActive = false;
  uint8_t savedMode = currentMode;
  for (uint8_t i = 0; i < MODE_AMOUNT; i++) {
    currentMode = eff_num_correct[i];
    setModeSettings();
    yield();
  }
  currentMode = savedMode;

  updateSets();

  ONflag = false;
  jsonWrite(configSetup, "Power", 0);
  systemShuttingDown = true;
  loadingFlag = false;

#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
  digitalWrite(MOSFET_PIN, !MOSFET_LEVEL);
#endif

  if (leds != nullptr) {
    FastLED.clear();
    FastLED.show();
  }

#if USE_WEATHER
  Weather::instance().forceUpdate();
#endif
  resetTimerState();
  manualOverride = true;
  manualOverrideUntil = millis() + 300000UL;

  jsonWrite(configSetup, "br", modes[currentMode].Brightness);
  jsonWrite(configSetup, "sp", modes[currentMode].Speed);
  jsonWrite(configSetup, "sc", modes[currentMode].Scale);


  Eeprom::instance().EepromPut(modes);
  saveConfig("setup");

  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

  pendingRestart = true;
}

// Сохранить настройки эффектов
void handle_eff_save() {
  if (!ONflag) {
    HTTP.send(403, "text/plain", "Lamp is off");
    return;
  }

  if (!LittleFS.begin(false)) {
    HTTP.send(500, "text/plain", "FS mount failed");
    return;
  }

  File file = LittleFS.open("/effect.ini", "w");
  if (!file) {
    HTTP.send(500, "text/plain", "Cannot create file");
    return;
  }

  for (uint8_t i = 0; i < MODE_AMOUNT; i++) {
    file.write(modes[i].Brightness);
    file.write(modes[i].Speed);
    file.write(modes[i].Scale);
    yield();
  }
  file.close();

  showWarning(CRGB::Blue, 2000U, 500U);
  HTTP.send(200, "text/plain", "OK");
}

// Загрузить настройки эффектов из файла
void handle_eff_read() {
  if (!LittleFS.begin(false)) {
    HTTP.send(500, "text/plain", "FS mount failed");
    return;
  }

  File file = LittleFS.open("/effect.ini", "r");
  if (!file) {
    HTTP.send(404, "text/plain", "File not found");
    return;
  }

  uint16_t file_size = file.size();
  if (file_size < 3 || file_size > MODE_AMOUNT * 3 || (file_size % 3) != 0) {
    file.close();
    HTTP.send(400, "text/plain", "Invalid file size");
    return;
  }

  uint16_t count = file_size / 3;
  if (count > MODE_AMOUNT) count = MODE_AMOUNT;

  for (uint16_t i = 0; i < count; i++) {
    uint8_t b = file.read();
    uint8_t s = file.read();
    uint8_t sc = file.read();

    if (b >= 1 && b <= 255) modes[i].Brightness = b;
    if (s >= 1 && s <= 255) modes[i].Speed = s;
    if (sc >= 1 && sc <= 100) modes[i].Scale = sc;

    yield();
  }
  file.close();

  SetBrightness(modes[currentMode].Brightness);
  loadingFlag = true;

  jsonWrite(configSetup, "br", modes[currentMode].Brightness);
  jsonWrite(configSetup, "sp", modes[currentMode].Speed);
  jsonWrite(configSetup, "sc", modes[currentMode].Scale);
  saveConfig("setup");

  HTTP.send(200, "text/plain", "OK");

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// -------------------------------------------------- АВТОЯРКОСТЬ ЭФФЕКТОВ (в зависимости от времени суток) --------------------------------------------

void handle_auto_bri () {
  if (!HTTP.hasArg("auto_bri")) {
    HTTP.send(400, "text/plain", "Missing auto_bri");
    return;
  }
  AutoBrightness = constrain(HTTP.arg("auto_bri").toInt(), 0, 1);
  jsonWrite(configSetup, "auto_bri", AutoBrightness);

#if USE_DAWN
  if (ONflag && !dawnFlag) {
#else
  if (ONflag) {
#endif
    SetBrightness(modes[currentMode].Brightness);
  }
  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);
  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

// ------------------------------------------------------------------ НАСТРОЙКИ ДИСПЛЕЯ ST7789 ---------------------------------------------------------

#if USE_ST7789
void handle_tft_clock_color() {
  int val = HTTP.arg("tft_clock_color").toInt();
  jsonWrite(configST7789, "tft_clock_color", val);
  saveConfig();
  tft_clock_color = val;
  loadingFlag = true;
  HTTP.send(200, F("text/plain"), F("OK"));
}

void handle_tft_date_color() {
  if (HTTP.hasArg("tft_date_color")) {
    uint8_t val = HTTP.arg("tft_date_color").toInt();
    if (val <= 20) {
      tft_date_color = val;
      jsonWrite(configST7789, "tft_date_color", tft_date_color);
      saveConfig();
      loadingFlag = true;
    }
  }
  HTTP.send(200, F("text/plain"), F("OK"));
}

void handle_tft_weather_color() {
  int val = HTTP.arg("tft_weather_color").toInt();
  jsonWrite(configST7789, "tft_weather_color", val);
  saveConfig();
  tft_weather_color = val;
  loadingFlag = true;
  HTTP.send(200, F("text/plain"), F("OK"));
}

void handle_tft_ticker_on() {
  bool val = (HTTP.arg("tft_ticker_on").toInt() == 1);
  jsonWrite(configST7789, "tft_ticker_on", val ? "1" : "0");
  saveConfig();
  tft_ticker_on = val;
  if (st7789Enabled) {
    tftTickerStop();
    tftTickerNextStart = millis() + tftTickerPeriodMs();
  }
  HTTP.send(200, F("text/plain"), F("OK"));
}

void handle_tft_ticker_color() {
  int val = HTTP.arg("tft_ticker_color").toInt();
  jsonWrite(configST7789, "tft_ticker_color", val);
  saveConfig();
  tft_ticker_color = val;
  if (st7789Enabled) {
    tftTickerStop();
    tftTickerNextStart = millis() + tftTickerPeriodMs();
  }
  HTTP.send(200, F("text/plain"), F("OK"));
}

void handle_tft_ticker_speed() {
  uint16_t val = constrain(HTTP.arg("tft_ticker_speed").toInt(), 50, 500);
  jsonWrite(configST7789, "tft_ticker_speed", val);
  saveConfig();
  tft_ticker_speed = val;
  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

void handle_tft_ticker_period() {
  uint16_t val = constrain(HTTP.arg("tft_ticker_period").toInt(), 0, 3600);
  jsonWrite(configST7789, "tft_ticker_period", val);
  saveConfig();
  tft_ticker_period = val;
  if (st7789Enabled) {
    tftTickerStop();
    tftTickerNextStart = millis() + tftTickerPeriodMs();
  }
  HTTP.send(200, F("text/plain"), F("OK"));
}

void handle_tft_ticker_text() {
  String s = HTTP.arg("tft_ticker_text");
  if (s.length() > 120) s.remove(120);
  jsonWrite(configST7789, "tft_ticker_text", s);
  saveConfig();
  s.toCharArray(TFTTickerText, sizeof(TFTTickerText));
  if (st7789Enabled) {
    tftTickerStop();
    tftTickerNextStart = millis() + tftTickerPeriodMs();
  }
  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

void handle_tft_brightness() {
  if (!HTTP.hasArg("tft_brightness")) {
    HTTP.send(400, "text/plain", "Missing parameter");
    return;
  }
  uint8_t brightness = constrain(HTTP.arg("tft_brightness").toInt(), 0, 255);
  if (brightness != tft_brightness) {
    tft_brightness = brightness;
    if (st7789Enabled) {
      TFT_SetBrightness(tft_brightness);
    }
    jsonWrite(configST7789, "tft_brightness", brightness);
    if (tft_auto_brightness) {
      tft_auto_brightness = false;
      jsonWrite(configST7789, "tft_auto_brightness", "0");
      if (st7789Enabled) {
        TFT_SetAutoBrightness(false);
      }
    }
    saveConfig();
  }
  HTTP.send(200, "text/plain", "OK");
}

void handle_tft_auto_brightness() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool enable = (HTTP.arg("value") == "1");
  if (enable != tft_auto_brightness) {
    tft_auto_brightness = enable;
    jsonWrite(configST7789, "tft_auto_brightness", enable ? "1" : "0");
    saveConfig();
    if (st7789Enabled) {
      TFT_SetAutoBrightness(enable);
    }
  }
  HTTP.send(200, "text/plain", "OK");
}

#endif // USE_ST7789
// --------------------------------
void handle_save_brightness() {
  uint8_t day_bright = constrain(HTTP.arg("day_bright").toInt(), 0, 255);
  uint8_t night_bright = constrain(HTTP.arg("night_bright").toInt(), 0, 255);

  jsonWrite(configSetup, "day_bright", day_bright);
  jsonWrite(configSetup, "night_bright", night_bright);
  saveConfig();

  DAY_HOURS_BRIGHTNESS = day_bright;
  NIGHT_HOURS_BRIGHTNESS = night_bright;

#if USE_ST7789
  jsonWrite(configST7789, "day_bright", day_bright);
  jsonWrite(configST7789, "night_bright", night_bright);
  writeFile(F("config_st7789.json"), configST7789);

  TFT_DAY_BRIGHTNESS = day_bright;
  TFT_NIGHT_BRIGHTNESS = night_bright;
  if (st7789Enabled) {
    if (!tft_auto_brightness) {
      TFT_SetBrightness(tft_brightness);
    } else {
      TFT_ApplyBrightnessNow();
    }
  }
#endif

  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  HTTP.send(200, F("text/plain"), F("OK"));
}

// ----------------------------------------------------------------------- НАСТРОЙКИ TM1637 ------------------------------------------------------------

#if USE_TM1637
void handle_tm1637_brightness() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  uint8_t brightness = constrain(HTTP.arg("value").toInt(), 0, 255);
  if (brightness != userTm1637Brightness) {
    userTm1637Brightness = brightness;
    jsonWrite(configSetup, "tm1637_brightness", String(brightness));
    if (userTm1637AutoBrightness) {
      userTm1637AutoBrightness = false;
      jsonWrite(configSetup, "tm1637_auto_brightness", "0");
    }
    saveConfig();
    if (tm1637Enabled) {
      clockTicker_blink();
    }
  }
  HTTP.send(200, "text/plain", String(brightness));
}

void handle_tm1637_auto_brightness() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool enable = (HTTP.arg("value") == "1");
  if (enable != userTm1637AutoBrightness) {
    userTm1637AutoBrightness = enable;
    jsonWrite(configSetup, "tm1637_auto_brightness", enable ? "1" : "0");
    saveConfig();
    if (tm1637Enabled) {
      clockTicker_blink();
    }
  }
  HTTP.send(200, "text/plain", enable ? "1" : "0");
}
#endif

// ---------------------------------------------------------------------- НАСТРОЙКИ МАТРИЦЫ ------------------------------------------------------------

// Чекбокс "Поддеоржка нескольких матриц"
#if MULTI_MATRIX
void handle_multi_matrix_enable() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }

  bool newVal = (HTTP.arg("value") == "1" || HTTP.arg("value").equalsIgnoreCase("true"));

  if (newVal == multiMatrixEnabled) {
    HTTP.send(200, "text/plain", "NO_CHANGE");
    return;
  }

  configLED = readFile(F("config_led_matrix.json"), 8192);
  if (configLED == "Failed" || configLED == "Large") configLED = "{}";

  jsonWrite(configLED, "multi_matrix", newVal ? 1 : 0);
  writeFile(F("config_led_matrix.json"), configLED);

  multiMatrixEnabled = newVal;

  // применение без перезагрузки
  loadingFlag = true;
  needFullRedraw = true;

#if MATRIX_LOG
  SYSLOG.add("multiMatrixEnabled: %d", multiMatrixEnabled);
#endif

  HTTP.send(200, "text/plain", "OK");
}
#endif

// -----------------------------------

void handle_matrix_tipe() {
  configLED = readFile(F("config_led_matrix.json"), 8192);
  if (configLED == "Failed" || configLED == "Large") {
    configLED = "{}";
  }

  int newType = HTTP.arg("m_t").toInt();
  if (newType != 0 && newType != 1) {
    newType = 0;
  }

  String oldType = jsonRead(configLED, "m_t");
  if (oldType.toInt() != newType) {
    jsonWrite(configLED, "m_t", newType);
    writeFile(F("config_led_matrix.json"), configLED);
    MatrixType = newType;
    loadingFlag = true;
    needFullRedraw = true;
    HTTP.send(200, "text/plain", "OK");
  } else {
    HTTP.send(200, "text/plain", "NO_CHANGE");
  }
}

void handle_matrix_orientation() {
  configLED = readFile(F("config_led_matrix.json"), 8192);
  if (configLED == "Failed" || configLED == "Large") configLED = "{}";

  int newOri = HTTP.arg("m_o").toInt();
  if (newOri < 0 || newOri > 7) newOri = 0;

  String oldOri = jsonRead(configLED, "m_o");
  if (oldOri.toInt() != newOri) {
    jsonWrite(configLED, "m_o", newOri);
    writeFile(F("config_led_matrix.json"), configLED);
    MatrixOrientation = newOri;
    loadingFlag = true;
    needFullRedraw = true;
    HTTP.send(200, "text/plain", "OK");
  } else {
    HTTP.send(200, "text/plain", "NO_CHANGE");
  }
}

// -------------------------------------------------------------------------- НАСТРОЙКИ MQTT -----------------------------------------------------------

#if USE_MQTT
void handle_mqtt_set() {
  String mq_ip = HTTP.arg("mq_ip");
  uint16_t mq_port = HTTP.arg("mq_port").toInt();
  String mq_user = HTTP.arg("mq_user");
  String mq_pass = HTTP.arg("mq_pass");
  String mq_topic = HTTP.arg("topic");

  if (mq_port < 1 || mq_port > 65535) mq_port = 1883;

  if (!MqttServer.fromString(mq_ip)) {
    mq_ip.toCharArray(MqttHost, sizeof(MqttHost) - 1);
    MqttHost[sizeof(MqttHost) - 1] = '\0';
    mqttIPaddr = false;
  } else {
    mqttIPaddr = true;
  }

  mq_user.toCharArray(MqttUser, sizeof(MqttUser) - 1);
  mq_pass.toCharArray(MqttPassword, sizeof(MqttPassword) - 1);
  mq_topic.toCharArray(TopicBase, sizeof(TopicBase) - 1);

  MqttUser[sizeof(MqttUser) - 1] = '\0';
  MqttPassword[sizeof(MqttPassword) - 1] = '\0';
  TopicBase[sizeof(TopicBase) - 1] = '\0';

  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configMQTT.length() == 0 || deserializeJson(cfg, configMQTT)) {
    cfg.clear();
    cfg.to<JsonObject>();
  }

  cfg["mq_ip"] = mq_ip;
  cfg["mq_port"] = (int)mq_port;
  cfg["mq_user"] = mq_user;
  cfg["mq_pass"] = mq_pass;
  cfg["topic"] = mq_topic;
  cfg["TopicS"] = String(Mqtt::instance().getClientId()) + '/' + String(TopicCmnd);
  cfg["TopicP"] = String(Mqtt::instance().getClientId()) + '/' + String(TopicSnd);

  configMQTT = "";
  configMQTT.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configMQTT);

  writeFile(F("config_mqtt.json"), configMQTT);

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

void handle_mqtt_on() {
  MqttOn = HTTP.arg("mq_on").toInt();

  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configMQTT.length() == 0 || deserializeJson(cfg, configMQTT)) {
    cfg.clear(); cfg.to<JsonObject>();
  }
  cfg["mq_on"] = (int)MqttOn;

  configMQTT = "";
  configMQTT.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configMQTT);
  writeFile(F("config_mqtt.json"), configMQTT);

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

void handle_mqtt_period() {
  MqttPeriod = HTTP.arg("mq_prd").toInt();
  if (MqttPeriod < 10)   MqttPeriod = 10;
  if (MqttPeriod > 3600) MqttPeriod = 3600;

  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configMQTT.length() == 0 || deserializeJson(cfg, configMQTT)) {
    cfg.clear(); cfg.to<JsonObject>();
  }
  cfg["mq_prd"] = (int)MqttPeriod;

  configMQTT = "";
  configMQTT.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configMQTT);
  writeFile(F("config_mqtt.json"), configMQTT);

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

#endif // USE_MQTT

// -------------------------------------------------------------------- ЧТЕНИЕ ФАЙЛОВ ФОЛРМАТА .OUT ---------------------------------------------------

#if USE_SD
void handle_list_out_files() {
  if (!sdEnabled) {
    HTTP.send(200, "application/json", "[]");
    return;
  }

  String fileList = "[";
  bool first = true;
  File root;

  String sizeFolder = String(matrixWidth) + "x" + String(matrixHeight);
  String effectsPath = "/effects/" + sizeFolder;

  auto openDir = [](const String & path) -> File {
    if (sdType == 1) return LittleFS.open(path);
    else return SD.open(path);
  };

  root = openDir(effectsPath);
  if (!root || !root.isDirectory()) {
    if (root) root.close();
    root = openDir("/effects/");
    if (!root || !root.isDirectory()) {
      if (root) root.close();
      HTTP.send(200, "application/json", "[]");
      return;
    }
  }

  while (true) {
    File file = root.openNextFile();
    if (!file) break;
    String name = file.name();
    int lastSlash = name.lastIndexOf('/');
    if (lastSlash >= 0) name = name.substring(lastSlash + 1);
    if (name.endsWith(".out")) {
      if (!first) fileList += ",";
      fileList += "\"" + name + "\"";
      first = false;
    }
    file.close();
  }
  root.close();
  fileList += "]";
  HTTP.send(200, "application/json", fileList);
}
#endif // USE_SD

// --------------------------------------------------------- СТАТУСЫ УСТРОЙСТВ В МОДАЛЬНОМ ОКНЕ МЕНЮ --------------------------------------------------

#if STATUS_DEVICE
// статус кнопки
void handle_button_status() {
  PJsonDoc doc(256);

#if USE_BUTTON
  if (buttonEnabled) {
    doc["button_status"] = button_type ? "СЕНСОРНАЯ" : "МЕХАНИЧЕСКАЯ";
  } else {
    doc["button_status"] = "ВЫКЛЮЧЕНА";
  }
  doc["enabled"] = buttonEnabled;
#else
  doc["button_status"] = "ОТКЛЮЧЕНО В ПРОШИВКЕ";
  doc["enabled"] = false;
#endif

  String response;
  serializeJson(doc, response);
  HTTP.send(200, "application/json; charset=utf-8", response);
}

// статус IR, RF
void handle_ir_rf_status() {
  PJsonDoc doc(512);
  String ir_status, rf_status;

#if USE_IR_RECEIVER
  if (irEnabled) {
    ir_status = (millis() - lastIRtime < 5000) ? "OK" : "ОЖИДАЕТ КОМАНДУ";
    String currentRemote = irManager.getCurrentRemoteName();
    if (currentRemote.length() > 0) {
      doc["ir_remote"] = currentRemote;
      doc["ir_remote_id"] = irManager.getCurrentRemoteId();
    } else {
      doc["ir_remote"] = "Не выбран";
      doc["ir_remote_id"] = "";
    }
  } else {
    ir_status = "ВЫКЛЮЧЕН";
    doc["ir_remote"] = "—";
    doc["ir_remote_id"] = "";
  }
#else
  ir_status = "ОТКЛЮЧЕНО В ПРОШИВКЕ";
  doc["ir_remote"] = "—";
  doc["ir_remote_id"] = "";
#endif

#if USE_RF_RECEIVER
  if (rfEnabled) {
    rf_status = rfReceiver.available() ? "OK" : "ОЖИДАЕТ КОМАНДУ";
    if (rf_status == "OK") rfReceiver.resetAvailable();
  } else {
    rf_status = "ВЫКЛЮЧЕН";
  }
#else
  rf_status = "ОТКЛЮЧЕНО В ПРОШИВКЕ";
#endif

  doc["ir"] = ir_status;
  doc["rf"] = rf_status;
  doc["ir_enabled"] = irEnabled;
  doc["rf_enabled"] = rfEnabled;
  String response;
  serializeJson(doc, response);
  HTTP.send(200, "application/json; charset=utf-8", response);
}

// статус дисплея tm1637
void handle_tm1637_status() {
  PJsonDoc doc(256);
  String status;
  bool connected = false;

#if USE_TM1637
  connected = true;
  status = tm1637Enabled ? "ВКЛЮЧЕН" : "ВЫКЛЮЧЕН";
#else
  status = "ОТКЛЮЧЕНО В ПРОШИВКЕ";
#endif

  doc["connected"] = connected;
  doc["status"] = status;
  doc["enabled"] = tm1637Enabled;
  String response;
  serializeJson(doc, response);
  HTTP.send(200, "application/json; charset=utf-8", response);
}

// статус дисплея st7789
void handle_st7789_status() {
  PJsonDoc doc(256);
  String status;
  bool connected = false;

#if USE_ST7789
  connected = true;
  status = st7789Enabled ? "ВКЛЮЧЕН" : "ВЫКЛЮЧЕН";
#else
  status = "ОТКЛЮЧЕНО В ПРОШИВКЕ";
#endif

  doc["connected"] = connected;
  doc["status"] = status;
  doc["enabled"] = st7789Enabled;
  String response;
  serializeJson(doc, response);
  HTTP.send(200, "application/json; charset=utf-8", response);
}

// статус мп3 плеера
void handle_mp3_status() {
  PJsonDoc doc(512);
  String status;
  bool card_ok = false;

#if USE_MP3_PLAYER
  card_ok = (mp3_player_connect == 4) ? mp3_card_ok : false;

  if (!mp3Enabled) {
    status = "ВЫКЛЮЧЕН";
  } else if (mp3_player_connect == 0) {
    status = "НЕТ СВЯЗИ";
  } else if (mp3_player_connect != 4) {
    status = "ИНИЦИАЛИЗАЦИЯ...";
  } else if (dfPlayerIsOriginal && !mp3_card_ok) {
    status = "КАРТА НЕИСПРАВНА";
  } else if (eff_sound_on && !mp3_stop && !pause_on) {
    status = "ИГРАЕТ";
  } else if (eff_sound_on && pause_on) {
    status = "ПАУЗА";
  } else if (eff_sound_on && mp3_stop) {
    status = "ВЫКЛЮЧЕН";
  } else {
    status = "ГОТОВ";
  }

  doc["connect"] = mp3_player_connect;
  doc["folder"] = CurrentFolder;
  doc["volume"] = eff_volume;
  doc["sound_on"] = eff_sound_on;
  doc["stop"] = mp3_stop;
  doc["pause"] = pause_on;
  doc["enabled"] = mp3Enabled;
#else
  status = "ОТКЛЮЧЕНО В ПРОШИВКЕ";
  card_ok = false;
  doc["connect"] = 0;
  doc["folder"] = 0;
  doc["volume"] = 0;
  doc["sound_on"] = 0;
  doc["stop"] = 1;
  doc["pause"] = 1;
  doc["enabled"] = false;
#endif

  doc["mp3_status"] = status;
  doc["card_ok"] = card_ok;

  String response;
  serializeJson(doc, response);
  HTTP.send(200, "application/json; charset=utf-8", response);
}

// статус Радио
void handle_radio_status() {
  PJsonDoc doc(256);

#if USE_RADIO
  doc["enabled"] = radioEnabled;
  doc["playing"] = radioPlaying;
  doc["paused"] = !radioPlaying && radioInited && currentStation > 0;
  doc["ready"] = radioInited;
  doc["station"] = currentStation;
  doc["volume"] = radioVolume;
  doc["station_name"] = (currentStation > 0) ? getStationName(currentStation - 1) : "";
#else
  doc["enabled"] = false;
  doc["playing"] = false;
  doc["paused"] = false;
  doc["ready"] = false;
  doc["station"] = 0;
  doc["volume"] = 0;
  doc["station_name"] = "ОТКЛЮЧЕНО В ПРОШИВКЕ";
#endif

  String resp;
  serializeJson(doc, resp);
  HTTP.send(200, "application/json; charset=utf-8", resp);
}

// статус SD
void handle_sd_status() {
  PJsonDoc doc(512);
  String sd_status;

#if USE_SD
  if (!sdEnabled) {
    sd_status = "ВЫКЛЮЧЕНО";
    doc["fs_status"] = "—";
  } else if (sdType == 1) {
    sd_status = "ЭМУЛЯЦИЯ В LITTLEFS";
    doc["fs_status"] = LittleFS.begin() ? "ОК" : "ОШИБКА";
  } else {
    sd_status = sd_card_present ? "ОК" : "КАРТА НЕ НАЙДЕНА";
    doc["fs_status"] = sd_card_present ? "ОК" : "ОШИБКА";
  }
#else
  sd_status = "ОТКЛЮЧЕНО В ПРОШИВКЕ";
#endif

  doc["sd_status"] = sd_status;
  doc["sd_enabled"] = sdEnabled;
  doc["sd_type"] = sdType;
  doc["card_present"] = sd_card_present;
  String response;
  serializeJson(doc, response);
  HTTP.send(200, "application/json; charset=utf-8", response);
}

// статус погоды
void handle_show_weather() {
#if USE_WEATHER
  if (!HTTP.hasArg("show_weather")) {
    HTTP.send(400, "text/plain", "Missing show_weather");
    return;
  }
  int enabled = HTTP.arg("show_weather").toInt();
  inClockWeatherMode = (enabled == 1);
  jsonWrite(configWeather, "show_weather", enabled);
  saveConfig();
  if (inClockWeatherMode && Wifi::instance().isConnected()) {
    Weather::instance().forceUpdate();
  }
  HTTP.send(200, "text/plain", "OK");
#else
  HTTP.send(503, "text/plain", "Weather disabled in firmware");
#endif
}

// статус OTA
uint8_t otaProgress = 0;
String  otaStatus = "ГОТОВ";
void handle_ota_status() {
  PJsonDoc doc(256);
  String status = "ГОТОВ";

#if USE_OTA
  if (Update.isRunning()) {
    status = (otaProgress == 0) ? "ЗАГРУЗКА..." : "ЗАПИСЬ... " + String(otaProgress) + "%";
  }
#else
  status = "ОТКЛЮЧЕНО В ПРОШИВКЕ";
#endif

  doc["status"] = status;
  doc["progress"] = otaProgress;
  doc["enabled"] = !!USE_OTA;

  String resp;
  serializeJson(doc, resp);
  HTTP.send(200, "application/json; charset=utf-8", resp);
}

// статус MQTT
void handle_mqtt_status() {
  PJsonDoc doc(256);
  String status;
  bool connected = false;

#if USE_MQTT
  connected = Mqtt::instance().isConnected();
  status = connected ? "ПОДКЛЮЧЕНО" : "НЕ ПОДКЛЮЧЕНО";
#else
  status = "ОТКЛЮЧЕНО В ПРОШИВКЕ";
#endif

  doc["status"] = status;
  doc["enabled"] = !!USE_MQTT;
  doc["connected"] = connected;

  String resp;
  serializeJson(doc, resp);
  HTTP.send(200, "application/json; charset=utf-8", resp);
}

// статус режим "Мультилампа"
void handle_multilamp_status() {
  PJsonDoc doc(512);

#if USE_MULTILAMP
  doc["enabled"] = true;
  doc["lamp1"] = ml1;
  doc["lamp2"] = ml2;
  doc["lamp3"] = ml3;
  doc["lamp4"] = ml4;
  doc["lamp5"] = ml5;
  doc["host1"] = String(Host1);
  doc["host2"] = String(Host2);
  doc["host3"] = String(Host3);
  doc["host4"] = String(Host4);
  doc["host5"] = String(Host5);
#if USE_MP3_PLAYER
  doc["send_sound"] = send_sound;
  doc["send_volume"] = send_eff_volume;
#endif
#else
  doc["enabled"] = false;
  doc["status"] = "ОТКЛЮЧЕНО В ПРОШИВКЕ";
#endif

  String resp;
  serializeJson(doc, resp);
  HTTP.send(200, "application/json; charset=utf-8", resp);
}

#endif // STATUS_DEVICE

// -------------------------------------------------------------------- НАСТРОЙКИ БЕГУЩЕЙ СТРОКИ ------------------------------------------------------

#if LED_PANEL
void ApplyRunningTextSettings() {
  if (!runTextEnabled) {
    textIsRunning = false;
    drawStringThisTick = false;
    runningTextTimer.setInterval(999999999UL);
    runningTextTimer.reset();
    Fill_String = false;
    currentRunningTextIntervalMs = 0;
    return;
  }

  if (IntervalrunText == 0) {
    // непрерывный режим (перезапуск с чистого листа)
    textIsRunning = true;
    drawStringThisTick = runTextOver;
    Fill_String = false;
    offset = matrixWidth + 10;
    scrollTimer = millis();
    runningTextTimer.setInterval(999999999UL);
    runningTextTimer.reset();
    currentRunningTextIntervalMs = 0;
    loadingFlag = true;
    needFullRedraw = true;
  } else {
    // периодический режим
    textIsRunning = false;
    uint32_t intervalMs = (uint32_t)IntervalrunText * 60000UL;
    if (currentRunningTextIntervalMs != intervalMs) {
      runningTextTimer.setInterval(intervalMs);
      runningTextTimer.reset();
      currentRunningTextIntervalMs = intervalMs;
    }
  }
#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Включить бегущую строку"
void handle_run_text_enabled() {
  String arg = HTTP.arg("value");
  bool newVal = (arg == "1" || arg.toInt() == 1);
  if (newVal == runTextEnabled) {
    HTTP.send(200, "text/plain", "OK");
    return;
  }

  runTextEnabled = newVal;

  if (!runTextEnabled) {
    // полное выключение бегущей строки
    runTextOver = false; // снять галочку и с "поверх эффекта"
    textIsRunning = false;
    drawStringThisTick = false;
    Fill_String = false;
    offset = matrixWidth + 10;
    runningTextTimer.setInterval(TIMER_DISABLED);
    runningTextTimer.reset();

    jsonWrite(configLedPanel, "run_text_over", "0");
  }

  jsonWrite(configLedPanel, "run_text_enabled", newVal ? "1" : "0");
  saveConfig();

  if (runTextEnabled) {
    ApplyRunningTextSettings();
  } else {
    loadingFlag = true;
    needFullRedraw = true;
  }

  HTTP.send(200, "text/plain", "OK");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Бегущая строка поверх эффекта"
void handle_run_text_over() {
  String arg = HTTP.arg("value");
  bool newVal = (arg == "1" || arg == "true" || arg.toInt() == 1);
  if (newVal == runTextOver) {
    HTTP.send(200, "text/plain", "OK");
    return;
  }

  runTextOver = newVal;
  jsonWrite(configLedPanel, "run_text_over", newVal ? "1" : "0");

  if (runTextOver) {
    if (!runTextEnabled) {
      runTextEnabled = true;
      jsonWrite(configLedPanel, "run_text_enabled", "1");
    }
    textIsRunning = true;
    drawStringThisTick = true;
    offset = matrixWidth + 10;
  } else {
    drawStringThisTick = false;
    if (!runTextEnabled) {
      textIsRunning = false;
    }
  }

  saveConfig();
  loadRunningTextSettings();

  loadingFlag = true;
  needFullRedraw = true;

  HTTP.send(200, "text/plain", "OK");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Текст бегущей строки
void handle_run_text() {
  String text = HTTP.arg("run_text");
  const size_t MAX_TEXT_LEN = sizeof(TextTicker) - 1;

  if (text.length() > MAX_TEXT_LEN) {
    text = text.substring(0, MAX_TEXT_LEN);
  }

  jsonWrite(configLedPanel, "run_text", text);
  timeout_save_file_changes = millis();
  bitSet(save_file_changes, 0);

  text.toCharArray(TextTicker, sizeof(TextTicker));

  if (textIsRunning) {
    offset = matrixWidth + 10;
    scrollTimer = millis();
    Fill_String = false;
    drawStringThisTick = runTextOver;
    loadingFlag = true;
    needFullRedraw = true;
  }

  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Интервал вывода бегущей строки
void handle_interval_run_text() {
  if (!HTTP.hasArg("interval_run_text")) {
    HTTP.send(400, F("text/plain"), F("Missing parameter: interval_run_text"));
    return;
  }
  String arg = HTTP.arg("interval_run_text");
  int newInterval = arg.toInt();
  newInterval = constrain(newInterval, 0, 60);

  if (newInterval == IntervalrunText) {
    HTTP.send(200, F("text/plain"), F("OK"));
    return;
  }

  IntervalrunText = newInterval;
  jsonWrite(configLedInterval, "interval_run_text", IntervalrunText);
  saveConfig();
  ApplyRunningTextSettings();
  HTTP.send(200, F("text/plain"), F("OK"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Смещение текста по Y
void handle_text_y_offset() {
  if (!HTTP.hasArg("text_y_offset")) {
    HTTP.send(400, "text/plain", "Parameter missing");
    return;
  }

  int value = HTTP.arg("text_y_offset").toInt();
  int maxShift = matrixHeight * 2;
  value = constrain(value, -maxShift, maxShift);

  if (textYOffset != value) {
    textYOffset = value;
    jsonWrite(configLedPanel, "text_y_offset", value);
    saveConfig();
    loadRunningTextSettings();
    loadingFlag = true;
    offset = matrixWidth + 10;
    textIsRunning = true;
    Fill_String = false;
  }

  HTTP.send(200, "text/plain", String(value));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Скорость бегущей строки
void handle_spt() {
  if (!HTTP.hasArg("spt")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  int newSpeed = constrain(HTTP.arg("spt").toInt(), 20, 220);
  if (newSpeed == SpeedRunningText) {
    HTTP.send(200, "text/plain", String(newSpeed));
    return;
  }
  SpeedRunningText = newSpeed;
  jsonWrite(configLedPanel, "spt", SpeedRunningText);
  saveConfig();

  if (runTextEnabled) {
    textIsRunning = false;
    drawStringThisTick = false;
    Fill_String = false;
    offset = matrixWidth + 10;
    scrollTimer = millis();
    loadingFlag = true;
    needFullRedraw = true;
    if (IntervalrunText == 0) {
      textIsRunning = true;
      drawStringThisTick = runTextOver;
    } else {
      runningTextTimer.reset();
    }
  }
  HTTP.send(200, "text/plain", String(newSpeed));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Оттенок текста бегущей строки
void handle_sct() {
  if (!HTTP.hasArg("sct")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  int value = constrain(HTTP.arg("sct").toInt(), 0, 255);

  rainbowText = false;

  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configLedPanel.length() == 0 || deserializeJson(cfg, configLedPanel)) {
    cfg.clear(); cfg.to<JsonObject>();
  }

  cfg["rainbow_text"] = "0";

  int sctForDisplay;
  if (value >= 253) {
    runTextColorCycle = true;
    autoRunTextHue = false;
    runTextHue = 0;
    ColorRunningText = 0;
    textIsRunning = true;
    offset = matrixWidth + 10;
    loadingFlag = true;
    cfg["run_text_cycle"] = "1";
    cfg["run_text_hue"]   = "0";
    sctForDisplay = 0;
  } else {
    runTextColorCycle = false;
    autoRunTextHue = false;
    runTextHue = (uint8_t)value;
    ColorRunningText = runTextHue;
    cfg["run_text_cycle"] = "0";
    cfg["run_text_hue"]   = String(runTextHue);
    sctForDisplay = runTextHue;
  }

  cfg["sct"] = String(sctForDisplay);

  configLedPanel = "";
  configLedPanel.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configLedPanel);
  saveConfig("ledpanel");

  loadingFlag = true;
  scrollTimer = millis() - 1000;

  HTTP.send(200, "text/plain", String(sctForDisplay));
}

// Шрифт бегущей строки
void handle_font_size() {
  if (!HTTP.hasArg("font_size")) {
    HTTP.send(400, "text/plain", "Missing font_size parameter");
    return;
  }

  String arg = HTTP.arg("font_size");
  if (arg.length() == 0) {
    HTTP.send(400, "text/plain", "Empty font_size value");
    return;
  }

  int val = arg.toInt();
  if (val < 0 || val > 2) {
    HTTP.send(400, "text/plain", "Invalid font_size value (must be 0–2)");
    return;
  }

  uint8_t newSize = (uint8_t)val;

  if (newSize == currentFont) {
    HTTP.send(200, "text/plain", "OK (no change)");
    return;
  }

  jsonWrite(configLedPanel, "font_size", newSize);
  saveConfig();

  setFontSize(newSize);

  const char* names[] = {"5×8", "8×13", "10×16"};

  HTTP.send(200, "text/plain", "OK");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}
#endif // LED_PANEL

// --------------------------------------------------------------------------- НАСТРОЙКИ ЧАСОВ --------------------------------------------------------

// Чекбокс "Авто-сдвиг часов"
void handle_auto_move_clock() {
  String arg = HTTP.arg("value");
  bool newVal = (arg == "1" || arg == "true" || arg.toInt() == 1);

  if (autoMoveClockEnabled != newVal) {
    autoMoveClockEnabled = newVal;
    jsonWrite(configLedPanel, "auto_move_clock", newVal ? "1" : "0");
    timeout_save_file_changes = millis();
    bitSet(save_file_changes, 0);

    if (newVal) {
      clockAutoOffsetY = 0;
      loadingFlag = true;
    }
  }

  HTTP.send(200, "text/plain", "OK");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Интервал вывода часов
void handle_print_time() {
  int val = HTTP.arg("print_time").toInt();
  if (val < 1 || val > 60) val = 30;
  PRINT_TIME = val;
  jsonWrite(configLedInterval, "print_time", PRINT_TIME);
  saveConfig();
  HTTP.send(200, "text/plain", "OK");
}

// Чекбокс "Часы бегущей строкой"
void handle_run_time_text_enabled() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value parameter");
    return;
  }

  String valStr = HTTP.arg("value");
  valStr.toLowerCase();
  bool newVal = (valStr == "1" || valStr == "true" || valStr == "on");
  runTimeTextEnabled = newVal;

  if (runTimeTextEnabled) {
    timeTextJustEnabled = true;
  }

  jsonWrite(configLedPanel, "run_time_text_enabled", runTimeTextEnabled ? "1" : "0");
  saveConfig();
  HTTP.send(200, "text/plain", runTimeTextEnabled ? "1" : "0");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Ведущий ноль"
void handle_clock_leading_zero() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value parameter");
    return;
  }
  String valStr = HTTP.arg("value");
  bool newVal = (valStr == "1" || valStr == "true" || valStr == "on");

  if (clockLeadingZero == newVal) {
    HTTP.send(200, "text/plain", clockLeadingZero ? "1" : "0");
    return;
  }

  clockLeadingZero = newVal;
  jsonWrite(configLedPanel, "clock_leading_zero", clockLeadingZero ? "1" : "0");
  saveConfig();
  loadingFlag = true;

  HTTP.send(200, "text/plain", clockLeadingZero ? "1" : "0");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Вертикальные часы"
void handle_clock_vert() {
  String arg = HTTP.arg("value");
  bool newVal = (arg == "1" || arg == "true" || arg.toInt() == 1);

  if (clockIsVertical != newVal) {
    clockIsVertical = newVal;
    jsonWrite(configLedPanel, "clock_vert", newVal ? "1" : "0");
    timeout_save_file_changes = millis();
    bitSet(save_file_changes, 0);
    loadingFlag = true;
    clockAutoOffsetY = 0;
    lastMinute = 255;
  }

  HTTP.send(200, "text/plain", "OK");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Включить ночные часы"
void handle_night_clock_enabled() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  uint8_t val = HTTP.arg("value").toInt();
  bool newVal;

  if (val == 2) {
    newVal = !nightClockEnabled;
  } else {
    newVal = (val == 1);
  }

  if (newVal == nightClockEnabled) {
    HTTP.send(200, "text/plain", nightClockEnabled ? "1" : "0");
    return;
  }

  nightClockEnabled = newVal;
  jsonWrite(configLedPanel, "night_clock_enabled", nightClockEnabled ? "1" : "0");

  if (nightClockEnabled) {
    if (userClockBrightness < 2) {
      userClockBrightness = jsonReadtoInt(configSetup, "br");
      if (userClockBrightness < 2) userClockBrightness = 30;
      jsonWrite(configSetup, "user_clock_br", userClockBrightness);
    }
    ONflag = true;
    jsonWrite(configSetup, "Power", 1);
    currentMode = eff_num_correct[EFF_CLOCK];
    loadingFlag = true;

    uint8_t ui_index = 0;
    for (ui_index = 0; ui_index < MODE_AMOUNT; ui_index++) {
      if (eff_num_correct[ui_index] == currentMode) break;
    }
    jsonWrite(configSetup, "eff_sel", ui_index);

    nightModeBrightness = nightClockBrightness;
    modes[currentMode].Brightness = nightModeBrightness;
    jsonWrite(configSetup, "br", nightModeBrightness);
    FastLED.setBrightness(nightModeBrightness);

    effectsTick();
    effTimer = millis() - 1000;
    changePower();
    sendCurrent(udpBuffer);
  } else {
    nightModeBrightness = 0;
    uint8_t normalBrightness = userClockBrightness;
    if (normalBrightness == 0) normalBrightness = 30;
    modes[currentMode].Brightness = normalBrightness;
    jsonWrite(configSetup, "br", normalBrightness);
    Eeprom::instance().EepromPut(modes);
    FastLED.setBrightness(normalBrightness);
    FastLED.show();
    Eeprom::instance().EepromPut(modes);
  }

  saveConfig();

  HTTP.send(200, "text/plain", nightClockEnabled ? "1" : "0");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Выбор яркости ночных часов
void handle_night_clock_brightness() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  uint8_t newVal = HTTP.arg("value").toInt();
  if (newVal < 1 || newVal > 255) {
    newVal = 1;
  }
  if (newVal == nightClockBrightness) {
    HTTP.send(200, "text/plain", String(nightClockBrightness));
    return;
  }
  nightClockBrightness = newVal;
  jsonWrite(configLedPanel, "night_clock_brightness", nightClockBrightness);

  bool setupChanged = false;
  if (nightClockEnabled && currentMode == eff_num_correct[EFF_CLOCK]) {
    nightModeBrightness = nightClockBrightness;
    modes[currentMode].Brightness = nightModeBrightness;
    jsonWrite(configSetup, "br", nightModeBrightness);
    setupChanged = true;
    FastLED.setBrightness(nightModeBrightness);
    FastLED.show();
  }

  saveConfig("ledpanel");
  if (setupChanged) saveConfig("setup");

  HTTP.send(200, "text/plain", String(nightClockBrightness));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

#if LED_PANEL
// Смещение часов по X
void handle_clock_x_offset() {
  if (!HTTP.hasArg("clock_x_offset")) {
    HTTP.send(400, "text/plain", "Parameter missing");
    return;
  }

  int value = HTTP.arg("clock_x_offset").toInt();
  value = constrain(value, -50, 50);

  if (clockXOffset != value) {
    clockXOffset = value;
    jsonWrite(configLedPanel, "clock_x_offset", value);
    saveConfig();
    loadingFlag = true;
    clockNeedRedraw = true;
    needFullRedraw = true;
  }

  HTTP.send(200, "text/plain", String(value));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Смещение часов по Y
void handle_clock_y_offset() {
  if (!HTTP.hasArg("clock_y_offset")) {
    HTTP.send(400, "text/plain", "Parameter missing");
    return;
  }

  int value = HTTP.arg("clock_y_offset").toInt();
  value = constrain(value, -20, 20);

  if (clockYOffset != value) {
    clockYOffset = value;
    jsonWrite(configLedPanel, "clock_y_offset", value);
    saveConfig();
    loadingFlag = true;
    clockNeedRedraw = true;
    needFullRedraw = true;
  }

  HTTP.send(200, "text/plain", String(value));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Оттенок часов
void handle_clock_hue() {
  if (!HTTP.hasArg("clock_hue")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }

  int value = constrain(HTTP.arg("clock_hue").toInt(), 0, 255);

  rainbowClock = false;

  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configLedPanel.length() == 0 || deserializeJson(cfg, configLedPanel)) {
    cfg.clear(); cfg.to<JsonObject>();
  }

  cfg["rainbow_clock"] = "0";

  if (value >= 253) { // ползунок на 255 = фэйд-режим
    clockColorCycle = true;
    clockHue = 0;
    cfg["clock_cycle"] = "1";
  } else {
    clockColorCycle = false;
    clockHue = (uint8_t)value;
    cfg["clock_cycle"] = "0";
  }

  cfg["clock_hue"] = String(clockHue);

  configLedPanel = "";
  configLedPanel.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configLedPanel);
  saveConfig("ledpanel");

  loadingFlag = true;

  HTTP.send(200, "text/plain", String(clockHue));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
#if USE_MQTT
  if (Wifi::instance().isConnected()) Mqtt::instance().needToPublish = true;
#endif
}
#endif // LED_PANEL

// ------------------------------------------------------------------------- НАСТРОЙКИ ПОГОДЫ ---------------------------------------------------------

#if USE_WEATHER
// Интервал вывода погоды
void handle_print_weather() {
  int val = HTTP.arg("print_weather").toInt();
  if (val < 1 || val > 60) val = 30;
  PRINT_WEATHER = val;
  jsonWrite(configLedInterval, "print_weather", PRINT_WEATHER);
  saveConfig();
  HTTP.send(200, "text/plain", "OK");
}

// Чекбокс "Погода бегущей строкой"
void handle_run_weather_text_enabled() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value parameter");
    return;
  }

  String valStr = HTTP.arg("value");
  valStr.toLowerCase();
  bool newVal = (valStr == "1" || valStr == "true" || valStr == "on");
  runWeatherTextEnabled = newVal;
  jsonWrite(configLedPanel, "run_weather_text_enabled", runWeatherTextEnabled ? "1" : "0");
  saveConfig();

  HTTP.send(200, "text/plain", runWeatherTextEnabled ? "1" : "0");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}
#endif // USE_WEATHER

#if LED_PANEL
#if USE_WEATHER
// Чекбокс "Включить погоду для отображеня на матрице"
void handle_weather_enabled() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, F("text/plain"), F("Parameter missing"));
    return;
  }
  bool newVal = HTTP.arg("value") == "1";

  if (newVal == weatherEnabled) {
    HTTP.send(200, "text/plain", "OK");
    return;
  }

  bool wasEnabled = weatherEnabled;
  weatherEnabled = newVal;
  jsonWrite(configLedPanel, "weather_enabled", weatherEnabled ? "1" : "0");
  saveConfig();
  loadingFlag = true;
  if (!weatherEnabled && wasEnabled) {
    clearLastWeatherZone();
    lastWeatherLeft = lastWeatherRight = -1;
  }

  weatherNeedRedraw = true;
  needFullRedraw = true;

  HTTP.send(200, "text/plain", "OK");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Оттенок погоды
void handle_weather_hue() {
  if (!HTTP.hasArg("weather_hue")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }

  int value = constrain(HTTP.arg("weather_hue").toInt(), 0, 255);

  rainbowWeather = false;

  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configLedPanel.length() == 0 || deserializeJson(cfg, configLedPanel)) {
    cfg.clear(); cfg.to<JsonObject>();
  }

  cfg["rainbow_weather"] = "0";

  if (value >= 253) {
    weatherColorCycle = true;
    weatherHue = 0;
    cfg["weather_cycle"] = "1";
  } else {
    weatherColorCycle = false;
    weatherHue = (uint8_t)value;
    cfg["weather_cycle"] = "0";
  }

  cfg["weather_hue"] = String(weatherHue);

  configLedPanel = "";
  configLedPanel.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configLedPanel);
  saveConfig("ledpanel");

  loadingFlag = true;
  weatherNeedRedraw = true;

  HTTP.send(200, "text/plain", String(weatherHue));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
#if USE_MQTT
  if (Wifi::instance().isConnected()) Mqtt::instance().needToPublish = true;
#endif
}

// Смещение погоды по X
void handle_weather_x_offset() {
  if (!HTTP.hasArg("weather_x_offset")) {
    HTTP.send(400, "text/plain", "Parameter missing");
    return;
  }

  int value = HTTP.arg("weather_x_offset").toInt();

  int maxOffset = matrixWidth - 20;
  int minOffset = -matrixWidth + 20;
  value = constrain(value, minOffset, maxOffset);

  if (weatherXOffset != value) {
    weatherXOffset = value;
    jsonWrite(configLedPanel, "weather_x_offset", String(value));
    saveConfig();

    loadingFlag = true;
    weatherNeedRedraw = true;
    needFullRedraw = true;
  }

  HTTP.send(200, "text/plain", String(value));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Смещение погоды по Y
void handle_weather_y_offset() {
  if (!HTTP.hasArg("weather_y_offset")) {
    HTTP.send(400, "text/plain", "Parameter missing");
    return;
  }

  int value = HTTP.arg("weather_y_offset").toInt();

  value = constrain(value, -16, 16);

  if (weatherYOffset != value) {
    weatherYOffset = value;
    jsonWrite(configLedPanel, "weather_y_offset", String(value));
    saveConfig();

    loadingFlag = true;
    weatherNeedRedraw = true;
  }

  HTTP.send(200, "text/plain", String(value));
}

// Чекбокс "Мигание °"
void handle_degree_blink() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool newVal = HTTP.arg("value") == "1";
  if (newVal == degreeSymbolBlinking) {
    HTTP.send(200, "text/plain", degreeSymbolBlinking ? "1" : "0");
    return;
  }
  degreeSymbolBlinking = newVal;
  jsonWrite(configLedPanel, "degree_blink", degreeSymbolBlinking ? "1" : "0");
  saveConfig();
  loadingFlag = true;

  HTTP.send(200, "text/plain", degreeSymbolBlinking ? "1" : "0");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}
#endif // USE_WEATHER

// ------------------------------------------------------------------------ НАСТРОЙКИ ДАТЫ ------------------------------------------------------------

// Чекбокс "Включить дату для отображеня на матрице"
void handle_date_enabled() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, F("text/plain"), F("Parameter missing"));
    return;
  }
  bool newVal = HTTP.arg("value") == "1";
  if (newVal == dateEnabled) {
    HTTP.send(200, "text/plain", "OK");
    return;
  }

  bool wasEnabled = dateEnabled;
  dateEnabled = newVal;
  jsonWrite(configLedPanel, "date_enabled", dateEnabled ? "1" : "0");
  saveConfig();

  if (!dateEnabled && wasEnabled) {
    clearLastDateZone();
    lastDateLeft = lastDateRight = -1;
    dateNeedRedraw = true;
  }

  loadingFlag = true;
  HTTP.send(200, "text/plain", "OK");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Оттенок даты
void handle_date_hue() {
  if (!HTTP.hasArg("date_hue")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }

  int value = constrain(HTTP.arg("date_hue").toInt(), 0, 255);

  rainbowDate = false;

  PJsonDoc cfg(JSON_BUFFER_SIZE);
  if (configLedPanel.length() == 0 || deserializeJson(cfg, configLedPanel)) {
    cfg.clear(); cfg.to<JsonObject>();
  }

  cfg["rainbow_date"] = "0";

  if (value >= 253) {
    dateColorCycle = true;
    dateHue = 0;
    cfg["date_cycle"] = "1";
  } else {
    dateColorCycle = false;
    dateHue = (uint8_t)value;
    cfg["date_cycle"] = "0";
  }

  cfg["date_hue"] = String(dateHue);

  configLedPanel = "";
  configLedPanel.reserve(measureJson(cfg) + 1);
  serializeJson(cfg, configLedPanel);
  saveConfig("ledpanel");

  loadingFlag = true;
  dateNeedRedraw = true;

  HTTP.send(200, "text/plain", String(dateHue));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
#if USE_MQTT
  if (Wifi::instance().isConnected()) Mqtt::instance().needToPublish = true;
#endif
}

// Смещение даты по X
void handle_date_x_offset() {
  if (!HTTP.hasArg("date_x_offset")) {
    HTTP.send(400, "text/plain", "Parameter missing");
    return;
  }

  int value = HTTP.arg("date_x_offset").toInt();

  int maxOffset = matrixWidth - 10;
  int minOffset = -matrixWidth + 10;
  value = constrain(value, minOffset, maxOffset);

  if (dateXOffset != value) {
    dateXOffset = value;
    jsonWrite(configLedPanel, "date_x_offset", String(value));
    saveConfig();
    loadingFlag = true;
    dateNeedRedraw = true;
    needFullRedraw = true;
  }

  HTTP.send(200, "text/plain", String(value));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Смещение даты по Y
void handle_date_y_offset() {
  if (!HTTP.hasArg("date_y_offset")) {
    HTTP.send(400, "text/plain", "Parameter missing");
    return;
  }

  int value = HTTP.arg("date_y_offset").toInt();

  value = constrain(value, -16, 16);

  if (dateYOffset != value) {
    dateYOffset = value;
    jsonWrite(configLedPanel, "date_y_offset", String(value));
    saveConfig();

    loadingFlag = true;
#if USE_WEATHER
    weatherNeedRedraw = true;
#endif
  }

  HTTP.send(200, "text/plain", String(value));
}

// Чекбокс "Показывать 4 цифры года"
void handle_date_full_year() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value parameter");
    return;
  }

  String valStr = HTTP.arg("value");
  bool newVal = (valStr == "1" || valStr == "true" || valStr == "on");

  if (showFullYearEnabled == newVal) {
    HTTP.send(200, "text/plain", showFullYearEnabled ? "1" : "0");
    return;
  }

  showFullYearEnabled = newVal;
  jsonWrite(configLedPanel, "date_full_year", showFullYearEnabled ? "1" : "0");
  saveConfig();

  loadingFlag = true;

  HTTP.send(200, "text/plain", showFullYearEnabled ? "1" : "0");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Мигание разделительных точек даты"
void handle_date_separator_blink() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool newVal = HTTP.arg("value") == "1";
  if (newVal == dateSeparatorBlinking) {
    HTTP.send(200, "text/plain", dateSeparatorBlinking ? "1" : "0");
    return;
  }
  dateSeparatorBlinking = newVal;
  jsonWrite(configLedPanel, "date_separator_blink", dateSeparatorBlinking ? "1" : "0");
  saveConfig();
  loadingFlag = true;
  HTTP.send(200, "text/plain", dateSeparatorBlinking ? "1" : "0");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Чекбокс "Показывать год"
void handle_date_show_year() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool newVal = HTTP.arg("value") == "1";
  if (newVal == showYearInDate) {
    HTTP.send(200, "text/plain", showYearInDate ? "1" : "0");
    return;
  }
  showYearInDate = newVal;
  jsonWrite(configLedPanel, "date_show_year", showYearInDate ? "1" : "0");
  saveConfig();
  loadingFlag = true;
  HTTP.send(200, "text/plain", showYearInDate ? "1" : "0");

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// ----------------------------------------------------------------------- ТАЙМЕРЫ и ИНТЕРВАЛЫ --------------------------------------------------------

#if USE_WEATHER
// Таймер Часы / Погода
void handle_timer_c_w() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, F("text/plain"), F("Missing value"));
    return;
  }

  bool newVal = HTTP.arg("value").toInt() != 0;
  if (newVal == timer_c_w) {
    HTTP.send(200, F("application/json"), F("{\"should_refresh\":\"true\"}"));
    return;
  }

  timer_c_d = false; timer_d_w = false; timer_c_d_w = false; timer_clock_fixed = false;
  timer_c_w = newVal;

  PJsonDoc cfgInt(JSON_BUFFER_SIZE);
  if (configLedInterval.length() == 0 || deserializeJson(cfgInt, configLedInterval)) {
    cfgInt.clear(); cfgInt.to<JsonObject>();
  }
  cfgInt["timer_c_w"] = timer_c_w ? "1" : "0";
  cfgInt["timer_c_d"] = "0";
  cfgInt["timer_d_w"] = "0";
  cfgInt["timer_c_d_w"] = "0";
  cfgInt["timer_clock_fixed"] = "0";

  PJsonDoc cfgPanel(JSON_BUFFER_SIZE);
  if (configLedPanel.length() == 0 || deserializeJson(cfgPanel, configLedPanel)) {
    cfgPanel.clear(); cfgPanel.to<JsonObject>();
  }

  if (timer_c_w) {
    weatherEnabled = true;
    clockNeedRedraw = true;
    weatherNeedRedraw = true;
    cfgPanel["weather_enabled"] = "1";
  } else {
    weatherEnabled = ((int)(cfgPanel["weather_enabled"] | 0)) == 1;
    clockNeedRedraw = true;
    weatherNeedRedraw = true;
    cfgPanel["weather_enabled"] = "0";
  }

  configLedInterval = "";
  configLedInterval.reserve(measureJson(cfgInt) + 1);
  serializeJson(cfgInt, configLedInterval);

  configLedPanel = "";
  configLedPanel.reserve(measureJson(cfgPanel) + 1);
  serializeJson(cfgPanel, configLedPanel);

  saveConfig();
  resetTimerState();

  HTTP.send(200, F("application/json"), F("{\"should_refresh\":\"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Интервал Часы / Погода
void handle_interval_c_w() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, F("text/plain"), F("Missing value"));
    return;
  }
  String valStr = HTTP.arg("value");
  if (valStr.length() == 0) {
    HTTP.send(400, F("text/plain"), F("Empty value"));
    return;
  }
  int newVal = valStr.toInt();
  if (newVal == 0 && valStr != "0") {
    HTTP.send(400, F("text/plain"), F("Invalid number format"));
    return;
  }
  newVal = constrain(newVal, 5, 600);
  if (newVal == interval_c_w) {
    HTTP.send(200, F("text/plain"), String(newVal).c_str());
    return;
  }
  interval_c_w = newVal;
  jsonWrite(configLedInterval, "interval_c_w", String(newVal));
  saveConfig();
  lastSwitchTime = millis();
  lastTimerSwitch = millis();

  if (timer_c_w) {
    clockNeedRedraw = true;
    weatherNeedRedraw = true;
  }

  HTTP.send(200, F("text/plain"), String(newVal).c_str());

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Таймер Дата / Погода
void handle_timer_d_w() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, F("text/plain"), F("Missing value"));
    return;
  }

  bool newVal = HTTP.arg("value").toInt() != 0;
  if (newVal == timer_d_w) {
    HTTP.send(200, F("application/json"), F("{\"should_refresh\":\"true\"}"));
    return;
  }

  timer_c_w = false;
  timer_c_d = false;
  timer_c_d_w = false;
  timer_clock_fixed = false;
  timer_d_w = newVal;

  PJsonDoc cfgInt(JSON_BUFFER_SIZE);
  if (configLedInterval.length() == 0 || deserializeJson(cfgInt, configLedInterval)) {
    cfgInt.clear(); cfgInt.to<JsonObject>();
  }
  cfgInt["timer_d_w"] = timer_d_w ? "1" : "0";
  cfgInt["timer_c_w"] = "0";
  cfgInt["timer_c_d"] = "0";
  cfgInt["timer_c_d_w"] = "0";
  cfgInt["timer_clock_fixed"] = "0";

  PJsonDoc cfgPanel(JSON_BUFFER_SIZE);
  if (configLedPanel.length() == 0 || deserializeJson(cfgPanel, configLedPanel)) {
    cfgPanel.clear(); cfgPanel.to<JsonObject>();
  }
  if (timer_d_w) {
    dateEnabled = true;
    weatherEnabled = true;
    dateNeedRedraw = true;
    weatherNeedRedraw = true;
    cfgPanel["date_enabled"] = "1";
    cfgPanel["weather_enabled"] = "1";
  } else {
    dateEnabled = ((int)(cfgPanel["date_enabled"] | 0)) == 1;
    weatherEnabled = ((int)(cfgPanel["weather_enabled"] | 0)) == 1;
    dateNeedRedraw = true;
    weatherNeedRedraw = true;
    cfgPanel["date_enabled"] = "0";
    cfgPanel["weather_enabled"] = "0";
  }

  configLedInterval = "";
  configLedInterval.reserve(measureJson(cfgInt) + 1);
  serializeJson(cfgInt, configLedInterval);

  configLedPanel = "";
  configLedPanel.reserve(measureJson(cfgPanel) + 1);
  serializeJson(cfgPanel, configLedPanel);

  saveConfig();
  resetTimerState();

  HTTP.send(200, F("application/json"), F("{\"should_refresh\":\"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Интервал Дата / Погода
void handle_interval_d_w() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, F("text/plain"), F("Missing value"));
    return;
  }
  String valStr = HTTP.arg("value");
  if (valStr.length() == 0) {
    HTTP.send(400, F("text/plain"), F("Empty value"));
    return;
  }
  int newVal = valStr.toInt();
  if (newVal == 0 && valStr != "0") {
    HTTP.send(400, F("text/plain"), F("Invalid number format"));
    return;
  }
  newVal = constrain(newVal, 5, 600);
  if (newVal == interval_d_w) {
    HTTP.send(200, F("text/plain"), String(newVal).c_str());
    return;
  }

  interval_d_w = newVal;
  jsonWrite(configLedInterval, "interval_d_w", String(newVal));
  saveConfig();
  lastSwitchTime = millis();
  lastTimerSwitch = millis();

  if (timer_d_w) {
    dateNeedRedraw = true;
    weatherNeedRedraw = true;
  }

  HTTP.send(200, F("text/plain"), String(newVal).c_str());

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Таймер Часы / Дата / Погода
void handle_timer_c_d_w() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, F("text/plain"), F("Missing value"));
    return;
  }

  bool newVal = HTTP.arg("value").toInt() != 0;
  if (newVal == timer_c_d_w) {
    HTTP.send(200, F("application/json"), F("{\"should_refresh\":\"true\"}"));
    return;
  }

  timer_c_w = false;
  timer_c_d = false;
  timer_d_w = false;
  timer_clock_fixed = false;
  timer_c_d_w = newVal;

  PJsonDoc cfgInt(JSON_BUFFER_SIZE);
  if (configLedInterval.length() == 0 || deserializeJson(cfgInt, configLedInterval)) {
    cfgInt.clear(); cfgInt.to<JsonObject>();
  }
  cfgInt["timer_c_d_w"] = timer_c_d_w ? "1" : "0";
  cfgInt["timer_c_w"] = "0";
  cfgInt["timer_c_d"] = "0";
  cfgInt["timer_d_w"] = "0";
  cfgInt["timer_clock_fixed"] = "0";

  PJsonDoc cfgPanel(JSON_BUFFER_SIZE);
  if (configLedPanel.length() == 0 || deserializeJson(cfgPanel, configLedPanel)) {
    cfgPanel.clear(); cfgPanel.to<JsonObject>();
  }
  if (timer_c_d_w) {
    dateEnabled = true;
    weatherEnabled = true;
    clockNeedRedraw = true;
    dateNeedRedraw = true;
    weatherNeedRedraw = true;
    cfgPanel["date_enabled"] = "1";
    cfgPanel["weather_enabled"] = "1";
  } else {
    dateEnabled = ((int)(cfgPanel["date_enabled"]    | 0)) == 1;
    weatherEnabled = ((int)(cfgPanel["weather_enabled"] | 0)) == 1;
    clockNeedRedraw = true;
    dateNeedRedraw = true;
    weatherNeedRedraw = true;
    cfgPanel["date_enabled"] = "0";
    cfgPanel["weather_enabled"] = "0";
  }

  configLedInterval = "";
  configLedInterval.reserve(measureJson(cfgInt) + 1);
  serializeJson(cfgInt, configLedInterval);

  configLedPanel = "";
  configLedPanel.reserve(measureJson(cfgPanel) + 1);
  serializeJson(cfgPanel, configLedPanel);

  saveConfig();
  resetTimerState();

  HTTP.send(200, F("application/json"), F("{\"should_refresh\":\"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Интервал Часы / Дата / Погода
void handle_interval_c_d_w() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, F("text/plain"), F("Missing value"));
    return;
  }
  String valStr = HTTP.arg("value");
  if (valStr.length() == 0) {
    HTTP.send(400, F("text/plain"), F("Empty value"));
    return;
  }
  int newVal = valStr.toInt();
  if (newVal == 0 && valStr != "0") {
    HTTP.send(400, F("text/plain"), F("Invalid number format"));
    return;
  }
  newVal = constrain(newVal, 5, 600);
  if (newVal == interval_c_d_w) {
    HTTP.send(200, F("text/plain"), String(newVal).c_str());
    return;
  }
  interval_c_d_w = newVal;
  jsonWrite(configLedInterval, "interval_c_d_w", String(newVal));
  saveConfig();

  lastSwitchTime = millis();
  lastTimerSwitch  = millis();

  if (timer_c_d_w) {
    clockNeedRedraw = true;
    dateNeedRedraw = true;
    weatherNeedRedraw = true;
  }

  HTTP.send(200, F("text/plain"), String(newVal).c_str());

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Таймер Часы + Дата / Погода
void handle_timer_clock_fixed() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, F("text/plain"), F("Missing value"));
    return;
  }

  bool newVal = HTTP.arg("value").toInt() != 0;
  if (newVal == timer_clock_fixed) {
    HTTP.send(200, F("application/json"), F("{\"should_refresh\":\"true\"}"));
    return;
  }

  timer_c_d_w = false;
  timer_c_d = false;
  timer_d_w = false;
  timer_c_w = false;
  timer_clock_fixed = newVal;

  PJsonDoc cfgInt(JSON_BUFFER_SIZE);
  if (configLedInterval.length() == 0 || deserializeJson(cfgInt, configLedInterval)) {
    cfgInt.clear(); cfgInt.to<JsonObject>();
  }
  cfgInt["timer_clock_fixed"] = timer_clock_fixed ? "1" : "0";
  cfgInt["timer_c_d_w"] = "0";
  cfgInt["timer_c_d"] = "0";
  cfgInt["timer_d_w"] = "0";
  cfgInt["timer_c_w"] = "0";

  PJsonDoc cfgPanel(JSON_BUFFER_SIZE);
  if (configLedPanel.length() == 0 || deserializeJson(cfgPanel, configLedPanel)) {
    cfgPanel.clear(); cfgPanel.to<JsonObject>();
  }
  if (timer_clock_fixed) {
    dateEnabled = true;
    weatherEnabled = true;
    clockNeedRedraw = true;
    dateNeedRedraw = true;
    weatherNeedRedraw = true;
    lastClockFixedSwitch = millis();
    cfgPanel["date_enabled"] = "1";
    cfgPanel["weather_enabled"] = "1";
  } else {
    dateEnabled = ((int)(cfgPanel["date_enabled"] | 0)) == 1;
    weatherEnabled = ((int)(cfgPanel["weather_enabled"] | 0)) == 1;
    clockNeedRedraw = true;
    dateNeedRedraw = true;
    weatherNeedRedraw = true;
    cfgPanel["date_enabled"] = "0";
    cfgPanel["weather_enabled"] = "0";
  }

  configLedInterval = "";
  configLedInterval.reserve(measureJson(cfgInt) + 1);
  serializeJson(cfgInt, configLedInterval);

  configLedPanel = "";
  configLedPanel.reserve(measureJson(cfgPanel) + 1);
  serializeJson(cfgPanel, configLedPanel);

  saveConfig();
  resetTimerState();

  HTTP.send(200, F("application/json"), F("{\"should_refresh\":\"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Интервал Часы + Дата / Погода
void handle_interval_clock_fixed() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, F("text/plain"), F("Missing value"));
    return;
  }
  String valStr = HTTP.arg("value");
  if (valStr.length() == 0) {
    HTTP.send(400, F("text/plain"), F("Empty value"));
    return;
  }
  int newVal = valStr.toInt();
  if (newVal == 0 && valStr != "0") {
    HTTP.send(400, F("text/plain"), F("Invalid number format"));
    return;
  }
  newVal = constrain(newVal, 5, 600);
  if (newVal == interval_clock_fixed) {
    HTTP.send(200, F("text/plain"), String(newVal).c_str());
    return;
  }
  interval_clock_fixed = newVal;
  jsonWrite(configLedInterval, "interval_clock_fixed", String(newVal));
  saveConfig();
  lastClockFixedSwitch = millis();

  if (timer_clock_fixed) {
    dateNeedRedraw = true;
    weatherNeedRedraw = true;
  }

  HTTP.send(200, F("text/plain"), String(newVal).c_str());

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

#endif // USE_WEATHER

// Таймер Часы / Дата
void handle_timer_c_d() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, F("text/plain"), F("Missing value"));
    return;
  }

  bool newVal = HTTP.arg("value").toInt() != 0;
  if (newVal == timer_c_d) {
    HTTP.send(200, F("application/json"), F("{\"should_refresh\":\"true\"}"));
    return;
  }

  timer_c_w = false;
  timer_d_w = false;
  timer_c_d_w = false;
  timer_clock_fixed = false;
  timer_c_d = newVal;

  PJsonDoc cfgInt(JSON_BUFFER_SIZE);
  if (configLedInterval.length() == 0 || deserializeJson(cfgInt, configLedInterval)) {
    cfgInt.clear(); cfgInt.to<JsonObject>();
  }
  cfgInt["timer_c_d"] = timer_c_d ? "1" : "0";
  cfgInt["timer_c_w"] = "0";
  cfgInt["timer_d_w"] = "0";
  cfgInt["timer_c_d_w"] = "0";
  cfgInt["timer_clock_fixed"] = "0";

  PJsonDoc cfgPanel(JSON_BUFFER_SIZE);
  if (configLedPanel.length() == 0 || deserializeJson(cfgPanel, configLedPanel)) {
    cfgPanel.clear(); cfgPanel.to<JsonObject>();
  }
  if (timer_c_d) {
    dateEnabled = true;
    clockNeedRedraw = true;
    dateNeedRedraw = true;
  } else {
    dateEnabled = ((int)(cfgPanel["date_enabled"] | 0)) == 1;
    clockNeedRedraw = true;
    dateNeedRedraw = true;
    cfgPanel["date_enabled"] = "0";
  }

  configLedInterval = "";
  configLedInterval.reserve(measureJson(cfgInt) + 1);
  serializeJson(cfgInt, configLedInterval);

  configLedPanel = "";
  configLedPanel.reserve(measureJson(cfgPanel) + 1);
  serializeJson(cfgPanel, configLedPanel);

  saveConfig();
  resetTimerState();

  HTTP.send(200, F("application/json"), F("{\"should_refresh\":\"true\"}"));

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif
#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

// Интервал Часы / Дата
void handle_interval_c_d() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, F("text/plain"), F("Missing value"));
    return;
  }
  String valStr = HTTP.arg("value");
  if (valStr.length() == 0) {
    HTTP.send(400, F("text/plain"), F("Empty value"));
    return;
  }
  int newVal = valStr.toInt();
  if (newVal == 0 && valStr != "0") {
    HTTP.send(400, F("text/plain"), F("Invalid number format"));
    return;
  }
  newVal = constrain(newVal, 5, 600);
  if (newVal == interval_c_d) {
    HTTP.send(200, F("text/plain"), String(newVal).c_str());
    return;
  }
  interval_c_d = newVal;
  jsonWrite(configLedInterval, "interval_c_d", String(newVal));
  saveConfig();
  lastSwitchTime = millis();
  lastTimerSwitch = millis();

  if (timer_c_d) {
    clockNeedRedraw = true;
    dateNeedRedraw = true;
  }

  HTTP.send(200, F("text/plain"), String(newVal).c_str());

#if USE_MULTILAMP
  repeat_multiple_lamp_control = true;
#endif

#if USE_MQTT
  if (Wifi::instance().isConnected()) {
    Mqtt::instance().needToPublish = true;
  }
#endif
}

#endif // LED_PANEL

// ----------------------------------------------------------------------------------------------------------------------------------------------------

void handle_index () {
  bool flg = false;
  if (HTTP.arg("index").toInt()) {
    flg = FileCopy(F("/index/index.setup.gz"), F("/index.json.gz"));
    if (flg) LittleFS.remove("/effect2.ini");
  }
  if (flg) HTTP.send(200, F("text/plain"), "OK");
  else HTTP.send(404, F("text/plain"), "File not found");
}

// ---------------------------------------------------------------

// Пароль на страницу настроек
void handle_PassOn() {
  if (!HTTP.hasArg("PassOn")) {
    HTTP.send(400, "text/plain", "Missing PassOn");
    return;
  }

  int val = HTTP.arg("PassOn").toInt();
  if (val != 0 && val != 1) {
    HTTP.send(400, "text/plain", "Invalid PassOn (must be 0 or 1)");
    return;
  }

  jsonWrite(configSetup, "PassOn", val);
  saveConfig();

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

// ----------------------------------------------------------------------- ЯЗЫК ИНТЕРФЕЙСА ------------------------------------------------------------

void handle_lang() {
  if (!HTTP.hasArg("lang")) {
    HTTP.send(400, "text/plain", "Missing lang");
    return;
  }
  jsonWrite(configSetup, "lang", HTTP.arg("lang"));
  saveConfig();
  Lang_set();

  String langStr = jsonRead(configSetup, "lang");
  langStr.toCharArray(currentLang, sizeof(currentLang));

  HTTP.send(200, F("application/json"), F("{\"should_refresh\": \"true\"}"));
}

void Lang_set () {
  String Name = "correct." + jsonRead(configSetup, "lang") + ".json";
  String Correct = readFile(Name, 2048);
  if (Correct == "Failed" || Correct == "Large" || Correct.isEmpty()) return;
  for (uint8_t n = 0; n < MODE_AMOUNT; n++) {
    eff_num_correct[n] = jsonReadtoInt(Correct, String(n));
    if (eff_num_correct[n] == currentMode) jsonWrite(configSetup, "eff_sel", n);
  }
}

// ----------------------------------------------------------------- СБРОС НАСТРОЕК ПО УМОЛЧАНИЮ ------------------------------------------------------

void handle_reset_to_default() {
  showWarning(CRGB::Red, 500, 250);
  setModeSettings();
  updateSets();

  const char* files[][2] = {
    {"/default/config.json", "/config.json"},
    {"/default/config_cycle.json", "/config_cycle.json"},
    {"/default/sound_list.json", "/sound_list.json"},
    {"/default/config_alarm.json", "/config_alarm.json"},
    {"/default/config_sunset.json", "/config_sunset.json"},
    {"/default/config_schedule.json", "/config_schedule.json"},
    {"/default/config_mp3.json", "/config_mp3.json"},
    {"/default/config_radio.json", "/config_radio.json"},
    {"/default/config_st7789.json", "/config_st7789.json"},
    {"/default/config_multilamp.json", "/config_multilamp.json"},
    {"/default/config_mqtt.json", "/config_mqtt.json"},
    {"/default/config_led_panel.json", "/config_led_panel.json"},
    {"/default/config_button.json", "/config_button.json"},
    {"/default/config_weather.json", "/config_weather.json"},
    {"/default/config_led_matrix.json", "/config_led_matrix.json"},
    {"/default/config_led_interval.json", "/config_led_interval.json"},
    {"/default/config_wifi.json", "/config_wifi.json"}
  };

  for (uint8_t i = 0; i < sizeof(files) / sizeof(files[0]); i++) {
    if (FileCopy(files[i][0], files[i][1])) {
      showWarning(CRGB::Green, 100, 100);
    } else {
      showWarning(CRGB::Red, 100, 100);
    }
    delay(50);
  }

  HTTP.send(200, "text/plain", "OK");
  pendingRestart = true;
}

// ---------------------------------------------------------- ВКЛЮЧЕНИЕ/ВЫКЛЮЧЕНИЕ МОДУЛЕЙ ЧЕРЕЗ ВЕБ --------------------------------------------------

// Кнопка
void handle_button_enable() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool val = HTTP.arg("value").toInt() != 0;
  if (val != buttonEnabled) {
    buttonEnabled = val;
    jsonWrite(configSetup, "button_enabled", buttonEnabled ? "1" : "0");
    saveConfig();
  }
  HTTP.send(200, "text/plain", buttonEnabled ? "1" : "0");
}

// IR-приёмник
void handle_ir_enable() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool val = HTTP.arg("value").toInt() != 0;
  if (val != irEnabled) {
    irEnabled = val;
    jsonWrite(configSetup, "ir_enabled", irEnabled ? "1" : "0");
    saveConfig();
  }
  HTTP.send(200, "text/plain", irEnabled ? "1" : "0");
}

// RF-приёмник
void handle_rf_enable() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool val = HTTP.arg("value").toInt() != 0;
  if (val != rfEnabled) {
    rfEnabled = val;
    jsonWrite(configSetup, "rf_enabled", rfEnabled ? "1" : "0");
    saveConfig();
  }
  HTTP.send(200, "text/plain", rfEnabled ? "1" : "0");
}

// TM1637 дисплей
void handle_tm1637_enable() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool val = HTTP.arg("value").toInt() != 0;
  if (val != tm1637Enabled) {
    tm1637Enabled = val;
    jsonWrite(configSetup, "tm1637_enabled", tm1637Enabled ? "1" : "0");
    saveConfig();

#if USE_TM1637
    if (tm1637Enabled) {
      display.setBrightness(7);
      display.clear();
      display.display(0, 0, 0, 0);
    } else {
      display.setBrightness(0);
      display.clear();
      display.display(0, 0, 0, 0);
    }
#endif
  }
  HTTP.send(200, "text/plain", tm1637Enabled ? "1" : "0");
}

// ST7789 дисплей
void handle_st7789_enable() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool val = HTTP.arg("value").toInt() != 0;
  if (val != st7789Enabled) {
    st7789Enabled = val;
    jsonWrite(configSetup, "st7789_enabled", st7789Enabled ? "1" : "0");
    saveConfig();

#if USE_ST7789
#ifdef TFT_BL
    if (st7789Enabled) {
      pinMode(TFT_BL, OUTPUT);
      digitalWrite(TFT_BL, HIGH);
    } else {
      digitalWrite(TFT_BL, LOW);
    }
#endif
#endif
  }
  HTTP.send(200, "text/plain", st7789Enabled ? "1" : "0");
}

// MP3 плеер
void handle_mp3_enable() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool val = HTTP.arg("value").toInt() != 0;

  if (val == mp3Enabled) {
    HTTP.send(200, "text/plain", mp3Enabled ? "1" : "0");
    return;
  }

  if (val) {
    setAudioSource(AUDIO_SOURCE_MP3);
  } else {
    disableAudioSource(AUDIO_SOURCE_MP3);
  }

  HTTP.send(200, "text/plain", mp3Enabled ? "1" : "0");
}

// SD карта
void handle_sd_enable() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool val = HTTP.arg("value").toInt() != 0;

#if USE_SD
  if (val != sdEnabled) {
    sdEnabled = val;
    jsonWrite(configSetup, "sd_enabled", sdEnabled ? "1" : "0");
    saveConfig();

    if (!sdEnabled) {
      if (outFile) {
        outFile.close();
        outAnimationActive = false;
      }
      outEffectActive = false;
      if (currentMode == EFF_SD) {
        currentMode = EFF_RAINBOW_VER;
        for (uint8_t i = 0; i < MODE_AMOUNT; i++) {
          if (eff_num_correct[i] == currentMode) {
            jsonWrite(configSetup, "eff_sel", i);
            break;
          }
        }
        saveConfig();
        loadingFlag = true;
      }
    } else {
      initSD();
    }
  }
  HTTP.send(200, "text/plain", sdEnabled ? "1" : "0");
#else
  HTTP.send(200, "text/plain", "Not supported");
#endif
}

void handle_sd_type() {
  if (!HTTP.hasArg("sd_type")) {
    HTTP.send(400, "text/plain", "Missing sd_type");
    return;
  }
  uint8_t val = constrain(HTTP.arg("sd_type").toInt(), 0, 1);

#if USE_SD && (defined(ESP32S3) || defined(CONFIG_IDF_TARGET_ESP32S3) || defined(ARDUINO_ESP32S3_DEV))
  if (val == sdType) {
    HTTP.send(200, "text/plain", String(sdType));
    return;
  }

  if (outFile) {
    outFile.close();
    outAnimationActive = false;
  }
  outEffectActive = false;

  if (currentMode == EFF_SD) {
    currentMode = EFF_RAINBOW_VER;
    for (uint8_t i = 0; i < MODE_AMOUNT; i++) {
      if (eff_num_correct[i] == currentMode) {
        jsonWrite(configSetup, "eff_sel", i);
        break;
      }
    }
  }

  sdType = val;
  jsonWrite(configSetup, "sd_type", sdType);
  saveConfig();

  HTTP.send(200, "text/plain", "OK_REBOOT");
  pendingRestart = true;
#else
  HTTP.send(200, "text/plain", "Not supported on this build");
#endif
}

// Радио
#if USE_RADIO
void handle_radio_enable() {
  if (!HTTP.hasArg("value")) {
    HTTP.send(400, "text/plain", "Missing value");
    return;
  }
  bool val = HTTP.arg("value").toInt() != 0;

  if (val == radioEnabled) {
    HTTP.send(200, "text/plain", radioEnabled ? "1" : "0");
    return;
  }

  if (val) {
    setAudioSource(AUDIO_SOURCE_RADIO);
  } else {
    disableAudioSource(AUDIO_SOURCE_RADIO);
  }

  HTTP.send(200, "text/plain", radioEnabled ? "1" : "0");
}
#endif

// *****************************************************************************************************************************************************
