// ******************************************************************************* Weather.h *************************************************************
#pragma once
// -----------
#include <Arduino.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
//#include "Ardu_Json.h"
#include "Constants.h"
#include "Types.h"
#include "Extern.h"
// ----------------------------

class Weather {
  public:
    static Weather& instance() {
      static Weather instance;
      return instance;
    }

    void requestReload();
    void loadSettings();
    void update();
    void updateIfNeeded();
    float getTemperature() const {
      return currentTemp;
    }
    String getCondition() const {
      return currentCondition;
    }
    bool isAvailable() const {
      return (currentTemp > -999.0f);
    }
    String getProviderName() const {
      return actualYandex ? "Yandex" : "OpenWeather";
    }
    bool isUsingYandex() const {
      return actualYandex;
    }
    void forceUpdate();
    String getCity() const {
      return weatherCity;
    }
    bool isYandexPreferred() const {
      return preferYandex;
    }
    bool isClockWeatherMode() const {
      return inClockWeatherMode;
    }
    bool isUsingYandexGraphQL() const {
      return actualYandex && useYandexGraphQL;
    }

    String getYandexGeoId() const {
      return yandexGeoId;
    }
    String getWeatherCity() const {
      return weatherCity;
    }
    void startTask();

  private:
    TaskHandle_t taskHandle = nullptr;
    void taskLoop();
    Weather() = default;
    ~Weather() = default;
    Weather(const Weather&) = delete;
    Weather& operator=(const Weather&) = delete;

    volatile uint32_t lastUpdateTime = 0;
    volatile bool needReloadSettings = false;

    bool fetchFromYandex();
    bool fetchFromOpenWeather();
    bool fetchFromYandexGraphQL();

    String buildWeatherDescription(String baseDesc, float windSpeed, int weatherId, const String& provider, float pressureMm);
    String getYandexRussianDescription(const String& engCond, float windSpeed, int precType, float precStrength, float temp, float humidity, float pressure);

    String weatherApiKey;
    String yandexApiKey;
    String yandexGeoId;
    String customYandexGeoId;
    String weatherCity;
    String customWeatherCity;
    String customLat;
    String customLon;
    String customCoordName;

    bool inClockWeatherMode = false;
    bool preferYandex = true;
    bool actualYandex = true;
    bool useYandexGraphQL = false;
    volatile uint32_t lastGraphQLUpdateTime = 0;

    float currentTemp = -999.0f;
    String currentCondition;

    WiFiClientSecure yandexClient;
    HTTPClient yandexHttp;
};

// *******************************************************************************************************************************************************
