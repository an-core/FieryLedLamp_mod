// ***************************************************************************** ArduinoJson.h ********************************************************
#pragma once
#include "PsramJson.h"
#include "Prototypes.h"
#include "Extern.h"
#include "SystemLog.h"
// -------------------------------------------

// ----------------------------------------------------------------------- ЧТЕНИЕ JSON -----------------------------------------------------------------

String jsonRead(String &json, const String &name) {
  PJsonDoc doc(JSON_BUFFER_SIZE); // PSRAM
  DeserializationError error = deserializeJson(doc, json);
  if (error) {
#if GENERAL_LOG
    SYSLOG.add("jsonRead FAIL '%s': %s (json=%u B, buf=%u)", name.c_str(), error.c_str(), (unsigned)json.length(), (unsigned)JSON_BUFFER_SIZE);
#endif
    return "";
  }
  JsonObject obj = doc.as<JsonObject>();
  return obj[name].as<String>();
}

int jsonReadtoInt(String &json, const String &name, int defaultValue = 0) {
  PJsonDoc doc(JSON_BUFFER_SIZE);
  DeserializationError error = deserializeJson(doc, json);
  if (error) {
#if GENERAL_LOG
    SYSLOG.add("jsonReadtoInt FAIL '%s': %s (json=%u B, buf=%u)", name.c_str(), error.c_str(), (unsigned)json.length(), (unsigned)JSON_BUFFER_SIZE);
#endif
    return defaultValue;
  }
  if (!doc.containsKey(name)) return defaultValue;
  return doc[name].as<int>();
}

// ----------------------------------------------------------------------- ЗАПИСЬ JSON -----------------------------------------------------------------

void jsonWrite(String &json, const String &name, const String &volume) {
  PJsonDoc doc(JSON_BUFFER_SIZE);
  DeserializationError error = deserializeJson(doc, json);
  if (error) {
#if GENERAL_LOG
    SYSLOG.add("jsonWrite FAIL '%s': %s (json=%u B, buf=%u)", name.c_str(), error.c_str(), (unsigned)json.length(), (unsigned)JSON_BUFFER_SIZE);
#endif
    return;
  }
  doc[name] = volume;
  json = "";
  json.reserve(measureJson(doc) + 1);
  serializeJson(doc, json);
}

void jsonWrite(String &json, const String &name, int volume) {
  PJsonDoc doc(JSON_BUFFER_SIZE);
  DeserializationError error = deserializeJson(doc, json);
  if (error) {
#if GENERAL_LOG
    SYSLOG.add("jsonWrite FAIL '%s': %s (json=%u B, buf=%u)", name.c_str(), error.c_str(), (unsigned)json.length(), (unsigned)JSON_BUFFER_SIZE);
#endif
    return;
  }
  doc[name] = volume;
  json = "";
  json.reserve(measureJson(doc) + 1);
  serializeJson(doc, json);
}

// ----------------------------------------------------------------------- РАБОТА С ФАЙЛАМИ ------------------------------------------------------------

bool writeFile(const String& fileName, const String& strings) {
  static bool fsMounted = false;
  if (!fsMounted) {
    if (!LittleFS.begin(false)) {
#if GENERAL_LOG
      SYSLOG.add("writeFile: LittleFS не смонтирован (%s)", fileName.c_str());
#endif
      return false;
    }
    fsMounted = true;
  }

  String tmpName = "/" + fileName + ".tmp";
  String realName = "/" + fileName;

  File f = LittleFS.open(tmpName, "w");
  if (!f) {
#if GENERAL_LOG
    SYSLOG.add("writeFile: не открыть %s", tmpName.c_str());
#endif
    return false;
  }
  size_t written = f.print(strings);
  f.close();

  if (written != strings.length()) {
#if GENERAL_LOG
    SYSLOG.add("writeFile: записано %u из %u (%s)", (unsigned)written, (unsigned)strings.length(), fileName.c_str());
#endif
    LittleFS.remove(tmpName);
    return false;
  }

  LittleFS.remove(realName);
  if (!LittleFS.rename(tmpName, realName)) {
#if GENERAL_LOG
    SYSLOG.add("writeFile: rename failed (%s)", fileName.c_str());
#endif
    LittleFS.remove(tmpName);
    return false;
  }
  return true;
}

String readFile(const String& fileName, size_t maxSize = 8192) {
  File configFile = LittleFS.open("/" + fileName, "r");

#if GENERAL_LOG
  SYSLOG.add("readFile(%s): open=%d", fileName.c_str(), (bool)configFile);
#endif

  if (!configFile) return "Failed";

  size_t fileSize = configFile.size();

#if GENERAL_LOG
  SYSLOG.add("readFile(%s): size=%u, maxSize=%u", fileName.c_str(), (unsigned)fileSize, (unsigned)maxSize);
#endif

  if (fileSize > maxSize) {
    configFile.close();
    return "Large";
  }

  String content;
  content.reserve(fileSize + 1);

  uint8_t buffer[512];
  while (configFile.available()) {
    int bytesRead = configFile.read(buffer, sizeof(buffer));
    if (bytesRead <= 0) break;
    content.concat((char*)buffer, bytesRead);
  }

  configFile.close();

#if GENERAL_LOG
  SYSLOG.add("readFile(%s): read=%u head=%.40s", fileName.c_str(), (unsigned)content.length(), content.c_str());
#endif

  if (content.length() == 0) return "Failed";
  return content;
}

String safeReadFile(const String& fileName, size_t maxSize) {
  String content = readFile(fileName, maxSize);
  if (content.isEmpty() || content == "Failed" || content == "Large") {
    return "{}";
  }

  PJsonDoc doc(JSON_BUFFER_SIZE);
  DeserializationError err = deserializeJson(doc, content);
  if (err) {
#if GENERAL_LOG
    SYSLOG.add("safeReadFile: невалидный JSON %s (%s)", fileName.c_str(), err.c_str());
#endif
  }

  return content;
}

// ----------------------------------------------------------------------- СОХРАНЕНИЕ КОНФИГОВ ---------------------------------------------------------

bool saveConfig(const char* which = nullptr) {
  auto match = [&](const char* name) -> bool {
    return (which == nullptr) || (strcmp(which, name) == 0);
  };

  bool allSuccess = true;

  if (match("setup")) {
    if (!writeFile(F("config.json"), configSetup)) allSuccess = false;
  }
  if (match("wifi")) {
    if (!writeFile(F("config_wifi.json"), configWiFi)) allSuccess = false;
  }
  if (match("ledpanel")) {
    if (!writeFile(F("config_led_panel.json"), configLedPanel)) allSuccess = false;
  }
  if (match("ledinter")) {
    if (!writeFile(F("config_led_interval.json"), configLedInterval)) allSuccess = false;
  }
  if (match("ledmatr")) {
    if (!writeFile(F("config_led_matrix.json"), configLED)) allSuccess = false;
  }
  if (match("cycle")) {
    if (!writeFile(F("config_cycle.json"), configCycle)) allSuccess = false;
  }

#if USE_BUTTON
  if (match("button")) {
    if (!writeFile(F("config_button.json"), configButton)) allSuccess = false;
  }
#endif
#if USE_MQTT
  if (match("mqtt")) {
    if (!writeFile(F("config_mqtt.json"), configMQTT)) allSuccess = false;
  }
#endif
#if USE_WEATHER
  if (match("weather")) {
    if (!writeFile(F("config_weather.json"), configWeather)) allSuccess = false;
  }
#endif
#if USE_MP3_PLAYER
  if (match("mp3")) {
    if (!writeFile(F("config_mp3.json"), configMP3)) allSuccess = false;
  }
#endif
#if USE_RADIO
  if (match("radio") && configRadio.length() > 0 && configRadio != "{\"stations\":[],\"effects\":{},\"volume\":10}") {
    if (!writeFile(F("config_radio.json"), configRadio)) allSuccess = false;
  }
#endif
#if USE_ST7789
  if (match("st7789")) {
    if (!writeFile(F("config_st7789.json"), configST7789)) allSuccess = false;
  }
#endif
#if USE_MULTILAMP
  if (match("multilamp")) {
    if (!writeFile(F("config_multilamp.json"), configMultilamp)) allSuccess = false;
  }
#endif
#if USE_DAWN
  if (match("alarm")) {
    if (!writeFile(F("config_alarm.json"), configAlarm)) allSuccess = false;
  }
#endif
#if USE_SUNSET
  if (match("sunset")) {
    if (!writeFile(F("config_sunset.json"), configSunset)) allSuccess = false;
  }
#endif
#if USE_SCHEDULE
  if (match("schedule")) {
    if (!writeFile(F("config_schedule.json"), configSchedule)) allSuccess = false;
  }
#endif

  if (!allSuccess) {
#if GENERAL_LOG
    SYSLOG.add("saveConfig: не все файлы сохранены (which=%s)", which ? which : "all");
#endif
  }

  return allSuccess;
}

// ******************************************************************************************************************************************************
