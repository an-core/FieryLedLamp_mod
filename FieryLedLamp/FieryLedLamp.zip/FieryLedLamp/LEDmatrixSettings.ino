// ********************************************************************** LEDmatrixSettings.ino *********************************************************
#include <FastLED.h>
#include "Constants.h"
#include "Extern.h"
#include "Prototypes.h"
//----------------------

// ============================================================================= ЯРКОСТЬ ===============================================================

// Применение настроек яркости
void SetBrightness(uint8_t newBrightness) {
  uint8_t finalBrightness = newBrightness;

#if USE_DAWN
  if (dawnFlag == 1) {
    return;
  }
#endif
#if USE_SUNSET
  if (sunsetFlag == 1) {
    return;
  }
#endif

#if USE_DAWN
  if (AutoBrightness && !ONflag && !dawnFlag) {
#else
  if (AutoBrightness && !ONflag) {
#endif
    uint8_t tb = getBrightnessForPrintTime();
    finalBrightness = (tb >= 1) ? tb : newBrightness;
  }
#if USE_DAWN
  else if (AutoBrightness && !dawnFlag && !day_night) {
#else
  else if (AutoBrightness && !day_night) {
#endif
    finalBrightness = constrain(newBrightness >> AutoBrightness, 1, 100);
  }

  FastLED.setBrightness(finalBrightness);

  // сохранение новой яркости только, если лампа включена
#if USE_DAWN
  if (dawnFlag != 1) {
#endif
    modes[currentMode].Brightness = newBrightness;

    if (ONflag) {
      jsonWrite(configSetup, "br", newBrightness);

      if (nightModeBrightness == 0 && currentMode == EFF_CLOCK) {
        userClockBrightness = newBrightness;
      }
    }
#if USE_DAWN
  }
#endif

#if USE_ST7789
  TFT_ApplyBrightnessNow();
#endif
} // void SetBrightness(uint8_t newBrightness)

// --------------------------------------------------------------------

// сохранение текущей яркости эффекта
void saveCurrentBrightness() {
  if (!ONflag) return;
  modes[currentMode].Brightness = FastLED.getBrightness();
  jsonWrite(configSetup, "br", modes[currentMode].Brightness);

  if (nightModeBrightness == 0 && currentMode == EFF_CLOCK) {
    userClockBrightness = modes[currentMode].Brightness;
  }

  Eeprom::instance().EepromPut(modes);
}

// --------------------------------------------------------------------

// загрузка и применение яркость для эффекта
void loadBrightnessForMode(uint8_t mode) {
  if (mode >= MODE_AMOUNT) mode = 0;

  uint8_t eepromBrightness = modes[mode].Brightness;

  if (mode == currentMode) {
    uint8_t jsonBrightness = jsonReadtoInt(configSetup, "br");
    if (jsonBrightness >= 1 && jsonBrightness <= 255) {
      modes[mode].Brightness = jsonBrightness;
      if (ONflag) {
        Eeprom::instance().EepromPut(modes);
      }
#if GENERAL_LOG
      SYSLOG.add("Яркость из JSON (%u) сохранена в EEPROM", jsonBrightness);
#endif
    } else {
      if (eepromBrightness == 0) {
        eepromBrightness = pgm_read_byte(&defaultSettings[mode][0]);
        modes[mode].Brightness = eepromBrightness;
        if (ONflag) {
          Eeprom::instance().EepromPut(modes);
        }
      }
      jsonWrite(configSetup, "br", String(eepromBrightness));
      if (ONflag) {
        saveConfig();
      }
    }
  } else {
    if (eepromBrightness == 0) {
      modes[mode].Brightness = pgm_read_byte(&defaultSettings[mode][0]);
      if (ONflag) {
        Eeprom::instance().EepromPut(modes);
      }
    }
  }

  if (mode == currentMode) {
    SetBrightness(modes[mode].Brightness);
  }
} // void loadBrightnessForMode(uint8_t mode)

// ============================================================================ LED_PANEL ==============================================================

void handleTimerPhases(bool &showClock, bool &showDate, bool &showWeather) {
#if LED_PANEL
  if (timer_clock_fixed) {
    static bool showDateNow = true;

    if (millis() - lastClockFixedSwitch >= (unsigned long)interval_clock_fixed * 1000UL) {
      showDateNow = !showDateNow;
      lastClockFixedSwitch = millis();
      loadingFlag = true;
    }

    showClock = true;
    showDate = showDateNow;
    showWeather = !showDateNow;
    return;
  }

  static uint32_t lastTimerSwitch = 0;
  static uint8_t currentTimerPhase = 0;
  uint16_t intervalSec = 10;
  uint8_t maxPhase = 0;

  if (timer_c_w) {
    intervalSec = interval_c_w;
    maxPhase = 1;
  }
  else if (timer_c_d) {
    intervalSec = interval_c_d;
    maxPhase = 1;
  }
  else if (timer_d_w) {
    intervalSec = interval_d_w;
    maxPhase = 1;
  }
  else if (timer_c_d_w) {
    intervalSec = interval_c_d_w;
    maxPhase = 2;
  }

  if (millis() - lastTimerSwitch >= (unsigned long)intervalSec * 1000UL) {
    currentTimerPhase = (currentTimerPhase + 1) % (maxPhase + 1);
    lastTimerSwitch = millis();
    loadingFlag = true;
  }

  if (timer_c_w) {
    showClock = (currentTimerPhase == 0);
    showWeather = (currentTimerPhase == 1);
  }
  else if (timer_c_d) {
    showClock = (currentTimerPhase == 0);
    showDate = (currentTimerPhase == 1);
  }
  else if (timer_d_w) {
    showDate = (currentTimerPhase == 0);
    showWeather = (currentTimerPhase == 1);
  }
  else if (timer_c_d_w) {
    showClock = (currentTimerPhase == 0);
    showDate = (currentTimerPhase == 1);
    showWeather = (currentTimerPhase == 2);
  }
#endif
}

// ------------------------------------------

#if LED_PANEL
void clearTextAreaOnly() {
  int y_start = textBaseY + textYOffset - 1;
  int y_end = y_start + LET_HEIGHT + 2;

  for (int y = max(0, y_start); y <= min((int)matrixHeight - 1, y_end); y++) {
    for (int x = 0; x < matrixWidth; x++) {
      // не затирать, если на матрице могут быть дата/погода
      if (y >= lastDateTop && y <= lastDateBottom && lastDateLeft >= 0) continue;
#if USE_WEATHER
      if (y >= lastWeatherTop && y <= lastWeatherBottom && lastWeatherLeft >= 0) continue;
#endif
      leds[XY(x, y)] = CRGB::Black;
    }
  }
} // void clearTextAreaOnly()
#endif

// ------------------------------------------

#if LED_PANEL
void finishRunningText() {
  if (systemShuttingDown) return;
  textIsRunning = false;
  offset = matrixWidth + 10;
  Fill_String = false;

  if (IntervalrunText > 0) {
    runningTextTimer.reset();
  } else if (!runTextOver) {
    textIsRunning = true;
    loadingFlag = true;
    offset = matrixWidth + 10;
  }
  loadingFlag = true;
}
#endif

// ------------------------------------------

// сброс таймера (часы, дата, погода)
void resetTimerState() {
  if (systemShuttingDown) return;
#if LED_PANEL
  lastTimerSwitch = millis();
  currentTimerPhase = 0;
  clockNeedRedraw = true;
  loadingFlag = true;
  needFullRedraw = true;
#endif
}

// ------------------------------------------

void led_panel(bool drawStringThisTick) {
#if LED_PANEL
  if (!ONflag) {
#if USE_DAWN || USE_SUNSET
    if (dawnFlag == 1
#if USE_SUNSET
        || sunsetFlag == 1
#endif
       ) {
      return;
    }
#endif

    static uint32_t lastLog = 0;
    if (millis() - lastLog > 5000) {
      lastLog = millis();
#if EFF_LOG
      SYSLOG.add("led_panel: ONflag=false, clearing (dawn=%d sunset=%d)", dawnFlag, sunsetFlag);
#endif
    }
    FastLED.clear();
    FastLED.show();
    return;
  }

  static uint32_t lastShow = 0;
  const uint16_t FRAME_MS = 15;
  bool anyTimerActive = (currentMode == EFF_CLOCK) && (timer_c_w || timer_c_d || timer_d_w || timer_c_d_w || timer_clock_fixed);

  // бегущая строка
  if (runTextEnabled && textIsRunning) {
    CRGB textColor = CHSV(ColorRunningText, 255U, 255U);
    if (runTextOver) {
      if (Painting == 0 && isLampActive() && currentMode != EFF_CLOCK) {
        effectsTick();
      }
      else if (currentMode == EFF_CLOCK && !drawStringThisTick) {
        FastLED.clear();
        bool showClock = true, showDate = false, showWeather = false;
        if (anyTimerActive) handleTimerPhases(showClock, showDate, showWeather);
        else {
          if (dateEnabled) showDate = true;
#if USE_WEATHER
          if (weatherEnabled) showWeather = true;
#endif
        }
        if (showClock) clockRoutine();
        if (showDate) dateRoutine();
#if USE_WEATHER
        if (showWeather) weatherRoutine();
#endif
      }
      clearTextAreaOnly();
      fillString(TextTicker, textColor, true);
    }
    else {
      FastLED.clear();
      fillString(TextTicker, textColor, false);
    }

    if (Fill_String) {
      finishRunningText();
    }
    loadingFlag = true;
  }
  else { // обычный режим (без бегущей строки)
    if (currentMode == EFF_CLOCK && !drawStringThisTick) {
      FastLED.clear();
      bool showClock = true, showDate = false, showWeather = false;
      if (anyTimerActive) {
        handleTimerPhases(showClock, showDate, showWeather);
      }
      else {
        if (dateEnabled) showDate = true;
#if USE_WEATHER
        if (weatherEnabled) showWeather = true;
#endif
      }
      if (showClock) clockRoutine();
      if (showDate) dateRoutine();
#if USE_WEATHER
      if (showWeather) weatherRoutine();
#endif
    }
    else if (ONflag && Painting == 0 && isLampActive()) {
    }
  } // обычный режим

  // вывод на матрицу
  bool needShow = loadingFlag || anyTimerActive || (millis() - lastShow >= FRAME_MS);
  if (needShow) {
#if EFF_LOG
    uint32_t t0 = millis();
#endif
    FastLED.show();
#if EFF_LOG
    uint32_t dt = millis() - t0;
    if (dt > 10) SYSLOG.add("show: %u ms", dt);
#endif
    lastShow = millis();
    loadingFlag = false;

#if EFF_LOG
    static uint32_t showCounter = 0;
    static uint32_t showTimer = 0;
    showCounter++;
    if (millis() - showTimer >= 1000) {
      SYSLOG.add("Show FPS: %u, mode=%u", showCounter, currentMode);
      showCounter = 0;
      showTimer = millis();
    }
#endif
  }
#endif // LED_PANEL
} // void led_panel(bool drawStringThisTick)

// ====================================================== СМЕНА ЦВЕТА ЧАСОВ, ДАТЫ, ПОГОДЫ, ТЕКСТА (НА МАТРИЦЕ) =========================================

void updateAutoHueModes() {
  static uint32_t prev = 0;
  const uint32_t interval = 80;
  const uint8_t step = 1;
  uint32_t now = millis();

  if (now - prev < interval) return;
  prev = now;

  bool changed = false;

#if LED_PANEL
#if USE_WEATHER
  if (autoWeatherHue && !rainbowWeather) {
    weatherHue = (weatherHue + step) % 256;
    changed = true;
  }
#endif // USE_WEATHER

  if (autoHueDate && !rainbowDate) {
    dateHue = (dateHue + step) % 256;
    changed = true;
  }
  if (autoRunTextHue && !rainbowText) {
    runTextHue = (runTextHue + step) % 256;
    ColorRunningText = runTextHue;
    changed = true;
  }
#endif // LED_PANEL

  if (autoClockHue && !rainbowClock) {
    clockHue = (clockHue + step) % 256;
    changed = true;
  }
  if (changed) {
    loadingFlag = true;
  }
}

// ======================================================================= IP-адрес НА МАТРИЦЕ =========================================================

void showIPOnMatrix() {
  if (!displayIpAtStart) return;
  static bool ipShown = false;
  if (ipShown) return;
  IPAddress ip;
  uint32_t startMs = millis();
  const uint32_t WAIT_MS = 15000UL;

  while (true) {
    ip = Wifi::instance().getCurrentIP();
    if (ip != IPAddress(0, 0, 0, 0)) break;
    if (millis() - startMs > WAIT_MS) break;
    Wifi::instance().loop();
    delay(200);
    yield();
  }

  if (ip == IPAddress(0, 0, 0, 0)) {
    return;
  }

  String ipToShow = ip.toString();
  ipShown = true;
  bool oldRunTextOver = runTextOver;
  runTextOver = false;
  loadingFlag = true;

#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
  digitalWrite(MOSFET_PIN, MOSFET_LEVEL);
#endif

#if USE_ST7789
  TFT_ShowIP(ipToShow.c_str());
#endif

  uint8_t savedBrightness = FastLED.getBrightness();
  FastLED.setBrightness(20);

  bool textEnded = false;
  while (!textEnded) {
#if USE_ST7789
    TFT_LoopTick();
#endif
    textEnded = fillString(ipToShow.c_str(), CRGB(220, 220, 240), false);
    FastLED.show();
    parseUDP();
    HTTP.handleClient();
    delay(1);
    yield();
  }

  FastLED.setBrightness(savedBrightness);
  FastLED.clear();
  FastLED.show();
  textIsRunning = false;
  runTextOver = oldRunTextOver;

#if defined(MOSFET_PIN) && defined(MOSFET_LEVEL)
#if USE_DAWN
  digitalWrite(MOSFET_PIN, ONflag || (dawnFlag == 1 && !manualOff) ? MOSFET_LEVEL : !MOSFET_LEVEL);
#else
  digitalWrite(MOSFET_PIN, ONflag ? MOSFET_LEVEL : !MOSFET_LEVEL);
#endif
#endif

  loadingFlag = false;
}

// ================================================================== РАБОТА С ПАМЯТЬЮ (буферы) ========================================================

template<typename T>
void safeDeleteArray(T*& ptr) {
  if (ptr) {
    delete[] ptr;
    ptr = nullptr;
  }
}

/* Хелперы для PSRAM. Возвращает nullptr при неудаче - как new(std::nothrow). На ESP32 без PSRAM автоматически падает на обычный malloc. */
static inline void* psram_alloc(size_t size) {
  if (size == 0) return nullptr;
  void* p = nullptr;
#if defined(BOARD_HAS_PSRAM) || defined(ESP32_PSRAM_USED)
  p = heap_caps_malloc(size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
#endif
  if (!p) p = malloc(size);
  return p;
}

// обнуляет
static inline void* psram_calloc(size_t num, size_t size) {
  if (num == 0 || size == 0) return nullptr;
  void* p = nullptr;
#if defined(BOARD_HAS_PSRAM) || defined(ESP32_PSRAM_USED)
  p = heap_caps_calloc(num, size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
#endif
  if (!p) p = calloc(num, size);
  return p;
}

static inline void psram_free(void* p) {
  if (p) heap_caps_free(p);
}

// для PSRAM-буферов
template<typename T>
void safePsramFreeArray(T*& ptr) {
  if (ptr) {
    heap_caps_free(ptr);
    ptr = nullptr;
  }
}

// -------------------------------------------------------------------

bool checkAlloc(void* ptr, const char* name) {
  if (!ptr) {
#if MATRIX_LOG
    SYSLOG.add("Ошибка выделения памяти: %s", name);
#endif
    return false;
  }
  return true;
}

// -------------------------------------------------------------------

void printFreeHeap(const char* stage) {
#if MEMORY_LOG
  SYSLOG.add("%s - свободно ОЗУ: %d байт", stage, ESP.getFreeHeap());
#endif
}

// -------------------------------------------------------------------

// освобождение 3D noise с указанием старой ширины матрицы
void freeNoise3D(uint16_t oldWidth) {
  if (!noise3d) return;

  for (uint8_t l = 0; l < NUM_LAYERSMAX; l++) {
    if (noise3d[l]) {
      for (uint16_t i = 0; i < oldWidth; i++) {
        safePsramFreeArray(noise3d[l][i]);
      }
      safePsramFreeArray(noise3d[l]);
    }
  }
  safePsramFreeArray(noise3d);
  noise3d = nullptr;
}

// -------------------------------------------------------------------

// освобождение всех буферов
void freeOldBuffers(uint16_t oldWidth, uint16_t oldHeight) {
  // DRAM (new[]/delete[])
  safeDeleteArray(leds);

  // PSRAM (heap_caps_malloc/heap_caps_free)
  safePsramFreeArray(effectBuffer);
  safePsramFreeArray(ledsbuff);
  safePsramFreeArray(line);
  safePsramFreeArray(shiftHue);
  safePsramFreeArray(shiftValue);
  //safePsramFreeArray(fireBufferGlobal);

  if (matrixValue) {
    for (uint16_t y = 0; y < oldHeight; y++) safePsramFreeArray(matrixValue[y]);
    safePsramFreeArray(matrixValue);
    matrixValue = nullptr;
  }

  if (noise) {
    for (uint16_t i = 0; i < prevMaxNoiseDim; i++) safePsramFreeArray(noise[i]);
    safePsramFreeArray(noise);
    noise = nullptr;
  }
  prevMaxNoiseDim = 0;

  freeNoise3D(oldWidth);
}

// -------------------------------------------------------------------

// выделение всех буферов (под новые размеры)
bool allocateAllBuffers(uint16_t width, uint16_t height, uint16_t used, MatrixBuffers& out) {
  // leds - DRAM
  out.leds = new (std::nothrow) CRGB[used];
  if (!out.leds) goto cleanup;

  // ledsbuff - PSRAM
  out.ledsbuff = (CRGB*) psram_calloc(used, sizeof(CRGB));
  if (!out.ledsbuff) goto cleanup;

  // effectBuffer - PSRAM
  out.effectBuffer = (CRGB*) psram_alloc(used * sizeof(CRGB));
  // без goto cleanup — effectBuffer опционален (как было)

  // одномерные PSRAM-буферы
  out.line = (uint8_t*) psram_calloc(width, 1);
  if (!out.line) goto cleanup;
  out.shiftHue = (uint8_t*) psram_calloc(height, 1);
  if (!out.shiftHue) goto cleanup;
  out.shiftValue = (uint8_t*) psram_calloc(height, 1);
  if (!out.shiftValue) goto cleanup;

  // matrixValue (2D) - PSRAM
  out.matrixValue = (uint8_t**) psram_alloc(height * sizeof(uint8_t*));
  if (!out.matrixValue) goto cleanup;
  for (uint16_t y = 0; y < height; y++) out.matrixValue[y] = nullptr;
  for (uint16_t y = 0; y < height; y++) {
    out.matrixValue[y] = (uint8_t*) psram_calloc(width, 1);
    if (!out.matrixValue[y]) goto cleanup;
  }

  // noise (2D) - PSRAM
  out.noiseDim = max(width, height);
  out.noise = (uint8_t**) psram_alloc(out.noiseDim * sizeof(uint8_t*));
  if (!out.noise) goto cleanup;
  for (uint16_t i = 0; i < out.noiseDim; i++) out.noise[i] = nullptr;
  for (uint16_t i = 0; i < out.noiseDim; i++) {
    out.noise[i] = (uint8_t*) psram_calloc(out.noiseDim, 1);
    if (!out.noise[i]) goto cleanup;
  }

  // noise3d (3D) - PSRAM
  out.noise3d = (uint8_t***) psram_alloc(NUM_LAYERSMAX * sizeof(uint8_t**));
  if (!out.noise3d) goto cleanup;
  for (uint8_t l = 0; l < NUM_LAYERSMAX; l++) out.noise3d[l] = nullptr;
  for (uint8_t l = 0; l < NUM_LAYERSMAX; l++) {
    out.noise3d[l] = (uint8_t**) psram_alloc(width * sizeof(uint8_t*));
    if (!out.noise3d[l]) goto cleanup;
    for (uint16_t i = 0; i < width; i++) out.noise3d[l][i] = nullptr;
    for (uint16_t i = 0; i < width; i++) {
      out.noise3d[l][i] = (uint8_t*) psram_calloc(height, 1);
      if (!out.noise3d[l][i]) goto cleanup;
    }
  }

  return true;

cleanup:
  freeAllBuffers(out, width, height, used);
  return false;
}

// -------------------------------------------------------------------

// выделенные буферы
void freeAllBuffers(MatrixBuffers& buf, uint16_t width, uint16_t height, uint16_t used) {
  safeDeleteArray(buf.leds); // DRAM

  safePsramFreeArray(buf.effectBuffer); // PSRAM
  safePsramFreeArray(buf.ledsbuff);
  safePsramFreeArray(buf.line);
  safePsramFreeArray(buf.shiftHue);
  safePsramFreeArray(buf.shiftValue);

  if (buf.matrixValue) {
    for (uint16_t y = 0; y < height; y++) safePsramFreeArray(buf.matrixValue[y]);
    safePsramFreeArray(buf.matrixValue);
  }

  if (buf.noise) {
    for (uint16_t i = 0; i < buf.noiseDim; i++) safePsramFreeArray(buf.noise[i]);
    safePsramFreeArray(buf.noise);
  }
  buf.noiseDim = 0;

  if (buf.noise3d) {
    for (uint8_t l = 0; l < NUM_LAYERSMAX; l++) {
      if (buf.noise3d[l]) {
        for (uint16_t i = 0; i < width; i++) safePsramFreeArray(buf.noise3d[l][i]);
        safePsramFreeArray(buf.noise3d[l]);
      }
    }
    safePsramFreeArray(buf.noise3d);
  }
}

// -------------------------------------------------------------------

bool reconfigureMatrix(uint16_t newWidth, uint16_t newHeight, uint16_t newUsed, uint16_t oldWidth, uint16_t oldHeight) {
  MatrixBuffers newBuf;
  if (!allocateAllBuffers(newWidth, newHeight, newUsed, newBuf)) {
#if MATRIX_LOG
    SYSLOG.add("Не удалось выделить буферы для новой матрицы (%dx%d)", newWidth, newHeight);
#endif
    return false;
  }

  freeOldBuffers(oldWidth, oldHeight); // освобождение старых буферов

  leds = newBuf.leds;
  ledsbuff = newBuf.ledsbuff;
  effectBuffer = newBuf.effectBuffer;
  line = newBuf.line;
  shiftHue = newBuf.shiftHue;
  shiftValue = newBuf.shiftValue;
  matrixValue = newBuf.matrixValue;
  noise = newBuf.noise;
  prevMaxNoiseDim = newBuf.noiseDim;
  noise3d = newBuf.noise3d;

  newBuf.leds = nullptr;
  newBuf.ledsbuff = nullptr;
  newBuf.effectBuffer = nullptr;
  newBuf.line = nullptr;
  newBuf.shiftHue = nullptr;
  newBuf.shiftValue = nullptr;
  newBuf.matrixValue = nullptr;
  newBuf.noise = nullptr;
  newBuf.noise3d = nullptr;

  return true;
}

// ******************************************************************************************************************************************************
