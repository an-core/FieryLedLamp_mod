// ************************************************************************ FIERYLEDLAMP ***************************************************************

#define VERSION "FieryLedLamp_ver.8.8"
#define BUILD_DATE __DATE__
#define BUILD_TIME __TIME__

// ========================================================================== ПЛАТФОРМЫ ===============================================================

#if defined(ESP32)
#define ESP32_USED

#if defined(ESP32S3) || defined(CONFIG_IDF_TARGET_ESP32S3) || defined(ARDUINO_ESP32S3_DEV)
#define ESP32_S3_USED
#endif

#if defined(BOARD_HAS_PSRAM)
#define ESP32_PSRAM_USED
#endif
#else
#error "ESP8266 больше не поддерживается"
#endif // defined(ESP32)

// ==================================================================== ПОДКЛЮЧЕНИЕ БИБЛИОТЕК =========================================================

#include <Arduino.h>
#include <time.h>
#include <pgmspace.h>
#include <FS.h>
#include <LittleFS.h>
#include <SD.h>
#include <SPI.h>
#include <WiFi.h>
#include <WiFiMulti.h>
#include <WebServer.h>
#include <ESP32SSDP.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <WiFiAP.h>
#include <WiFiUdp.h>
#include <Update.h>
#include <EEPROM.h>
#include <FastLED.h>
#include <nvs_flash.h>
#include <esp_wifi.h>
#include <esp_system.h>
#include <esp_int_wdt.h>
#include <esp_task_wdt.h>
// --------------------------
#include "Constants.h"
#include "ArduinoJson.h"
#include "Prototypes.h"
#include "Extern.h"
#include "Types.h"
#include "TimerMinim.h"
#include "Time.h"
#include "Fonts.h"
#include "Eeprom.h"
#include "Favorites.h"
#include "WiFi.h"
#include "IRManager.h"

#if USE_WEATHER
#include "Weather.h"
#endif

#if DEBUG_ENABLED
#include "SystemLog.h"
#endif

#if USE_BUTTON
#include <GyverButton.h>
#endif

#if USE_OTA
#include "Ota.h"
#endif

#if USE_MQTT
#include "Mqtt.h"
#endif

#if USE_TM1637
#include "TM1637Display.h"
#endif

#if USE_IR_RECEIVER
#include <IRrecv.h>
#include "ir_codes.h"
#endif

#if USE_RF_RECEIVER
#include <RCSwitch.h> // rc-switch by sui77,fingolfin версия 2.6.4 (https://github.com/sui77/rc-switch/releases)
#include "rf_codes.h"
#endif

#if USE_BLYNK
#include <BlynkSimpleEsp32.h>
#endif

#if USE_MP3_PLAYER
#include <HardwareSerial.h>
#if MP3_DEBUG
#define FEEDBACK 1
#else
#define FEEDBACK 0
#endif
#endif

// =================================================================== ИНИЦИАЛИЗАЦИЯ ПЕРЕМЕННЫХ =======================================================

bool buttonEnabled = false;
bool irEnabled = false;
bool rfEnabled = false;
bool tm1637Enabled = false;
bool st7789Enabled = false;
bool mp3Enabled = false;
bool radioEnabled = false;
bool sdEnabled = false;
uint8_t sdType = 0;

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// WI-FI
volatile bool pendingRestart = false;
volatile bool g_flagForceSync = false;
volatile bool g_flagAutoTz = false;
String configWiFi;                               // Конфиг настроек WiFi (config_wifi.json)
String AP_NAME = "";                             // Имя точки доступа
String AP_PASS = "";                             // Пароль точки доступа
String LAMP_NAME = "";                           // Имя лампы
bool Always_ap = true;                           // Чекбокс "Показывать точку доступа всегда" (AP всегда активна)
bool wifi_multi_enabled = false;                 // Чекбокс "Переключаться между Wi-Fi сетями"
uint8_t use_static_ip = 0;                       // Чекбокс "Использовать статический IP"
bool ssdpInitialized = false;                    // Флаг инициализации ssdp
uint8_t wifi_timeout = 60;                       // Таймаут подключения к WiFi
uint32_t forcedApTimeoutMs = 60000UL;            // Время принудительного включения AP при отсутствии WiFi
uint32_t wifiReconnectInterval = 30000UL;        // Интервал переподключения к WiFi
uint32_t wifiCheckInterval = 300000UL;           // Интервал проверки WiFi
static bool forcedAPActive = false;              // Флаг, что AP поднята принудительно
bool waitingForWifi = false;                     // Флаг ожидания появления WiFi сети
static uint32_t lastStaConnectedTime = 0;        // Время последнего успешного STA-соединения
uint32_t lastWifiCheckTime = 0;                  // Время последней проверки WiFi
uint32_t lastReconnectAttempt = 0;               // Время последней попытки переподключения
bool displayIpAtStart = true;                    // Чекбокс Показать IP адрес при старте
uint8_t ip_brightness = 100;                     // Яркость при показе IP адреса бегущей строкой
static bool ipShown = false;                     // Флаг, что IP уже показан при старте
const uint8_t AP_STATIC_IP[] = {192, 168, 4, 1}; // Статический IP точки доступа
IPAddress previousIP;                            // Предыдущий IP адрес
IPAddress Static_IP;                             // Статический IP адрес (настраивается в Web)
IPAddress Gateway;                               // Шлюз для статического IP
IPAddress Subnet;                                // Маска подсети для статического IP
IPAddress DNS1;                                  // DNS-сервер
IPAddress DNS2(8, 8, 8, 8);                      // DNS-сервер

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// матрица
String configLED;                                // Конфиг настроек матрицы (config_led_matrix.json)
uint16_t segWidth = WIDTH;                       // Ширина одного сегмента
uint16_t segHeight = HEIGHT;                     // Высота одного сегмента
#if MULTI_MATRIX
uint8_t segMatrix_w = SEG_MATRIX_W;              // Количество матриц по горизонтали
uint8_t segMatrix_h = SEG_MATRIX_H;              // Количество матриц по вертикали
uint16_t matrixWidth = segWidth * segMatrix_w;   // Общая ширина
uint16_t matrixHeight = segHeight * segMatrix_h; // Общая высота
bool panelFlip = false;                          // Переворот панели/матрицы на 180 градусов
bool multiMatrixEnabled = true;                  // рантайм-флаг: включена ли поддержки нескольких матриц
#else
uint16_t matrixWidth = segWidth;                 // Общая ширина
uint16_t matrixHeight = segHeight;               // Общая высота
#endif
uint16_t usedLeds = matrixWidth * matrixHeight;  // Общее количество LED (будет пересчитано)
uint8_t MatrixType = MATRIX_TYPE;                // Тип матрицы (змейка/параллельно)
uint8_t MatrixOrientation = MATRIX_ORIENTATION;  // Ориентация матрицы

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// текст и шрифты
volatile bool isPrintingMessage = false;         // Флаг блокировки выполнения расписания на время вывода погоды/времени
bool isStringRunning = false;                    // Флаг, что текст в процессе вывода
String runTextStr;                               // Текст бегущей строки
int32_t offset = 0;                              // Позиция текста
uint8_t currentFont = 0;                         // Текущий шрифт: 0 = 5×8, 1 = 8×13, 2 = 10×16
uint8_t LET_WIDTH   = 5;                         // Ширина символа текущего шрифта
uint8_t LET_HEIGHT  = 8;                         // Высота символа текущего шрифта
char TextTicker[513];                            // Массив для текста бегущей строки
uint8_t getBrightnessForPrintTime();             // Получить яркость для вывода времени/погоды
bool Fill_String = false;                        // Флаг необходимости вывода текста
uint8_t SpeedFactor(uint8_t spd);                // Преобразование скорости в задержку
uint8_t SpeedRunningText;                        // Скорость бегущей строки
uint8_t ColorRunningText = 180;                  // Цвет текста
uint8_t ColorTextFon;                            // Цвет фона для текста
bool textIsRunning = false;                      // Флаг, что текст сейчас бежит
bool runTextEnabled = false;                     // Чекбокс "Включить бегущую строку"
bool runTextOver = false;                        // Чекбокс "Бегущая строка поверх эффекта"
int16_t textYOffset = 0;                         // Смещение текста по Y (по высоте)
uint8_t RuninTextOverEffects = 0;                // Счётчик для отрисовки поверх эффектов
int16_t textBaseY = 0;                           // Базовая Y-координата для текста
int16_t textPixelWidth = 0;                      // Ширина текста
uint32_t Last_Time_RuninText = 0;                // Последнее время обновления бегущей строки
uint32_t runningTextLastUpdate = 0;              // Время последнего обновления текста
bool drawStringThisTick = false;                 // Рисовать строку
uint32_t currentRunningTextIntervalMs = 0;       // Текущий интервал вывода бегущей строки
bool rainbowText = false;                        // Чекбокс "Разноцветный текст"
int  runTextHue = 0;                             // Оттенок текста
bool runTextColorCycle = false;                  // Циклическое изменение цвета текста
bool autoRunTextHue = false;                     // Автоматическая смена оттенка
bool textColorCycle = false;                     // Циклическая смена цвета
uint32_t scrollTimer = 0;                        // Таймер для скролла текста
uint8_t IntervalrunText = 1;                     // Интервал вывода бегущей строки
uint8_t staticFont = 0;                          // 0-3x5, 1-5x8, 2-8x13, 3-10x16

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// время
String autoDetectedTz = "";
String NTP_SERVER1 = "ntp3.vniiftri.ru";         // Первый NTP-сервер
String NTP_SERVER2 = "ru.pool.ntp.org";          // Второй NTP-сервер
bool day_night = false;                          // Флаг день/ночь (true = день, false = ночь)
uint32_t lastTimePrinted = 0U;                   // Время последнего вывода времени
uint8_t selectedSettings = 0U;                   // Флаг выбора случайных настроек
uint32_t thisTime = 0;                           // Текущее время
bool clockIsVertical = false;                    // Чекбокс "Вертикальные часы"
uint8_t hours;                                   // Текущий час
int poleX = 0;                                   // X-координата для часов
int poleY = 0;                                   // Y-координата для часов
uint8_t clockHue = 0;                            // Оттенок часов
static uint8_t lastHour = 255;                   // Для отслеживания изменений времени
static uint8_t lastMinute = 255;                 // Для отслеживания изменений времени
static uint8_t lastSecond = 255;                 // Для отслеживания изменений времени
uint8_t ColonBri = 255;                          // Текущая яркость двоеточия
int8_t clockAutoOffsetY = 0;                     // Авто-сдвиг часов по Y при смене минут
bool autoMoveClockEnabled = true;                // Чекбокс "Авто-сдвиг часов при смене минут"
int clockXOffset = 0;                            // Смещение часов по X
int clockYOffset = 0;                            // Смещение часов по Y
bool rainbowClock = false;                       // Чекбокс "Разноцветные часы"
bool clockColorCycle = false;                    // Циклическое изменение цвета часов
uint8_t globalColonBrightness = 255;             // Глобальная яркость двоеточия
bool autoClockHue = false;                       // Автоматическая смена оттенка часов
bool clockLeadingZero = true;                    // Чекбокс "Ведущий ноль в часах"
bool clockNeedRedraw = false;                    // Флаг необходимости перерисовки часов
int clockPoleX = 0, clockPoleY = 0;              // Координаты часов на матрице
bool timeSynched = false;                        // Флаг синхронизации времени
bool runTimeTextEnabled = true;                  // Чекбокс "Часы бегущей строкой"
bool timeTextJustEnabled = false;                // Флаг, что часы только что включили
uint16_t NIGHT_HOURS_START;                      // Начало ночного времени
uint16_t NIGHT_HOURS_STOP;                       // Завершение ночного времен
unsigned int DAY_HOURS_BRIGHTNESS;               // Яркость дневного времени
unsigned int NIGHT_HOURS_BRIGHTNESS;             // Яркость ночного времени
uint8_t PRINT_TIME = 60;                         // Интервал вывода времени
bool nightClockEnabled = true;                   // Чекбокс Включить ночные часы
uint8_t nightClockBrightness = 2;                // Яркость ночных часов
uint8_t nightClockHue = 0;                       // Оттенок ночных часов
uint8_t userClockBrightness = 30;                // Пользовательская яркость для обычных (дневных) часов
uint8_t nightModeBrightness = 0;                 // 0 - не активен, 2 - ночной режим

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// погода
#if USE_WEATHER
bool weatherSpeakEnabled = true;                 // Разрешить озвучивание погоды (голосовое описание)
String configWeather;                            // Содержимое файла config_weather.json
uint8_t PRINT_WEATHER = 10;                      // Интервал вывода погоды на матрицу (минуты)
bool runWeatherTextEnabled = true;               // Выводить погоду бегущей строкой (да/нет)
bool weatherEnabled = false;                     // Включить отображение погоды на матрице (чекбокс)
bool degreeSymbolBlinking = true;                // Мигать символом градуса (°)
bool rainbowWeather = false;                     // Радужный режим цвета погоды
bool autoWeatherHue = false;                     // Автоматически менять оттенок погоды
uint8_t weatherHue = 0;                          // Базовый оттенок цвета погоды (0-255)
int weatherXOffset = 0;                          // Смещение отображения погоды по X (в пикселях)
int weatherYOffset = 0;                          // Смещение отображения погоды по Y (в пикселях)
int8_t weatherAutoOffsetY = 0;                   // Автоматическое смещение по Y (для центрирования)
bool forceWeatherEnabled = false;                // Принудительно включить погоду (для таймеров переключения)
bool weatherColorCycle = false;                  // Циклическая смена цвета погоды
uint8_t globalDegBrightness = 128;               // Яркость символа градуса (0-255)
bool weatherNeedRedraw = false;                  // Флаг, что погоду нужно перерисовать
int weatherPoleX = 0, weatherPoleY = 0;          // Координаты верхнего левого угла погоды на матрице
int16_t lastWeatherLeft = -1;                    // Последняя левая граница зоны погоды (для очистки)
int16_t lastWeatherRight = -1;                   // Последняя правая граница зоны погоды
int16_t lastWeatherTop = -1;                     // Последняя верхняя граница зоны погоды
int16_t lastWeatherBottom = -1;                  // Последняя нижняя граница зоны погоды
bool weatherTextJustEnabled = false;             // Флаг: погода только что включена
bool inClockWeatherMode = false;
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// дисплей TM1637
#if USE_TM1637
uint8_t DispBrightness = 1;                      // Яркость дисплея TM1637
bool dotFlag = false;                            // Флаг мигания двоеточия
uint32_t tmr_blink = 0;                          // Таймер мигания
bool aDirection = false;                         // Направление анимации
uint32_t DisplayTimer;                           // Таймер отображения
uint8_t LastEffect = 255;                        // Последний эффект
uint8_t userTm1637Brightness = 255;              // Пользовательская яркость TM1637
bool    userTm1637AutoBrightness = true;         // Автояркость TM1637
#if USE_MP3_PLAYER
uint8_t LastCurrentFolder = 255;                 // Последняя папка MP3
#endif
#endif // USE_TM1637

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// дисплей ST7789
#if USE_ST7789
uint8_t last_minute;                             // Для отслеживания изменений времени (минуты)
String configST7789;                             // Конфиг дисплея ST7789 (config_st7789.json)
uint8_t tft_clock_color = 0;                     // Цвет часов
uint8_t tft_weather_color = 1;                   // Цвет погоды
bool tft_ticker_on = false;                      // Чекбокс "Включить бегущую строку"
uint8_t tft_ticker_color = 0;                    // Цвет бегущей строки
uint16_t tft_ticker_speed = 60;                  // Скорость бегущей строки
uint16_t tft_ticker_period = 60;                 // Интервал вывода
char TFTTickerText[128] = {0};                   // Текст бегущей строки
uint8_t tft_brightness = 255;                    // Яркость подсветки дисплея
bool tft_auto_brightness = true;                 // Автояркость подсветки
uint8_t TFT_DAY_BRIGHTNESS = 255;                // Яркость днём
uint8_t TFT_NIGHT_BRIGHTNESS = 50;               // Яркость ночью
uint8_t tft_date_color = 0;                      // Цвет даты
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// общий таймер для дисплеев
#if (USE_TM1637 || USE_ST7789)
uint32_t tmr_clock = 0;                          // Таймер для дисплея
uint32_t displaySwitchTimer = 0;                 // Таймер переключения Часы/Погода/Дата
DisplayMode displayMode = DISP_MODE_CLOCK;       // Текущий режим отображения
uint32_t DISPLAY_SWITCH_INTERVAL = 10000;        // Интервал переключения
uint8_t DisplayFlag = 0;                         // Флаг отображения
bool dateSwitchEnabled = true;
bool weatherSwitchEnabled = true;
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// кнопка
#if USE_BUTTON
uint8_t button_type = BUTTON_TYPE;               // Тип кнопки: 0 - механическая, 1 - сенсорная
uint8_t btn_click_power = 1U;                    // Вкл/выкл лампы
uint8_t btn_click_next = 2U;                     // Следующий эффект
uint8_t btn_click_prev = 3U;                     // Предыдущий эффект
uint8_t btn_click_action4 = 4U;                  // OTA обновление
uint8_t btn_click_ip = 5U;                       // Показать IP
uint8_t btn_click_time = 6U;                     // Показать время
uint8_t btn_click_sound = 8U;                    // Вкл/выкл звук
uint8_t btn_click_weather = 9U;                  // Показать погоду
String configButton;                             // Конфиг кнопки (config_button.json)
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// пульт IR
#if USE_IR_RECEIVER
uint32_t lastIRCode = 0;
uint8_t IR_Data_Ready = 0;                       // Статус ИК-данных
unsigned long IR_Repeat_Timer = 0;               // Таймер для повторов ИК-команд
unsigned long lastIRtime = 0;                    // Время последнего приёма ИК-сигнала
uint32_t IR_Code = 0x00000000;                   // Последний полученный ИК-код
uint32_t IR_Tick_Timer;                          // Таймер для ИК-приёмника
uint32_t IR_Dgit_Enter_Timer;                    // Таймер ввода двухцифрового номера эффекта
uint8_t Repeat;                                  // Счётчик повторов
uint8_t Enter_Digit_1;                           // Флаг: введена первая цифра
uint8_t Enter_Number;                            // Введённый номер эффекта
IRrecv irrecv(IR_RECEIVER_PIN);                  // Объект ИК-приёмника
decode_results results;                          // Результат декодирования ИК-сигнала
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// пульт RF
#if USE_RF_RECEIVER
uint32_t RF_Code = 0;                            // Последний полученный RF-код
uint8_t RF_Data_Ready = 0;                       // Статус RF-данных
RCSwitch rfReceiver = RCSwitch();                // Объект RF-приёмника
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// мп3 плеер
#if USE_MP3_PLAYER
QueueHandle_t mp3CmdQueue = nullptr;             // Очередь команд MP3 (между ядрами)
volatile bool announceSessionActive = false;
uint8_t mp3_init_step = 0;                       // Текущий шаг инициализации DFPlayer
bool mp3Initialized = false;                     // Плеер успешно инициализирован
volatile uint8_t mp3_player_connect = 0;         // Статус подключения: 0=нет, 4=OK, 5=без карты
volatile uint8_t eff_volume = 9;                 // Громкость
volatile uint8_t eff_sound_on = 0;               // Включено ли звуковое сопровождение эффектов
volatile uint8_t mp3_folder = 1;                 // Текущая папка воспроизведения
volatile uint8_t mp3_folder_last = 255;          // Последняя использованная папка
volatile uint8_t CurrentFolder = 1;              // Текущая выбранная папка в интерфейсе
volatile uint8_t CurrentFolder_last = 0;         // Предыдущее значение CurrentFolder
uint8_t alarm_volume = 15;                       // Громкость рассвета/будильника
uint8_t sunset_volume = 10;                      // Громкость заката
uint8_t day_advert_volume = 12;                  // Громкость озвучки времени днём
uint8_t night_advert_volume = 5;                 // Громкость озвучки времени ночью
uint8_t weather_day_volume = 12;                 // Громкость озвучки погоды днём
uint8_t weather_night_volume = 5;                // Громкость озвучки погоды ночью
uint8_t AlarmFolder = 99;                        // Папка мелодии рассвета
uint8_t SunsetFolder = 99;                       // Папка мелодии заката
uint8_t previous_folder = 0;                     // Предыдущая папка (для возврата)
volatile bool alarm_sound_on = true;             // Играть звук при рассвете
volatile bool sunset_sound_on = false;           // Играть звук при закате
volatile bool dawnflag_sound = false;            // Флаг активного звукового режима рассвета
volatile bool sunsetflag_sound = false;          // Флаг активного звукового режима заката
volatile bool alarm_sound_flag = false;          // Флаг, что сейчас играет мелодия рассвета
volatile bool sunset_sound_flag = false;         // Флаг, что сейчас играет мелодия заката
volatile bool isAnnouncing = false;
volatile bool advert_hour = false;
volatile bool advert_flag = false;
volatile bool weather_advert_flag = false;
volatile bool set_mp3_play_now = false;
volatile bool mp3_stop = true;
volatile bool pause_on = true;
volatile bool wasPlayingBeforeAnnounce = false;
volatile bool day_advert_sound_on = true;
volatile bool night_advert_sound_on = true;
volatile bool alarm_advert_sound_on = true;
bool mp3_card_ok = false;                        // SD-карта обнаружена
bool dfPlayerIsOriginal = false;                 // Оригинальный DFPlayer или клон
uint32_t alarm_timer = 0;                        // Таймер для мелодии Рассвета
uint32_t sunset_timer = 0;                       // Таймер для мелодии Заката
uint32_t weather_advert_timer = 0;               // Таймер для озвучки погоды
uint32_t mp3_timer = 0;
uint32_t mp3_check_timer = 0;
uint16_t mp3_delay = 30;                         // Пауза после отправки команды DFPlayer
uint8_t  Equalizer = 0;                          // Эквалайзер (0-5)
uint32_t ADVERT_TIMER_1 = 800UL;
uint32_t ADVERT_TIMER_2 = 1400UL;
uint16_t ADVERT_TIMER_H = 1600;
uint16_t ADVERT_TIMER_M = 1800;
uint8_t weather_advert_state = 0;                // Текущее состояние машины состояний озвучки погоды
uint8_t weather_advert_count = 0;                // Количество треков в очереди погоды
uint8_t weather_advert_index = 0;                // Текущий индекс трека погоды
uint16_t weather_advert_tracks[8];               // Массив с номерами треков для озвучки погоды
bool timeAnnounceEnabled = true;                 // Разрешить озвучивание времени
bool time_always = false;                        // Озвучивать время всегда (даже ночью)
bool weather_always = false;                     // Озвучивать погоду всегда
bool manual_time_request = false;                // Ручной запрос озвучки времени
bool manual_weather_request = false;             // Ручной запрос озвучки погоды
bool show_weather_desc = true;                   // Озвучивать описание погоды
int day_weather_temp_on = 1;                     // Озвучивать температуру днём
int day_weather_desc_on = 1;                     // Озвучивать описание днём
int night_weather_temp_on = 1;
int night_weather_desc_on = 1;
bool send_sound = true;
bool send_eff_volume = true;
String configMP3;                                // Конфиг настроек плеера (config_mp3.json)
String soundList;                                // Конфиг списка папок мелодий для эффектов (sound_list.json)
uint8_t mp3_receive_buf[10];                     // Буфер для приёма ответов от плеера
uint16_t saved_mp3_track = 0;                    // Сохранённый трек перед озвучкой
uint8_t saved_mp3_folder = 0;                    // Сохранённая папка перед озвучкой
static Mp3PlayState mp3PlayState = MP3_PLAY_IDLE;
static uint32_t mp3PlayTimer = 0;
static uint8_t mp3PlayPendingFolder = 0;
static bool mp3PlayNeedPause = false;
volatile bool mp3_pending_time_advert = false;
volatile bool mp3_pending_weather_advert = false;
volatile bool mp3_pending_weather_force = false;
volatile bool mp3_pending_time_force = false;
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// Радио
#if USE_RADIO
uint8_t effects_stations[MODE_AMOUNT] = {0};
bool radioPlaying = false;
uint8_t currentStation = 0;
String configRadio;
volatile bool radioPendingStop = false;
uint8_t radioVolume = 10;
bool radioInited = false;
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// LED Панель
String configLedPanel;                           // Конфиг настроек отображения часов, даты, погоды, бегущей строки (config_led_panel.json)
bool needFullRedraw = false;                     // Флаг полной перерисовки матрицы

// -------------------------------------------

// дата
bool showFullYearEnabled = true;                 // Чекбокс "Показывать 4 цифры года" (иначе 2 цифры)
bool dateEnabled = true;                         // Чекбокс "Включить дату"
uint8_t globalPointBrightness = 255;             // Яркость разделительных точек
int dateXOffset = 0;                             // Смещение даты по X (по ширине матрицы)
int dateYOffset = 0;                             // Смещение даты по Y (по высоте матрицы)
uint8_t dateHue = 0;                             // Оттенок даты
bool dateSeparatorBlinking = true;               // Чекбокс "Мигание разделительных точек в дате"
bool showYearInDate = true;                      // Чекбокс "Показывать год"
bool rainbowDate = false;                        // Чекбокс "Разноцветная дата"
bool autoHueDate = false;                        // Автоматическая смена оттенка даты
bool forceDateEnabled = false;                   // Принудительное включение даты
bool dateColorCycle = false;                     // Циклическое изменение цвета даты
bool dateNeedRedraw = false;                     // Флаг необходимости перерисовки даты
int datePoleX = 0, datePoleY = 0;                // Координаты даты на матрице (после выравнивания)
int16_t lastDateLeft = -1;                       // Последняя левая граница даты (для очистки)
int16_t lastDateRight = -1;                      // Последняя правая граница даты (для очистки)
int16_t lastDateTop = -1;                        // Последняя верхняя граница даты (для очистки)
int16_t lastDateBottom = -1;                     // Последняя нижняя граница даты (для очистки)

// -------------------------------------------

// таймеры и интервалы
bool timer_c_w = false;                          // Чекбокс "Таймер Часы / Погода"
bool timer_d_w = false;                          // Чекбокс "Таймер Дата / Погода"
bool timer_c_d_w = false;                        // Чекбокс "Таймер Часы / Дата / Погода"
bool timer_c_d = false;                          // Чекбокс "Таймер Часы / Дата"
bool timer_clock_fixed = false;                  // Чекбокс "Часы + Дата / Погода" (часы всегда, дата/погода чередуются)
uint16_t interval_c_w = 10;                      // Интервал переключения Часы/Погода
uint16_t interval_d_w = 10;                      // Интервал переключения Дата/Погода
uint16_t interval_c_d_w = 10;                    // Интервал переключения Часы/Дата/Погода
uint16_t interval_c_d = 10;                      // Интервал переключения Часы/Дата
uint16_t interval_clock_fixed = 10;              // Интервал переключения между датой и погодой (сек.)
uint8_t currentTimerPhase = 0;                   // Текущая фаза: 0 = часы, 1 = дата, 2 = погода
unsigned long lastTimerSwitch = 0;               // Время последнего переключения таймера
unsigned long lastSwitchTime = 0;                // Таймер переключения в часах, дате, погоде (которые на матрице рисуются)
unsigned long lastClockFixedSwitch = 0;          // Время последнего переключения в этом режиме

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// избранное
uint8_t Favorit_only;

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// рассвет
#if USE_DAWN
String configAlarm;
uint8_t dawnMode;             // Длительность рассвета
uint8_t dawnFlag = 0;         // Статус рассвета
uint16_t dawnPosition;        // Текущая позиция
uint8_t DAWN_BRIGHT;          // Яркость рассвета
uint8_t DAWN_TIMEOUT;
AlarmType alarms[7] = {};
CRGB dawnColor[6];
uint8_t dawnCounter = 0;
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// закат
#if USE_SUNSET
String configSunset;
uint8_t sunsetMode;           // Длительность заката
uint8_t sunsetFlag = 0;       // Статус заката
uint16_t sunsetPosition;      // Текущая позиция
uint8_t SUNSET_BRIGHT;        // Яркость заката
SunsetType sunsets[7] = {};
CRGB sunsetColor[6];
uint8_t sunsetCounter = 0;
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// расписание лампы
#if USE_SCHEDULE
String configSchedule;
scheduleType schedule[MAX_SCHEDULE_ENTRIES];  // Массив событий по расписанию
bool allowScheduleAtStartup = false;          // Разрешить выполнение расписания при старте
uint32_t scheduleStartupDelay = 0;            // Задержка перед первым выполнением расписания
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// управление несколькими лампами
#if USE_MULTILAMP
String configMultilamp;
char Host1[16];         // IP адрес лампы
char Host2[16];         // IP адрес лампы
char Host3[16];         // IP адрес лампы
char Host4[16];         // IP адрес лампы
char Host5[16];         // IP адрес лампы
uint8_t ml1;            // Флаг включения синхронизации с каждой лампой
uint8_t ml2;            // Флаг включения синхронизации с каждой лампой
uint8_t ml3;            // Флаг включения синхронизации с каждой лампой
uint8_t ml4;            // Флаг включения синхронизации с каждой лампой
uint8_t ml5;            // Флаг включения синхронизации с каждой лампой
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

bool sd_card_present = false;
bool outEffectActive = false;
uint8_t effSdIndex = 255;

// ----------------------------------------------------------------------------------------------------------------------------------------------------

#if USE_SD
bool outAnimationActive = false;
String lastOutFileName = "";
uint32_t outLastFrameTime = 0;
uint16_t outFrameDelay = 100;
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

String configSetup = "{}";                       // Конфиг лампы (config.json)
String configCycle = "{}";                       // Конфиг режима Цикл (config_cycle.json)
String configLedInterval;                        // Конфиг интервалов часы/дата/погода/бегущая строка (config_led_interval.json)
volatile bool configChanged = false;             // Флаг изменения конфига
uint8_t globalHueCycle = 0;                      // Глобальный цикл оттенка
bool requirePasswordInLocalNetwork = true;       // Установка пароля для редактора в локальной сети
uint8_t eff_num_correct[MODE_AMOUNT];            // Корректировка номеров эффектов
uint8_t effects_folders[MODE_AMOUNT] = {0};      // Номера папок для озвучивания каждого эффекта
bool repeat_multiple_lamp_control = false;       // Флаг повторной отправки команды на другие лампы
bool effectDrawn = false;                        // Флаг, что эффект отрисован (для часов, см. в effect_ticker)
uint8_t TURN_ON_AFTER_SHUTDOWN;                  // Чекбокс "Включать лампу после обесточивания"
uint16_t current_limit;                          // Лимит тока (мА)
uint8_t AutoBrightness;                          // Автояркость
uint8_t currentMode;                             // Текущий эффект
bool loadingFlag = true;                         // Флаг перезагрузки эффекта
bool ONflag = false;                             // Состояние лампы
uint8_t random_on;                               // Чекбокс "Перемешать выбранные эффекты"
uint8_t FPSdelay = DYNAMIC;                      // Задержка между кадрами
uint8_t save_file_changes = 0;                   // Битовая маска для отложенного сохранения файлов (см. в Constants.h)
uint32_t timeout_save_file_changes;              // Таймер отложенного сохранения
bool manualOverride = false;                     // Ручное управление активно
bool manualOverrideOff = false;                  // Ручное выключение лампы (блокировка авто-включения)
bool manualOff = false;                          // Ручное выключение (для рассвета)
bool manualsOff = false;                         // Ручное выключение (для заката)
uint32_t manualOverrideUntil = 0;                // Время окончания ручного управления
bool connect = false;                            // Флаг UDP-соединения
uint16_t localPort = ESP_UDP_PORT;               // Порт для UDP
char packetBuffer[MAX_UDP_BUFFER_SIZE];          // Буфер для UDP-пакетов
char inputBuffer[MAX_UDP_BUFFER_SIZE];           // Буфер для входящих команд
char udpBuffer[MAX_UDP_BUFFER_SIZE];             // Буфер для исходящих UDP-сообщений
uint8_t T_flag = 0;
uint8_t first_entry = 1;
volatile bool systemShuttingDown = false;
bool showClock = true;
bool weatherErrActive = false;
uint32_t weatherErrTimer = 0;
char currentLang[4] = "ru";
uint8_t lastNonAnimSel = 1;

// ----------------------------------------------------------------------------------------------------------------------------------------------------

#if USE_UPDATE_CHECK
bool updateCheckPending = false;
bool updateCheckInProgress = false;
uint32_t updateCheckLastRun = 0;
String cachedUpdateResponse = "";
bool cachedUpdateValid = false;
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// MQTT
#if USE_MQTT
String configMQTT;            // Конфиг MQTT (config_mqtt.json)
uint32_t mqtt_timer = 0;      // Таймер для MQTT
bool MqttOn = false;          // Чекбокс "Включить MQTT"
uint16_t MqttPeriod = 60;     // Период публикации состояния
IPAddress MqttServer;         // IP-адрес MQTT-брокера
char MqttHost[64] = {0};      // Адрес MQTT-брокера
char MqttUser[32] = {0};      // Имя пользователя MQTT
char MqttPassword[32] = {0};  // Пароль MQTT
char TopicBase[64] = {0};
bool mqttIPaddr = false;
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// таймеры
uint32_t my_timer;                    // Основной системный таймер
bool timerMode = false;               // Флаг таймерного режима
uint32_t manualControlTimer = 0;      // Таймер ручного управления
bool manualControlActive = false;
uint32_t effTimer;
static uint32_t lastMedium = 0;
static uint32_t lastSlow = 0;
static uint32_t lastWiFi = 0;
#if HEAP_SIZE_PRINT
uint32_t mem_timer;
#endif

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// буферы для матрицы
CRGB* effectBuffer = nullptr;                 // Для эффектов
CRGB* leds = nullptr;                         // Основной буфер LED
CRGB* ledsbuff;                               // Вторичный буфер LED
uint8_t*** noise3d = nullptr;                 // 3D-буфер для шумовых эффектов
uint8_t **noise = nullptr;                    // 2D-буфер для шумовых эффектов
uint8_t* line = nullptr;                      // Для отрисовки линий
uint8_t* shiftHue = nullptr;                  // Для смещения оттенка
uint8_t* shiftValue = nullptr;                // Для смещения яркости
uint16_t* fireBufferGlobal = nullptr;         // Для огненных эффектов
uint8_t** matrixValue = nullptr;

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// ntp-серверы
const char* ntp1;                             // Указатель на первый NTP-сервер
const char* ntp2;                             // Указатель на второй NTP-сервер
const char* ntpServer1 = "ntp3.vniiftri.ru";  // NTP-сервер по умолчанию
const char* ntpServer2 = "ru.pool.ntp.org";   // Резервный NTP-сервер
const char* defaultTz = "MSK-3";              // Часовой пояс по умолчанию

// ----------------------------------------------------------------------------------------------------------------------------------------------------

// MQTT
#if USE_MQTT
AsyncMqttClient* mqttClient = NULL;           // Указатель на MQTT-клиент
#endif

// ==================================================================== ОБЪЯВЛЕНИЯ ОБЪЕКТОВ ===========================================================

ModeType modes[MODE_AMOUNT];
File fsUploadFile;                            // HTTP-загрузка
timerMinim timeTimer(999UL);                  // Таймер эффектов
timerMinim printTimer(60000UL);               // Таймер вывода времени
timerMinim runningTextTimer(60000UL);         // Таймер бегущей строки
timerMinim offlineTimer(forcedApTimeoutMs);   // Таймер принудительной точки доступа
WiFiMulti wifiMulti;
#if USE_IR_RECEIVER
IRManager irManager;
#endif
WiFiUDP Udp;
WebServer server(80);
WebServer HTTP(ESP_HTTP_PORT);
#if USE_UPDATE_CHECK
UpdateCache updateCache = { "", 0, false }; // экземпляр кэша
#endif
#if USE_SD
fs::File outFile; // файл .out эффекта
#endif

// ------------------------------------------

#if USE_TM1637
TM1637Display display(CLK, DIO);
#endif

// ------------------------------------------

#if USE_BUTTON
GButton touch(BTN_PIN);
#endif

// ------------------------------------------

#if USE_MP3_PLAYER
HardwareSerial mp3(2);
#endif

// ************************************************************************** VOID SETUP() **************************************************************

void setup() {

  Serial.begin(115200);
  delay(300);
  esp_task_wdt_init(30, true);
#if GENERAL_LOG
  SYSLOG.add("=== FIERY LED LAMP ===");
#endif

  FS_init(); // Инициализация LittleFS
  loadAllConfigs(); // Чтение всех json конфигов
  BackupsIfNeeded(); // Восстановление настроек из бэкапа
  printConfigSizes();
  loadAllSettings(); // Загрузка всех настроек

#if USE_RADIO && USE_MP3_PLAYER
  if (radioEnabled && mp3Enabled) {
    disableAudioSource(AUDIO_SOURCE_MP3);
  }
#endif

#if USE_IR_RECEIVER
  irManager.loadSavedRemote(); // Загрузка сохранённого ИК пульта
#endif

  initHardware(); // MOSFET, ALARM пины, SD карта
  loadMatrixAndInitLEDs(); // Настройки матрицы (матрица + FastLED)

#if USE_ANIMATIONS
  initAnimations(); // Инициализация покадровых анимаций
#endif

#if USE_SD
  if (sdEnabled) initSD(); // Инициализация SD карты
#endif

#if USE_TM1637
  if (tm1637Enabled) initTM1637(); // Инициализация дисплея TM1637
#endif

#if USE_ST7789
  if (st7789Enabled) initST7789(); // Инициализация дисплея ST7789
#endif

  Time::instance(); // Инициализация времени
  String saved_tz = jsonRead(configSetup, "tz");
  saved_tz.trim();
  if (saved_tz.length() == 0 || saved_tz == "auto") saved_tz = "MSK-3";
  myTime.tzsetup(saved_tz.c_str());

  Wifi::instance().begin(); // Инициализация WiFi

#if USE_UPDATE_CHECK
  xTaskCreatePinnedToCore(updateCheckTask, "updchk", 6144, NULL, 1, NULL, 0);
#endif

  initDeferredTasks();

#if USE_WEATHER
  Weather::instance().startTask();
#endif

#if USE_MQTT
  initMQTT(); // Инициализация MQTT клиента
#endif

#if USE_BUTTON
  if (buttonEnabled) initButtonHardware(); // Инициализация кнопки
#endif

#if USE_IR_RECEIVER
  if (irEnabled) initIR(); // Инициализация ИК приёмника
#endif

#if USE_RF_RECEIVER
  if (rfEnabled) initRF(); // Инициализация RF приёмника
#endif

#if USE_MP3_PLAYER
  mp3CmdQueue = xQueueCreate(32, sizeof(Mp3CmdMsg)); // очередь команд
  xTaskCreatePinnedToCore(mp3Task, "mp3Task", 12288, NULL, 1, NULL, 0);
#endif

#if USE_RADIO
  if (radioEnabled) {
    radioInit();  // Инициализация I2S для радио
    if (ONflag) {
      uint8_t stId = radioGetStationForMode(currentMode);
      if (stId > 0) radioPlayStation(stId);
    }
  }
#endif

#if USE_DAWN
  initAlarm(); // Инициализация будильника "Рассвет"
#endif

#if USE_SUNSET
  initSunset(); // Инициализация режима "Закат"
#endif

#if USE_SCHEDULE
  initSchedule(); // Инициализация расписания лампы
#endif

#if USE_OTA
  Ota::instance().setWarningDelegate(&showWarning);
#endif

  initWebServices(); // Инициализация веб-сервисов
  initSystemTimers(); // Инициализация системных таймеров
  finalizeSetup(); // Завершающие настройки

} // void setup()

// ************************************************************************** VOID LOOP() **************************************************************

void loop() {

  if (pendingRestart) {
    delay(500);
    ESP.restart();
  }

  parseUDP();

  HTTP.handleClient();

#if USE_OTA
  Ota::instance().HandleOtaUpdate();
#endif

#if USE_BUTTON
  if (buttonEnabled) {
    buttonTick();
  }
#endif

  timeTick();

#if USE_IR_RECEIVER
  if (irEnabled) {
    IR_Receive_Handle();
    if (IR_Data_Ready) {
      IR_Receive_Button_Handle();
      IR_Data_Ready = 0;
    }
  }
#endif

#if USE_RF_RECEIVER
  if (rfEnabled) {
    RF_Receive_Handle();
    if (RF_Data_Ready) {
      RF_Receive_Button_Handle();
      RF_Data_Ready = 0;
    }
  }
#endif

  uint32_t now = millis();
  if (now - lastMedium >= MEDIUM_TASK_INTERVAL) {
    lastMedium += MEDIUM_TASK_INTERVAL;
    handleMediumTasks();
  }

  if (now - lastSlow >= SLOW_TASK_INTERVAL) {
    lastSlow += SLOW_TASK_INTERVAL;
    handleSlowTasks();
  }

  if (now - lastWiFi >= WIFI_TASK_INTERVAL) {
    lastWiFi += WIFI_TASK_INTERVAL;
    Wifi::instance().loop();
  }

#if USE_TM1637
  if (tm1637Enabled) {
    handleTM1637();
  }
#endif

#if USE_ST7789
  if (st7789Enabled) {
    TFT_LoopTick();
  }
#endif

#if USE_RADIO
  radioLoop();
#endif

  bool needEffects = ONflag;
#if USE_DAWN
  needEffects |= dawnFlag;
#endif

#if USE_SUNSET
  needEffects |= sunsetFlag;
#endif

  static bool matrixCleared = false;
  if (needEffects && !systemShuttingDown) {
    effectsTick();
    matrixCleared = false;
  } else if (!systemShuttingDown && leds != nullptr && !matrixCleared) {
    FastLED.clear();
    FastLED.show();
    matrixCleared = true;
  }

  handleRunningText();
  handleFavorites();

  if (manualControlActive && (now - manualControlTimer >= 30000)) {
    manualControlActive = false;
  }

  bool shouldSleep = !ONflag;
#if USE_DAWN && USE_SUNSET
  shouldSleep = shouldSleep && !dawnFlag && !sunsetFlag;
#elif USE_DAWN
  shouldSleep = shouldSleep && !dawnFlag;
#elif USE_SUNSET
  shouldSleep = shouldSleep && !sunsetFlag;
#else
#endif // USE_DAWN && USE_SUNSET

  shouldSleep = shouldSleep && !Favorites::instance().FavoritesRunning;

  if (shouldSleep) {
    delay(8);
  } else {
    yield();
  }

} // void loop()

// ******************************************************************************************************************************************************
