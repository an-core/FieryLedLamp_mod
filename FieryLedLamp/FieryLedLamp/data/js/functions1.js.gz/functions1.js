var CONFIG = {
    AJAX_TIMEOUT: 12000,
    UPDATE_CHECK_CACHE_TTL: 10 * 60 * 1000,
    AUTO_UPDATE_CHECK_INTERVAL: 60 * 60 * 1000,
    VERSION_CACHE_TTL: 5 * 60 * 1000,
    WEATHER_REFRESH_INTERVAL: 60000,
    RADIO_MODE_AMOUNT: 135,
    RADIO_MAX_STATIONS: 255,
    TOOLTIP_RETRY_LIMIT: 10,
    TOOLTIP_RETRY_DELAY: 300
};

var STORAGE_KEYS = {
    UPDATE_NOTIFICATION: 'update_notification_shown',
    VERSION_CACHE: 'firmware_version_cache',
    UPDATE_CHECK_CACHE: 'update_check_cache',
    UPDATE_BADGE_SEEN: 'update_badge_seen_version',
    TIME_SENT: 'timeSent',
    SESSION_LOGIN: 'sossionLogin'
};

var MODULE_CHECKBOX_MAP = {
    button_enable: 'button',
    ir_enable: 'ir',
    rf_enable: 'rf',
    tm1637_enable: 'tm1637',
    st7789_enable: 'st7789',
    mp3_enable: 'sound',
    radio_enable: 'radio',
    sd_enable: 'sd'
};

var statusColors = {
    sd: {
        'ОК': '#00ff00',
        'ЭМУЛЯЦИЯ В LITTLEFS': '#00ff00',
        'ВЫКЛЮЧЕНО': '#888888',
        'КАРТА НЕ НАЙДЕНА': '#ff0000',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    mp3: {
        'ГОТОВ': '#00ff00',
        'OK': '#00ff00',
        'ИГРАЕТ': '#00ff00',
        'ПАУЗА': '#ffff00',
        'ВЫКЛЮЧЕН': '#888888',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888',
        'НЕТ СВЯЗИ': '#ff0000',
        'ИНИЦИАЛИЗАЦИЯ...': '#ff8800',
        'КАРТА НЕИСПРАВНА': '#ff8800'
    },
    radio: {
        'ИГРАЕТ': '#00ff00',
        'OK': '#00ff00',
        'ПАУЗА': '#ffff00',
        'ОСТАНОВЛЕНО': '#888888',
        'ВЫКЛЮЧЕНО': '#888888',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888',
        'НЕТ СВЯЗИ': '#ff0000',
        'ОШИБКА': '#ff0000'
    },
    button: {
        'СЕНСОРНАЯ': '#00ff88',
        'МЕХАНИЧЕСКАЯ': '#00cc00',
        'ВЫКЛЮЧЕНА': '#888888',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    ir: {
        'OK': '#00ff00',
        'ОЖИДАЕТ КОМАНДУ': '#ffff00',
        'ВЫКЛЮЧЕН': '#888888',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    rf: {
        'OK': '#00ff00',
        'ОЖИДАЕТ КОМАНДУ': '#ffff00',
        'ВЫКЛЮЧЕН': '#888888',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    tm1637: {
        'ВКЛЮЧЕН': '#00ff00',
        'ВЫКЛЮЧЕН': '#888888',
        'НЕТ СВЯЗИ': '#ff0000',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    st7789: {
        'ВКЛЮЧЕН': '#00ff00',
        'ВЫКЛЮЧЕН': '#888888',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    ota: {
        'ГОТОВ': '#00ff00',
        'ГОТОВО К ОБНОВЛЕНИЮ': '#00ff00',
        'ЗАГРУЗКА...': '#ff8800',
        'ЗАПИСЬ...': '#ff8800',
        'УСПЕШНО': '#00ff00',
        'ОШИБКА': '#ff0000',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    mqtt: {
        'ПОДКЛЮЧЕНО': '#00ff00',
        'НЕ ПОДКЛЮЧЕНО': '#ff0000',
        'НЕТ СВЯЗИ': '#ff0000',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    multilamp: {
        'ВКЛЮЧЕНО': '#00ff88',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    wifi: {
        'Точка доступа': '#ffaa00',
        'Клиент Wi-Fi': '#00ff00'
    }
};

var NOTIFICATION_STYLES = {
    NO_UPDATE: 'background: linear-gradient(135deg, rgba(100, 181, 246, 0.1), rgba(100, 181, 246, 0.02)); border: 1px solid rgba(100, 181, 246, 0.2); border-radius: 12px; padding: 16px 20px; margin-top: 12px; display: flex; align-items: center; gap: 12px;',
    UPDATE_AVAILABLE: 'background: linear-gradient(135deg, rgba(76, 175, 80, 0.15), rgba(76, 175, 80, 0.05)); border: 1px solid rgba(76, 175, 80, 0.3); border-radius: 12px; padding: 16px 20px; margin-top: 12px; display: flex; align-items: center; gap: 12px;',
    ERROR: 'background: linear-gradient(135deg, rgba(244, 67, 54, 0.15), rgba(244, 67, 54, 0.05)); border: 1px solid rgba(244, 67, 54, 0.3); border-radius: 12px; padding: 16px 20px; margin-top: 12px; display: flex; align-items: center; gap: 12px;'
};

var HEADER_STYLES = {
    ATTENTION: 'color: #ff1744; font-weight: bold; font-size: 16px; padding-left:4px; border-radius:8px; background: rgba(255, 23, 68, 0.2); border: 1px solid rgba(255, 23, 68, 0.3); animation: attention-pulse 1.5s ease-in-out infinite;',
    NEW: 'color: #4caf50; font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgb(31 189 43 / 48%);',
    PREVIOUS_1: 'color: #ff9800; font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgb(211 209 205 / 14%);',
    PREVIOUS_2: 'color: #ff9800; font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgb(211 209 205 / 14%);',
    PREVIOUS_OTHER: 'color: rgba(255, 152, 0, 0.6); font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgb(211 209 205 / 14%);',
    DEFAULT: 'color: #64b5f6; font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgba(100, 181, 246, 0.08);',
    FIRMWARE: 'color: #29b6f6; font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgba(41, 182, 246, 0.18); border: 1px solid rgba(41, 182, 246, 0.35);',
    FIRMWARE_FS: 'color: #ab47bc; font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgba(171, 71, 188, 0.2); border: 1px solid rgba(171, 71, 188, 0.4);'
};

var ITEM_STYLES = {
    ATTENTION: 'padding: 8px 14px; margin-bottom: 4px; background: rgba(255, 23, 68, 0.08); border-radius: 8px; border-left: 3px solid #ff1744;',
    NEW: 'padding: 8px 14px; margin-bottom: 4px; background: rgba(255,255,255,0.03); border-radius: 8px; border-left: 3px solid #0f8d06;',
    PREVIOUS: 'padding: 8px 14px; margin-bottom: 4px; background: rgba(255,255,255,0.03); border-radius: 8px; border-left: 3px solid #8D6E63;',
    DEFAULT: 'padding: 8px 14px; margin-bottom: 4px; background: rgba(255,255,255,0.03); border-radius: 8px; border-left: 3px solid #64b5f6;',
    INDENT: 'padding-left: 24px; border-left-color: transparent; background: transparent;'
};

/* ------------------------------- */

function isObject(obj) {
    return obj != null && obj.constructor.name === 'Object';
}

function normalizeVer(v) {
    return String(v || '').trim().replace(/^v/i, '').toLowerCase();
}

function formatBuildDateTime(datetime) {
    try {
        if (!datetime || typeof datetime !== 'string')
            return '';
        var date = new Date(datetime);
        if (isNaN(date.getTime()))
            return '';
        var day = String(date.getDate()).padStart(2, '0');
        var month = String(date.getMonth() + 1).padStart(2, '0');
        var year = date.getFullYear();
        var hours = String(date.getHours()).padStart(2, '0');
        var minutes = String(date.getMinutes()).padStart(2, '0');
        return 'Сборка: ' + day + '.' + month + '.' + year + ' ' + hours + ':' + minutes;
    } catch (e) {
        return '';
    }
}

var _timers = {};

function managedSetInterval(name, fn, ms) {
    managedClearInterval(name);
    _timers[name] = setInterval(fn, ms);
}

function managedClearInterval(name) {
    if (_timers[name]) {
        clearInterval(_timers[name]);
        delete _timers[name];
    }
}

function debounce(fn, ms) {
    var t;
    return function () {
        var ctx = this,
        args = arguments;
        clearTimeout(t);
        t = setTimeout(function () {
            fn.apply(ctx, args);
        }, ms);
    };
}

/* ------------------------------- */

var state = {
    jsonPage: null,
    jsonResponse: {},
    moduleStates: {},
    features: {},
    patterns: null,
    dragSrcEl: null,
    active: 'egiste',
    allTooltips: [],
    updateData: null,
    versionData: null,
    weatherJustChanged: 0,
    radio: {
        stations: [],
        map: {},
        effList: []
    }
};

// Legacy aliases (used by HTML / other modules)
var jsonPage = null;
var jsonResponse = {};
var patterns = null;
var _allTooltips = [];

/* ------------------------------- */

function elem(id) {
    return document.getElementById(id);
}

function val(id, value) {
    var el = elem(id);
    if (!el)
        return;
    if (value !== undefined && value !== null && value !== '') {
        el.value = (value === ' ' ? '' : value);
    } else if (value === undefined) {
        return el.value;
    } else {
        el.value = '';
    }
}

function html(id, value) {
    var el = elem(id);
    if (!el)
        return;
    if (value === 'onclick') {
        if (jsonResponse.message === 'Not registered') {
            el.setAttribute('onclick', "alert('" + jsonResponse.LangNotRegistered + "');return false");
        }
        return;
    }
    if (value) {
        el.innerHTML = (value === ' ' ? '' : value);
    } else {
        return el.innerHTML;
    }
}

function toggle(id, action) {
    var el = elem(id);
    if (!el)
        return;
    var cl = el.classList;
    if (cl.contains('hidden')) {
        if (action !== 'show') {
            cl.remove('hidden');
            cl.add('show');
        }
    } else if (action !== 'hidden') {
        cl.remove('show');
        cl.add('hidden');
    }
}

function log(text) {
    var container = document.getElementById('url-content');
    if (!container)
        return;
    var listitems = container.getElementsByTagName('li');
    for (var i = 0; i < listitems.length; i++) {
        listitems[i].classList.remove('tdFadeInRight');
        if (i > 70)
            container.removeChild(listitems[0]);
    }
    container.innerHTML += text;
    container.scrollTop = container.scrollHeight;
}

function togglePasswordVisibility(inputId) {
    var input = document.getElementById(inputId);
    if (!input)
        return;
    var btn = document.getElementById(inputId + '_toggle');
    if (input.type === 'password') {
        input.type = 'text';
        if (btn)
            btn.classList.add('password-visible');
    } else {
        input.type = 'password';
        if (btn)
            btn.classList.remove('password-visible');
    }
}

/* ------------------------------- */

var ajax = {};

ajax.x = function () {
    var xhr;
    if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
    } else {
        xhr = new ActiveXObject('Microsoft.XMLHTTP');
    }
    xhr.timeout = CONFIG.AJAX_TIMEOUT;
    return xhr;
};

ajax.send = function (url, callback, method, data, async) {
    if (method !== 'PUT')
        submit_disabled(true);
    if (async === undefined)
        async = true;

    var x = ajax.x();
    x.open((method === 'PUT' ? 'GET' : method), url, async);
    x.onreadystatechange = function () {
        if (x.readyState === 4) {
            if (method !== 'PUT')
                submit_disabled(false);
            if (x.status >= 200 && x.status < 300) {
                callback(x.responseText);
            } else {
                console.warn('HTTP ' + x.status + ' for ' + url + ' — treating as FileNotFound');
                callback('FileNotFound');
            }
        }
    };
    x.ontimeout = function () {
        if (method !== 'PUT')
            submit_disabled(false);
        console.warn('Request timeout: ' + url);
        callback('FileNotFound');
    };
    x.onerror = function () {
        if (method !== 'PUT')
            submit_disabled(false);
        console.warn('Request error: ' + url);
        callback('FileNotFound');
    };
    if (method === 'POST') {
        x.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    }
    x.send(data);
};

ajax.get = function (url, data, callback, async) {
    var query = [];
    for (var key in data) {
        query.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
    }
    ajax.send(url + (query.length ? '?' + query.join('&') : ''), callback, 'GET', null, async);
};

ajax.put = function (url, data, callback, async) {
    var query = [];
    for (var key in data) {
        query.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
    }
    ajax.send(url + (query.length ? '?' + query.join('&') : ''), callback, 'PUT', null, async);
};

ajax.post = function (url, data, callback, async) {
    var query = [];
    for (var key in data) {
        query.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
    }
    ajax.send(url, callback, 'POST', query.join('&'), async);
};

function createXmlHttpObject() {
    var xmlHttp;
    if (window.XMLHttpRequest) {
        xmlHttp = new XMLHttpRequest();
    } else {
        xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
    }
    return xmlHttp;
}
var xmlHttp = createXmlHttpObject();

/* ------------------------------- */

function renameBlock(jsonResponseObj, str, skipEval) {
    if (str) {
        var arr = str.match(/\{\{\S+?\}\}/gim);
        if (arr) {
            for (var i = 0; i < arr.length; i++) {
                var id = arr[i].slice(2, -2);
                var value = jsonResponseObj[id] !== undefined ? jsonResponseObj[id] : '';
                str = str.replace(new RegExp('{{' + id + '}}', 'g'), value);
            }
        }
    }
    if (typeof str !== 'undefined' && str != null && str) {
        if (skipEval)
            return str;
        try {
            return eval(str);
        } catch (e) {
            return str;
        }
    } else {
        return '';
    }
}

function renameGet(str) {
    if (str) {
        var arr = str.match(/\[\[\S+?\]\]/gim);
        if (arr) {
            for (var i = 0; i < arr.length; i++) {
                var id = arr[i].slice(2, -2);
                var element = elem(id);
                if (element) {
                    var txt = '';
                    try {
                        if (element.tagName === 'SELECT') {
                            if (element.selectedIndex >= 0 && element.options[element.selectedIndex]) {
                                txt = element.options[element.selectedIndex].value;
                            } else if (element.options.length > 0) {
                                txt = element.options[0].value;
                            } else {
                                txt = '';
                            }
                        } else if (element.tagName === 'INPUT') {
                            txt = encodeURIComponent(element.value || '');
                        } else if (element.tagName === 'TEXTAREA') {
                            txt = encodeURIComponent(element.value || '');
                        } else {
                            txt = element.innerHTML || '';
                        }
                    } catch (e) {
                        txt = '';
                        console.warn('renameGet: ошибка чтения [[[' + id + ']]]:', e.message);
                    }
                    str = str.replace(new RegExp('\\[\\[' + id + '\\]\\]', 'g'), txt);
                }
            }
        }
    }
    return str;
}

function searchModule(modules, find) {
    var findModules = '';
    for (var key in modules) {
        if (modules[key].indexOf(find) !== -1)
            findModules = 1;
    }
    return findModules;
}

/* ------------------------------- */

function initRangeSliders() {
    document.querySelectorAll('input[type="range"]').forEach(function (slider) {
        if (slider._rangeInited)
            return;
        slider._rangeInited = true;

        var label = slider.closest('label');
        var h4 = label ? label.querySelector('h4') : null;
        var originalTitle = h4 ? h4.innerHTML : '';

        slider.addEventListener('input', function () {
            if (!h4)
                return;
            var v = slider.value;
            if (/\{\{.*?\}\}/.test(originalTitle)) {
                h4.innerHTML = originalTitle.replace(/\{\{.*?\}\}/, v);
            } else {
                h4.innerHTML = originalTitle.replace(/\d+(?!.*\d)/, v);
            }
        });
    });
}

function initBrightnessSliders() {
    var IDS = {
        tm1637_brightness: 'tm1637_auto_brightness',
        tft_brightness: 'tft_auto_brightness'
    };
    Object.keys(IDS).forEach(function (sliderId) {
        var checkboxId = IDS[sliderId];
        var slider = document.getElementById(sliderId);
        var checkbox = document.getElementById(checkboxId);

        if (slider && !slider._brightnessInited) {
            slider._brightnessInited = true;
            var label = slider.closest('label');
            var h4 = label ? label.querySelector('h4') : null;
            var originalTitle = h4 ? h4.innerHTML : '';

            slider.addEventListener('input', function () {
                if (checkbox && checkbox.checked) {
                    checkbox.checked = false;
                } else {
                    var cb = document.getElementById(checkboxId);
                    if (cb && cb.checked)
                        cb.checked = false;
                }
                if (h4) {
                    var v = slider.value;
                    if (/\{\{.*?\}\}/.test(originalTitle)) {
                        h4.innerHTML = originalTitle.replace(/\{\{.*?\}\}/, v);
                    } else {
                        h4.innerHTML = originalTitle.replace(/\d+(?!.*\d)/, v);
                    }
                }
            });
        }
        if (checkbox && !checkbox._brightnessInited) {
            checkbox._brightnessInited = true;
            if (typeof jsonResponse !== 'undefined' && jsonResponse && jsonResponse[checkboxId] !== undefined) {
                checkbox.checked = (jsonResponse[checkboxId] === '1');
            }
        }
    });
}

/* ------------------------------- */

function viewTemplate(jsonPageObj, jsonResponseObj, othe_opt) {
    var i = 0;
    for (var key in jsonPageObj) {
        var element = elem(key);
        if (Array.isArray(jsonPageObj[key]) && element) {
            var arr = jsonPageObj[key];
            for (var j = 0; j < arr.length; j++) {
                renderElement(arr[j], element, jsonResponseObj, othe_opt);
            }
        }
        i++;
    }

    initRangeSliders();

    elem('content').innerHTML += '<div id="content-edit-button"></div>';

    if (typeof initWeatherBlock === 'function' && document.getElementById('weatherNowDisplay')) {
        initWeatherBlock();
    }
    if (typeof radioLoadAll === 'function' && document.getElementById('radio_stations_container')) {
        radioLoadAll();
    }
    if (elem('edit-content').classList.contains('show')) {
        activeDragDrop(true);
    }
}

function renderElement(obj, element, jr, othe_opt) {
    var action_val = renameGet(obj.action) || '';
    var socket_val = renameGet(obj.socket) || '';
    var actiondown_val = renameGet(obj.actiondown) || '';
    var name_val = obj.name || '';
    var class_val = obj.class ? renameBlock(jr, obj.class) || '' : '';
    var style_val = obj.style ? 'style="' + (renameBlock(jr, obj.style) || '') + '"' : '';
    var pattern_val = obj.pattern || '';
    var state_val = renameBlock(jr, obj.state, true) || '';
    var response_val = renameBlock(jr, obj.response) || '';
    var module_val = obj.module;
    var type_val = obj.type || 'none';

    var hidden = '';
    if (!obj.module || searchModule(jr.module, obj.module)) {
        hidden = 'fs-block ';
        if (othe_opt === 'loadJson')
            hidden = ' ';
    } else {
        hidden = 'fs-block hidden ';
        if (othe_opt === 'loadJson')
            hidden = 'hidden ';
    }

    if (type_val === 'div') {
        var divId = name_val || ('auto-div-' + Math.random().toString(36).slice(2));
        element.insertAdjacentHTML('beforeend', '<div id="' + divId + '" class="' + hidden + class_val + '" ' + style_val + '></div>');
        if (obj.content && Array.isArray(obj.content)) {
            var tempJson = {};
            tempJson[divId] = obj.content;
            viewTemplate(tempJson, jr, othe_opt);
        }
    } else if (type_val === 'hr') {
        element.innerHTML += '<hr id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '>';
    } else if (['h1', 'h2', 'h3', 'h4', 'h5', 'h6'].indexOf(type_val) !== -1) {
        element.innerHTML += '<' + type_val + ' id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '>' + renameBlock(jr, obj.title) + '</' + type_val + '>';
    } else if (type_val === 'none' || typeof type_val === 'undefined') {
        element.innerHTML += '<div id="' + name_val + '" class="' + hidden + '" ' + style_val + '>' + renameBlock(jr, obj.title) + '</div>';
    } else if (type_val === 'textarea') {
        if (action_val)
            action_val = 'onfocusout="send_request(this, \'' + (module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
        element.innerHTML += '<div class="' + hidden + '"><textarea ' + action_val + ' id="' + name_val + '" class="form-control ' + class_val + '" ' + style_val + ' ' + (pattern_val ? 'pattern="' + pattern_val + '"' : '') + ' placeholder="' + renameBlock(jr, obj.title) + '">' + state_val + '</textarea></div>';
    } else if (type_val === 'input') {
        if (action_val)
            action_val = 'onfocusout="send_request(this, \'' + (module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
        if (socket_val)
            action_val = 'onfocusout="send_socket(this, \'\', \'' + socket_val + '\')"';
        element.innerHTML += '<input ' + action_val + ' id="' + name_val + '" class="form-control ' + hidden + class_val + '" ' + style_val + ' ' + (pattern_val ? 'pattern="' + pattern_val + '"' : '') + ' placeholder="' + renameBlock(jr, obj.title) + '" value="' + state_val + '">';
    } else if (type_val === 'password') {
        if (action_val)
            action_val = 'onfocusout="send_request(this, \'' + (module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
        if (socket_val)
            action_val = 'onfocusout="send_socket(this, \'\', \'' + socket_val + '\')"';
        var inputId = name_val;
        var toggleId = name_val + '_toggle';
        var rawStyle = style_val.replace(/^style="|"$/g, '');
        element.innerHTML +=
        '<div class="password-wrapper" style="position:relative;display:inline-flex;align-items:center;' + rawStyle + '">' +
        '<input ' + action_val + ' id="' + inputId + '" class="form-control ' + hidden + class_val + '" style="width:100%;height:100%;background:transparent;border:none;color:inherit;padding-right:40px;font-size:inherit;text-align:center;font-weight:inherit" ' + (pattern_val ? 'pattern="' + pattern_val + '"' : '') + ' placeholder="' + renameBlock(jr, obj.title) + '" value="' + state_val + '" type="password">' +
        '<button type="button" onclick="togglePasswordVisibility(\'' + inputId + '\')" id="' + toggleId + '" class="password-toggle-btn" title="Показать / скрыть">' +
        '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
        '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>' +
        '</svg></button></div>';
    } else if (type_val === 'button') {
        if (action_val)
            action_val = 'onclick="send_request(this, \'' + (module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
        if (socket_val)
            action_val = 'onclick="send_socket(this, \'\', \'' + socket_val + '\')"';
        if (actiondown_val)
            actiondown_val = 'onmouseup="send_request(this, \'' + (module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
        element.innerHTML += '<input id="' + name_val + '" ' + action_val + ' ' + actiondown_val + ' class="' + hidden + class_val + '" ' + style_val + ' value="' + renameBlock(jr, obj.title) + '" type="button">';
    } else if (type_val === 'checkbox') {
        var checked = '';
        if (!obj.design) {
            if (state_val == 1)
                checked = 'checked';
            if (action_val) {
                action_val = 'onchange="val(this.id,(this.checked?\'1\':\'0\'));send_request(this, \'' + (module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
            } else {
                action_val = 'onchange="val(this.id,(this.checked?\'1\':\'0\'));"';
            }
            var isMultiMatrix = (obj.class || '').split(/\s+/).indexOf('multi_matrix_field') !== -1;
            var wrapperExtra = isMultiMatrix ? 'multi_matrix_wrap' : '';
            var inputClass = (obj.class || '').replace(/\bmulti_matrix_field\b/g, '').replace(/\s+/g, ' ').trim();
            element.innerHTML += '<label class="' + wrapperExtra + '" ' + style_val + '><input id="' + name_val + '" value="' + state_val + '" ' + action_val + ' type="checkbox" class="' + hidden + inputClass + '" ' + checked + '> ' + renameBlock(jr, obj.title) + '</label>';
        } else {
            if (state_val == 0)
                checked = 'checked=""';
            if (action_val) {
                action_val = 'onchange="val(this.id,(this.checked?\'0\':\'1\'));send_request(this, \'' + (module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
            } else {
                action_val = 'onchange="val(this.id,(this.checked?\'0\':\'1\'));"';
            }
            element.innerHTML += '<div class="toggle-button-cover" ' + style_val + '><div class="button-cover"><div class="button r ' + obj.design + '"><input type="checkbox" id="' + name_val + '" ' + action_val + ' class="checkbox" ' + checked + '><div class="knobs"></div><div class="layer"></div></div></div><label for="' + name_val + '">' + renameBlock(jr, obj.title) + '</label></div>';
        }
    } else if (type_val === 'range') {
        var onchange_attr = '';
        if (obj.action) {
            onchange_attr = 'onchange="send_request(this, renameGet(\'' + obj.action + '\'), \'' + response_val + '\')"';
        }
        var minAttr = (obj.min !== undefined && obj.min !== null) ? ' min="' + obj.min + '"' : '';
        var maxAttr = (obj.max !== undefined && obj.max !== null) ? ' max="' + obj.max + '"' : '';
        var stepAttr = (obj.step !== undefined && obj.step !== null) ? ' step="' + obj.step + '"' : '';
        var valueAttr = (state_val !== '' && state_val !== undefined && state_val !== null) ? ' value="' + state_val + '"' : '';
        element.innerHTML += '<div class="' + hidden + '"><label id="' + (name_val ? 'label-' + name_val : '') + '" ' + style_val + ' style="display:block;"><h4>' + renameBlock(jr, obj.title) + '</h4> <input id="' + name_val + '" class="form-control ' + class_val + '" ' + onchange_attr + ' ' + pattern_val + minAttr + maxAttr + stepAttr + valueAttr + ' type="range"></label></div>';
    } else if (type_val === 'table') {
        element.innerHTML += '<table class="' + hidden + class_val + '" ' + style_val + ' id="' + name_val + '"><thead id="thead-' + state_val.replace(/[^a-z0-9]/gi, '-') + '"><tr><td><center><span class="loader"></span>' + jr.LangLoading + '</center></td></tr></thead><tbody id="tbody-' + state_val.replace(/[^a-z0-9]/gi, '-') + '"></tbody></table>';
        loadTable(state_val, obj.title);
    } else if (type_val === 'select') {
        if (action_val)
            action_val = 'onchange="send_request(this, \'' + (module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
        if (socket_val)
            action_val = 'onchange="send_socket(this, \'\', \'' + socket_val + '\')"';
        var option = '';
        var jsonSelect = obj.title;
        if (jsonSelect && typeof jsonSelect === 'object' && Object.keys(jsonSelect).length > 0) {
            for (var key in jsonSelect) {
                option += '<option value="' + renameBlock(jr, key) + '"' + (state_val == key ? ' selected' : '') + '>' + renameBlock(jr, jsonSelect[key]) + '</option>';
            }
        } else if (jsonSelect && typeof jsonSelect === 'string' && jsonSelect.length > 0) {
            loadSelect(jsonSelect, name_val, state_val);
        }
        element.innerHTML += '<select class="form-control ' + hidden + class_val + '" ' + style_val + ' ' + action_val + ' id="' + name_val + '">' + option + '</select>';
    } else if (type_val === 'dropdown') {
        var option = '';
        var i2 = 0;
        var title1 = '';
        jsonSelect = obj.title;
        for (var key2 in jsonSelect) {
            if (i2 === 0)
                title1 += renameBlock(jr, jsonSelect[key2]);
            else
                option += '<li><a href="' + renameBlock(jr, key2) + '">' + renameBlock(jr, jsonSelect[key2]) + '</a></li>';
            i2++;
        }
        element.innerHTML += '<div class="' + hidden + ' btn-group"><a href="#" class="dropdown-toggle ' + class_val + '" ' + style_val + ' onclick="toggle(\'' + name_val + '\');return false">' + title1 + '</a><ul class="dropdown-menu hidden" id="' + name_val + '">' + option + '</ul></div>';
    } else if (type_val === 'configs') {
        var option = '<div id="' + name_val + '"><div id="' + state_val.replace(/[^a-z0-9]/gi, '-') + '" class="' + class_val + '" ' + style_val + '><center><span class="loader"></span>' + jr.LangLoading + '</center></div></div>';
        option += '<div class="btn-group btn-block"><input style="width:85%" onclick="changeTextarea(\'' + state_val.replace(/[^a-z0-9]/gi, '-') + '\');send_request_edit(this, val(\'' + state_val.replace(/[^a-z0-9]/gi, '-') + '-edit\'),\'configs/' + state_val + '\',\'if(confirm(\\\'' + jr.LangReset2 + ' ' + jr.LangReset3 + '\\\')){send_request(this,\\\'/restart?device=ok\\\');toggle(\\\'restart-esp\\\');setTimeout(function(){toggle(\\\'restart-esp\\\');},20000);};\');" class="btn btn-block btn-success" value="' + jr.LangSave + '" type="button">';
        option += '<a href="#" style="width:15%" class="btn btn-info dropdown-toggle" onclick="toggle(\'cloud\');return false"><i class="cloud-img"></i> <span class="caret"></span></a>';
        option += '<ul class="dropdown-menu hidden" style="right:0;left:auto" id="cloud"><li><a onclick="toggle(\'cloud\');cloudUpload(\'' + jr.mac + '\',\'' + jr.configs + '\');return false" href="#"><i class="cloud-img"></i> ' + jr.LangCloudUpload + '</a></li><li><a onclick="toggle(\'cloud\');cloudDownload(\'' + jr.mac + '\',\'' + jr.configs + '.txt\');return false" href="#"><i class="cloud-img"></i> ' + jr.LangCloudDownload + '</a></li><li><a href="/configs/' + jr.configs + '.txt?download=true" download=""><i class="download-img"></i> ' + jr.LangCloudPC + '</a></li></ul>';
        option += '</div>';
        element.innerHTML += '<div class="' + hidden + '">' + option + '</div>';
        setTimeout("loadConfigs('" + state_val + "',jsonResponse)", 500);
    } else if (type_val === 'link') {
        element.innerHTML += '<a id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + ' href="' + renameGet(obj.action) + '">' + renameBlock(jr, obj.title) + '</a>';
    } else if (type_val === 'img') {
        element.innerHTML += '<img id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + ' src="' + renameGet(obj.state) + '" onclick="' + renameGet(obj.action) + '" title="' + renameBlock(jr, obj.title) + '"/>';
    } else if (type_val === 'text') {
        element.innerHTML += '<div id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '>' + renameBlock(jr, obj.title) + '</div>';
    } else if (type_val === 'iframe') {
        element.innerHTML += renameBlock(jr, obj.title) + '<iframe src="' + state_val + '" id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '></iframe>';
    } else if (type_val === 'chart') {
        element.innerHTML += '<div id="' + name_val + '" class="' + hidden + ' ' + renameBlock(jr, '{{' + state_val.replace(/[^a-z0-9]/gi, '') + '-hidden}}') + '"><button class="close" onclick="hide(\'' + state_val.replace(/[^a-z0-9]/gi, '') + '-hidden\',this)">×</button><a href="' + renameGet(obj.action) + '" target="_blank" class="close">' + (typeof action_val !== 'undefined' && action_val ? '<i class="popup-img"></i>' : '') + '</a><h2><span id="' + state_val.replace(/[^a-z0-9]/gi, '') + '-title">' + renameBlock(jr, obj.title) + '</span> <span id="' + state_val.replace(/[^a-z0-9]/gi, '') + '-data"></span></h2><div id="' + state_val.replace(/[^a-z0-9]/gi, '') + '" class="' + class_val + '" ' + style_val + '></div><hr></div>';
        if (renameBlock(jr, '{{' + state_val.replace(/[^a-z0-9]/gi, '') + '-hidden}}') !== 'hidden') {
            setTimeout("loadChart('" + state_val.replace(/[^a-z0-9]/gi, '') + "','" + state_val + "', {" + obj.options + "}," + obj.refresh + "," + obj.points + ",'" + obj.chartist + "')", 1500);
        }
    } else if (type_val === 'loadJson') {
        element.innerHTML += '<div id="json-' + state_val.replace(/[^a-z0-9]/gi, '-') + '" class="' + hidden + class_val + '" ' + style_val + '><center><span class="loader"></span>' + jr.LangLoading + '</center></div>';
        loadJson(state_val, obj.refresh, jr);
    } else if (type_val === 'file') {
        var set_action = '';
        if (obj.action != undefined)
            set_action = ",'send_request(this,\\'" + obj.action + "\\')";
        element.innerHTML += '<div class="' + hidden + '"><textarea ' + style_val + ' id="file-' + state_val.replace(/[^a-z0-9]/gi, '-') + '">' + jr.LangLoading + '</textarea><input class="' + class_val + '" onclick="send_request_edit(this, val(\'file-' + state_val.replace(/[^a-z0-9]/gi, '-') + '\'),\'/' + state_val + '\' ' + set_action + ');" value="' + renameBlock(jr, obj.title) + '" type="button"></div>';
        loadFile(state_val);
    } else if (type_val === 'csv') {
        var set_action = '';
        if (obj.action != undefined)
            set_action = ",'send_request(this,\\'" + obj.action + "\\')";
        element.innerHTML += '<div class="' + hidden + '"><table id="table-csv-' + state_val.replace(/[^a-z0-9]/gi, '-') + '" ' + style_val + '></table><textarea style="display:none" id="csv-' + state_val.replace(/[^a-z0-9]/gi, '-') + '"></textarea><input class="' + class_val + '" onclick="html_to_csv(\'csv-' + state_val.replace(/[^a-z0-9]/gi, '-') + '\');send_request_edit(this, val(\'csv-' + state_val.replace(/[^a-z0-9]/gi, '-') + '\'),\'/' + state_val + '\' ' + set_action + ');" value="Save" type="button"></div>';
        loadCSV(state_val, obj.title);
    } else if (type_val === 'time-list') {
        element.innerHTML += '<table class="' + hidden + class_val + '" ' + style_val + ' id="' + name_val + '"><tbody id="time-list"></tbody></table>';
        loadTime(jr);
    } else if (type_val === 'time-add') {
        var template = function (x, y, i, z) {
            return ' <label class="label label-' + x + '"><input type="checkbox" name="day-' + y + '" id="day-' + i + '" checked>' + jr['Lang' + z] + '</label> ';
        };
        var option = '<input type="hidden" id="hidden-val-then" value="1"><div id="new-then"></div> <h4>';
        option += template('danger', 'sun', '0', 'Sun');
        option += template('info', 'mon', '1', 'Mon');
        option += template('info', 'tue', '2', 'Tue');
        option += template('info', 'wed', '3', 'Wed');
        option += template('info', 'thu', '4', 'Thu');
        option += template('info', 'fri', '5', 'Fri');
        option += template('danger', 'sat', '6', 'Sat');
        option += ' <label class="label label-default"><input type="checkbox" onchange="toggleCheckbox(this)" checked>' + jr.LangAll + '</label><br>';
        option += ' <label class="label label-default"><input type="checkbox" name="run1" id="run-1">' + jr.LangRun1 + '</label></h4>';
        option += '<input id="set-time" class="form-control" pattern="(0[0-9]|1[0-9]|2[0-3])(:[0-5][0-9]){2}" placeholder="' + jr.LangTime4 + '. ' + jr.LangExample + ': 07:09:30" value="" style="width:90%;display:inline"><a href="#" class="btn btn-default" style="width:10%;" onclick="val(\'set-time\',\'Loading...\');ajax.get(\'/config.live.json\',{},function(response){var jsonFiles=JSON.parse(response);val(\'set-time\',jsonFiles[\'time\']);},true);return false"><i class="clock-img"></i></a>';
        option += '<input class="btn btn-block btn-lg btn-success" onclick="addTimer();" value="' + jr.LangSave + '" type="button">';
        element.innerHTML += '<div class="' + hidden + '">' + option + '</div>';
        loadNewThen('new-then', ' ');
        html('load-life-opt', 'onclick');
    } else if (type_val === 'scenary-list') {
        element.innerHTML += '<table class="' + hidden + class_val + '" ' + style_val + ' id="' + name_val + '"><tbody id="scenary-list"></tbody></table>';
        loadScenary(jr, 'loadList');
    } else if (type_val === 'scenary-add') {
        var option = '<select class="form-control" id="ssdp-list0" onchange="loadScenaryList(0,\'loadInTextarea\',this.options[this.selectedIndex].value);loadLive(this.value,\'config.live.json\',\'ssdp-module\');toggle(\'ssdp-module\',\'hidden\');"></select>';
        option += '<select class="form-control hidden" id="ssdp-module" onchange="pattern(this.querySelector(\':checked\').getAttribute(\'title\'),\'ssdp-command\');toggle(\'hidden-if\',\'hidden\');toggle(\'or-and\',\'hidden\');"></select>';
        option += '<span class="hidden" id="hidden-if"><select class="form-control" id="ssdp-condition" style="width:50%;display:inline"><option value="=">' + jr.LangEqual + ' (=)</option><option value="<">' + jr.LangLess + ' (<)</option><option value=">">' + jr.LangMore + ' (>)</option><option value="<=" disabled>' + jr.LangLess + ' ' + jr.LangOr + ' ' + jr.LangEqual + ' (<=) ' + jr.LangSoon + '</option><option value=">=" disabled>' + jr.LangMore + ' ' + jr.LangOr + ' ' + jr.LangEqual + ' (>=) ' + jr.LangSoon + '</option><option value="!=">' + jr.LangNotEqual + ' (!=)</option></select>';
        option += '<input class="form-control" id="ssdp-command" pattern="" style="width:40%;display:inline" value=""><a href="#" id="load-life-opt" class="btn btn-default" style="width:10%;" onclick="loadLive2(\'ssdp-list0\',\'ssdp-module\',\'ssdp-command\');return false"><i class="find-replace-img"></i></a></span>';
        option += '<textarea id="scenary-list-edit" style="display:none" class="form-control"></textarea>';
        option += '<input type="hidden" id="hidden-val-and" value="1"><input type="hidden" id="hidden-val-or" value="1"><div id="new-and-or"></div>';
        option += '<div class="btn-group hidden" id="or-and" style="width:100%;"><input onclick="loadNewAnd(\'new-and-or\');" class="btn btn-sm btn-default" style="width:50%;" value="+ ' + jr.LangAnd + '" type="button">';
        option += '<input onclick="loadNewOr(\'new-and-or\');" class="btn btn-sm btn-default" style="width:50%;" value="+ ' + jr.LangOr + '" type="button"></div>';
        option += '<input type="hidden" id="hidden-val-then" value="1"><div id="new-then"></div>';
        option += '<input onclick="loadNewThen(\'new-then\');" class="btn btn-sm btn-block btn-default" value="+ ' + jr.LangThen + '" type="button">';
        option += '<input onclick="saveScenary(jsonResponse,\'\')" class="btn btn-block btn-lg btn-success" value="' + jr.LangSave + '" type="button">';
        element.innerHTML += '<div class="' + hidden + '"><h3>' + jr.LangIf + '</h3> ' + option + '</div>';
        loadScenary(jr);
        html('load-life-opt', 'onclick');
    } else if (type_val === 'scenary-test') {
        var option = '<select class="form-control" id="ssdp-list2" style="display:none"><option value="' + location.host + '">-</option></select>';
        option += '<input type="hidden" id="hidden-val-then" value="1"><div id="new-then"></div>';
        option += '<select class="form-control hidden" id="scenary-then2" style="width:50%;" onchange="loadCommandHelp(this.value,\'command-help2\',\'scenary-othe2\');toggle(\'if-then2\',\'hidden\');"><option value=""></option></select>';
        option += '<div id="if-then2" class="hidden"><div id="command-help2" class="alert alert-warning"></div><a href="#" id="scenary-othe-play2" class="btn btn-default" style="width:10%;float:right;" onclick="send_request(this, \'http://\'+elem(\'ssdp-list2\').options[elem(\'ssdp-list2\').selectedIndex].value+\'/cmd?command=\'+elem(\'scenary-then2\').options[elem(\'scenary-then2\').selectedIndex].value+\' \'+elem(\'scenary-othe2\').value.replace(/&/g,\'%26\'),\'\');return false" title="' + jr.LangRun + '"><i class="eye-img"></i></a><input class="form-control" style="width:90%" placeholder="Действие" id="scenary-othe2" type="text"></div>';
        element.innerHTML += '<div class="' + hidden + '"><h4 style="float:left;">Module:</h4> ' + option + '</div>';
        setTimeout("loadCommand('" + location.host + "','command.json','scenary-then2');toggle('scenary-then2','hidden');", 500);
    } else if (type_val === 'macros') {
        element.innerHTML += '<div class="' + hidden + class_val + '" ' + style_val + ' id="' + (name_val ? name_val : 'loadMacros') + '"></div>';
        loadMacros(jr, (name_val ? name_val : 'loadMacros'));
    } else if (type_val === 'login') {
        var option = '<h2>' + jr.Авторизация + '</h2><div class="alert alert-warning" >' + renameBlock(jr, obj.title) + '</div>';
        option += '<input id="passLogin" class="form-control" placeholder="Password" value="" onfocus="this.type=\'text\'" type="password">';
        option += '<a class="btn btn-block btn-success" href="#" onclick="if(\'' + state_val + '\'==val(\'passLogin\')){sessionStorage.setItem(\'sossionLogin\', \'hidden\');toggle(\'loginForm\');}else{alert(\'The password is incorrect\')}">' + jr.Авторизация + '</a>';
        element.innerHTML += '<div id="loginForm" class="' + hidden + ' ' + jr.sossionLogin + '" style="background-color:#fff;position:fixed;top:0;left:0;right:0;bottom:0;z-index:9999;padding:10% 30%;">' + option + '</div>';
    } else if (type_val === 'wifi') {
        element.innerHTML += '<div class="' + hidden + ' btn-group btn-block" id="ssid-group"><a href="#" class="btn btn-default btn-block dropdown-toggle" onclick="toggle(\'ssid-select\');loadWifi(\'ssid-select\',\'' + name_val + '\');return false"><span id="ssid-name">' + state_val + '</span> <span class="caret"></span></a><ul class="dropdown-menu hidden" id="ssid-select"><li><a href="#">' + jr.LangLoading + '</a></li></ul></div>';
        element.innerHTML += '<input id="' + name_val + '" value="' + state_val + '" class="form-control hidden ' + class_val + '" ' + style_val + ' ' + pattern_val + ' placeholder="' + renameBlock(jr, obj.title) + '">';
    } else if (type_val === 'time' && typeof jr.time !== 'undefined') {
        element.innerHTML += '<div id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '><strong id="timeDisplay">' + state_val + '</strong></div><div id="dateDisplay" style="text-align:center;color:#adadad;font-size:16px;margin-bottom:20px"></div>';
        updateTimeBlock();
        managedSetInterval('time-block-' + name_val, updateTimeBlock, 1000);
    } else if (type_val === 'weather') {
        element.innerHTML += '<div id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '><h4>' + renameBlock(jr, obj.title) + '</h4><strong id="weatherNowDisplay">--°C</strong></div>';
    } else if (type_val === 'rgb') {
        element.innerHTML += '<div class="' + hidden + ' ' + name_val + '-thumb ' + class_val + '"><div class="' + name_val + '-preview"></div><img alt="" ' + style_val + ' src="' + renameBlock(jr, obj.title) + '"></div><canvas id="' + name_val + '-cs" style="display:none"></canvas>';
        element.innerHTML += '<input id="' + name_val + '" value="' + state_val + '" class="form-control hidden">';
        setTimeout("createRGB('" + name_val + "', '" + obj.action + "','" + module_val + "','" + response_val + "')", 500);
    } else if (type_val === 'issues') {
        element.innerHTML += '<div id="issues-list" class="' + hidden + class_val + '" ' + style_val + '><center><span class="loader"></span>' + jr.LangLoading + '</center></div>';
        setTimeout("loadIssues('tretyakovsa/Sonoff_WiFi_switch'," + state_val + ');', 1500);
    } else if (type_val === 'commits') {
        element.innerHTML += '<div id="commits-list" class="' + hidden + class_val + '" ' + style_val + '><center><span class="loader"></span>' + jr.LangLoading + '</center></div>';
        setTimeout("loadCommits('tretyakovsa/Sonoff_WiFi_switch'," + state_val + ');', 1500);
    } else if (type_val === 'dev') {
        renderDevBlock(element, obj, jr, name_val, class_val, style_val, hidden, state_val);
    }
}

function updateTimeBlock() {
    fetch('/get_time')
    .then(function (r) {
        return r.json();
    })
    .then(function (d) {
        var timeStr = d.time || '--:--:--';
        var city = d.city || '';
        var dateStr = d.date || '';
        var displayElem = document.getElementById('timeDisplay');
        var dateElem = document.getElementById('dateDisplay');
        if (displayElem) {
            displayElem.innerHTML = (city && city.length > 0) ? (city + ': ' + timeStr) : timeStr;
        }
        if (dateElem && dateStr)
            dateElem.innerHTML = dateStr;
    })
    .catch(function () {
        var displayElem = document.getElementById('timeDisplay');
        if (displayElem)
            displayElem.innerHTML = '--:--:--';
    });
}

function renderDevBlock(element, obj, jr, name_val, class_val, style_val, hidden, state_val) {
    var option = '<div id="' + name_val + '" class="' + class_val + '" ' + style_val + '><a href="/help.htm" target="_blank" class="close"><i class="help-img"></i></a>' + renameBlock(jr, obj.title) + '<span id="dev-update" class="hidden"><a href="/edit" class="btn btn-primary" target="_blank">File manager</a> <a href="/page.htm?starting" class="btn btn-primary">Starting log</a> <a href="/page.htm?debug" class="btn btn-primary">Debug</a> ';
    if (searchModule(jr.module, 'upgrade')) {
        option += ' <div class="btn-group"><a href="#" class="btn btn-danger dropdown-toggle" onclick="toggle(\'repos-all\');loadBuild(\'sonoff\',\'all\',\'' + state_val + '\');return false">Upgrade <span class="caret"></span></a><ul class="dropdown-menu hidden" id="repos-all" style="min-width:350px"><li><a href="https://github.com/tretyakovsa/Sonoff_WiFi_switch/commits/master" style="text-align:right" target="_blank"><i class="help-img"></i> Github code history</a><ul id="sonoff-all" style="margin-right:20px"><li><a href="#">' + jr.LangLoading + '</a></li></ul></li></ul></div>';
    }
    option += '<br><br>';
    option += jr.LangType + ': <div class="btn-group"><select class="btn btn-default btn-sx" onchange="send_request(this, \'/configs?set=\'+this.value,\'[[configs-edit-button]]\')"><option value="' + jr.configs + '">' + jr.configs + '</option><option value="sonoff-rf">Sonoff-rf / Sonoff TH16 / Wi-Fi Smart Socket</option><option value="sonoff-pow">Sonoff-Pow (' + jr.LangSoon + ')</option><option value="rgb">RGB (WS2811/WS2812/NeoPixel LEDs)</option><option value="rgb-shim">RGB SHIM (5050/3528/2835)</option><option value="jalousie">Jalousie</option><option value="smart-room">Smart-Room</option><option value="wifi-relay-5v">WiFi Relay 5v</option><option value="manually">Manually</option></select> <a href="/page.htm?configs&' + jr.configs.toLowerCase() + '" id="configs-edit-button" class="btn btn-primary"><i class="opt-img"></i></a></div><hr>';
    option += '<form method="POST" action="/update" enctype="multipart/form-data"><div class="btn-group"><input type="file" class="btn btn-primary btn-xs" name="update" style="height:33px" accept=".bin"><input type="submit" class="btn btn-default btn-sm" value="Update build" onclick="this.value=\'' + jr.LangLoading + '\';" style="height:33px"></div></form>';
    option += '</span></div>';
    element.innerHTML += '<div class="' + hidden + '">' + option + '</div>';
}

/* ------------------------------- */

function loadJson(file, setDelay, jr) {
    function setLoad() {
        ajax.get(file + '?' + Math.random(), {}, function (response) {
            html('json-' + file.replace(/[^a-z0-9]/gi, '-'), ' ');
            var jsonPage2 = JSON.parse(response);
            viewTemplate(jsonPage2, jr, 'loadJson');
        }, true);
    }
    if (!isNaN(setDelay)) {
        managedSetInterval('loadJson-' + file, setLoad, setDelay);
    } else {
        setLoad();
    }
}

function loadSelect(file, name_val, state_val) {
    ajax.get(file + '?' + Math.random(), {}, function (response) {
        var result = JSON.parse(response);
        var option = '';
        for (var key in result) {
            option += '<option value="' + renameBlock(jsonResponse, key) + '"' + (state_val == key ? ' selected' : '') + '>' + renameBlock(jsonResponse, result[key]) + '</option>';
        }
        elem(name_val).innerHTML = option;
    }, true);
}

function loadFile(file) {
    ajax.get(file + '?' + Math.random(), {}, function (response) {
        val('file-' + file.replace(/[^a-z0-9]/gi, '-'), response);
    }, true);
}

function loadCSV(file, title) {
    ajax.get(file + '?' + Math.random(), {}, function (response) {
        var tbody = '';
        var table_tr = response.replace(/\r\n|\n\r|\n|\r/g, '\n').split('\n');
        for (var i = 0; i < table_tr.length; i++) {
            var table_td = table_tr[i].split(';');
            tbody += '<tr>';
            for (var y = 0; y < table_td.length; y++) {
                if (i === 0) {
                    tbody += '<th>' + table_td[y] + '</th>';
                } else if (title[y]) {
                    if (title[y] === 'html') {
                        tbody += '<td>' + table_td[y] + '</td>';
                    } else if (title[y] === 'del') {
                        tbody += '<td><input class="btn btn-danger" type="button" value="' + table_td[y] + '" onclick="location.href=\'/del?file=' + file + '&line=' + i + '\'"></td>';
                    } else if (title[y].split(':')[0] === 'select') {
                        tbody += '<td><select class="form-control" id="csv-select-' + i + '"></select></td>';
                        loadSelect(title[y].split(':')[1], 'csv-select-' + i, table_td[y]);
                    } else {
                        tbody += '<td><input class="form-control" type="' + title[y] + '" value="' + table_td[y] + '" ' + (title[y] === 'checkbox' ? 'onclick="(this.checked?this.value=1:this.value=0)"' : '') + ' ' + (title[y] === 'checkbox' && table_td[y] == 1 ? 'checked' : '') + '></td>';
                    }
                }
            }
            tbody += '</tr>';
        }
        document.getElementById('table-csv-' + file.replace(/[^a-z0-9]/gi, '-')).innerHTML = '' + tbody + '';
    }, true);
}

function html_to_csv(file) {
    var csv = [];
    var fixed = '';
    var rows = document.querySelectorAll('[id^="table-' + file + '"] tr');
    for (var i = 0; i < rows.length; i++) {
        var row = [],
        cols = rows[i].querySelectorAll('td, th, input, select');
        for (var j = 0; j < cols.length; j++) {
            if (typeof cols[j].value !== 'undefined')
                fixed = cols[j].value;
            else
                fixed = cols[j].innerHTML;
            if (fixed.indexOf('<input') === -1) {
                if (cols[j].innerHTML.indexOf('select') === 1) {
                    row.push(cols[j + 1].value);
                    j++;
                } else {
                    row.push(fixed);
                }
            }
        }
        csv.push(row.join(';'));
    }
    val(file, csv.join('\r\n'));
}

function loadTable(file, jsonTable) {
    ajax.get(file + '?' + Math.random(), {}, function (response) {
        var timers = JSON.parse(response);
        var setTable = Object.keys(timers);
        html('thead-' + file.replace(/[^a-z0-9]/gi, '-'), ' ');
        html('tbody-' + file.replace(/[^a-z0-9]/gi, '-'), ' ');
        var thead = '';
        for (var key in jsonTable)
            thead += '<th>' + renameBlock(jsonResponse, jsonTable[key]) + '</th>';
        elem('thead-' + file.replace(/[^a-z0-9]/gi, '-')).innerHTML += thead;
        for (var i = 0; i < timers[setTable].length; i++) {
            var tbody = '';
            for (var keys in jsonTable)
                tbody += '<td>' + timers[setTable][i][keys] + '</td>';
            elem('tbody-' + file.replace(/[^a-z0-9]/gi, '-')).innerHTML += '<tr>' + tbody + '</tr>';
        }
    }, true);
}

/* ------------------------------- */

var set_real_time;

function setContent(stage, load_page) {
    return new Promise(function (resolve, reject) {
        jsonResponse = '';

        var loaderBg = document.querySelector('.container.loader-bg');
        var loaderWave = document.querySelector('.loader-wave');
        if (loaderBg)
            loaderBg.classList.add('loading');
        if (loaderWave)
            loaderWave.style.display = 'flex';

        var pages = window.location.search.substring(1).split('&');
        if (load_page)
            pages[0] = load_page;
        pages[0] = (pages[0] ? pages[0] : 'index');
        var parts = pages[0].split('.');
        if (parts.length > 1)
            pages[0] = parts[0];

        var jsonFile = pages[0];
        if (jsonFile === 'index')
            jsonFile = 'index.setup';

        ajax.get(jsonFile + '.json?' + Math.random(), {}, function (response) {
            elem('download-json').href = pages[0] + '.json';

            if (response !== 'FileNotFound') {
                try {
                    jsonPage = JSON.parse(response);
                } catch (e) {
                    console.error('JSON.parse failed for ' + jsonFile + '.json:', e, 'responseLength:', (response || '').length, 'head:', (response || '').substring(0, 100));
                    elem('content').innerHTML = '<br><br><h1>Ошибка разбора "' + pages[0] + '.json"</h1><hr><h2>' + (e.message || 'JSON parse error') + '</h2><pre style="color:#ff8888;white-space:pre-wrap">' + (response || '').substring(0, 500) + '</pre>';
                    hideLoader();
                    resolve();
                    return;
                }
                state.jsonPage = jsonPage;
                var jsonEdit = response;

                if (jsonPage.configs) {
                    loadConfigsSequentially(jsonPage.configs, 0, stage, pages, jsonEdit, resolve);
                } else {
                    elem('content').innerHTML = '<br><br><h1>File "' + pages[0] + '.json" cannot view.<\/h1><hr><h2>Please add configs array.<br>Example: "configs":["/config.live.json"]<br>You can edit this file on right side of this page.</h2>';
                    val('edit-json', jsonEdit);
                    toggle('container_column', 'hide');
                    toggle('edit-content');
                    toggle('url-content');
                    hideLoader();
                    resolve();
                }
            } else {
                elem('content').innerHTML += '<br><br><h1>Files "' + pages[0] + '.json" not found.</h1><hr><h2>Maybe you want to open some file of these:</h2><h3 id="file-list"><span class="loader"></span>Loading...</h3>';
                toggle('container_column', 'hide');
                ajax.get('/list?dir=/', {}, function (response) {
                    html('file-list', ' ');
                    var jsonFiles = JSON.parse(response);
                    jsonFiles.sort(function (a, b) {
                        return (a.name < b.name) ? 1 : ((b.name < a.name) ? -1 : 0);
                    });
                    for (var i = 0; i < jsonFiles.length; i++) {
                        if (jsonFiles[i].name.substr(-4) === 'json' || jsonFiles[i].name.substr(-7) === 'json.gz') {
                            elem('file-list').innerHTML += '<a href="/' + (location.pathname === 'index.htm' ? 'index' : 'page') + '.htm?' + jsonFiles[i].name.split('.')[0] + '">' + jsonFiles[i].name + '</a><br>';
                        }
                    }
                    hideLoader();
                    resolve();
                }, true);
            }
        }, true);
    });
}

function loadConfigsSequentially(configs, index, stage, pages, jsonEdit, resolve) {
    if (index >= configs.length) {
        finalizePage(stage, pages, jsonEdit);
        resolve();
        return;
    }

    jsonPage.configs[index] = renameBlock(jsonResponse, jsonPage.configs[index]);

    ajax.get(jsonPage.configs[index], {}, function (configResponse) {
        if (configResponse !== 'FileNotFound') {
            try {
                var jsonResponseNew = JSON.parse(configResponse);
                jsonResponse = mergeObject(jsonResponseNew, jsonResponse || {});
                log('<li><span class="label label-warning">GET</span> <a href="' + jsonPage.configs[index] + '" class="btn btn-link" style="text-transform:none;text-align:left;white-space:normal;display:inline" target="_blank">' + jsonPage.configs[index] + '</a> <span class="label label-default">200 OK</span></li>');
            } catch (e) {
                console.error('JSON.parse FAILED for config:', jsonPage.configs[index], 'error:', e.message, 'responseLength:', (configResponse || '').length, 'head:', (configResponse || '').substring(0, 100));
                log('<li><span class="label label-warning">GET</span> <a href="' + jsonPage.configs[index] + '" class="btn btn-link" style="text-transform:none;text-align:left;white-space:normal;display:inline" target="_blank">' + jsonPage.configs[index] + '</a> <span class="label label-danger">Parse Error: ' + e.message + '</span></li>');
            }
        } else {
            if (jsonPage.configs[index].indexOf('socket ') >= 0) {
                if (stage === 'first')
                    run_socket(jsonPage.configs[index]);
                log('<li><span class="label label-warning">WS</span> <a href="' + jsonPage.configs[index] + '" class="btn btn-link" style="text-transform:none;text-align:left;white-space:normal;display:inline" target="_blank">' + jsonPage.configs[index] + '</a> <span class="label label-default">Connected</span></li>');
            } else {
                log('<li><span class="label label-warning">GET</span> <a href="' + jsonPage.configs[index] + '" class="btn btn-link" style="text-transform:none;text-align:left;white-space:normal;display:inline" target="_blank">' + jsonPage.configs[index] + '</a> <span class="label label-danger">File Not Found</span></li>');
            }
        }
        loadConfigsSequentially(configs, index + 1, stage, pages, jsonEdit, resolve);
    });
}

function finalizePage(stage, pages, jsonEdit) {
    for (var y = 0; y < pages.length; y++) {
        jsonResponse['urlArray' + y] = pages[y];
    }
    jsonResponse.urlArray = window.location.search.substring(1);

    var theCookies = document.cookie.split(';');
    for (var y2 = 1; y2 <= theCookies.length; y2++) {
        jsonResponse[theCookies[y2 - 1].split('=')[0].replace(/^ /, '')] = theCookies[y2 - 1].split('=')[1];
    }
    jsonResponse.sossionLogin = sessionStorage.getItem(STORAGE_KEYS.SESSION_LOGIN);

    var element_title = elem('title');
    if (element_title)
        element_title.innerHTML = '';

    if (jsonPage.class)
        elem('content').className = jsonPage.class;
    if (jsonPage.style)
        elem('content').style = jsonPage.style;

    if (jsonPage.reload) {
        set_real_time = setTimeout(function () {
            setContent('edit');
        }, jsonPage.reload);
    }

    if (stage === 'first') {
        val('edit-json', jsonEdit);
        toggle('container_column', 'hide');
        syncClientTime();
    } else {
        elem('content').innerHTML = '';
        jsonPage = JSON.parse(val('edit-json'));
        state.jsonPage = jsonPage;
    }
    val('edit-view', 'view');

    if (jsonPage.content) {
        viewTemplate(jsonPage, jsonResponse);

        html('edit-save', 'onclick');

        setTimeout(function () {
            var nightBtn = document.querySelector('.night-clock-off, .night-clock-on');
            if (nightBtn) {
                var nstate = nightBtn.getAttribute('data-state') || '0';
                if (jsonResponse.night_clock_enabled !== undefined)
                    nstate = jsonResponse.night_clock_enabled;
                updateNightClockButton(nstate);
            }
            if (jsonResponse.use_animations == '1') {
                loadAnimationsList();
                updateAnimBlock();
                if (jsonResponse.anim_sel && jsonResponse.anim_sel !== '0' && jsonResponse.eff_sel === '0') {
                    fetch('/set_anim?anim=' + jsonResponse.anim_sel);
                }
            } else {
                var animSel = document.getElementById('anim_sel');
                if (animSel)
                    animSel.style.display = 'none';
            }
            var tzSelect = document.getElementById('tz_select');
            if (tzSelect) {
                var newSelect = tzSelect.cloneNode(true);
                tzSelect.parentNode.replaceChild(newSelect, tzSelect);
                newSelect.addEventListener('change', function () {
                    var input = document.getElementById('custom_tz_input');
                    if (input) {
                        if (this.value === 'CUSTOM') {
                            input.style.display = 'block';
                            input.focus();
                        } else {
                            input.style.display = 'none';
                        }
                    }
                });
                var input2 = document.getElementById('custom_tz_input');
                if (input2) {
                    if (newSelect.value === 'CUSTOM')
                        input2.style.display = 'block';
                    else
                        input2.style.display = 'none';
                }
            }
            initAllTooltips();
            initBrightnessSliders();
        }, 200);

        setTimeout(function () {
            document.querySelectorAll('input.range-pending').forEach(function (el) {
                el.classList.remove('range-pending');
            });
        }, 700);
    } else {
        log('<li class="alert alert-danger" style="margin:5px 0;">content array not found in "' + pages[0] + '.json"<\/li>');
        elem('content').innerHTML += '<br><br><h1>File "' + pages[0] + '.json" cannot view.<\/h1><hr><h2>You can edit it right.<\/h2>';
        toggle('edit-content');
        toggle('url-content');
    }
    setTimeout(loadModuleStates, 100);
    hideLoader();
}
