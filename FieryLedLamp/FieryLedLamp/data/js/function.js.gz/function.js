var ajax = {};

ajax.x = function() {
    var xhr;
    if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
    } else {
        xhr = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xhr.timeout = 5000;
    return xhr;
};

ajax.send = function(url, callback, method, data, async) {
    if (method != 'PUT') {
        submit_disabled(true);
    }
    if (async === undefined) {
        async = true;
    }
    var x = ajax.x();
    x.open((method == 'PUT' ? 'GET' : '' + method + ''), url, async);
    x.onreadystatechange = function() {
        if (x.readyState == 4) {
            if (method != 'PUT') {
                submit_disabled(false);
            }
            callback(x.responseText);
        }
    };

    x.ontimeout = function() {
        if (method != 'PUT') {
            submit_disabled(false);
        }
        console.log('Request timeout: ' + url);
    };
    x.onerror = function() {
        if (method != 'PUT') {
            submit_disabled(false);
        }
        console.log('Request error: ' + url);
    };
    if (method == 'POST') {
        x.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    }
    x.send(data);
};

ajax.get = function(url, data, callback, async) {
    console.log("Запрос к URL:", url);
    var query = [];
    for (var key in data) {
        query.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
    }
    ajax.send(url + (query.length ? '?' + query.join('&') : ''), callback, 'GET', null, async);
};

ajax.put = function(url, data, callback, async) {
    var query = [];
    for (var key in data) {
        query.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
    }
    ajax.send(url + (query.length ? '?' + query.join('&') : ''), callback, 'PUT', null, async)
};

ajax.post = function(url, data, callback, async) {
    var query = [];
    for (var key in data) {
        query.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
    }
    ajax.send(url, callback, 'POST', query.join('&'), async)
};

var xmlHttp = createXmlHttpObject();

function createXmlHttpObject() {
    if (window.XMLHttpRequest) {
        xmlHttp = new XMLHttpRequest();
    } else {
        xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
    }
    return xmlHttp;
}

var set_real_time;
var active = 'egiste';
var jsonPage;
var jsonResponse;
let dragSrcEl = null;
let patterns = null;

document.onkeydown = function(e) {
    var evtobj = window.event ? event : e
    var element = elem('edit-content');
    var charCode = String.fromCharCode(evtobj.which).toLowerCase();
    if (charCode === 'e' && evtobj.ctrlKey && element) {
        window.open('/edit', '_blank');
    }
    if (charCode === 'm' && evtobj.ctrlKey && element) {
        toggle('edit-content');
        toggle('url-content');
        activeDragDrop(true);
    }
    if (charCode === 's' && evtobj.ctrlKey && element) {
        evtobj.preventDefault();
        send_request_edit(this, val('edit-json'), window.location.search.substring(1).split("&")[0] + '.json');
        toggle('edit-content');
        toggle('url-content');
        activeDragDrop(true);
    }
}

function activeDragDrop(status) {
    elem('content-edit-button').innerHTML = '<input class="btn btn-block btn-default" onclick="toggle(\'new-element\');" value="Add new element" type="button">';
    patterns = jsonPage.content.slice(0);
    let cols = document.querySelectorAll("#content .fs-block");
    cols.forEach(addDnDHandlers);
    document.querySelectorAll('#content .fs-block').forEach((el) => {
        el.setAttribute('draggable', status);
    });
}

function create_new_element(status) {
    var new_element = {};
    new_element['type'] = elem('new-element-type').options[elem('new-element-type').selectedIndex].innerHTML;
    if (new_element['type'] != 'Create new page') {

        if (elem('new-element-title').value != '') {
            new_element['title'] = elem('new-element-title').value;
        }
        if (elem('new-element-state').value != '') {
            new_element['state'] = elem('new-element-state').value;
        }
        if (elem('new-element-class').value != '') {
            new_element['class'] = elem('new-element-class').value;
        }
        if (elem('new-element-style').value != '') {
            new_element['style'] = elem('new-element-style').value;
        }
        if (elem('new-element-action').value != '') {
            new_element['action'] = elem('new-element-action').value;
        }
        if (elem('new-element-socket').value != '') {
            new_element['socket'] = elem('new-element-socket').value;
        }
        if (elem('new-element-response').value != '') {
            new_element['response'] = elem('new-element-response').value;
        }
        if (elem('new-element-id').value != '') {
            new_element['id'] = elem('new-element-id').value;
        }
        if (elem('new-element-pattern').value != '') {
            new_element['pattern'] = elem('new-element-pattern').value;
        }
        if (elem('new-element-module').value != '') {
            new_element['module'] = elem('new-element-module').value;
        }

        oldjson = JSON.parse(val('edit-json'));
        oldjson['content'].push(new_element);
        val('edit-json', JSON.stringify(oldjson).replace(/"},/g, '"},\n\n').replace(/],"/g, '],\n"'));
    } else {
        ajax.get('/new_page.json', {}, function(response) {
            var formData = new FormData();
            formData.append("path", "/" + elem('new-element-id').value + '.json');
            xmlHttp.open("PUT", "/edit");
            xmlHttp.onload = function() {
                var formData = new FormData();
                formData.append("data", new Blob([response], {
                    type: 'text/json'
                }), "/" + elem('new-element-id').value + '.json');
                xmlHttp.open("POST", "/edit");
                xmlHttp.onload = function() {
                    location.href = "/?" + elem('new-element-id').value;
                }
                xmlHttp.send(formData);
            }
            xmlHttp.send(formData);
        }, true);
    }

    toggle('new-element');
    setContent('edit');
    html('url-content', ' ');
    activeDragDrop(true);
}

function create_new_element_show(status) {
    document.querySelectorAll('#new-element-ipnut .form-control').forEach((el) => {
        if (el.classList != 'hidden') {
            el.classList.add('hidden')
        }
    });

    status = status.split(",");
    for (var i = 0; i < status.length; i++) {
        toggle('new-element-' + status[i], 'shows');
        elem('new-element-' + status[i]).value = '';
    }
}

function log(log) {
    var listitems = document.getElementById("url-content").getElementsByTagName("li")
    for (var i = 0; i < listitems.length; i++) {
        listitems[i].classList.remove("tdFadeInRight");
        if (i > 70) {
            document.getElementById("url-content").removeChild(listitems[0]);
        }
    }
    elem('url-content').innerHTML += log;
    elem('url-content').scrollTop = elem('url-content').scrollHeight;
}

function setContent(stage, load_page) {
    return new Promise((resolve, reject) => {
        jsonResponse = '';

        const loaderBg = document.querySelector('.container.loader-bg');
        const loaderWave = document.querySelector('.loader-wave');

        if (loaderBg)
            loaderBg.classList.add('loading');
        if (loaderWave)
            loaderWave.style.display = 'flex';

        var pages = window.location.search.substring(1).split("&");
        if (load_page) {
            pages[0] = load_page;
        }
        pages[0] = (pages[0] ? pages[0] : 'index');
        var parts = pages[0].split('.');
        if (parts.length > 1) {
            pages[0] = parts[0];
        }

        let jsonFile = pages[0];
        if (jsonFile === 'index') {
            jsonFile = 'index.setup';
        }
        ajax.get(jsonFile + '.json?' + Math.random(), {}, function(response) {
            elem('download-json').href = pages[0] + ".json";

            if (response != 'FileNotFound') {
                jsonPage = JSON.parse(response);
                var jsonEdit = response;

                if (jsonPage.configs) {
                    const loadConfigs = (configs, index = 0) => {
                        if (index >= configs.length) {

                            for (var y = 0; y < pages.length; y++) {
                                jsonResponse["urlArray" + y] = pages[y];
                            }
                            jsonResponse.urlArray = window.location.search.substring(1);

                            var theCookies = document.cookie.split(';');
                            for (var y = 1; y <= theCookies.length; y++) {
                                jsonResponse[theCookies[y - 1].split("=")[0].replace(/^ /, '')] = theCookies[y - 1].split("=")[1];
                            }
                            jsonResponse.sossionLogin = sessionStorage.getItem('sossionLogin');

                            var element_title = elem('title');
                            if (element_title)
                                element_title.innerHTML = '';

                            if (jsonPage.class)
                                elem('content').className = jsonPage.class;
                            if (jsonPage.style)
                                elem('content').style = jsonPage.style;

                            if (jsonPage.reload) {
                                set_real_time = setTimeout("setContent('edit')", jsonPage.reload);
                            }

                            if (stage == 'first') {
                                val('edit-json', jsonEdit);
                                toggle('container_column', 'hide');
                                syncClientTime();
                            } else {
                                elem('content').innerHTML = '';
                                jsonPage = JSON.parse(val('edit-json'));
                            }
                            val('edit-view', 'view');

                            if (jsonPage.content) {
                                viewTemplate(jsonPage, jsonResponse);
                                html("edit-save", "oncli" + "ck");
                            } else {
                                log('<li class="alert alert-danger" style="margin:5px 0;">content array not found in "' + pages[0] + '.json"<\/li>');
                                elem('content').innerHTML += '<br><br><h1>File "' + pages[0] + '.json" cannot view.<\/h1><hr><h2>You can edit it right.<\/h2>';
                                toggle('edit-content');
                                toggle('url-content');
                            }
                            setTimeout(loadModuleStates, 100);
                            hideLoader();
                            resolve();
                        } else {
                            jsonPage.configs[index] = renameBlock(jsonResponse, jsonPage.configs[index]);

                            ajax.get(jsonPage.configs[index], {}, function(configResponse) {
                                if (configResponse != 'FileNotFound') {
                                    var jsonResponseNew = JSON.parse(configResponse);
                                    jsonResponse = mergeObject(jsonResponseNew, jsonResponse || {});
                                    log('<li><span class="label label-warning">GET</span> <a href="' + jsonPage.configs[index] + '" class="btn btn-link" style="text-transform:none;text-align:left;white-space:normal;display:inline" target="_blank">' + jsonPage.configs[index] + '</a> <span class="label label-default">200 OK</span></li>');
                                } else {
                                    if (jsonPage.configs[index].indexOf('socket ') >= 0) {
                                        if (stage == 'first') {
                                            run_socket(jsonPage.configs[index]);
                                        }
                                        log('<li><span class="label label-warning">WS</span> <a href="' + jsonPage.configs[index] + '" class="btn btn-link" style="text-transform:none;text-align:left;white-space:normal;display:inline" target="_blank">' + jsonPage.configs[index] + '</a> <span class="label label-default">Connected</span></li>');
                                    } else {
                                        log('<li><span class="label label-warning">GET</span> <a href="' + jsonPage.configs[index] + '" class="btn btn-link" style="text-transform:none;text-align:left;white-space:normal;display:inline" target="_blank">' + jsonPage.configs[index] + '</a> <span class="label label-danger">File Not Found</span></li>');
                                    }
                                }
                                loadConfigs(configs, index + 1);
                            }, true);
                        }
                    };

                    loadConfigs(jsonPage.configs);
                } else {
                    elem('content').innerHTML = '<br><br><h1>File "' + pages[0] + '.json" cannot view.<\/h1><hr><h2>Please add configs array.<br>Example: "configs":["/config.live.json"]<br>You can edit this file on right side of this page.</h2>';
                    val('edit-json', jsonEdit);
                    toggle('container_column', 'hide');
                    toggle('edit-content');
                    toggle('url-content');

                    hideLoader();
                    resolve();
                }
            } else {
                elem('content').innerHTML += '<br><br><h1>Files "' + pages[0] + '.json" not found.</h1><hr><h2>Maybe you want to open some file of these:</h2><h3 id="file-list"><span class="loader"></span>Loading...</h3>';
                toggle('container_column', 'hide');

                ajax.get('/list?dir=/', {}, function(response) {
                    html('file-list', ' ');
                    var jsonFiles = JSON.parse(response);
                    jsonFiles.sort(function(a, b) {
                        return (a.name < b.name) ? 1 : ((b.name < a.name) ? -1 : 0);
                    });

                    for (var i = 0; i < jsonFiles.length; i++) {
                        if (jsonFiles[i].name.substr(-4) == 'json' || jsonFiles[i].name.substr(-7) == 'json.gz') {
                            elem('file-list').innerHTML += '<a href="/' + (location.pathname == 'index.htm' ? 'index' : 'page') + '.htm?' + jsonFiles[i].name.split('.')[0] + '">' + jsonFiles[i].name + '</a><br>';
                        }
                    }

                    hideLoader();
                    resolve();
                }, true);
            }
        }, true);
    });
}

function syncClientTime() {
    var now = Math.floor(Date.now() / 1000);
    var tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (tz && tz !== 'undefined') {
        ajax.get('/set_client_time', {
            time: now,
            tz: tz
        }, function(response) {
            console.log('Client time sync:', response);
        }, true);
    }
}

function hideLoader() {
    const loaderBg = document.querySelector('.container.loader-bg');
    const loaderWave = document.querySelector('.loader-wave');

    if (loaderBg)
        loaderBg.classList.remove('loading');
    if (loaderWave)
        loaderWave.style.display = 'none';
}

function searchModule(modules, find) {
    var findModules = '';
    for (var key in modules) {
        if (modules[key].indexOf(find) != -1) {
            findModules = 1;
        }
    }
    return findModules;
}

function searchModuleOld(modules, find) {
    var findModules = '';
    for (var key in modules) {
        if (modules[key] == find) {
            findModules = 1;
        }
    }
    return findModules;
}

function viewTemplate(jsonPage, jsonResponse, othe_opt) {
    var i = 0;
    for (var key in jsonPage) {
        var element = elem(key);
        if (Array.isArray(jsonPage[key]) && element) {
            var arr = jsonPage[key];
            for (var j = 0; j < arr.length; j++) {
                var obj = arr[j];
                var action_val = renameGet(obj.action) || '';
                var socket_val = renameGet(obj.socket) || '';
                var actiondown_val = renameGet(obj.actiondown) || '';
                var name_val = obj.name || '';
                var class_val = obj.class ? renameBlock(jsonResponse, obj.class) || '' : '';
                var style_val = obj.style ? 'style="' + (renameBlock(jsonResponse, obj.style) || '') + '"' : '';
                var pattern_val = obj.pattern || '';
                var state_val = renameBlock(jsonResponse, obj.state, true) || '';
                var response_val = renameBlock(jsonResponse, obj.response) || '';
                var module_val = obj.module;
                var type_val = obj.type || 'none';

                var hidden = '';
                if (!obj.module || searchModule(jsonResponse.module, obj.module)) {
                    hidden = 'fs-block ';
                    if (othe_opt == 'loadJson') {
                        hidden = ' ';
                    }
                } else {
                    hidden = 'fs-block hidden ';
                    if (othe_opt == 'loadJson') {
                        hidden = 'hidden ';
                    }
                }

                if (type_val == 'div') {
                    var divElement = '<div id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '>';
                    if (obj.content && Array.isArray(obj.content)) {
                        var tempJson = {
                            temp: obj.content
                        };
                        divElement += '<div id="temp">';
                        element.innerHTML += divElement;
                        viewTemplate(tempJson, jsonResponse, othe_opt);
                        element.innerHTML += '</div>';
                    } else {
                        element.innerHTML += divElement + '</div>';
                    }
                } else if (type_val == 'hr') {
                    element.innerHTML += '<hr id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '>';
                } else if (type_val == 'h1' || type_val == 'h2' || type_val == 'h3' || type_val == 'h4' || type_val == 'h5' || type_val == 'h6') {
                    element.innerHTML += '<' + type_val + ' id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '>' + renameBlock(jsonResponse, obj.title) + '</' + type_val + '>';
                } else if (type_val == 'none' || typeof type_val === 'undefined') {
                    element.innerHTML += '<div id="' + name_val + '" class="' + hidden + '" ' + style_val + '>' + renameBlock(jsonResponse, obj.title) + '</div>';
                } else if (type_val == 'textarea') {
                    if (action_val)
                        action_val = 'onfocusout="send_request(this, \'' + (typeof module_val != 'undefined' && module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
                    element.innerHTML += '<div class="' + hidden + '"><textarea ' + action_val + ' id="' + name_val + '" class="form-control ' + class_val + '" ' + style_val + ' ' + (pattern_val ? 'pattern="' + pattern_val + '"' : '') + ' placeholder="' + renameBlock(jsonResponse, obj.title) + '">' + state_val + '</textarea></div>';
                } else if (type_val == 'input') {
                    if (action_val)
                        action_val = 'onfocusout="send_request(this, \'' + (typeof module_val != 'undefined' && module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
                    if (socket_val)
                        action_val = 'onfocusout="send_socket(this, \'\', \'' + socket_val + '\')"';
                    element.innerHTML += '<input ' + action_val + ' id="' + name_val + '" class="form-control ' + hidden + class_val + '" ' + style_val + ' ' + (pattern_val ? 'pattern="' + pattern_val + '"' : '') + ' placeholder="' + renameBlock(jsonResponse, obj.title) + '" value="' + state_val + '">';
                } else if (type_val == 'password') {
                    if (action_val)
                        action_val = 'onfocusout="send_request(this, \'' + (typeof module_val != 'undefined' && module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
                    if (socket_val)
                        action_val = 'onfocusout="send_socket(this, \'\', \'' + socket_val + '\')"';
                    element.innerHTML += '<input ' + action_val + ' id="' + name_val + '" class="form-control ' + hidden + class_val + '" ' + style_val + ' ' + (pattern_val ? 'pattern="' + pattern_val + '"' : '') + ' placeholder="' + renameBlock(jsonResponse, obj.title) + '" value="' + state_val + '" onfocus="this.type=\'text\'" type="password">';
                } else if (type_val == 'button') {
                    if (action_val)
                        action_val = 'onclick="send_request(this, \'' + (typeof module_val != 'undefined' && module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
                    if (socket_val)
                        action_val = 'onclick="send_socket(this, \'\', \'' + socket_val + '\')"';
                    if (actiondown_val)
                        actiondown_val = 'onmouseup="send_request(this, \'' + (typeof module_val != 'undefined' && module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
                    element.innerHTML += '<input id="' + name_val + '" ' + action_val + ' ' + actiondown_val + ' class="' + hidden + class_val + '" ' + style_val + ' value="' + renameBlock(jsonResponse, obj.title) + '" type="button">';
                } else if (type_val == 'checkbox') {
                    var checked = '';
                    if (!obj.design) {
                        if (state_val == 1) {
                            checked = 'checked';
                        }
                        if (action_val) {
                            action_val = 'onchange="val(this.id,(this.checked?\'1\':\'0\'));send_request(this, \'' + (typeof module_val != 'undefined' && module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
                        } else {
                            action_val = 'onchange="val(this.id,(this.checked?\'1\':\'0\'));"';
                        }
                        element.innerHTML += '<label ' + style_val + '><input id="' + name_val + '" value="' + state_val + '" ' + action_val + ' type="checkbox" class="' + hidden + class_val + '" ' + checked + '> ' + renameBlock(jsonResponse, obj.title) + '</label>';
                    } else {
                        if (state_val == 0) {
                            checked = 'checked=""';
                        }
                        if (action_val) {
                            action_val = 'onchange="val(this.id,(this.checked?\'0\':\'1\'));send_request(this, \'' + (typeof module_val != 'undefined' && module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
                        } else {
                            action_val = 'onchange="val(this.id,(this.checked?\'0\':\'1\'));"';
                        }
                        element.innerHTML += '<div class="toggle-button-cover" ' + style_val + '><div class="button-cover"><div class="button r ' + obj.design + '"><input type="checkbox" id="' + name_val + '" ' + action_val + ' class="checkbox" ' + checked + '><div class="knobs"></div><div class="layer"></div></div></div><label for="' + name_val + '">' + renameBlock(jsonResponse, obj.title) + '</label></div>';
                    }
                } else if (type_val == 'range') {
                    if (action_val)
                        action_val = 'onchange="send_request(this, \'' + (typeof module_val != 'undefined' && module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
                    element.innerHTML += '<div class="' + hidden + '"><label id="' + (name_val ? 'label-' + name_val : '') + '" ' + style_val + ' style="display:block;"><h4>' + renameBlock(jsonResponse, obj.title) + '</h4> <input id="' + name_val + '" class="form-control ' + class_val + '" ' + action_val + ' ' + pattern_val + ' value="' + state_val + '" type="range"></label></div>';
                } else if (type_val == 'table') {
                    element.innerHTML += '<table class="' + hidden + class_val + '" ' + style_val + ' id="' + name_val + '"><thead id="thead-' + state_val.replace(/[^a-z0-9]/gi, '-') + '"><tr><td><center><span class="loader"></span>' + jsonResponse.LangLoading + '</center></td></tr></thead><tbody id="tbody-' + state_val.replace(/[^a-z0-9]/gi, '-') + '"></tbody></table>';
                    loadTable(state_val, obj.title);
                } else if (type_val == 'select') {
                    if (action_val)
                        action_val = 'onchange="send_request(this, \'' + (typeof module_val != 'undefined' && module_val ? 'cmd?command=' : '') + '\' + renameGet(\'' + obj.action + '\'),\'' + response_val + '\')"';
                    if (socket_val)
                        action_val = 'onchange="send_socket(this, \'\', \'' + socket_val + '\')"';
                    var option = '';
                    jsonSelect = obj.title;
                    if (isObject(jsonSelect)) {
                        for (var key in jsonSelect) {
                            option += '<option value="' + renameBlock(jsonResponse, key) + '"' + (state_val == key ? ' selected' : '') + '>' + renameBlock(jsonResponse, jsonSelect[key]) + '</option>';
                        }
                    } else {
                        loadSelect(jsonSelect, name_val, state_val);
                    }
                    element.innerHTML += '<select class="form-control ' + hidden + class_val + '" ' + style_val + ' ' + action_val + ' id="' + name_val + '">' + option + '</select>';
                } else if (type_val == 'dropdown') {
                    var option = '';
                    var i = 0;
                    var title1 = '';
                    jsonSelect = obj.title;
                    for (var key in jsonSelect) {
                        if (i == 0) {
                            title1 += renameBlock(jsonResponse, jsonSelect[key]);
                        } else {
                            option += '<li><a href="' + renameBlock(jsonResponse, key) + '">' + renameBlock(jsonResponse, jsonSelect[key]) + '</a></li>';
                        }
                        i++;
                    }
                    element.innerHTML += '<div class="' + hidden + ' btn-group"><a href="#" class="dropdown-toggle ' + class_val + '" ' + style_val + ' onclick="toggle(\'' + name_val + '\');return false">' + title1 + '</a><ul class="dropdown-menu hidden" id="' + name_val + '">' + option + '</ul></div>';
                } else if (type_val == 'configs') {
                    var option = '';
                    option += '<div id="' + name_val + '"><div id="' + state_val.replace(/[^a-z0-9]/gi, '-') + '" class="' + class_val + '" ' + style_val + '><center><span class="loader"></span>' + jsonResponse.LangLoading + '</center></div></div>';
                    option += '<div class="btn-group btn-block"><input style="width:85%" onclick="changeTextarea(\'' + state_val.replace(/[^a-z0-9]/gi, '-') + '\');send_request_edit(this, val(\'' + state_val.replace(/[^a-z0-9]/gi, '-') + '-edit\'),\'configs/' + state_val + '\',\'if(confirm(\\\'' + jsonResponse.LangReset2 + ' ' + jsonResponse.LangReset3 + '\\\')){send_request(this,\\\'/restart?device=ok\\\');toggle(\\\'restart-esp\\\');setTimeout(function(){toggle(\\\'restart-esp\\\');},20000);};\');" class="btn btn-block btn-success" value="' + jsonResponse.LangSave + '" type="button">';
                    option += '<a href="#" style="width:15%" class="btn btn-info dropdown-toggle" onclick="toggle(\'cloud\');return false"><i class="cloud-img"></i> <span class="caret"></span></a>';
                    option += '<ul class="dropdown-menu hidden" style="right:0;left:auto" id="cloud"><li><a onclick="toggle(\'cloud\');cloudUpload(\'' + jsonResponse.mac + '\',\'' + jsonResponse.configs + '\');return false" href="#"><i class="cloud-img"></i> ' + jsonResponse.LangCloudUpload + '</a></li><li><a onclick="toggle(\'cloud\');cloudDownload(\'' + jsonResponse.mac + '\',\'' + jsonResponse.configs + '.txt\');return false" href="#"><i class="cloud-img"></i> ' + jsonResponse.LangCloudDownload + '</a></li><li><a href="/configs/' + jsonResponse.configs + '.txt?download=true" download=""><i class="download-img"></i> ' + jsonResponse.LangCloudPC + '</a></li></ul>';
                    option += '</div>';
                    element.innerHTML += '<div class="' + hidden + '">' + option + '</div>';
                    setTimeout("loadConfigs('" + state_val + "',jsonResponse)", 500);
                } else if (type_val == 'link') {
                    element.innerHTML += '<a id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + ' href="' + renameGet(obj.action) + '">' + renameBlock(jsonResponse, obj.title) + '</a>';
                } else if (type_val == 'img') {
                    element.innerHTML += '<img id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + ' src="' + renameGet(obj.state) + '" onclick="' + renameGet(obj.action) + '" title="' + renameBlock(jsonResponse, obj.title) + '"/>';
                } else if (type_val == 'text') {
                    element.innerHTML += '<div id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '>' + renameBlock(jsonResponse, obj.title) + '</div>';
                } else if (type_val == 'iframe') {
                    element.innerHTML += renameBlock(jsonResponse, obj.title) + '<iframe src="' + state_val + '" id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '></iframe>';
                } else if (type_val == 'chart') {
                    element.innerHTML += '<div id="' + name_val + '" class="' + hidden + ' ' + renameBlock(jsonResponse, '{{' + state_val.replace(/[^a-z0-9]/gi, '') + '-hidden}}') + '"><button class="close" onclick="hide(\'' + state_val.replace(/[^a-z0-9]/gi, '') + '-hidden\',this)">×</button><a href="' + renameGet(obj.action) + '" target="_blank" class="close">' + (typeof action_val != 'undefined' && action_val ? '<i class="popup-img"></i>' : '') + '</a><h2><span id="' + state_val.replace(/[^a-z0-9]/gi, '') + '-title">' + renameBlock(jsonResponse, obj.title) + '</span> <span id="' + state_val.replace(/[^a-z0-9]/gi, '') + '-data"></span></h2><div id="' + state_val.replace(/[^a-z0-9]/gi, '') + '" class="' + class_val + '" ' + style_val + '></div><hr></div>';
                    if (renameBlock(jsonResponse, '{{' + state_val.replace(/[^a-z0-9]/gi, '') + '-hidden}}') != 'hidden') {
                        setTimeout("loadChart('" + state_val.replace(/[^a-z0-9]/gi, '') + "','" + state_val + "', {" + obj.options + "}," + obj.refresh + "," + obj.points + ",'" + obj.chartist + "')", 1500);
                    }
                } else if (type_val == 'loadJson') {
                    element.innerHTML += '<div id="json-' + state_val.replace(/[^a-z0-9]/gi, '-') + '" class="' + hidden + class_val + '" ' + style_val + '><center><span class="loader"></span>' + jsonResponse.LangLoading + '</center></div>';
                    loadJson(state_val, obj.refresh, jsonResponse);
                } else if (type_val == 'file') {
                    var set_action = '';
                    if (obj.action != undefined) {
                        set_action = ",'send_request(this,\\'" + obj.action + "\\')";
                    }
                    element.innerHTML += '<div class="' + hidden + '"><textarea ' + style_val + ' id="file-' + state_val.replace(/[^a-z0-9]/gi, '-') + '">' + jsonResponse.LangLoading + '</textarea><input class="' + class_val + '" onclick="send_request_edit(this, val(\'file-' + state_val.replace(/[^a-z0-9]/gi, '-') + '\'),\'/' + state_val + '\' ' + set_action + ');" value="' + renameBlock(jsonResponse, obj.title) + '" type="button"></div>';
                    loadFile(state_val);
                } else if (type_val == 'csv') {
                    var set_action = '';
                    if (obj.action != undefined) {
                        set_action = ",'send_request(this,\\'" + obj.action + "\\')";
                    }
                    element.innerHTML += '<div class="' + hidden + '"><table id="table-csv-' + state_val.replace(/[^a-z0-9]/gi, '-') + '" ' + style_val + '></table><textarea style="display:none" id="csv-' + state_val.replace(/[^a-z0-9]/gi, '-') + '"></textarea><input class="' + class_val + '" onclick="html_to_csv(\'csv-' + state_val.replace(/[^a-z0-9]/gi, '-') + '\');send_request_edit(this, val(\'csv-' + state_val.replace(/[^a-z0-9]/gi, '-') + '\'),\'/' + state_val + '\' ' + set_action + ');" value="Save" type="button"></div>';
                    loadCSV(state_val, obj.title);
                } else if (type_val == 'time-list') {
                    element.innerHTML += '<table class="' + hidden + class_val + '" ' + style_val + ' id="' + name_val + '"><tbody id="time-list"></tbody></table>';
                    loadTime(jsonResponse);
                } else if (type_val == 'time-add') {
                    const template = (x, y, i, z) => ' <label class="label label-' + x + '"><input type="checkbox" name="day-' + y + '" id="day-' + i + '" checked>' + jsonResponse['Lang' + z] + '</label> ';
                    var option = '';
                    option += '<input type="hidden" id="hidden-val-then" value="1"><div id="new-then"></div> <h4>';
                    option += template('danger', 'sun', '0', 'Sun');
                    option += template('info', 'mon', '1', 'Mon');
                    option += template('info', 'tue', '2', 'Tue');
                    option += template('info', 'wed', '3', 'Wed');
                    option += template('info', 'thu', '4', 'Thu');
                    option += template('info', 'fri', '5', 'Fri');
                    option += template('danger', 'sat', '6', 'Sat');
                    option += ' <label class="label label-default"><input type="checkbox" onchange="toggleCheckbox(this)" checked>' + jsonResponse.LangAll + '</label><br>';
                    option += ' <label class="label label-default"><input type="checkbox" name="run1" id="run-1">' + jsonResponse.LangRun1 + '</label></h4>';
                    option += '<input id="set-time" class="form-control" pattern="(0[0-9]|1[0-9]|2[0-3])(:[0-5][0-9]){2}" placeholder="' + jsonResponse.LangTime4 + '. ' + jsonResponse.LangExample + ': 07:09:30" value="" style="width:90%;display:inline"><a href="#" class="btn btn-default" style="width:10%;" onclick="val(\'set-time\',\'Loading...\');ajax.get(\'/config.live.json\',{},function(response){var jsonFiles=JSON.parse(response);val(\'set-time\',jsonFiles[\'time\']);},true);return false"><i class="clock-img"></i></a>';
                    option += '<input class="btn btn-block btn-lg btn-success" onclick="addTimer();" value="' + jsonResponse.LangSave + '" type="button">';
                    element.innerHTML += '<div class="' + hidden + '">' + option + '</div>';
                    loadNewThen('new-then', ' ');
                    html("load-life-opt", "onclick");
                } else if (type_val == 'scenary-list') {
                    element.innerHTML += '<table class="' + hidden + class_val + '" ' + style_val + ' id="' + name_val + '"><tbody id="scenary-list"></tbody></table>';
                    loadScenary(jsonResponse, 'loadList');
                } else if (type_val == 'scenary-add') {
                    var option = '';
                    option += '<select class="form-control" id="ssdp-list0" onchange="loadScenaryList(0,\'loadInTextarea\',this.options[this.selectedIndex].value);loadLive(this.value,\'config.live.json\',\'ssdp-module\');toggle(\'ssdp-module\',\'hidden\');"></select>';
                    option += '<select class="form-control hidden" id="ssdp-module" onchange="pattern(this.querySelector(\':checked\').getAttribute(\'title\'),\'ssdp-command\');toggle(\'hidden-if\',\'hidden\');toggle(\'or-and\',\'hidden\');"></select>';
                    option += '<span class="hidden" id="hidden-if"><select class="form-control" id="ssdp-condition" style="width:50%;display:inline"><option value="=">' + jsonResponse.LangEqual + ' (=)</option><option value="<">' + jsonResponse.LangLess + ' (<)</option><option value=">">' + jsonResponse.LangMore + ' (>)</option><option value="<=" disabled>' + jsonResponse.LangLess + ' ' + jsonResponse.LangOr + ' ' + jsonResponse.LangEqual + ' (<=) ' + jsonResponse.LangSoon + '</option><option value=">=" disabled>' + jsonResponse.LangMore + ' ' + jsonResponse.LangOr + ' ' + jsonResponse.LangEqual + ' (>=) ' + jsonResponse.LangSoon + '</option><option value="!=">' + jsonResponse.LangNotEqual + ' (!=)</option></select>';
                    option += '<input class="form-control" id="ssdp-command" pattern="" style="width:40%;display:inline" value=""><a href="#" id="load-life-opt" class="btn btn-default" style="width:10%;" onclick="loadLive2(\'ssdp-list0\',\'ssdp-module\',\'ssdp-command\');return false"><i class="find-replace-img"></i></a></span>';
                    option += '<textarea id="scenary-list-edit" style="display:none" class="form-control"></textarea>';
                    option += '<input type="hidden" id="hidden-val-and" value="1"><input type="hidden" id="hidden-val-or" value="1"><div id="new-and-or"></div>';
                    option += '<div class="btn-group hidden" id="or-and" style="width:100%;"><input onclick="loadNewAnd(\'new-and-or\');" class="btn btn-sm btn-default" style="width:50%;" value="+ ' + jsonResponse.LangAnd + '" type="button">';
                    option += '<input onclick="loadNewOr(\'new-and-or\');" class="btn btn-sm btn-default" style="width:50%;" value="+ ' + jsonResponse.LangOr + '" type="button"></div>';
                    option += '<input type="hidden" id="hidden-val-then" value="1"><div id="new-then"></div>';
                    option += '<input onclick="loadNewThen(\'new-then\');" class="btn btn-sm btn-block btn-default" value="+ ' + jsonResponse.LangThen + '" type="button">';
                    option += '<input onclick="saveScenary(jsonResponse,\'\')" class="btn btn-block btn-lg btn-success" value="' + jsonResponse.LangSave + '" type="button">';
                    element.innerHTML += '<div class="' + hidden + '"><h3>' + jsonResponse.LangIf + '</h3> ' + option + '</div>';
                    loadScenary(jsonResponse);
                    html("load-life-opt", "onclick");
                } else if (type_val == 'scenary-test') {
                    var option = '';
                    option += '<select class="form-control" id="ssdp-list2" style="display:none"><option value="' + location.host + '">-</option></select>';
                    option += '<input type="hidden" id="hidden-val-then" value="1"><div id="new-then"></div>';
                    option += '<select class="form-control hidden" id="scenary-then2" style="width:50%;" onchange="loadCommandHelp(this.value,\'command-help2\',\'scenary-othe2\');toggle(\'if-then2\',\'hidden\');"><option value=""></option></select>';
                    option += '<div id="if-then2" class="hidden"><div id="command-help2" class="alert alert-warning"></div><a href="#" id="scenary-othe-play2" class="btn btn-default" style="width:10%;float:right;" onclick="send_request(this, \'http://\'+elem(\'ssdp-list2\').options[elem(\'ssdp-list2\').selectedIndex].value+\'/cmd?command=\'+elem(\'scenary-then2\').options[elem(\'scenary-then2\').selectedIndex].value+\' \'+elem(\'scenary-othe2\').value.replace(/&/g,\'%26\'),\'\');return false" title="' + jsonResponse.LangRun + '"><i class="eye-img"></i></a><input class="form-control" style="width:90%" placeholder="Действие" id="scenary-othe2" type="text"></div>';
                    element.innerHTML += '<div class="' + hidden + '"><h4 style="float:left;">Module:</h4> ' + option + '</div>';
                    setTimeout("loadCommand('" + location.host + "','command.json','scenary-then2');toggle('scenary-then2','hidden');", 500);
                } else if (type_val == 'macros') {
                    element.innerHTML += '<div class="' + hidden + class_val + '" ' + style_val + ' id="' + (name_val ? name_val : 'loadMacros') + '"></div>';
                    loadMacros(jsonResponse, (name_val ? name_val : 'loadMacros'));
                } else if (type_val == 'login') {
                    var option = '';
                    option += '<h2>' + jsonResponse.Авторизация + '</h2><div class="alert alert-warning" >' + renameBlock(jsonResponse, obj.title) + '</div>';
                    option += '<input id="passLogin" class="form-control" placeholder="Password" value="" onfocus="this.type=\'text\'" type="password">';
                    option += '<a class="btn btn-block btn-success" href="#" onclick="if(\'' + state_val + '\'==val(\'passLogin\')){sessionStorage.setItem(\'sossionLogin\', \'hidden\');toggle(\'loginForm\');}else{alert(\'The password is incorrect\')}">' + jsonResponse.Авторизация + '</a>';
                    element.innerHTML += '<div id="loginForm" class="' + hidden + ' ' + jsonResponse.sossionLogin + '" style="background-color:#fff;position:fixed;top:0;left:0;right:0;bottom:0;z-index:9999;padding:10% 30%;">' + option + '</div>';
                } else if (type_val == 'wifi') {
                    element.innerHTML += '<div class="' + hidden + ' btn-group btn-block" id="ssid-group"><a href="#" class="btn btn-default btn-block dropdown-toggle" onclick="toggle(\'ssid-select\');loadWifi(\'ssid-select\',\'' + name_val + '\');return false"><span id="ssid-name">' + state_val + '</span> <span class="caret"></span></a><ul class="dropdown-menu hidden" id="ssid-select"><li><a href="#">' + jsonResponse.LangLoading + '</a></li></ul></div>';
                    element.innerHTML += '<input id="' + name_val + '" value="' + state_val + '" class="form-control hidden ' + class_val + '" ' + style_val + ' ' + pattern_val + ' placeholder="' + renameBlock(jsonResponse, obj.title) + '">';
                } else if (type_val == 'time' && typeof jsonResponse.time !== "undefined") {
                    element.innerHTML += '<div id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '>' +
                        '<strong id="timeDisplay">' + state_val + '</strong>' +
                        '</div>' +
                        '<div id="dateDisplay" style="text-align:center;color:#adadad;font-size:16px;margin-bottom:20px"></div>';

                    function updateTimeBlock() {
                        fetch('/get_time')
                            .then(r => r.json())
                            .then(d => {
                                let timeStr = d.time || '--:--:--';
                                let city = d.city || '';
                                let dateStr = d.date || '';
                                let displayElem = document.getElementById('timeDisplay');
                                let dateElem = document.getElementById('dateDisplay');

                                if (displayElem) {
                                    if (city && city.length > 0) {
                                        displayElem.innerHTML = city + ': ' + timeStr;
                                    } else {
                                        displayElem.innerHTML = timeStr;
                                    }
                                }

                                if (dateElem && dateStr) {
                                    dateElem.innerHTML = dateStr;
                                }
                            })
                            .catch(() => {
                                let displayElem = document.getElementById('timeDisplay');
                                if (displayElem)
                                    displayElem.innerHTML = '--:--:--';
                            });
                    }
                    updateTimeBlock();
                    setInterval(updateTimeBlock, 1000);
                } else if (type_val == 'weather') {
                    element.innerHTML += '<div id="' + name_val + '" class="' + hidden + class_val + '" ' + style_val + '>' +
                        '<h4>' + renameBlock(jsonResponse, obj.title) + '</h4>' +
                        '<strong id="weatherNowDisplay">--°C</strong>' +
                        '</div>';

                    function updateWeatherBlock() {
                        fetch('/get_weather')
                            .then(r => r.json())
                            .then(d => {
                                // Проверяем, есть ли данные
                                if (!d || d.temp === undefined || d.temp === null || isNaN(d.temp)) {
                                    let displayElem = document.getElementById('weatherNowDisplay');
                                    if (displayElem)
                                        displayElem.innerHTML = 'Нет данных';
                                    return;
                                }

                                let temp = Math.round(d.temp);
                                let condRaw = d.text || d.condition || '';
                                // Убираем источник из строки, если он есть
                                let cond = condRaw.replace(/^(Яндекс|OpenWeather):\s*\d+°C\s*,?\s*/, '').trim();
                                let city = d.city || '';
                                let sign = (temp > 0) ? '+' : (temp < 0) ? '-' : '';
                                let displayTemp = sign + Math.abs(temp) + '°C';
                                let displayText = cond ? (', ' + cond) : '';
                                let displayElem = document.getElementById('weatherNowDisplay');
                                if (displayElem) {
                                    if (city && city.length > 0 && city !== 'undefined') {
                                        displayElem.innerHTML = city + ': ' + displayTemp + displayText;
                                    } else {
                                        displayElem.innerHTML = displayTemp + displayText;
                                    }
                                }
                            })
                            .catch(err => {
                                console.error('Weather fetch error:', err);
                                let displayElem = document.getElementById('weatherNowDisplay');
                                if (displayElem)
                                    displayElem.innerHTML = 'Ошибка';
                            });
                    }
                    updateWeatherBlock();
                    setInterval(updateWeatherBlock, 60000);
                } else if (type_val == 'rgb') {
                    element.innerHTML += '<div class="' + hidden + ' ' + name_val + '-thumb ' + class_val + '"><div class="' + name_val + '-preview"></div><img alt="" ' + style_val + ' src="' + renameBlock(jsonResponse, obj.title) + '"></div><canvas id="' + name_val + '-cs" style="display:none"></canvas>';
                    element.innerHTML += '<input id="' + name_val + '" value="' + state_val + '" class="form-control hidden">';
                    setTimeout("createRGB('" + name_val + "', '" + obj.action + "','" + module_val + "','" + response_val + "')", 500);
                } else if (type_val == 'issues') {
                    element.innerHTML += '<div id="issues-list" class="' + hidden + class_val + '" ' + style_val + '><center><span class="loader"></span>' + jsonResponse.LangLoading + '</center></div>';
                    setTimeout("loadIssues('tretyakovsa/Sonoff_WiFi_switch'," + (state_val) + ");", 1500);
                } else if (type_val == 'commits') {
                    element.innerHTML += '<div id="commits-list" class="' + hidden + class_val + '" ' + style_val + '><center><span class="loader"></span>' + jsonResponse.LangLoading + '</center></div>';
                    setTimeout("loadCommits('tretyakovsa/Sonoff_WiFi_switch'," + (state_val) + ");", 1500);
                } else if (type_val == 'dev') {
                    var option = '<div id="' + name_val + '" class="' + class_val + '" ' + style_val + '><a href="/help.htm" target="_blank" class="close"><i class="help-img"></i></a>' + renameBlock(jsonResponse, obj.title) + '<span id="dev-update" class="hidden"><a href="/edit" class="btn btn-primary" target="_blank">File manager</a> <a href="/page.htm?starting" class="btn btn-primary">Starting log</a> <a href="/page.htm?debug" class="btn btn-primary">Debug</a> ';
                    if (searchModule(jsonResponse.module, "upgrade")) {
                        option += ' <div class="btn-group"><a href="#" class="btn btn-danger dropdown-toggle" onclick="toggle(\'repos-all\');loadBuild(\'sonoff\',\'all\',\'' + state_val + '\');return false">Upgrade <span class="caret"></span></a><ul class="dropdown-menu hidden" id="repos-all" style="min-width:350px"><li><a href="https://github.com/tretyakovsa/Sonoff_WiFi_switch/commits/master" style="text-align:right" target="_blank"><i class="help-img"></i> Github code history</a><ul id="sonoff-all" style="margin-right:20px"><li><a href="#">' + jsonResponse.LangLoading + '</a></li></ul></li></ul></div>';
                    }
                    option += '<br><br>';
                    option += jsonResponse.LangType + ': <div class="btn-group"><select class="btn btn-default btn-sx" onchange="send_request(this, \'/configs?set=\'+this.value,\'[[configs-edit-button]]\')"><option value="' + jsonResponse.configs + '">' + jsonResponse.configs + '</option><option value="sonoff-rf">Sonoff-rf / Sonoff TH16 / Wi-Fi Smart Socket</option><option value="sonoff-pow">Sonoff-Pow (' + jsonResponse.LangSoon + ')</option><option value="rgb">RGB (WS2811/WS2812/NeoPixel LEDs)</option><option value="rgb-shim">RGB SHIM (5050/3528/2835)</option><option value="jalousie">Jalousie</option><option value="smart-room">Smart-Room</option><option value="wifi-relay-5v">WiFi Relay 5v</option><option value="manually">Manually</option></select> <a href="/page.htm?configs&' + jsonResponse.configs.toLowerCase() + '" id="configs-edit-button" class="btn btn-primary"><i class="opt-img"></i></a></div><hr>';
                    option += '<form method="POST" action="/update" enctype="multipart/form-data"><div class="btn-group"><input type="file" class="btn btn-primary btn-xs" name="update" style="height:33px" accept=".bin"><input type="submit" class="btn btn-default btn-sm" value="Update build" onclick="this.value=\'' + jsonResponse.LangLoading + '\';" style="height:33px"></div></form>';
                    option += '</span></div>';
                    element.innerHTML += '<div class="' + hidden + '">' + option + '</div>';
                }
            }
        }
        i++;
    }
    elem('content').innerHTML += '<div id="content-edit-button"></div>';
    if (elem('edit-content').classList == 'show') {
        activeDragDrop(true);
    }

    setTimeout(function() {
        var nightBtn = document.querySelector('.night-clock-off, .night-clock-on');
        if (nightBtn) {
            var state = nightBtn.getAttribute('data-state') || '0';
            if (jsonResponse.night_clock_enabled !== undefined) {
                state = jsonResponse.night_clock_enabled;
            }
            updateNightClockButton(state);
        }
    }, 50);

    setTimeout(function() {
        var tzSelect = document.getElementById('tz_select');
        if (tzSelect) {
            var newSelect = tzSelect.cloneNode(true);
            tzSelect.parentNode.replaceChild(newSelect, tzSelect);

            newSelect.addEventListener('change', function() {
                var input = document.getElementById('custom_tz_input');
                if (input) {
                    if (this.value === 'CUSTOM') {
                        input.style.display = 'block';
                        input.focus();
                    } else {
                        input.style.display = 'none';
                    }
                }
            });

            var input = document.getElementById('custom_tz_input');
            if (input) {
                if (newSelect.value === 'CUSTOM') {
                    input.style.display = 'block';
                } else {
                    input.style.display = 'none';
                }
            }
        }
    }, 100);

    setTimeout(function() {
        initTzTooltip();
        initWeatherTooltip();
    }, 200);
}

function isObject(obj) {
    return obj != null && obj.constructor.name === "Object"
}

function loadJson(file, setDelay, jsonResponse) {
    function setLoad() {
        ajax.get(file + '?' + Math.random(), {}, function(response) {
            html('json-' + file.replace(/[^a-z0-9]/gi, '-'), ' ');
            var jsonPage2 = JSON.parse(response);
            viewTemplate(jsonPage2, jsonResponse, 'loadJson');
        }, true);
    };
    if (!isNaN(setDelay)) {
        var valTime;
        clearInterval(valTime);
        valTime = setInterval(function() {
            setLoad();
        }, setDelay);
    } else {
        setLoad();
    }
}

function loadSelect(file, name_val, state_val) {
    ajax.get(file + '?' + Math.random(), {}, function(response) {
        var result = JSON.parse(response);
        option = '';
        for (var key in result) {
            option += '<option value="' + renameBlock(jsonResponse, key) + '"' + (state_val == key ? ' selected' : '') + '>' + renameBlock(jsonResponse, result[key]) + '</option>';
        }
        elem(name_val).innerHTML = option;
    }, true);
}

function loadFile(file) {
    ajax.get(file + '?' + Math.random(), {}, function(response) {
        val('file-' + file.replace(/[^a-z0-9]/gi, '-'), response);
    }, true);
}

function loadCSV(file, title) {
    ajax.get(file + '?' + Math.random(), {}, function(response) {
        var tbody = '';
        var table_tr = response.replace(/\r\n|\n\r|\n|\r/g, "\n").split("\n");
        for (var i = 0; i < table_tr.length; i++) {
            var table_td = table_tr[i].split(";");
            tbody += '<tr>';
            for (var y = 0; y < table_td.length; y++) {
                if (i == 0) {
                    tbody += '<th>' + table_td[y] + '</th>';
                } else {
                    if (title[y]) {
                        if (title[y] == 'html') {
                            tbody += '<td>' + table_td[y] + '</td>';
                        } else if (title[y] == 'del') {
                            tbody += '<td><input class="btn btn-danger" type="button" value="' + table_td[y] + '" onclick="location.href=\'/del?file=' + file + '&line=' + i + '\'"></td>';
                        } else if (title[y].split(":")[0] == 'select') {
                            tbody += '<td><select class="form-control" id="csv-select-' + i + '"></select></td>';
                            loadSelect(title[y].split(":")[1], "csv-select-" + i, table_td[y]);
                        } else {
                            tbody += '<td><input class="form-control" type="' + title[y] + '" value="' + table_td[y] + '" ' + (title[y] == 'checkbox' ? 'onclick="(this.checked?this.value=1:this.value=0)"' : '') + ' ' + (title[y] == 'checkbox' && table_td[y] == 1 ? 'checked' : '') + '></td>';
                        }
                    }
                }
            }
            tbody += '</tr>';
        }
        document.getElementById('table-csv-' + file.replace(/[^a-z0-9]/gi, '-')).innerHTML = '' + tbody + '';
    }, true);
}

function html_to_csv(file) {
    var csv = [];
    var fixed = '';
    var rows = document.querySelectorAll('[id^="table-' + file + '"] tr')
    for (var i = 0; i < rows.length; i++) {
        var row = [],
            cols = rows[i].querySelectorAll("td, th, input, select");
        for (var j = 0; j < cols.length; j++) {
            if (typeof cols[j].value !== "undefined") {
                fixed = cols[j].value;
            } else {
                fixed = cols[j].innerHTML;
            }
            if (fixed.indexOf("<input") == -1) {
                if (cols[j].innerHTML.indexOf("select") == 1) {
                    var select_new_final = cols[j + 1].value;
                    row.push(select_new_final);
                    j++;
                } else {
                    row.push(fixed);
                }
            }
        }
        csv.push(row.join(";"));
    }
    val(file, csv.join("\r\n"));
}

function mergeObject(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
            if (source.hasOwnProperty(key)) {
                target[key] = source[key];
            }
        }
    }
    return target;
}

function saveScenary(jsonResponse, loadList) {
    ajax.get('http://' + elem('ssdp-list0').options[elem('ssdp-list0').selectedIndex].value + '/config.options.json?' + Math.random(), {}, function(response) {
        var view = JSON.parse(response);
        var scenary_file = (view['configs'] ? 'scenary/' + view['configs'] + '.txt' : 'scenary.save.txt');

        loadInTextarea();
        send_request_edit(this, val('scenary-list-edit') + '\r\n', scenary_file, 'send_request(this, \'http://\'+elem(\'ssdp-list0\').options[elem(\'ssdp-list0\').selectedIndex].value+\'/setscenary\');val(\'ssdp-list0\',\' \');loadScenary(jsonResponse,\'loadList\');', elem('ssdp-list0').options[elem('ssdp-list0').selectedIndex].value);
    }, true);
}

function loadCommand(ip, file, where) {
    html(where, '<option value="">Loading...</option>');
    ajax.get('http://' + ip + '/' + file, {}, function(response) {
        var option = '';
        var jsonLive = JSON.parse(response);
        for (var key in jsonLive.command) {
            option += '<option value="' + jsonLive.command[key] + '" title="' + typeof jsonLive.command[key] + '">' + (renameBlock(jsonResponse, '{{Lang' + jsonLive.command[key] + '}}') === undefined ? jsonLive.command[key] : renameBlock(jsonResponse, '{{Lang' + jsonLive.command[key] + '}}')) + '</option>';
        }
        html(where, '<option value="">' + jsonResponse.LangSelect + '</option>' + option);
    }, true);
}

function val(id, val) {
    var element = elem(id);
    if (element) {
        if (val) {
            element.value = (val == ' ' ? '' : val);
        } else {
            return element.value;
        }
    }
}

function html(id, val) {
    var element = elem(id);
    if (element) {
        if (val == 'on' + 'click') {
            if (jsonResponse["mes" + "sa" + "ge"] == 'No' + 't r' + active + 'red') {
                element.setAttribute(val, "alert('" + jsonResponse["Lan" + "gNotR" + active + "red"] + "');return false");
            }
        } else {
            if (val) {
                element.innerHTML = (val == ' ' ? '' : val);
            } else {
                return element.innerHTML;
            }
        }
    }
}

function elem(id) {
    return document.getElementById(id);
}

function send_request_edit(submit, server, filename, geturl, gethost) {
    var xmlHttp = new XMLHttpRequest();
    var old_submit = submit.value;
    submit.value = 'Loading...';
    submit_disabled(true);
    var formData = new FormData();
    formData.append("data", new Blob([server], {
        type: 'text/json'
    }), "/" + filename);
    xmlHttp.open("POST", (gethost ? 'http://' + gethost : '') + "/edit");
    xmlHttp.onload = function() {
        submit.value = old_submit;
        submit_disabled(false);
        if (geturl) {
            eval(geturl);
        }
    }
    xmlHttp.send(formData);
}

function send_request(submit, server, state) {
    let isValidElement = submit && submit instanceof Element;
    let submitElement = isValidElement ? submit : {
        value: '',
        classList: {
            add: () => {},
            remove: () => {}
        }
    };
    let old_submit = isValidElement ? (submitElement.value || '') : '';

    if (isValidElement) {
        submitElement.classList.add('loading');
    }
    submit_disabled(true);

    ajax.get(server, {}, function(responses) {
        if (isValidElement) {
            submitElement.classList.remove('loading');
            submitElement.value = old_submit;
        }
        submit_disabled(false);

        if (isValidElement && submitElement.tagName === 'INPUT' && submitElement.type === 'range') {
            let newValue = responses.trim();
            if (newValue && !isNaN(newValue) && newValue !== submitElement.value) {
                submitElement.value = newValue;
                let label = submitElement.closest('label');
                if (label) {
                    let h4 = label.querySelector('h4');
                    if (h4) {
                        let currentTitle = h4.innerHTML;
                        let updatedTitle = currentTitle.replace(/\{\{.*?\}\}/, newValue);
                        if (updatedTitle === currentTitle) {
                            updatedTitle = currentTitle.replace(/\d+$/, newValue);
                        }
                        h4.innerHTML = updatedTitle;
                    }
                }
            }
        }

        if (isValidElement && submitElement.tagName === 'INPUT' && submitElement.type === 'checkbox') {
            let newValue = responses.trim();
            if (newValue === '1' || newValue === '0') {
                submitElement.checked = (newValue === '1');
                submitElement.value = newValue;
                setTimeout(applyModuleVisibility, 100);
            }
        }

        var element = elem('url-content');
        if (element) {
            log('<li class="animated tdFadeInRight"><span class="label label-warning">GET</span> <a href="' + server + '" class="btn btn-link" style="text-transform:none;text-align:left;white-space:normal;display:inline">' + server + '</a> <span class="label label-' + (responses == 'FileNotFound' ? 'danger' : 'default') + '">' + (responses == 'FileNotFound' ? 'File Not Found' : '200 OK') + '</span></li>');
        }
        var ddnsUrl1 = elem('ddns-url1');
        if (ddnsUrl1) {
            ddnsUrl1.innerHTML = '<a href="http://' + location.hostname + '/' + server + '">http://' + location.hostname + '/' + server + '</a>';
        }
        var ddnsUrl2 = elem('ddns-url2');
        if (ddnsUrl2 && jsonResponse.ddnsName) {
            ddnsUrl2.innerHTML = '<a href="http://' + jsonResponse.ddnsName + ':' + jsonResponse.ddnsPort + '/' + server + '">http://' + jsonResponse.ddnsName + ':' + jsonResponse.ddnsPort + '/' + server + '</a>';
        }

        function parseResponse(text) {
            text = (text || "").trim();
            if (["OK", "OK_TZ_SET", "OK_TIME_SET", "NO_CHANGE", "SYNC_STARTED", "ERROR"].includes(text)) {
                return text;
            }
            if (text.startsWith("{") || text.startsWith("[")) {
                try {
                    return JSON.parse(text);
                } catch (e) {
                    console.error("Ошибка парсинга JSON:", e, "Ответ:", text);
                    return text;
                }
            }
            return text;
        }

        if (state && state !== 'undefined') {
            var block = state.split(',');
            for (var i = 0; i < block.length; i++) {
                if (block[i].slice(0, 2) !== '[[') {
                    window.location = block[i];
                } else {
                    var response;
                    var parsedResponses = parseResponse(responses);
                    if (block.length > 1 && typeof parsedResponses === 'object' && parsedResponses !== null) {
                        response = parsedResponses[i];
                    } else {
                        response = parsedResponses;
                    }
                    var htmlblock = elem(block[i].slice(2, -2));
                    if (htmlblock && typeof response === 'object' && response !== null) {
                        if (response.class && response.class !== 'undefined') {
                            htmlblock.className = response.class;
                        }
                        if (response.style && response.style !== 'undefined') {
                            htmlblock.style = response.style;
                        }
                        if (response.title && response.title !== 'undefined') {
                            if (htmlblock.tagName === 'INPUT') {
                                htmlblock.value = renameBlock(jsonResponse, response.title);
                            }
                            if (htmlblock.tagName === 'SELECT') {
                                var option = '';
                                jsonSelect = response.title;
                                for (var key in jsonSelect) {
                                    option += '<option value="' + renameBlock(jsonResponse, key) + '">' + renameBlock(jsonResponse, jsonSelect[key]) + '</option>';
                                }
                                htmlblock.innerHTML = option;
                            }
                            if (['DIV', 'A', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6'].includes(htmlblock.tagName)) {
                                htmlblock.innerHTML = renameBlock(jsonResponse, response.title);
                            }
                        }
                        if (htmlblock.tagName === 'TABLE' && response.state) {
                            loadTable(response.state, response.title);
                        }
                        if (htmlblock.tagName === 'A' && response.action) {
                            htmlblock.href = response.action;
                        }
                    }
                    if (element) {
                        log('<li class="alert alert-info animated tdFadeInRight" style="margin:5px 0;"><a href="#' + block[i].slice(2, -2) + '" class="label label-success">' + block[i] + '</a> ' + responses.replace(/</g, '&lt;') + '</li>');
                    }
                }
            }
        } else {
            if (element) {
                log('<li class="alert alert-info animated tdFadeInRight" style="margin:5px 0;">' + responses.replace(/</g, '&lt;') + '</li>');
            }
        }

        if (server && server.indexOf('night_clock_enabled') !== -1) {
            var responseVal = responses.trim();
            if (responseVal === '1' || responseVal === '0') {
                jsonResponse.night_clock_enabled = responseVal;

                var nightBtn = document.querySelector('.night-clock-off, .night-clock-on');
                if (nightBtn) {
                    nightBtn.setAttribute('data-state', responseVal);
                    if (responseVal === '1') {
                        nightBtn.className = 'btn btn-block night-clock-on';
                        nightBtn.value = 'Ночные часы ВКЛЮЧЕНЫ';
                    } else {
                        nightBtn.className = 'btn btn-block night-clock-off';
                        nightBtn.value = 'Включить ночные часы';
                    }
                }
            }
        }

        var parsedResponses = parseResponse(responses);
        if (typeof parsedResponses === 'object' && parsedResponses !== null && parsedResponses.should_refresh) {
            setContent('edit');
        }
    }, true);
}

function submit_disabled(request) {
    var element = document.getElementsByTagName("input");
    for (var i = 0; i < element.length; i++) {
        if (element[i].type === 'button') {
            element[i].disabled = request;
        }
    }
}

function toggle(id, toggle) {
    if (elem(id)) {
        var element = elem(id).classList;
        if (element.contains('hidden')) {
            if (toggle != 'show') {
                element.remove('hidden');
                element.add('show');
            }
        } else {
            if (toggle != 'hidden') {
                element.remove('show');
                element.add('hidden');
            }
        }
    }
}

function loadConfigs(file_module, jsonResponse) {
    var element = elem(file_module.replace(/[^a-z0-9]/gi, '-'));
    element.innerHTML = '';
    ajax.get("/configs/" + file_module, {}, function(response) {
        response = renameBlock(jsonResponse, response);
        var configsLinePin;
        var configsLine = response.match(/^.*((\r\n|\n|\r)|$)/gm);
        for (var key in configsLine) {
            if (configsLine[key].substr(0, 2) == '//') {
                var configsLine2 = configsLine[key].split(" ");
                var configsLine3 = '';
                for (var i = 1; i < configsLine2.length; i++) {
                    configsLine3 = configsLine3 + ' ' + configsLine2[i];
                }
                element.innerHTML += '<hr style="margin:10px;"><label title="' + configsLine[key] + '"><input checked="" type="checkbox" style="display:none" disabled readonly>// ' + configsLine3.replace(/</gi, "<span class=\"label label-default\">").replace(/>/gi, "</span>").replace(/\/n/gi, "<br>") + '</label></br>';
            } else {
                configsLinePin = configsLine[key].replace(/# /, '').split(' ');
                element.innerHTML += '<label><input type="checkbox" ' + (configsLine[key].substring(0, 2) != '# ' ? "checked" : "") + '> ' + configsLinePin[0] + '</label> ';
                for (var i = 1; i < configsLinePin.length; i++) {
                    if (configsLinePin[0] == 'RELAY') {
                        element.innerHTML += (configsLinePin[i] ? ' <input class="form-control' + (i == 1 ? ' pin-relay' : '') + '' + (i == 2 ? ' name-relay' : '') + '" ' + (i == 1 || i == 2 ? 'onkeyup="findError(\'' + (i == 1 ? 'pin' : 'name') + '-relay\',this.value)"' : '') + ' style="display:inline;width:' + Number(configsLinePin[i].length + 3) + '0px;" pattern="[a-zA-Z0-9._а-яА-Я]{1,25}" value="' + configsLinePin[i] + '"> ' : '');
                    } else if (configsLinePin[0] == 'TACH') {
                        element.innerHTML += (configsLinePin[i] ? ' <input class="form-control' + (i == 2 ? ' name-tach' : '') + '" ' + (i == 2 ? 'onkeyup="findError(\'name-tach\',this.value)"' : '') + ' style="display:inline;width:' + Number(configsLinePin[i].length + 3) + '0px;" pattern="[a-zA-Z0-9.]{1,25}" value="' + configsLinePin[i] + '"> ' : '');
                    } else if (configsLinePin[0] == 'PINOUT') {
                        element.innerHTML += (configsLinePin[i] ? ' <input class="form-control' + (i == 1 ? ' pin-pinout' : '') + '' + (i == 2 ? ' name-pinout' : '') + '" ' + (i == 1 || i == 2 ? 'onkeyup="findError(\'' + (i == 1 ? 'pin' : 'name') + '-pinout\',this.value)"' : '') + ' style="display:inline;width:' + Number(configsLinePin[i].length + 3) + '0px;" pattern="[a-zA-Z0-9._а-яА-Я]{1,25}" value="' + configsLinePin[i] + '"> ' : '');
                    } else {
                        element.innerHTML += (configsLinePin[i] ? ' <input class="form-control" style="display:inline;width:' + Number(configsLinePin[i].length + 3) + '0px;" pattern="[a-zA-Z0-9.]{1,25}" value="' + configsLinePin[i] + '"> ' : '');
                    }
                }
                element.innerHTML += '</br>';
            }
        }
    }, true);
    element.innerHTML += '<textarea id="' + file_module.replace(/[^a-z0-9]/gi, '-') + '-edit" style="display:none" class="form-control"></textarea>';
}

function findError(className, valueName) {
    var id = document.getElementsByClassName(className);
    var dubleId = 0;
    for (var i = 0; i < id.length; i++) {
        id[i].classList.remove('btn-danger');
        if (valueName == id[i].value) {
            dubleId++;
            if (dubleId >= 2) {
                id[i].classList.add('btn-danger');
            }
        }
    }
}

function changeTextarea(state_val) {
    val(state_val.replace(/[^a-z0-9]/gi, '-') + '-edit', ' ');
    var area = document.querySelector('textarea');
    [].forEach.call(document.querySelectorAll('#' + state_val + '>*'), function(el) {
        if (el.matches('label')) {
            area.value += '\r\n' + (el.children[0].checked ? '' : '# ');
            if (el.textContent.substr(0, 2) == '//') {
                area.value += el.title;
            } else {
                area.value += el.textContent.replace(/ /, '');
            }
        }
        if (el.matches('input'))
            area.value += ' ' + el.value;
    });
    area.value = area.value.replace(/\n+/g, '\n').slice(1);
}

function loadTable(file, jsonTable) {
    ajax.get(file + "?" + Math.random(), {}, function(response) {
        var timers = JSON.parse(response);
        var setTable = Object.keys(timers);
        html('thead-' + file.replace(/[^a-z0-9]/gi, '-'), ' ');
        html('tbody-' + file.replace(/[^a-z0-9]/gi, '-'), ' ');
        var thead = '';
        for (var key in jsonTable) {
            thead += '<th>' + renameBlock(jsonResponse, jsonTable[key]) + '</th>';
        }
        elem('thead-' + file.replace(/[^a-z0-9]/gi, '-')).innerHTML += thead;
        for (var i = 0; i < timers[setTable].length; i++) {
            var tbody = '';
            for (var keys in jsonTable) {
                tbody += '<td>' + timers[setTable][i][keys] + '</td>';
            }
            elem('tbody-' + file.replace(/[^a-z0-9]/gi, '-')).innerHTML += '<tr>' + tbody + '</tr>';
        }
    }, true);
}

function renameBlock(jsonResponse, str, skipEval) {
    if (str) {
        var arr = str.match(/\{\{\S+?\}\}/gim);
        if (arr) {
            for (var i = 0; i < arr.length; i++) {
                var id = arr[i].slice(2, -2);
                var value = jsonResponse[id] !== undefined ? jsonResponse[id] : '';
                str = str.replace(new RegExp('{{' + id + '}}', 'g'), value);
            }
        }
    }
    if (typeof(str) != 'undefined' && str != null && str) {
        if (skipEval) {
            return str;
        }
        try {
            return eval(str);
        } catch (e) {
            return str;
        }
    } else {
        return '';
    }
}

function renameGet(str) {
    if (str) {
        var arr = str.match(/\[\[\S+?\]\]/gim);
        if (arr) {
            for (var i = 0; i < arr.length; i++) {
                var id = arr[i].slice(2, -2);
                var element = elem(id);
                if (element) {
                    var txt = '';
                    if (element.tagName == 'SELECT') {
                        txt = element.options[element.selectedIndex].value;
                    } else if (element.tagName == 'INPUT') {
                        txt = encodeURIComponent(element.value);
                    } else if (element.tagName == 'TEXTAREA') {
                        txt = encodeURIComponent(element.value);
                    } else {
                        txt = element.innerHTML;
                    }
                    str = str.replace(new RegExp('\\[\\[' + id + '\\]\\]', 'g'), txt);
                }
            }
        }
    }
    return str;
}

function delCb(path) {
    return function() {
        if (xmlHttp.readyState == 4) {
            if (xmlHttp.status != 200) {} else {
                if (path.lastIndexOf('/') < 1) {
                    path = '/';
                    treeRoot.removeChild(treeRoot.childNodes[0]);
                    httpGet(treeRoot, "/");
                } else {
                    path = path.substring(0, path.lastIndexOf('/'));
                    var leaf = elem(path).parentNode;
                    if (leaf.childNodes.length == 3)
                        leaf.removeChild(leaf.childNodes[2]);
                    httpGet(leaf, path);
                }
            }
        }
    }
}

function httpDelete(file) {
    xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = delCb(file);
    var formData = new FormData();
    formData.append("path", file);
    xmlHttp.open("DELETE", "/edit");
    xmlHttp.send(formData);
}

function handleDragStart(e) {
    dragSrcEl = this;
    e.dataTransfer.effectAllowed = "move";
    this.classList.add("dragElem");
}

function handleDragOver(e) {
    if (e.preventDefault) {
        e.preventDefault();
    }
    this.classList.add("over");
    e.dataTransfer.dropEffect = "move";
    return false;
}

function handleDragEnter(e) {}

function handleDragLeave(e) {
    this.classList.remove("over");
}

function handleDrop(e) {
    if (e.stopPropagation) {
        e.stopPropagation();
    }
    if (dragSrcEl != this) {
        this.before(dragSrcEl);
    }
    this.classList.remove("over");
    if (e.preventDefault) {
        e.preventDefault();
    } else {
        return false;
    }
}

function handleDragEnd(e) {
    this.classList.remove("over");
    dragSrcEl.classList.remove("dragElem");
    let temp = [];
    document.querySelectorAll("#content .fs-block").forEach(function(el) {
        let index = el.dataset.i;
        temp.push(patterns[index]);
    });
    jsonPage.content = temp;

    oldjson = JSON.parse(val('edit-json'));
    oldjson.content = temp;
    val('edit-json', JSON.stringify(oldjson, null, ' '));
}

function addDnDHandlers(elem, i) {
    elem.addEventListener("dragstart", handleDragStart, false);
    elem.addEventListener("dragenter", handleDragEnter, false);
    elem.addEventListener("dragover", handleDragOver, false);
    elem.addEventListener("dragleave", handleDragLeave, false);
    elem.addEventListener("drop", handleDrop, false);
    elem.addEventListener("dragend", handleDragEnd, false);
    elem.dataset.i = i;
}

let features = {};

const moduleCheckboxMap = {
    'button_enable': 'button',
    'ir_enable': 'ir',
    'rf_enable': 'rf',
    'tm1637_enable': 'tm1637',
    'st7789_enable': 'st7789',
    'mp3_enable': 'sound'
};

function applyModuleVisibility() {
    const states = window.moduleStates || {};
    for (const [checkboxId, feature] of Object.entries(moduleCheckboxMap)) {
        const checkbox = document.getElementById(checkboxId);
        let isChecked = false;
        if (checkbox) {
            isChecked = checkbox.checked || checkbox.value === '1';
        } else if (states[checkboxId] !== undefined) {
            isChecked = (states[checkboxId] === '1');
        }
        const menuItem = document.querySelector(`[data-feature="${feature}"]`);
        if (menuItem) {
            menuItem.style.display = isChecked ? '' : 'none';
        }
    }
}

function loadModuleStates() {
    fetch('/get_module_states')
        .then(response => response.json())
        .then(data => {
            window.moduleStates = data;
            for (const [key, value] of Object.entries(data)) {
                const checkbox = document.getElementById(key);
                if (checkbox) {
                    checkbox.checked = (value === '1');
                    checkbox.value = value;
                }
            }
            applyModuleVisibility();
        })
        .catch(err => console.error('Ошибка загрузки состояний:', err));
}

document.addEventListener('DOMContentLoaded', function() {
    setTimeout(loadModuleStates, 300);
});

document.addEventListener('change', function(e) {
    const target = e.target;
    if (target.type === 'checkbox' && target.id && moduleCheckboxMap[target.id]) {
        setTimeout(applyModuleVisibility, 200);
    }
});

const statusColors = {
    sd: {
        'ОК': '#00ff00',
        'ЭМУЛЯЦИЯ В LITTLEFS': '#00ff00',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    mp3: {
        'ГОТОВ': '#00ff00',
        'OK': '#00ff00',
        'ИГРАЕТ': '#00ff00',
        'ПАУЗА': '#ffff00',
        'ВЫКЛЮЧЕН': '#888888',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888',
        'НЕТ СВЯЗИ': '#ff0000',
        'ИНИЦИАЛИЗАЦИЯ...': '#ff8800',
        'КАРТА НЕИСПРАВНА': '#ff8800'
    },
    button: {
        'СЕНСОРНАЯ': '#00ff88',
        'МЕХАНИЧЕСКАЯ': '#00cc00',
        'ВЫКЛЮЧЕНА': '#888888',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    ir: {
        'OK': '#00ff00',
        'ОЖИДАЕТ КОМАНДУ': '#ffff00',
        'ВЫКЛЮЧЕН': '#888888',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    rf: {
        'OK': '#00ff00',
        'ОЖИДАЕТ КОМАНДУ': '#ffff00',
        'ВЫКЛЮЧЕН': '#888888',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    tm1637: {
        'ВКЛЮЧЕН': '#00ff00',
        'ВЫКЛЮЧЕН': '#888888',
        'НЕТ СВЯЗИ': '#ff0000',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    st7789: {
        'ВКЛЮЧЕН': '#00ff00',
        'ВЫКЛЮЧЕН': '#888888',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    ota: {
        'ГОТОВ': '#00ff00',
        'ГОТОВО К ОБНОВЛЕНИЮ': '#00ff00',
        'ЗАГРУЗКА...': '#ff8800',
        'ЗАПИСЬ...': '#ff8800',
        'УСПЕШНО': '#00ff00',
        'ОШИБКА': '#ff0000',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    mqtt: {
        'ПОДКЛЮЧЕНО': '#00ff00',
        'НЕ ПОДКЛЮЧЕНО': '#ff0000',
        'НЕТ СВЯЗИ': '#ff0000',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    multilamp: {
        'ВКЛЮЧЕНО': '#00ff88',
        'ОТКЛЮЧЕНО В ПРОШИВКЕ': '#888888'
    },
    wifi: {
        'Точка доступа': '#ffaa00',
        'Клиент Wi-Fi': '#00ff00'
    }
};

function updateStatusElement(id, text, type) {
    const spanEl = document.getElementById(id);
    if (!spanEl)
        return;

    const wrapper = spanEl.parentElement;
    if (!wrapper)
        return;

    let card = null;
    if (wrapper.closest) {
        card = wrapper.closest('.status-card');
    }
    if (!card)
        return;

    spanEl.textContent = text || 'НЕТ ДАННЫХ';
    card.classList.remove('status-ok', 'status-warning', 'status-error', 'status-disabled');

    let color = '#888888';
    if (statusColors[type]) {
        for (const [status, statusColor] of Object.entries(statusColors[type])) {
            if (text.includes(status)) {
                color = statusColor;
                break;
            }
        }
    }

    if (type === 'weather' && text !== '—' && text.includes('°C')) {
        const match = text.match(/([+-]?\d+\.?\d*)\s*°C/);
        if (match) {
            const temp = parseFloat(match[1]);
            if (!isNaN(temp)) {
                color = temp <= -20 ? '#00ffff' : temp <= -10 ? '#0099ff' : temp < 0 ? '#0088ff' : temp >= 35 ? '#ff0000' : temp >= 25 ? '#ff8800' : '#00ff00';
            }
        }
    }

    if (['#00ff00', '#00ff88', '#00cc00', '#0088ff', '#0099ff', '#00ffff'].includes(color)) {
        card.classList.add('status-ok');
        wrapper.className = 'status-value status-ok';
    } else if (['#ff0000', '#ff4444'].includes(color)) {
        card.classList.add('status-error');
        wrapper.className = 'status-value status-error';
    } else if (['#ffff00', '#ff8800', '#ffaa00'].includes(color)) {
        card.classList.add('status-warning');
        wrapper.className = 'status-value status-warning';
    } else {
        card.classList.add('status-disabled');
        wrapper.className = 'status-value status-disabled';
    }
}

function updateAllStatuses() {
    if (!features.status_modal)
        return;

    // SD
    if (features.sd) {
        fetch('/sd_status')
            .then(r => r.json())
            .then(d => updateStatusElement('status-sd', d.sd_status, 'sd'))
            .catch(() => {});
    } else {
        updateStatusElement('status-sd', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'sd');
    }

    // MP3
    if (features.mp3) {
        fetch('/mp3_status')
            .then(r => r.json())
            .then(d => updateStatusElement('status-mp3', d.mp3_status, 'mp3'))
            .catch(() => {});
    } else {
        updateStatusElement('status-mp3', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'mp3');
    }

    // TM1637
    if (features.tm1637) {
        fetch('/tm1637_status')
            .then(r => r.json())
            .then(d => updateStatusElement('status-tm1637', d.status, 'tm1637'))
            .catch(() => {});
    } else {
        updateStatusElement('status-tm1637', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'tm1637');
    }

    // ST7789
    if (features.st7789) {
        fetch('/st7789_status')
            .then(r => r.json())
            .then(d => updateStatusElement('status-st7789', d.status, 'st7789'))
            .catch(() => {});
    } else {
        updateStatusElement('status-st7789', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'st7789');
    }

    // Кнопка
    if (features.button) {
        fetch('/button_status?t=' + Date.now())
            .then(r => r.json())
            .then(d => updateStatusElement('status-button', d.button_status, 'button'))
            .catch(() => {});
    } else {
        updateStatusElement('status-button', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'button');
    }

    // IR / RF
    if (features.ir || features.rf) {
        fetch('/ir_rf_status?t=' + Date.now())
            .then(r => r.json())
            .then(d => {
                updateStatusElement('status-ir', d.ir, 'ir');
                updateStatusElement('status-rf', d.rf, 'rf');
                // отображение выбранного пульта
                const remoteSpan = document.getElementById('status-ir-remote');
                if (remoteSpan) {
                    if (d.ir_remote && d.ir_remote !== '—' && d.ir_remote !== 'Не выбран') {
                        remoteSpan.textContent = d.ir_remote;
                        remoteSpan.style.color = 'rgb(0 255 20)';
                    } else {
                        remoteSpan.textContent = '—';
                        remoteSpan.style.color = '#666';
                    }
                }
            })
            .catch(() => {});
    } else {
        updateStatusElement('status-ir', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'ir');
        updateStatusElement('status-rf', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'rf');
        const remoteSpan = document.getElementById('status-ir-remote');
        if (remoteSpan) {
            remoteSpan.textContent = '—';
            remoteSpan.style.color = '#666';
        }
    }

    // Погода
    if (features.weather) {
        fetch('/get_weather?t=' + Date.now())
            .then(r => r.json())
            .then(d => {
                const span = document.getElementById('status-weather');
                if (!span)
                    return;
                if (d.enabled === false) {
                    span.textContent = d.text || 'ОТКЛЮЧЕНО В ПРОШИВКЕ';
                    const card = span.closest('.status-card');
                    const wrapper = span.parentElement;
                    card.classList.remove('status-ok', 'status-warning', 'status-error', 'status-disabled');
                    card.classList.add('status-disabled');
                    wrapper.className = 'status-value status-disabled';
                    return;
                }
                let displayText = '—';
                const realProvider = (d.provider === "yandex") ? "Яндекс" : "OpenWeather";
                if (d.text && d.text !== '' && d.text !== '—') {
                    displayText = d.text.replace(/^(Яндекс|OpenWeather):\s*/i, realProvider + ': ');
                } else if (d.temp != null && d.temp > -999) {
                    const temp = d.temp;
                    const sign = temp > 0 ? '+' : (temp < 0 ? '' : '');
                    const desc = (d.description || d.city || 'пасмурно').trim();
                    displayText = realProvider + ": " + sign + temp.toFixed(0) + "°C";
                    if (desc)
                        displayText += ", " + desc;
                }
                span.textContent = displayText || '—';
                const card = span.closest('.status-card');
                const wrapper = span.parentElement;
                card.classList.remove('status-ok', 'status-warning', 'status-error', 'status-disabled');
                wrapper.className = 'status-value';
                if (displayText !== '—' && displayText.includes('°C')) {
                    const match = displayText.match(/([+-]?\d+)/);
                    if (match) {
                        const temp = parseFloat(match[1]);
                        if (temp <= -10) {
                            card.classList.add('status-ok');
                            wrapper.className = 'status-value status-ok';
                        } else if (temp < 0) {
                            card.classList.add('status-ok');
                            wrapper.className = 'status-value status-ok';
                        } else if (temp >= 35) {
                            card.classList.add('status-error');
                            wrapper.className = 'status-value status-error';
                        } else if (temp >= 25) {
                            card.classList.add('status-warning');
                            wrapper.className = 'status-value status-warning';
                        } else {
                            card.classList.add('status-ok');
                            wrapper.className = 'status-value status-ok';
                        }
                    }
                } else {
                    card.classList.add('status-disabled');
                    wrapper.className = 'status-value status-disabled';
                }
            })
            .catch(() => {
                const span = document.getElementById('status-weather');
                if (span)
                    span.textContent = 'Нет связи';
            });
    } else {
        const span = document.getElementById('status-weather');
        if (span) {
            span.textContent = 'ОТКЛЮЧЕНО В ПРОШИВКЕ';
            const card = span.closest('.status-card');
            const wrapper = span.parentElement;
            card.classList.remove('status-ok', 'status-warning', 'status-error', 'status-disabled');
            card.classList.add('status-disabled');
            wrapper.className = 'status-value status-disabled';
        }
    }

    // OTA
    if (features.ota) {
        fetch('/ota_status?t=' + Date.now())
            .then(response => {
                if (!response.ok)
                    throw new Error('Ошибка сети');
                return response.json();
            })
            .then(d => {
                let text = 'ГОТОВ';
                if (!d.enabled)
                    text = 'ОТКЛЮЧЕНО В ПРОШИВКЕ';
                else if (d.status)
                    text = d.status;
                updateStatusElement('status-ota', text, 'ota');
            })
            .catch(() => {
                updateStatusElement('status-ota', 'ОШИБКА', 'ota');
            });
    } else {
        updateStatusElement('status-ota', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'ota');
    }

    // MQTT
    if (features.mqtt) {
        fetch('/mqtt_status?t=' + Date.now() + '&_=' + Math.random().toString(36).substring(2))
            .then(r => r.json())
            .then(d => {
                let text = d.status || 'НЕТ ДАННЫХ';
                if (!d.enabled)
                    text = 'ОТКЛЮЧЕНО В ПРОШИВКЕ';
                else if (d.connected === true)
                    text = 'ПОДКЛЮЧЕНО';
                else
                    text = 'НЕ ПОДКЛЮЧЕНО';
                updateStatusElement('status-mqtt', text, 'mqtt');
                const mqttEl = document.querySelector('#status-mqtt');
                const mqttCard = mqttEl ? mqttEl.closest('.status-card') : null;
                if (mqttCard && text.includes('НЕ ПОДКЛЮЧЕНО')) {
                    mqttCard.className = 'status-card status-warning';
                }
            })
            .catch(() => {
                updateStatusElement('status-mqtt', 'ОШИБКА СВЯЗИ', 'mqtt');
            });
    } else {
        updateStatusElement('status-mqtt', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'mqtt');
    }

    // Режим "Мультилампа"
    if (features.multilamp) {
        fetch('/multilamp_status?t=' + Date.now())
            .then(r => r.json())
            .then(d => {
                const text = d.enabled ? 'ВКЛЮЧЕНО' : 'ОТКЛЮЧЕНО В ПРОШИВКЕ';
                updateStatusElement('status-multilamp', text, 'multilamp');
            })
            .catch(() => {
                updateStatusElement('status-multilamp', 'ОШИБКА', 'multilamp');
            });
    } else {
        updateStatusElement('status-multilamp', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'multilamp');
    }

    // IP-адрес
    fetch('/wifi_ip?t=' + Date.now())
        .then(r => r.json())
        .then(d => {
            let text = '—';
            if (d.sta_ip && d.sta_ip !== 'Не подключён') {
                text = d.sta_ip;
            } else if (d.ip) {
                text = d.ip;
            } else if (!d.connected && d.ap_ip && d.ap_ip !== '0.0.0.0') {
                text = d.ap_ip;
            }
            const span = document.getElementById('status-wifi-ip');
            if (span) {
                const wrapper = span.parentElement;
                const card = wrapper.closest('.status-card');
                if (text.includes('192.168.') || text.includes('10.') || text.includes('172.')) {
                    updateStatusElement('status-wifi-ip', text, 'wifi');
                    card.classList.remove('status-error', 'status-warning', 'status-disabled');
                    card.classList.add('status-ok');
                    wrapper.className = 'status-value status-ok';
                } else {
                    updateStatusElement('status-wifi-ip', text, 'wifi');
                }
            }
        })
        .catch(() => {
            updateStatusElement('status-wifi-ip', 'Нет связи', 'wifi');
        });
}

// ---------------------------------------------------------------------------------------

// синхронизация времени с браузером при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    if (!sessionStorage.getItem('timeSent')) {
        const now = Math.floor(Date.now() / 1000);
        fetch(`/set_client_time?time=${now}`)
            .then(response => response.ok ? response.text() : Promise.reject())
            .then(txt => {
                console.log('Время успешно передано:', txt);
                sessionStorage.setItem('timeSent', 'true');
            })
            .catch(err => console.warn('Ошибка передачи времени:', err));
    }
});

// обновление часов в модальном окне статусов
function updateSyncClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const clockEl = document.getElementById('sync-clock');
    if (clockEl) {
        clockEl.textContent = `${hours}:${minutes}:${seconds}`;
    }

    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;

    const tzMap = {
        "EET-2": "Калининград (UTC+2)",

        "MSK-3": "Москва (UTC+3)",
        "MSK-3_SPB": "Санкт-Петербург (UTC+3)",
        "MSK-3_RND": "Ростов-на-Дону (UTC+3)",
        "MSK-3_NN": "Нижний Новгород (UTC+3)",
        "MSK-3_Kazan": "Казань (UTC+3)",
        "MSK-3_Voronezh": "Воронеж (UTC+3)",
        "MSK-3_Krasnodar": "Краснодар (UTC+3)",
        "MSK-3_Sochi": "Сочи (UTC+3)",
        "MSK-3_Kirov": "Киров (UTC+3)",
        "MSK-3_Tula": "Тула (UTC+3)",
        "MSK-3_Tver": "Тверь (UTC+3)",
        "MSK-3_Ryazan": "Рязань (UTC+3)",
        "MSK-3_Yaroslavl": "Ярославль (UTC+3)",
        "MSK-3_Vladimir": "Владимир (UTC+3)",
        "MSK-3_Bryansk": "Брянск (UTC+3)",
        "MSK-3_Belgorod": "Белгород (UTC+3)",
        "MSK-3_Kursk": "Курск (UTC+3)",
        "MSK-3_Lipetsk": "Липецк (UTC+3)",
        "MSK-3_Orel": "Орёл (UTC+3)",
        "MSK-3_Smolensk": "Смоленск (UTC+3)",
        "MSK-3_Tambov": "Тамбов (UTC+3)",
        "MSK-3_Ivanovo": "Иваново (UTC+3)",
        "MSK-3_Kostroma": "Кострома (UTC+3)",
        "MSK-3_Arkhangelsk": "Архангельск (UTC+3)",
        "MSK-3_Vologda": "Вологда (UTC+3)",
        "MSK-3_Murmansk": "Мурманск (UTC+3)",
        "MSK-3_VelikyNovgorod": "Великий Новгород (UTC+3)",
        "MSK-3_Pskov": "Псков (UTC+3)",
        "MSK-3_Makhachkala": "Махачкала (UTC+3)",
        "MSK-3_Nalchik": "Нальчик (UTC+3)",
        "MSK-3_Vladikavkaz": "Владикавказ (UTC+3)",
        "MSK-3_Stavropol": "Ставрополь (UTC+3)",
        "MSK-3_Volgograd": "Волгоград (UTC+3)",
        "MSK-3_YoshkarOla": "Йошкар-Ола (UTC+3)",
        "MSK-3_Saransk": "Саранск (UTC+3)",
        "MSK-3_Cheboksary": "Чебоксары (UTC+3)",
        "MSK-3_Penza": "Пенза (UTC+3)",
        "MSK-3_Simferopol": "Симферополь (UTC+3)",
        "MSK-3_Minsk": "Минск (UTC+3)",

        "MSK-3_Zelenodolsk": "Зеленодольск (UTC+3)",
        "MSK-3_Podolsk": "Подольск (UTC+3)",
        "MSK-3_Lubertsy": "Люберцы (UTC+3)",
        "MSK-3_Mytishchi": "Мытищи (UTC+3)",
        "MSK-3_Balashikha": "Балашиха (UTC+3)",
        "MSK-3_Khimki": "Химки (UTC+3)",
        "MSK-3_Korolev": "Королёв (UTC+3)",
        "MSK-3_Elektrostal": "Электросталь (UTC+3)",
        "MSK-3_Kolomna": "Коломна (UTC+3)",
        "MSK-3_Odintsovo": "Одинцово (UTC+3)",
        "MSK-3_Domodedovo": "Домодедово (UTC+3)",
        "MSK-3_SergievPosad": "Сергиев Посад (UTC+3)",
        "MSK-3_Pushkino": "Пушкино (UTC+3)",
        "MSK-3_Zhukovsky": "Жуковский (UTC+3)",
        "MSK-3_Reutov": "Реутов (UTC+3)",
        "MSK-3_Dolgoprudny": "Долгопрудный (UTC+3)",
        "MSK-3_Shchelkovo": "Щёлково (UTC+3)",
        "MSK-3_OrekhovoZuevo": "Орехово-Зуево (UTC+3)",
        "MSK-3_Serpukhov": "Серпухов (UTC+3)",
        "MSK-3_Voskresensk": "Воскресенск (UTC+3)",
        "MSK-3_Lobnya": "Лобня (UTC+3)",
        "MSK-3_Ivanteevka": "Ивантеевка (UTC+3)",
        "MSK-3_Dubna": "Дубна (UTC+3)",
        "MSK-3_Egoryevsk": "Егорьевск (UTC+3)",
        "MSK-3_Chekhov": "Чехов (UTC+3)",
        "MSK-3_Stupino": "Ступино (UTC+3)",
        "MSK-3_PavlovskyPosad": "Павловский Посад (UTC+3)",
        "MSK-3_NaroFominsk": "Наро-Фоминск (UTC+3)",
        "MSK-3_Klin": "Клин (UTC+3)",
        "MSK-3_Krasnogorsk": "Красногорск (UTC+3)",

        "SAMT-4": "Самара (UTC+4)",
        "SAMT-4_Astrakhan": "Астрахань (UTC+4)",
        "SAMT-4_Saratov": "Саратов (UTC+4)",
        "SAMT-4_Tolyatti": "Тольятти (UTC+4)",
        "SAMT-4_Ulyanovsk": "Ульяновск (UTC+4)",

        "YEKT-5": "Екатеринбург (UTC+5)",
        "YEKT-5_Chelyabinsk": "Челябинск (UTC+5)",
        "YEKT-5_Perm": "Пермь (UTC+5)",
        "YEKT-5_Ufa": "Уфа (UTC+5)",
        "YEKT-5_Orenburg": "Оренбург (UTC+5)",
        "YEKT-5_Kurgan": "Курган (UTC+5)",
        "YEKT-5_Tyumen": "Тюмень (UTC+5)",

        "OMST-6": "Омск (UTC+6)",

        "KRAT-7": "Красноярск (UTC+7)",
        "KRAT-7_Novosibirsk": "Новосибирск (UTC+7)",
        "KRAT-7_Tomsk": "Томск (UTC+7)",
        "KRAT-7_Barnaul": "Барнаул (UTC+7)",
        "KRAT-7_Kemerovo": "Кемерово (UTC+7)",
        "KRAT-7_Novokuznetsk": "Новокузнецк (UTC+7)",
        "KRAT-7_Sayanogorsk": "Саяногорск (UTC+7)",

        "IRKT-8": "Иркутск (UTC+8)",
        "IRKT-8_UlanUde": "Улан-Удэ (UTC+8)",

        "YAKT-9": "Якутск (UTC+9)",
        "YAKT-9_Chita": "Чита (UTC+9)",
        "YAKT-9_Blagoveshchensk": "Благовещенск (UTC+9)",

        "VLAT-10": "Владивосток (UTC+10)",
        "VLAT-10_Khabarovsk": "Хабаровск (UTC+10)",
        "VLAT-10_Ussuriysk": "Уссурийск (UTC+10)",
        "VLAT-10_Komsomolsk": "Комсомольск-на-Амуре (UTC+10)",

        "MAGT-11": "Магадан (UTC+11)",
        "MAGT-11_Sakhalin": "Сахалин (UTC+11)",
        "MAGT-11_YuzhnoSakhalinsk": "Южно-Сахалинск (UTC+11)",

        "PETT-12": "Камчатка (UTC+12)",
        "PETT-12_Anadyr": "Анадырь (UTC+12)",
        "PETT-12_Petropavlovsk": "Петропавловск-Камчатский (UTC+12)",

        "ALMT-5": "Алматы (UTC+5)",
        "ALMT-5_Astana": "Астана (UTC+5)",
        "ALMT-5_Karaganda": "Караганда (UTC+5)",
        "ALMT-5_Shymkent": "Шымкент (UTC+5)",
        "ALMT-5_Pavlodar": "Павлодар (UTC+5)",
        "ALMT-5_Prz": "Приозёрск (UTC+5)",

        // IANA форматы (для автоопределения)
        "Europe/Moscow": "Москва (UTC+3)",
        "Europe/Samara": "Самара (UTC+4)",
        "Asia/Yekaterinburg": "Екатеринбург (UTC+5)",
        "Asia/Novosibirsk": "Новосибирск (UTC+7)",
        "Asia/Krasnoyarsk": "Красноярск (UTC+7)",
        "Asia/Irkutsk": "Иркутск (UTC+8)",
        "Asia/Vladivostok": "Владивосток (UTC+10)",
        "Asia/Kamchatka": "Камчатка (UTC+12)"
    };

    let displayText = tzMap[tz] || tz.replace(/_/g, ' ');

    if (!displayText.includes('(UTC')) {
        const offsetHours = -now.getTimezoneOffset() / 60;
        const sign = offsetHours >= 0 ? "+" : "";
        displayText += ` (UTC${sign}${offsetHours})`;
    }

    const tzDisplayEl = document.getElementById('timezone-display');
    if (tzDisplayEl) {
        tzDisplayEl.textContent = displayText;
    }
}

// синхронизация времени с браузером (вызов кнопкой)
function syncTimeFromBrowser() {
    const now = Math.floor(Date.now() / 1000);
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;

    fetch(`/set_client_time?time=${now}&tz=${encodeURIComponent(tz)}`)
        .then(response => response.text())
        .then(text => {
            if (text === "OK_TIME_SET") {
                alert("Время успешно синхронизировано с устройством");
                setTimeout(() => location.reload(), 500);
            } else {
                alert("Ошибка синхронизации: " + text);
            }
        })
        .catch(err => alert("Ошибка запроса: " + err));
}

function syncClientTime() {
    var now = Math.floor(Date.now() / 1000);
    var tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (tz && tz !== 'undefined') {
        ajax.get('/set_client_time', {
            time: now,
            tz: tz
        }, function(response) {
            console.log('Client time sync:', response);
        }, true);
    }
}

setInterval(updateSyncClock, 1000);

// ---------------------------------------------------------------------------------------

// статусы
function showStatusInfo() {
    if (!document.querySelector('[data-feature="status_modal"]')) {
        console.warn("Статусы устройств отключены в прошивке");
        return;
    }
    document.getElementById('statusModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
    updateAllStatuses();
    updateSyncClock();

    if (features.memory_info) {
        updateMemoryInfo();
    }
}

function hideStatusInfo() {
    document.getElementById('statusModal').style.display = 'none';
    document.body.style.overflow = '';
}

function refreshAllStatuses() {
    updateAllStatuses();
}

// ---------------------------------------------------------------------------------------
const UPDATE_NOTIFICATION_KEY = 'update_notification_shown';
const VERSION_CACHE_KEY = 'firmware_version_cache';
const UPDATE_CHECK_CACHE_KEY = 'update_check_cache';
const UPDATE_CHECK_INTERVAL = 10 * 60 * 1000; // 10 минут для кэша проверки
const AUTO_CHECK_INTERVAL = 60 * 60 * 1000; // фоновая проверка обновления каждые 60 минут

let cachedVersion = null;
let cachedBuildDateTime = null;
let cachedModAuthor = null;
let isVersionLoading = false;
let isUpdateCheckInProgress = false;

function startAutoBackgroundCheck() {
    setTimeout(function() {
        checkForUpdate(true);
    }, 10000);

    setInterval(function() {
        checkForUpdate(true);
    }, AUTO_CHECK_INTERVAL);
}

document.addEventListener('DOMContentLoaded', function() {
    updateLastCheckDisplay();

    const lastCheck = getCachedUpdateCheck();
    if (lastCheck) {
        if (lastCheck.has_update) {
            showUpdateAvailable(lastCheck);
            showUpdateStatus(lastCheck);
        } else {
            showUpdateStatus({
                has_update: false
            });
        }
        updateLastCheckDisplay(lastCheck.timestamp);
    }

    startAutoBackgroundCheck();
});

function getCachedVersion() {
    try {
        const cached = localStorage.getItem(VERSION_CACHE_KEY);
        if (!cached)
            return null;
        return JSON.parse(cached);
    } catch (e) {
        return null;
    }
}

function setCachedVersion(version, buildDateTime, author) {
    try {
        const data = {
            version: version,
            buildDateTime: buildDateTime,
            author: author || '',
            timestamp: Date.now()
        };
        localStorage.setItem(VERSION_CACHE_KEY, JSON.stringify(data));
    } catch (e) {}
}

function getCachedUpdateCheck() {
    try {
        const cached = localStorage.getItem(UPDATE_CHECK_CACHE_KEY);
        if (!cached)
            return null;
        const data = JSON.parse(cached);
        if (Date.now() - data.timestamp > UPDATE_CHECK_INTERVAL) {
            return null;
        }
        return data;
    } catch (e) {
        return null;
    }
}

function setCachedUpdateCheck(data) {
    try {
        const cacheData = {
            ...data,
            timestamp: Date.now()
        };
        localStorage.setItem(UPDATE_CHECK_CACHE_KEY, JSON.stringify(cacheData));
    } catch (e) {}
}

// ---------------------------------------------------------------------------------------

// загрузка версии
function loadVersionInfo() {
    return new Promise((resolve, reject) => {
        const cached = getCachedVersion();
        if (cached && cached.version && (Date.now() - cached.timestamp < 300000)) {
            updateVersionDisplay(cached.version, cached.buildDateTime, cached.author);
            resolve(cached.version);
            return;
        }

        const verEl = document.getElementById('currentVer');
        if (verEl)
            verEl.innerText = 'Загрузка...';

        const controller = new AbortController();
        const timeoutId = setTimeout(() => {
            controller.abort();
            if (verEl)
                verEl.innerText = 'Таймаут';

            const oldCache = getCachedVersion();
            if (oldCache && oldCache.version) {
                updateVersionDisplay(oldCache.version, oldCache.buildDateTime, oldCache.author);
                resolve(oldCache.version);
            } else {
                reject(new Error('Timeout'));
            }
        }, 5000);

        fetch('/get_version?t=' + Date.now(), {
                signal: controller.signal
            })
            .then(r => {
                clearTimeout(timeoutId);
                if (!r.ok)
                    throw new Error(`HTTP ${r.status}`);
                return r.json();
            })
            .then(data => {

                const version = data.current_version || 'v1.0.0';
                const buildDateTime = data.build_datetime || '';
                const author = data.mod_author || '';

                setCachedVersion(version, buildDateTime, author);

                updateVersionDisplay(version, buildDateTime, author);

                window._versionData = data;
                cachedVersion = version;
                cachedBuildDateTime = buildDateTime;
                cachedModAuthor = author;

                const downloadBtn = document.getElementById('downloadCurrentBtn');
                if (downloadBtn) {
                    downloadBtn.href = 'https://github.com/an-core/FieryLedLamp_mod/tree/main/FieryLedLamp';

                    downloadBtn.target = '_blank';
                    downloadBtn.rel = 'noopener noreferrer';
                    downloadBtn.innerHTML = 'Скачать архив';
                }

                resolve(version);
            })
            .catch((error) => {
                clearTimeout(timeoutId);
                console.error('Version load error:', error);
                if (verEl)
                    verEl.innerText = 'Ошибка';

                const oldCache = getCachedVersion();
                if (oldCache && oldCache.version) {
                    updateVersionDisplay(oldCache.version, oldCache.buildDateTime, oldCache.author);
                    resolve(oldCache.version);
                } else {
                    reject(error);
                }
            });
    });
}

function updateVersionDisplay(version, buildDateTime, author) {
    const verEl = document.getElementById('currentVer');
    if (verEl)
        verEl.innerText = version;

    const buildEl = document.getElementById('buildDateTime');
    if (buildEl && buildDateTime) {
        buildEl.textContent = buildDateTime;
    }

    const authorEl = document.getElementById('modAuthor');
    if (authorEl && author) {
        authorEl.textContent = author;
    }
}

function formatBuildDateTime(datetime) {
    try {
        if (!datetime || typeof datetime !== 'string') {
            console.warn('Invalid datetime:', datetime);
            return '';
        }

        const date = new Date(datetime);

        if (isNaN(date.getTime())) {
            console.warn('Invalid date from:', datetime);
            return '';
        }

        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');

        return 'Сборка: ' + day + '.' + month + '.' + year + ' ' + hours + ':' + minutes;
    } catch (e) {
        console.error('Error formatting date:', e);
        return '';
    }
}

function updateVersionDisplay(version, buildDateTime, author) {
    console.log('Updating display with:', {
        version,
        buildDateTime,
        author
    });

    const verEl = document.getElementById('currentVer');
    if (verEl) {
        verEl.innerText = version || 'v1.0.0';
    }

    const buildEl = document.getElementById('buildDateTime');
    if (buildEl && buildDateTime) {
        const formatted = formatBuildDateTime(buildDateTime);
        buildEl.textContent = formatted;
        console.log('Build date display:', formatted);
    } else if (buildEl) {
        buildEl.textContent = 'Сборка: не указана';
    }

    const authorEl = document.getElementById('modAuthor');
    if (authorEl && author) {
        authorEl.textContent = author;
    }
}

function refreshVersionInfo() {
    console.log('Refreshing version info...');

    fetch('/get_version?t=' + Date.now())
        .then(r => {
            if (!r.ok)
                throw new Error('HTTP ' + r.status);
            return r.json();
        })
        .then(data => {
            console.log('Version data received:', data);

            const cacheData = {
                version: data.current_version || 'v1.0.0',
                buildDateTime: data.build_datetime || '',
                author: data.mod_author || '',
                timestamp: Date.now()
            };
            localStorage.setItem('firmware_version_cache', JSON.stringify(cacheData));

            updateVersionDisplay(
                cacheData.version,
                cacheData.buildDateTime,
                cacheData.author);
        })
        .catch(err => {
            console.error('Error refreshing version:', err);
            try {
                const cached = localStorage.getItem('firmware_version_cache');
                if (cached) {
                    const data = JSON.parse(cached);
                    updateVersionDisplay(data.version, data.buildDateTime, data.author);
                }
            } catch (e) {
                console.error('Cache error:', e);
            }
        });
}

// ---------------------------------------------------------------------------------------

// проверка обновлений
function checkForUpdate(forceCheck = false) {
    if (isUpdateCheckInProgress) {
        console.log('Проверка обновлений уже выполняется');
        return;
    }

    // проверка кэша
    if (!forceCheck) {
        const cached = getCachedUpdateCheck();
        if (cached) {
            if (cached.has_update) {
                showUpdateAvailable(cached);
                showUpdateStatus(cached);
            } else {
                const updateBlock = document.getElementById('updateAvailable');
                if (updateBlock)
                    updateBlock.style.display = 'none';
                showUpdateStatus({
                    has_update: false
                });
            }
            updateLastCheckDisplay(cached.timestamp);
            return;
        }
    }

    isUpdateCheckInProgress = true;

    const loadingEl = document.getElementById('updateLoading');
    if (loadingEl) {
        loadingEl.style.display = 'inline-block';
        loadingEl.textContent = '';
    }

    const statusContainer = document.getElementById('updateStatusContainer');
    if (statusContainer) {
        let statusDiv = statusContainer.querySelector('.update-status');
        if (!statusDiv) {
            statusDiv = document.createElement('div');
            statusDiv.className = 'update-status';
            statusContainer.appendChild(statusDiv);
        }
        statusDiv.style.cssText = 'background: rgba(255,255,255,0.05); border-radius: 12px; padding: 12px 16px; margin-top: 8px; display: flex; align-items: center; gap: 10px;';
        statusDiv.innerHTML = `
		<span style="font-size: 20px;">⏳</span>
            <div>
                <div style="color: #90a4ae; font-weight: 500; font-size: 14px;">Проверка обновлений...</div>
            </div>
        `;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
        controller.abort();
        console.warn('Таймаут проверки обновлений');
        isUpdateCheckInProgress = false;
        if (loadingEl)
            loadingEl.style.display = 'none';

        const statusContainer = document.getElementById('updateStatusContainer');
        if (statusContainer) {
            let statusDiv = statusContainer.querySelector('.update-status');
            if (statusDiv) {
                statusDiv.style.cssText = NOTIFICATION_STYLES.ERROR;
                statusDiv.innerHTML = `
                    <span style="font-size: 20px;">⏱️</span>
                    <div>
                        <div style="color: #ef5350; font-weight: bold; font-size: 14px;">Таймаут проверки</div>
                        <div style="color: #90a4ae; font-size: 12px;">Сервер не отвечает</div>
                    </div>
                `;
                setTimeout(() => hideStatusWithAnimation(statusDiv), 5000);
            }
        }
    }, 15000);

    fetch('/check_update?t=' + Date.now(), {
            signal: controller.signal
        })
        .then(r => {
            clearTimeout(timeoutId);
            if (!r.ok)
                throw new Error(`HTTP ${r.status}`);
            return r.json();
        })
        .then(data => {
            if (loadingEl)
                loadingEl.style.display = 'none';

            setCachedUpdateCheck(data);
            window._updateData = data;

            if (data.has_update === true) {
                showUpdateStatus(data);
                showUpdateAvailable(data);
            } else {
                const updateBlock = document.getElementById('updateAvailable');
                if (updateBlock)
                    updateBlock.style.display = 'none';
                showUpdateStatus({
                    has_update: false
                });
            }

            updateLastCheckDisplay(Date.now());
            isUpdateCheckInProgress = false;
        })
        .catch((error) => {
            clearTimeout(timeoutId);
            if (loadingEl)
                loadingEl.style.display = 'none';

            console.error('Ошибка проверки обновлений:', error);
            const updateBlock = document.getElementById('updateAvailable');
            if (updateBlock)
                updateBlock.style.display = 'none';

            const statusContainer = document.getElementById('updateStatusContainer');
            if (statusContainer) {
                let statusDiv = statusContainer.querySelector('.update-status');
                if (!statusDiv) {
                    statusDiv = document.createElement('div');
                    statusDiv.className = 'update-status';
                    statusContainer.appendChild(statusDiv);
                }
                statusDiv.style.cssText = NOTIFICATION_STYLES.ERROR;
                statusDiv.innerHTML = `
                    <span style="font-size: 20px;">❌</span>
                    <div>
                        <div style="color: #ef5350; font-weight: bold; font-size: 14px;">Ошибка проверки</div>
                        <div style="color: #90a4ae; font-size: 12px;">${error.message || 'Проверьте подключение'}</div>
                    </div>
                `;
                setTimeout(() => hideStatusWithAnimation(statusDiv), 5000);
            }

            isUpdateCheckInProgress = false;
        });
}

function manualCheckUpdate(event) {
    if (event) {
        event.stopPropagation();
    }
    checkForUpdate(true);
}

// ---------------------------------------------------------------------------------------

// отображение обновления
function showUpdateAvailable(data) {
    const updateBlock = document.getElementById('updateAvailable');
    if (!updateBlock)
        return;

    updateBlock.style.display = 'block';
    updateBlock.style.background = 'linear-gradient(135deg, #0d2b3e 0%, #1a4a6a 100%)';
    updateBlock.classList.add('has-update');

    const updateLabel = document.getElementById('updateLabel');
    if (updateLabel)
        updateLabel.innerHTML = 'Вышло обновление мода';

    const updateVerText = document.getElementById('updateVerText');
    if (updateVerText) {
        updateVerText.textContent = data.update_version || 'v1.0.0';
    }

    const updateDate = document.getElementById('updateDate');
    if (updateDate && data.update_datetime) {
        updateDate.textContent = 'от ' + data.update_datetime;
    }

    const updateDownloadBtn = document.getElementById('updateDownloadBtn');
    if (updateDownloadBtn) {
        updateDownloadBtn.href = data.update_folder_url || 'https://github.com/an-core/FieryLedLamp_mod/tree/main/update';
        updateDownloadBtn.target = '_blank';
        updateDownloadBtn.rel = 'noopener noreferrer';
        updateDownloadBtn.style.display = 'inline-flex';

        updateDownloadBtn.innerHTML = 'Скачать обновление';
    }
}

function showUpdateStatus(data) {
    const container = document.getElementById('updateStatusContainer');
    if (!container)
        return;

    let statusDiv = container.querySelector('.update-status');
    if (!statusDiv) {
        statusDiv = document.createElement('div');
        statusDiv.className = 'update-status';
        container.appendChild(statusDiv);
    }

    const currentVersion = data.update_version || 'unknown';

    if (data.has_update === true) {
        const shownVersion = localStorage.getItem(UPDATE_NOTIFICATION_KEY);
        if (shownVersion === currentVersion) {
            statusDiv.style.display = 'none';
            return;
        }
    }

    if (statusDiv._hideTimer) {
        clearTimeout(statusDiv._hideTimer);
        statusDiv._hideTimer = null;
    }

    statusDiv.classList.remove('hiding', 'hidden-status');
    statusDiv.style.display = 'flex';
    statusDiv.style.opacity = '1';

    let displayTime = 3000;

    if (data.has_update === true) {
        displayTime = 5000;
        statusDiv.style.cssText = NOTIFICATION_STYLES.UPDATE_AVAILABLE + ' opacity: 1; transform: translateY(0); transition: opacity 0.5s ease-in-out, transform 0.3s ease-in-out;';
        statusDiv.innerHTML = `
            <div>
                <div style="color: #4caf50; font-weight: bold; font-size: 15px;">Доступно новое обновление!</div>
            </div>
        `;
        localStorage.setItem(UPDATE_NOTIFICATION_KEY, currentVersion);
    } else if (data.has_update === false || data.has_update === undefined) {
        localStorage.removeItem(UPDATE_NOTIFICATION_KEY);
        if (data.error) {
            displayTime = 6000;
            statusDiv.style.cssText = NOTIFICATION_STYLES.ERROR + ' opacity: 1; transform: translateY(0); transition: opacity 0.5s ease-in-out, transform 0.3s ease-in-out;';
            statusDiv.innerHTML = `
                <span style="font-size: 24px;">⚠️</span>
                <div>
                    <div style="color: #ef5350; font-weight: bold; font-size: 15px;">Ошибка проверки обновлений</div>
                    <div style="color: #90a4ae; font-size: 13px; margin-top: 2px;">${data.error}</div>
                </div>
            `;
        } else {
            displayTime = 3000;
            statusDiv.style.cssText = NOTIFICATION_STYLES.NO_UPDATE + ' opacity: 1; transform: translateY(0); transition: opacity 0.5s ease-in-out, transform 0.3s ease-in-out;';
            statusDiv.innerHTML = `
                <div>
                    <div style="color: #64b5f6; font-weight: bold; font-size: 15px;">У вас установлена последняя версия</div>
                </div>
            `;
        }
    }

    statusDiv._hideTimer = setTimeout(() => {
        hideStatusWithAnimation(statusDiv);
    }, displayTime);
}

function hideStatusWithAnimation(statusDiv) {
    if (!statusDiv)
        return;

    if (statusDiv._hideTimer) {
        clearTimeout(statusDiv._hideTimer);
        statusDiv._hideTimer = null;
    }

    statusDiv.classList.add('hiding');
    statusDiv._hideTimer = setTimeout(() => {
        statusDiv.classList.add('hidden-status');
        statusDiv.style.display = 'none';
        statusDiv.classList.remove('hiding');
    }, 500);
}

function updateLastCheckDisplay(timestamp) {
    const container = document.getElementById('lastCheckContainer');
    if (!container)
        return;

    const time = timestamp ? new Date(timestamp) : new Date();
    const dateStr = time.toLocaleString('ru-RU', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });

    container.innerHTML = `
        <div style="font-size: 0.8em; color: #78909c; margin-top: 6px; padding-top: 6px; border-top: 1px solid rgba(255,255,255,0.06); display: flex; align-items: center; gap: 6px;">
            <span style="opacity:0.6; cursor: pointer; transition: transform 0.2s; display: inline-block;" 
                onclick="manualCheckUpdate(event)"
                onmouseover="this.style.transform='rotate(180deg)'" 
                onmouseout="this.style.transform='rotate(0deg)'"
                title="Нажмите для ручной проверки обновлений">🔄</span>
            <span>Время проверки: </span>
            <span style="color: #a0b4c4; font-weight: 500;">${dateStr}</span>
        </div>
    `;
    container.style.display = 'block';
}

// ---------------------------------------------------------------------------------------

// управление модальным окном
function showSoftwareInfo() {
    if (!document.querySelector('[data-feature="software_modal"]')) {
        console.warn("Информация о ПО отключена в прошивке");
        return;
    }

    if (window._memoryUpdateInterval) {
        clearInterval(window._memoryUpdateInterval);
        window._memoryUpdateInterval = null;
    }

    document.getElementById('softwareModal').style.display = 'block';
    document.body.style.overflow = 'hidden';

    loadVersionInfo()
        .then(() => {
            setTimeout(() => {
                checkForUpdate(false);
            }, 300);
        })
        .catch((error) => {
            console.error('Ошибка загрузки информации о ПО:', error);
        });
}

function hideSoftwareInfo() {
    document.getElementById('softwareModal').style.display = 'none';
    document.body.style.overflow = '';

    const statusDiv = document.querySelector('.update-status');
    if (statusDiv && statusDiv._hideTimer) {
        clearTimeout(statusDiv._hideTimer);
        statusDiv._hideTimer = null;
    }

    if (!window._memoryUpdateInterval && features && features.memory_info) {
        window._memoryUpdateInterval = setInterval(updateMemoryInfo, 5000);
        setTimeout(updateMemoryInfo, 100);
    }
}

// ---------------------------------------------------------------------------------------

const NOTIFICATION_STYLES = {
    NO_UPDATE: 'background: linear-gradient(135deg, rgba(100, 181, 246, 0.1), rgba(100, 181, 246, 0.02)); border: 1px solid rgba(100, 181, 246, 0.2); border-radius: 12px; padding: 16px 20px; margin-top: 12px; display: flex; align-items: center; gap: 12px;',
    UPDATE_AVAILABLE: 'background: linear-gradient(135deg, rgba(76, 175, 80, 0.15), rgba(76, 175, 80, 0.05)); border: 1px solid rgba(76, 175, 80, 0.3); border-radius: 12px; padding: 16px 20px; margin-top: 12px; display: flex; align-items: center; gap: 12px;',
    ERROR: 'background: linear-gradient(135deg, rgba(244, 67, 54, 0.15), rgba(244, 67, 54, 0.05)); border: 1px solid rgba(244, 67, 54, 0.3); border-radius: 12px; padding: 16px 20px; margin-top: 12px; display: flex; align-items: center; gap: 12px;'
};

// ---------------------------------------------------------------------------------------

// changelog, planned
function showChangelogModal() {
    const modal = document.getElementById('changelogModal');
    if (!modal)
        return;

    modal.style.display = 'block';

    const content = document.getElementById('changelogContent');
    if (!content)
        return;

    if (window._updateData && window._updateData.changelog) {
        renderChangelog(content);
        return;
    }

    content.innerHTML = `
        <div style="text-align: center; padding: 20px; color: #666;">
            <span class="loader-bar" style="display: inline-block; margin: 0 3px;"></span>
            <span class="loader-bar" style="display: inline-block; margin: 0 3px; animation-delay: -1.1s;"></span>
            <span class="loader-bar" style="display: inline-block; margin: 0 3px; animation-delay: -1.0s;"></span>
            <br><br>
            <span style="color: #888;">Загрузка списка изменений...</span>
        </div>
    `;

    fetch('/check_update?t=' + Date.now())
        .then(r => r.json())
        .then(data => {
            window._updateData = data;
            if (data && data.changelog && data.changelog.length > 0) {
                renderChangelog(content);
            } else {
                content.innerHTML = '<div style="text-align:center;padding:20px;color:#ff9800;">Список изменений пока пуст</div>';
            }
        })
        .catch(() => {
            content.innerHTML = '<div style="text-align:center;padding:20px;color:#ef5350;">Ошибка загрузки данных</div>';
        });
}

function showPlannedUpdates() {
    const content = document.getElementById('changelogContent');
    if (!content)
        return;

    content.innerHTML = `
        <div style="text-align: center; padding: 20px; color: #666;">
            <span class="loader-bar" style="display: inline-block; margin: 0 3px;"></span>
            <span class="loader-bar" style="display: inline-block; margin: 0 3px; animation-delay: -1.1s;"></span>
            <span class="loader-bar" style="display: inline-block; margin: 0 3px; animation-delay: -1.0s;"></span>
            <br><br>
            <span style="color: #888;">Загрузка планируемых обновлений...</span>
        </div>
    `;

    fetch('/check_update?t=' + Date.now())
        .then(r => r.json())
        .then(data => {
            window._updateData = data;
            if (data && data.planned && data.planned.length > 0) {
                const tempData = {
                    update_version: 'Планы на будущее',
                    changelog: data.planned
                };
                const currentData = window._updateData;
                window._updateData = tempData;
                renderChangelog(content);
                window._updateData = currentData;
            } else {
                content.innerHTML = '<div style="text-align:center;padding:20px;color:#ff9800;">Список планируемых обновлений пока пуст</div>';
            }
        })
        .catch((error) => {
            console.error('Ошибка загрузки planned:', error);
            content.innerHTML = '<div style="text-align:center;padding:20px;color:#ef5350;">Ошибка загрузки данных</div>';
        });
}

function showCurrentChangelog() {
    const content = document.getElementById('changelogContent');
    if (!content)
        return;

    content.innerHTML = `
        <div style="text-align: center; padding: 20px; color: #666;">
            <span class="loader-bar" style="display: inline-block; margin: 0 3px;"></span>
            <span class="loader-bar" style="display: inline-block; margin: 0 3px; animation-delay: -1.1s;"></span>
            <span class="loader-bar" style="display: inline-block; margin: 0 3px; animation-delay: -1.0s;"></span>
            <br><br>
            <span style="color: #888;">Загрузка...</span>
        </div>
    `;

    fetch('/check_update?t=' + Date.now())
        .then(r => r.json())
        .then(data => {
            window._updateData = data;
            if (data && data.changelog && data.changelog.length > 0) {
                renderChangelog(content);
            } else {
                content.innerHTML = '<div style="text-align:center;padding:20px;color:#ff9800;">Список изменений пока пуст</div>';
            }
        })
        .catch(() => {
            content.innerHTML = '<div style="text-align:center;padding:20px;color:#ef5350;">Ошибка загрузки данных</div>';
        });
}

function renderChangelog(content) {
    const data = window._updateData;
    const version = data && data.update_version ? data.update_version : 'Обновление';
    const dateTime = data && (data.update_datetime || data.update_date) ? (data.update_datetime || data.update_date) : '';
    const isPlanned = version === 'Планы на будущее';

    let html = '<div style="margin-bottom: 16px; padding-bottom: 16px; border-bottom: 1px solid rgba(255,255,255,0.08);">' +
        '<div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">' +
        '<div>' +
        '<span style="color: #64b5f6; font-weight: bold;">' + version + '</span>' +
        '<span style="color: #90a4ae; font-size: 13px; margin-left: 12px;">' + (dateTime ? 'от ' + dateTime : '') + '</span>' +
        '</div>' +
        '<div style="display: flex; gap: 8px;">' +
        '<button onclick="' + (isPlanned ? 'showCurrentChangelog()' : 'showPlannedUpdates()') + '" style="' +
        'background: ' + (isPlanned ? 'rgba(100, 181, 246, 0.2)' : 'rgb(43 41 58 / 75%)') + ';' +
        'color: ' + (isPlanned ? '#64b5f6' : 'rgb(238 243 242 / 68%)') + ';' +
        'border: 1px solid ' + (isPlanned ? 'rgba(100, 181, 246, 0.3)' : 'rgba(255, 152, 0, 0.3)') + ';' +
        'padding: 4px 10px; border-radius: 6px; cursor: pointer; font-size: 11px; transition: all 0.3s ease; display: inline-flex; align-items: center; gap: 4px;"' +
        ' onmouseover="this.style.transform=\'scale(1.05)\'" onmouseout="this.style.transform=\'scale(1)\'">' +
        (isPlanned ? 'Текущие изменения' : 'Планы') +
        '</button>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<ul style="list-style: none; padding: 0; margin: 0;">';

    if (data && data.changelog && data.changelog.length > 0) {
        let prevUpdateCounter = 0;
        let currentSection = 'new';

        data.changelog.forEach(function(item) {
            let type = 'item';
            let text = '';

            if (typeof item === 'object' && item !== null) {
                type = item.type || 'item';
                text = item.text || '';
            } else if (typeof item === 'string') {
                text = item;
            } else {
                return;
            }

            const safeText = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            let style = '';

            if (type === 'header') {
                if (safeText.includes('ВНИМАНИЕ!')) {
                    currentSection = 'attention';
                    style = HEADER_STYLES.ATTENTION;
                } else if (safeText.includes('ПРЕДЫДУЩЕЕ ОБНОВЛЕНИЕ') || safeText.includes('ПРОШЛОЕ ОБНОВЛЕНИЕ')) {
                    currentSection = 'previous';
                    prevUpdateCounter++;
                    if (prevUpdateCounter === 1) {
                        style = HEADER_STYLES.PREVIOUS_1;
                    } else if (prevUpdateCounter === 2) {
                        style = HEADER_STYLES.PREVIOUS_2;
                    } else {
                        style = HEADER_STYLES.PREVIOUS_OTHER;
                    }
                } else if (safeText.includes('НОВОЕ ОБНОВЛЕНИЕ')) {
                    currentSection = 'new';
                    style = HEADER_STYLES.NEW;
                } else if (safeText.includes('ПЛАНИРУЕМЫЕ ОБНОВЛЕНИЯ')) {
                    currentSection = 'planned';
                    style = 'color: #ff6f00; font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgba(255, 111, 0, 0.2); border: 1px dashed rgba(255, 111, 0, 0.3);';
                } else if (safeText.includes('ИДЕИ ДЛЯ ОБНОВЛЕНИЙ')) {
                    currentSection = 'ideas';
                    style = 'color: #7c4dff; font-weight: bold; font-size: 15px; padding-left:10px; border-radius:8px; background: rgb(109 69 207 / 44%); border: 1px dashed rgba(124, 77, 255, 0.2);';
                } else {
                    currentSection = 'default';
                    style = HEADER_STYLES.DEFAULT;
                }
            } else if (type === 'item') {
                if (safeText.startsWith('  ')) {
                    style = ITEM_STYLES.INDENT;
                } else {
                    switch (currentSection) {
                        case 'attention':
                            style = ITEM_STYLES.ATTENTION;
                            break;
                        case 'new':
                            style = ITEM_STYLES.NEW;
                            break;
                        case 'previous':
                            style = ITEM_STYLES.PREVIOUS;
                            break;
                        case 'planned':
                            style = 'padding: 8px 14px; margin-bottom: 4px; background: rgba(255, 111, 0, 0.05); border-radius: 8px; border-left: 3px solid #ff6f00;';
                            break;
                        case 'ideas':
                            style = 'padding: 8px 14px; margin-bottom: 4px; background: rgba(124, 77, 255, 0.05); border-radius: 8px; border-left: 3px solid #720ce7;';
                            break;
                        default:
                            style = ITEM_STYLES.NEW;
                            break;
                    }
                }
            }

            if (safeText.trim() === '') {
                html += '<li style="height: 8px; list-style: none;"></li>';
                return;
            }

            const displayText = safeText.replace(/^  /, '');
            html += '<li style="display: flex; align-items: flex-start; gap: 10px; ' + style + '">' + '<span style="color: #e0e0e0; line-height: 1.5;">' + displayText + '</span>' + '</li>';
        });
    } else {
        html += '<li style="padding: 10px 14px; color: #888; text-align: center; list-style: none;">Список изменений будет добавлен в следующем обновлении</li>';
    }

    html += '</ul>';
    content.innerHTML = html;
}

function closeChangelogModal() {
    const modal = document.getElementById('changelogModal');
    if (modal)
        modal.style.display = 'none';
}

// ---------------------------------------------------------------------------------------

// стили для changelog
const HEADER_STYLES = {
    ATTENTION: 'color: #ff1744; font-weight: bold; font-size: 16px; padding-left:4px; border-radius:8px; background: rgba(255, 23, 68, 0.2); border: 1px solid rgba(255, 23, 68, 0.3); animation: attention-pulse 1.5s ease-in-out infinite;',
    NEW: 'color: #4caf50; font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgb(31 189 43 / 48%);',
    PREVIOUS_1: 'color: #ff9800; font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgb(211 209 205 / 14%);',
    PREVIOUS_2: 'color: #ff9800; font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgb(211 209 205 / 14%);',
    PREVIOUS_OTHER: 'color: rgba(255, 152, 0, 0.6); font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgb(211 209 205 / 14%);',
    DEFAULT: 'color: #64b5f6; font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgba(100, 181, 246, 0.08);'
};

const ITEM_STYLES = {
    ATTENTION: 'padding: 8px 14px; margin-bottom: 4px; background: rgba(255, 23, 68, 0.08); border-radius: 8px; border-left: 3px solid #ff1744;',
    NEW: 'padding: 8px 14px; margin-bottom: 4px; background: rgba(255,255,255,0.03); border-radius: 8px; border-left: 3px solid #0f8d06;',
    PREVIOUS: 'padding: 8px 14px; margin-bottom: 4px; background: rgba(255,255,255,0.03); border-radius: 8px; border-left: 3px solid #8D6E63;',
    DEFAULT: 'padding: 8px 14px; margin-bottom: 4px; background: rgba(255,255,255,0.03); border-radius: 8px; border-left: 3px solid #64b5f6;',
    INDENT: 'padding-left: 24px; border-left-color: transparent; background: transparent;'
};

// ---------------------------------------------------------------------------------------

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const statusModal = document.getElementById('statusModal');
        if (statusModal && statusModal.style.display === 'block') {
            hideStatusInfo();
        }
        const softwareModal = document.getElementById('softwareModal');
        if (softwareModal && softwareModal.style.display === 'block') {
            hideSoftwareInfo();
        }
        const changelogModal = document.getElementById('changelogModal');
        if (changelogModal && changelogModal.style.display === 'block') {
            closeChangelogModal();
        }
    }
});

document.addEventListener('click', function(e) {
    if (e.target.id === 'statusModal') {
        hideStatusInfo();
    }
    if (e.target.id === 'softwareModal') {
        hideSoftwareInfo();
    }
    if (e.target.id === 'changelogModal') {
        closeChangelogModal();
    }
});

document.addEventListener('DOMContentLoaded', function() {
    updateLastCheckDisplay();

    const lastCheck = getCachedUpdateCheck();
    if (!lastCheck) {
        setTimeout(function() {
            checkForUpdate(false);
        }, 2000);
    }
});

// ---------------------------------------------------------------------------------------

function sendClientTime() {
    const now = new Date();
    const unixTime = Math.floor(now.getTime() / 1000);
    const offsetSeconds = now.getTimezoneOffset() * 60;
    const tzName = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const url = `/set_client_time?time=${unixTime}&offset=${offsetSeconds}&tz=${encodeURIComponent(tzName)}`;
    fetch(url).catch(() => {});
}

function autoDetectTz() {
    fetch('/tz?tz=auto')
        .then(response => {
            if (!response.ok)
                throw new Error('Ошибка сервера');
            return response.text();
        })
        .then(text => {
            console.log('Часовой пояс успешно определён:', text);
            location.reload();
        })
        .catch(error => {
            console.warn('Не удалось определить пояс:', error.message);
        });
}

// ---------------------------------------------------------------------------------------

let memoryInfoAbortController = null;
let memoryInfoTimeoutId = null;
let isMemoryInfoLoading = false;

function updateMemoryInfo() {
    const memInfoEl = document.getElementById('mem-info');
    if (!memInfoEl) {
        console.warn('Элемент mem-info не найден');
        return;
    }

    if (!features.memory_info) {
        memInfoEl.textContent = 'Память: отключено';
        memInfoEl.classList.add('mem-disabled');
        return;
    }

    if (isMemoryInfoLoading) {
        return;
    }

    if (memoryInfoTimeoutId) {
        clearTimeout(memoryInfoTimeoutId);
        memoryInfoTimeoutId = null;
    }
    if (memoryInfoAbortController) {
        memoryInfoAbortController.abort();
        memoryInfoAbortController = null;
    }

    isMemoryInfoLoading = true;

    const controller = new AbortController();
    memoryInfoAbortController = controller;

    const timeoutId = setTimeout(() => {
        controller.abort();
        const el = document.getElementById('mem-info');
        if (el)
            el.textContent = 'Память: таймаут';
        isMemoryInfoLoading = false;
        memoryInfoTimeoutId = null;
        memoryInfoAbortController = null;
    }, 3000);

    memoryInfoTimeoutId = timeoutId;

    fetch('/heap?t=' + Date.now(), {
            signal: controller.signal
        })
        .then(r => {
            if (memoryInfoTimeoutId) {
                clearTimeout(memoryInfoTimeoutId);
                memoryInfoTimeoutId = null;
            }
            if (!r.ok)
                throw new Error(`HTTP ${r.status}`);
            return r.json();
        })
        .then(data => {
            const el = document.getElementById('mem-info');
            if (!el)
                return;

            el.classList.remove('mem-critical', 'mem-warning', 'mem-good');

            const freeDramKb = Math.round(data.free / 1024);
            const totalDramKb = Math.round(data.total_dram / 1024);
            const freePsramKb = data.free_psram ? Math.round(data.free_psram / 1024) : 0;
            const totalPsramKb = data.total_psram ? Math.round(data.total_psram / 1024) : 0;
            const hasPsram = data.psram === true;
            const freeTotalKb = freeDramKb + freePsramKb;
            const totalKb = totalDramKb + totalPsramKb;
            const percent = totalKb > 0 ? Math.round((freeTotalKb / totalKb) * 100) : 0;

            let text = '';
            if (hasPsram && totalPsramKb >= 512) {
                text = `Память: ${freeDramKb}k + ${freePsramKb}k из ${totalDramKb}k + ${totalPsramKb}k (${percent}%)`;
            } else if (hasPsram && totalPsramKb > 0) {
                text = `Память: ${freeDramKb}k${freePsramKb > 0 ? ' + ' + freePsramKb + 'k' : ''} из ${totalKb}k (${percent}%)`;
            } else {
                text = `Память: ${freeTotalKb}k из ${totalKb}k (${percent}%)`;
            }
            if (data.chip)
                text = `${data.chip}: ` + text;
            el.textContent = text;

            if (percent < 20)
                el.classList.add('mem-critical');
            else if (percent < 40)
                el.classList.add('mem-warning');
            else
                el.classList.add('mem-good');

            isMemoryInfoLoading = false;
            memoryInfoAbortController = null;
        })
        .catch(err => {
            if (memoryInfoTimeoutId) {
                clearTimeout(memoryInfoTimeoutId);
                memoryInfoTimeoutId = null;
            }
            if (err.name === 'AbortError') {} else {
                console.error('Ошибка получения информации о памяти:', err);
            }
            const el = document.getElementById('mem-info');
            if (el)
                el.textContent = 'Память: ошибка';
            isMemoryInfoLoading = false;
            memoryInfoAbortController = null;
        });
}

function showMemoryDetails() {
    const memEl = document.getElementById('mem-info');
    if (!memEl)
        return;

    let currentText = memEl.textContent;
    currentText = currentText.replace(/^JavaScript:\s*.*?\n?/i, '');

    if (currentText === 'Память: отключено' || currentText === 'Память: ошибка' || currentText === 'Память: загрузка...') {
        alert(currentText);
        return;
    }

    fetch('/heap?t=' + Date.now())
        .then(r => r.ok ? r.json() : Promise.reject())
        .then(data => {
            const freeDramKb = Math.round(data.free / 1024);
            const totalDramKb = Math.round(data.total_dram / 1024);
            const freePsramKb = data.free_psram ? Math.round(data.free_psram / 1024) : 0;
            const totalPsramKb = data.total_psram ? Math.round(data.total_psram / 1024) : 0;
            const hasPsram = data.psram === true;
            const freeTotalKb = freeDramKb + freePsramKb;
            const totalKb = totalDramKb + totalPsramKb;
            const percent = totalKb > 0 ? Math.round((freeTotalKb / totalKb) * 100) : 0;

            let msg = `Чип: ${data.chip || 'ESP32'}\n\n`;
            msg += `DRAM: ${freeDramKb} КБ свободно из ${totalDramKb} КБ\n`;
            if (hasPsram)
                msg += `PSRAM: ${freePsramKb} КБ свободно из ${totalPsramKb} КБ\n`;
            msg += `\nВсего свободно: ${freeTotalKb} КБ из ${totalKb} КБ (${percent}%)\n`;
            if (percent < 20)
                msg += `Критически мало свободной памяти!`;
            else if (percent < 40)
                msg += `Свободной памяти мало, возможны замедления.`;
            else
                msg += `Памяти достаточно для стабильной работы.`;

            alert(msg);
        })
        .catch(() => alert('Не удалось получить детальную информацию о памяти'));
}

document.addEventListener('DOMContentLoaded', () => {
    const memInfo = document.getElementById('mem-info');
    if (memInfo) {
        memInfo.style.cursor = 'pointer';
        memInfo.addEventListener('click', showMemoryDetails);
    }
});

// Ночные часы
function updateNightClockButton(state) {
    var btn = document.querySelector('.night-clock-off, .night-clock-on');
    if (!btn)
        return;

    if (state === '1') {
        btn.className = 'btn btn-block night-clock-on';
        btn.value = 'Ночные часы ВКЛЮЧЕНЫ';
        btn.setAttribute('data-state', '1');
    } else {
        btn.className = 'btn btn-block night-clock-off';
        btn.value = 'Включить ночные часы';
        btn.setAttribute('data-state', '0');
    }
}

function toggleNightClock(btn) {
    var currentState = btn.getAttribute('data-state') || '0';
    var newState = currentState === '1' ? '0' : '1';

    if (newState === '1') {
        btn.classList.add('active');
        btn.classList.add('pulse');
        btn.innerHTML = 'Ночные часы ВКЛЮЧЕНЫ';
        btn.setAttribute('data-state', '1');
    } else {
        btn.classList.remove('active');
        btn.classList.remove('pulse');
        btn.innerHTML = 'Включить ночные часы';
        btn.setAttribute('data-state', '0');
    }

    ajax.get('/night_clock_enabled', {
        value: newState
    }, function(response) {
        if (response === '1' || response === '0') {
            if (response === '1') {
                btn.classList.add('active');
                btn.classList.add('pulse');
                btn.innerHTML = 'Ночные часы ВКЛЮЧЕНЫ';
                btn.setAttribute('data-state', '1');
            } else {
                btn.classList.remove('active');
                btn.classList.remove('pulse');
                btn.innerHTML = 'Включить ночные часы';
                btn.setAttribute('data-state', '0');
            }
            jsonResponse.night_clock_enabled = response;
        }
    }, true);
}

// свой часовой пояс
function applyCustomTimezone() {
    const tzInput = document.getElementById('custom_tz_input');
    if (!tzInput)
        return;

    const tzValue = tzInput.value.trim();
    if (tzValue.length === 0) {
        showNotification('Введите часовой пояс', 'warning');
        return;
    }

    showLoading(true);

    fetch(`/set_custom_tz?tz=${encodeURIComponent(tzValue)}`)
        .then(response => response.text())
        .then(data => {
            showLoading(false);
            if (data === 'OK_TZ_SET') {
                showNotification('Часовой пояс успешно установлен', 'success');
                updateTimezoneInfo();
                updateSelectState(tzValue);
            } else {
                showNotification('Ошибка: ' + data, 'error');
            }
        })
        .catch(error => {
            showLoading(false);
            showNotification('Ошибка соединения', 'error');
            console.error('Error:', error);
        });
}

function updateTimezoneInfo() {
    fetch('/get_tz_info')
        .then(response => response.json())
        .then(data => {
            const infoElement = document.getElementById('current_tz_info');
            if (infoElement) {
                infoElement.textContent = 'Текущий часовой пояс: ' + data.display_name;
            }

            const customInput = document.getElementById('custom_tz_input');
            if (customInput && data.is_custom) {
                customInput.value = data.custom || data.current;
            }

            const select = document.getElementById('tz_select');
            if (select && !data.is_custom) {
                select.value = data.current;
            }
        })
        .catch(error => console.error('Error fetching TZ info:', error));
}

function updateSelectState(value) {
    const select = document.getElementById('tz_select');
    if (select) {
        const options = Array.from(select.options);
        const exists = options.some(opt => opt.value === value);
        if (exists) {
            select.value = value;
        } else {
            select.value = '';
        }
    }
}

function autoDetectTimezone() {
    showLoading(true);
    fetch('/auto_tz')
        .then(response => response.text())
        .then(data => {
            showLoading(false);
            if (data === 'AUTO_OK') {
                showNotification('Часовой пояс автоматически определён', 'success');
                setTimeout(() => {
                    updateTimezoneInfo();
                    fetch('/get_tz_info')
                        .then(r => r.json())
                        .then(info => {
                            if (!info.is_custom) {
                                const select = document.getElementById('tz_select');
                                if (select) {
                                    select.value = info.current;
                                }
                            }
                        });
                }, 500);
            } else {
                showNotification('Не удалось определить часовой пояс', 'error');
            }
        })
        .catch(error => {
            showLoading(false);
            showNotification('Ошибка соединения', 'error');
            console.error('Error:', error);
        });
}

document.addEventListener('DOMContentLoaded', function() {
    const applyBtn = document.getElementById('apply_custom_tz');
    if (applyBtn) {
        applyBtn.addEventListener('click', applyCustomTimezone);
    }

    const autoBtn = document.getElementById('auto_tz_btn');
    if (autoBtn) {
        autoBtn.addEventListener('click', autoDetectTimezone);
    }

    const customInput = document.getElementById('custom_tz_input');
    if (customInput) {
        customInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                applyCustomTimezone();
            }
        });
    }

    updateTimezoneInfo();
});

// подсказка часового пояса
function initTzTooltip() {
    var header = document.getElementById('tz_header');
    var tooltip = document.getElementById('tz_tooltip');

    if (!header || !tooltip) {
        setTimeout(initTzTooltip, 500);
        return;
    }

    if (header._tz_initialized) {
        return;
    }
    header._tz_initialized = true;

    header.onclick = function(e) {
        e.stopPropagation();
        e.preventDefault();
        var tip = document.getElementById('tz_tooltip');
        if (tip) {
            tip.style.display = (tip.style.display === 'none' || tip.style.display === '') ? 'block' : 'none';
        }
    };

    document.addEventListener('click', function(e) {
        var tip = document.getElementById('tz_tooltip');
        var hdr = document.getElementById('tz_header');
        if (tip && tip.style.display === 'block' && hdr &&
            !hdr.contains(e.target) && !tip.contains(e.target)) {
            tip.style.display = 'none';
        }
    });
}

// подсказка в погоде
function initWeatherTooltip() {
    var header = document.getElementById('weather_header');
    var tooltip = document.getElementById('weather_tooltip');

    if (!header || !tooltip) {
        setTimeout(initWeatherTooltip, 500);
        return;
    }

    if (header._weather_initialized) {
        return;
    }
    header._weather_initialized = true;

    header.onclick = function(e) {
        e.stopPropagation();
        e.preventDefault();
        var tip = document.getElementById('weather_tooltip');
        if (tip) {
            tip.style.display = (tip.style.display === 'none' || tip.style.display === '') ? 'block' : 'none';
        }
    };

    document.addEventListener('click', function(e) {
        var tip = document.getElementById('weather_tooltip');
        var hdr = document.getElementById('weather_header');
        if (tip && tip.style.display === 'block' && hdr &&
            !hdr.contains(e.target) && !tip.contains(e.target)) {
            tip.style.display = 'none';
        }
    });
}

// подсказка в расписании
function initScheduleTooltip() {
    var header = document.getElementById('schedule_header');
    var tooltip = document.getElementById('schedule_tooltip');

    if (!header || !tooltip) {
        setTimeout(initScheduleTooltip, 500);
        return;
    }

    if (header._schedule_initialized) {
        return;
    }
    header._schedule_initialized = true;

    header.onclick = function(e) {
        e.stopPropagation();
        e.preventDefault();
        var tip = document.getElementById('schedule_tooltip');
        if (tip) {
            tip.style.display = (tip.style.display === 'none' || tip.style.display === '') ? 'block' : 'none';
        }
    };

    document.addEventListener('click', function(e) {
        var tip = document.getElementById('schedule_tooltip');
        var hdr = document.getElementById('schedule_header');
        if (tip && tip.style.display === 'block' && hdr &&
            !hdr.contains(e.target) && !tip.contains(e.target)) {
            tip.style.display = 'none';
        }
    });
}

// подсказка для логов
function initLogsTooltip() {
    var header = document.getElementById('logs_header');
    var tooltip = document.getElementById('logs_tooltip');

    if (!header || !tooltip) {
        setTimeout(initLogsTooltip, 500);
        return;
    }

    if (header._logs_initialized) {
        return;
    }
    header._logs_initialized = true;

    header.onclick = function(e) {
        e.stopPropagation();
        e.preventDefault();
        var tip = document.getElementById('logs_tooltip');
        if (tip) {
            tip.style.display = (tip.style.display === 'none' || tip.style.display === '') ? 'block' : 'none';
        }
    };

    document.addEventListener('click', function(e) {
        var tip = document.getElementById('logs_tooltip');
        var hdr = document.getElementById('logs_header');
        if (tip && tip.style.display === 'block' && hdr &&
            !hdr.contains(e.target) && !tip.contains(e.target)) {
            tip.style.display = 'none';
        }
    });
}

// подсказка для wifi
function initWifiTooltip() {
    var header = document.getElementById('wifi_header');
    var tooltip = document.getElementById('wifi_tooltip');

    if (!header || !tooltip) {
        setTimeout(initWifiTooltip, 500);
        return;
    }

    if (header._wifi_initialized) {
        return;
    }
    header._wifi_initialized = true;

    header.onclick = function(e) {
        e.stopPropagation();
        e.preventDefault();
        var tip = document.getElementById('wifi_tooltip');
        if (tip) {
            tip.style.display = (tip.style.display === 'none' || tip.style.display === '') ? 'block' : 'none';
        }
    };

    document.addEventListener('click', function(e) {
        var tip = document.getElementById('wifi_tooltip');
        var hdr = document.getElementById('wifi_header');
        if (tip && tip.style.display === 'block' && hdr &&
            !hdr.contains(e.target) && !tip.contains(e.target)) {
            tip.style.display = 'none';
        }
    });
}

// подсказка в настройках оборудования
function initHardwareTooltip() {
    var header = document.getElementById('hardware_header');
    var tooltip = document.getElementById('hardware_tooltip');

    if (!header || !tooltip) {
        setTimeout(initHardwareTooltip, 500);
        return;
    }

    if (header._hardware_initialized) {
        return;
    }
    header._hardware_initialized = true;

    header.onclick = function(e) {
        e.stopPropagation();
        e.preventDefault();
        var tip = document.getElementById('hardware_tooltip');
        if (tip) {
            tip.style.display = (tip.style.display === 'none' || tip.style.display === '') ? 'block' : 'none';
        }
    };

    document.addEventListener('click', function(e) {
        var tip = document.getElementById('hardware_tooltip');
        var hdr = document.getElementById('hardware_header');
        if (tip && tip.style.display === 'block' && hdr &&
            !hdr.contains(e.target) && !tip.contains(e.target)) {
            tip.style.display = 'none';
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    setTimeout(initTzTooltip, 200);
    setTimeout(initWeatherTooltip, 200);
    setTimeout(initScheduleTooltip, 200);
    setTimeout(initLogsTooltip, 200);
    setTimeout(initWifiTooltip, 200);
    setTimeout(initHardwareTooltip, 200);
});