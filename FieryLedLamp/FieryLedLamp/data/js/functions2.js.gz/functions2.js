function hideLoader() {
    var loaderBg = document.querySelector('.container.loader-bg');
    var loaderWave = document.querySelector('.loader-wave');
    if (loaderBg)
        loaderBg.classList.remove('loading');
    if (loaderWave)
        loaderWave.style.display = 'none';
}

function mergeObject(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
            if (source.hasOwnProperty(key))
                target[key] = source[key];
        }
    }
    return target;
}

/* ------------------------------- */

var dragSrcEl = null;

function activeDragDrop(status) {
    elem('content-edit-button').innerHTML = '<input class="btn btn-block btn-default" onclick="toggle(\'new-element\');" value="Add new element" type="button">';
    patterns = jsonPage.content.slice(0);
    state.patterns = patterns;
    var cols = document.querySelectorAll('#content .fs-block');
    cols.forEach(addDnDHandlers);
    document.querySelectorAll('#content .fs-block').forEach(function (el) {
        el.setAttribute('draggable', status);
    });
}

function handleDragStart() {
    dragSrcEl = this;
    event.dataTransfer.effectAllowed = 'move';
    this.classList.add('dragElem');
}

function handleDragOver(e) {
    if (e.preventDefault)
        e.preventDefault();
    this.classList.add('over');
    e.dataTransfer.dropEffect = 'move';
    return false;
}

function handleDragEnter() {}

function handleDragLeave() {
    this.classList.remove('over');
}

function handleDrop(e) {
    if (e.stopPropagation)
        e.stopPropagation();
    if (dragSrcEl !== this)
        this.before(dragSrcEl);
    this.classList.remove('over');
    if (e.preventDefault)
        e.preventDefault();
    else
        return false;
}

function handleDragEnd() {
    this.classList.remove('over');
    dragSrcEl.classList.remove('dragElem');
    var temp = [];
    document.querySelectorAll('#content .fs-block').forEach(function (el) {
        temp.push(patterns[el.dataset.i]);
    });
    jsonPage.content = temp;
    var oldjson = JSON.parse(val('edit-json'));
    oldjson.content = temp;
    val('edit-json', JSON.stringify(oldjson, null, ' '));
}

function addDnDHandlers(el, i) {
    el.addEventListener('dragstart', handleDragStart, false);
    el.addEventListener('dragenter', handleDragEnter, false);
    el.addEventListener('dragover', handleDragOver, false);
    el.addEventListener('dragleave', handleDragLeave, false);
    el.addEventListener('drop', handleDrop, false);
    el.addEventListener('dragend', handleDragEnd, false);
    el.dataset.i = i;
}

function create_new_element() {
    var new_element = {};
    new_element.type = elem('new-element-type').options[elem('new-element-type').selectedIndex].innerHTML;
    if (new_element.type !== 'Create new page') {
        if (elem('new-element-title').value !== '')
            new_element.title = elem('new-element-title').value;
        if (elem('new-element-state').value !== '')
            new_element.state = elem('new-element-state').value;
        if (elem('new-element-class').value !== '')
            new_element.class = elem('new-element-class').value;
        if (elem('new-element-style').value !== '')
            new_element.style = elem('new-element-style').value;
        if (elem('new-element-action').value !== '')
            new_element.action = elem('new-element-action').value;
        if (elem('new-element-socket').value !== '')
            new_element.socket = elem('new-element-socket').value;
        if (elem('new-element-response').value !== '')
            new_element.response = elem('new-element-response').value;
        if (elem('new-element-id').value !== '')
            new_element.id = elem('new-element-id').value;
        if (elem('new-element-pattern').value !== '')
            new_element.pattern = elem('new-element-pattern').value;
        if (elem('new-element-module').value !== '')
            new_element.module = elem('new-element-module').value;

        var oldjson = JSON.parse(val('edit-json'));
        oldjson.content.push(new_element);
        val('edit-json', JSON.stringify(oldjson).replace(/"},/g, '"},\n\n').replace(/],"/g, '],\n"'));
    } else {
        ajax.get('/new_page.json', {}, function (response) {
            var formData = new FormData();
            formData.append('path', '/' + elem('new-element-id').value + '.json');
            xmlHttp.open('PUT', '/edit');
            xmlHttp.onload = function () {
                var fd = new FormData();
                fd.append('data', new Blob([response], {
                        type: 'text/json'
                    }), '/' + elem('new-element-id').value + '.json');
                xmlHttp.open('POST', '/edit');
                xmlHttp.onload = function () {
                    location.href = '/?' + elem('new-element-id').value;
                };
                xmlHttp.send(fd);
            };
            xmlHttp.send(formData);
        }, true);
    }
    toggle('new-element');
    setContent('edit');
    html('url-content', ' ');
    activeDragDrop(true);
}

function create_new_element_show(status) {
    document.querySelectorAll('#new-element-ipnut .form-control').forEach(function (el) {
        if (el.classList != 'hidden')
            el.classList.add('hidden');
    });
    status = status.split(',');
    for (var i = 0; i < status.length; i++) {
        toggle('new-element-' + status[i], 'shows');
        elem('new-element-' + status[i]).value = '';
    }
}

/* ------------------------------- */

function parseResponse(text) {
    text = (text || '').trim();
    if (['OK', 'OK_TZ_SET', 'OK_TIME_SET', 'NO_CHANGE', 'SYNC_STARTED', 'OK_REBOOT', 'ERROR'].indexOf(text) !== -1)
        return text;
    if (text.startsWith('{') || text.startsWith('[')) {
        try {
            return JSON.parse(text);
        } catch (e) {
            console.error('Ошибка парсинга JSON:', e, 'Ответ:', text);
            return text;
        }
    }
    return text;
}

function send_request(submit, server, stateParam) {
    var isValidElement = false;
    try {
        isValidElement = submit && (submit.nodeType === 1);
    } catch (e) {
        isValidElement = false;
    }

    if (isValidElement && typeof server === 'string' && server.indexOf('save_weather_params') === 0 && typeof saveWeatherParamsWithResolve === 'function') {
        saveWeatherParamsWithResolve();
        return;
    }

    var submitElement = isValidElement ? submit : {
        value: '',
        classList: {
            add: function () {},
            remove: function () {}
        }
    };
    var old_submit = isValidElement ? (submitElement.value || '') : '';

    if (isValidElement)
        submitElement.classList.add('loading');
    submit_disabled(true);

    ajax.get(server, {}, function (responses) {
        if (isValidElement) {
            submitElement.classList.remove('loading');
            submitElement.value = old_submit;
        }
        submit_disabled(false);

        var parsedResponses = parseResponse(responses);

        if (parsedResponses === 'OK_REBOOT') {
            showRebootOverlay();
            return;
        }

        if (isValidElement && submitElement.tagName === 'INPUT' && submitElement.type === 'range') {
            var newValue = responses.trim();
            if (newValue && !isNaN(newValue) && newValue !== submitElement.value) {
                submitElement.value = newValue;
                var label = submitElement.closest('label');
                if (label) {
                    var h4 = label.querySelector('h4');
                    if (h4) {
                        var currentTitle = h4.innerHTML;
                        var updatedTitle = currentTitle.replace(/\{\{.*?\}\}/, newValue);
                        if (updatedTitle === currentTitle)
                            updatedTitle = currentTitle.replace(/\d+$/, newValue);
                        h4.innerHTML = updatedTitle;
                    }
                }
            }
        }

        if (isValidElement && submitElement.tagName === 'INPUT' && submitElement.type === 'checkbox') {
            var nv = responses.trim();
            if (nv === '1' || nv === '0') {
                submitElement.checked = (nv === '1');
                submitElement.value = nv;
                setTimeout(applyModuleVisibility, 100);
            }
        }

        var element = elem('url-content');
        if (element) {
            log('<li class="animated tdFadeInRight"><span class="label label-warning">GET</span> <a href="' + server + '" class="btn btn-link" style="text-transform:none;text-align:left;white-space:normal;display:inline">' + server + '</a> <span class="label label-' + (responses === 'FileNotFound' ? 'danger' : 'default') + '">' + (responses === 'FileNotFound' ? 'File Not Found' : '200 OK') + '</span></li>');
        }

        var ddnsUrl1 = elem('ddns-url1');
        if (ddnsUrl1)
            ddnsUrl1.innerHTML = '<a href="http://' + location.hostname + '/' + server + '">http://' + location.hostname + '/' + server + '</a>';
        var ddnsUrl2 = elem('ddns-url2');
        if (ddnsUrl2 && jsonResponse.ddnsName)
            ddnsUrl2.innerHTML = '<a href="http://' + jsonResponse.ddnsName + ':' + jsonResponse.ddnsPort + '/' + server + '">http://' + jsonResponse.ddnsName + ':' + jsonResponse.ddnsPort + '/' + server + '</a>';

        if (stateParam && stateParam !== 'undefined') {
            var block = stateParam.split(',');
            for (var i = 0; i < block.length; i++) {
                if (block[i].slice(0, 2) !== '[[') {
                    window.location = block[i];
                } else {
                    var resp;
                    if (block.length > 1 && typeof parsedResponses === 'object' && parsedResponses !== null)
                        resp = parsedResponses[i];
                    else
                        resp = parsedResponses;

                    var htmlblock = elem(block[i].slice(2, -2));
                    if (htmlblock && typeof resp === 'object' && resp !== null) {
                        if (resp.class && resp.class !== 'undefined')
                            htmlblock.className = resp.class;
                        if (resp.style && resp.style !== 'undefined')
                            htmlblock.style = resp.style;
                        if (resp.title && resp.title !== 'undefined') {
                            if (htmlblock.tagName === 'INPUT')
                                htmlblock.value = renameBlock(jsonResponse, resp.title);
                            if (htmlblock.tagName === 'SELECT') {
                                var option = '';
                                var jsonSelect = resp.title;
                                for (var key in jsonSelect)
                                    option += '<option value="' + renameBlock(jsonResponse, key) + '">' + renameBlock(jsonResponse, jsonSelect[key]) + '</option>';
                                htmlblock.innerHTML = option;
                            }
                            if (['DIV', 'A', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6'].indexOf(htmlblock.tagName) !== -1)
                                htmlblock.innerHTML = renameBlock(jsonResponse, resp.title);
                        }
                        if (htmlblock.tagName === 'TABLE' && resp.state)
                            loadTable(resp.state, resp.title);
                        if (htmlblock.tagName === 'A' && resp.action)
                            htmlblock.href = resp.action;
                    }
                    if (element)
                        log('<li class="alert alert-info animated tdFadeInRight" style="margin:5px 0;"><a href="#' + block[i].slice(2, -2) + '" class="label label-success">' + block[i] + '</a> ' + responses.replace(/</g, '&lt;') + '</li>');
                }
            }
        } else {
            if (element)
                log('<li class="alert alert-info animated tdFadeInRight" style="margin:5px 0;">' + responses.replace(/</g, '&lt;') + '</li>');
        }

        if (server && server.indexOf('night_clock_enabled') !== -1) {
            var responseVal = responses.trim();
            if (responseVal === '1' || responseVal === '0') {
                jsonResponse.night_clock_enabled = responseVal;
                var nightBtn = document.querySelector('.night-clock-off, .night-clock-on');
                if (nightBtn) {
                    nightBtn.setAttribute('data-state', responseVal);
                    if (responseVal === '1') {
                        nightBtn.className = 'btn btn-block night-clock-on';
                        nightBtn.value = 'Ночные часы ВКЛЮЧЕНЫ';
                    } else {
                        nightBtn.className = 'btn btn-block night-clock-off';
                        nightBtn.value = 'Включить ночные часы';
                    }
                }
            }
        }

        if (server && server.indexOf('set_anim') !== -1) {
            if (typeof parsedResponses === 'object' && parsedResponses !== null && parsedResponses.anim_sel !== undefined) {
                jsonResponse.anim_sel = parsedResponses.anim_sel;
                if (parsedResponses.eff_sel !== undefined) {
                    jsonResponse.eff_sel = parsedResponses.eff_sel;
                    var effSel = document.querySelector('select[name="eff_sel"]');
                    if (effSel)
                        effSel.value = parsedResponses.eff_sel;
                }
                var sel = document.getElementById('anim_sel');
                if (sel)
                    sel.value = parsedResponses.anim_sel;
            }
        }

        if (typeof server === 'string' && server.indexOf('save_weather_param') !== -1) {
            var weatherKeys = ['weather_source', 'yandex_geo', 'custom_yandex_geo', 'city', 'custom_city', 'yandex_api_key', 'openweather_key', 'show_weather_condition'];
            var isWeatherKey = weatherKeys.some(function (k) {
                return server.indexOf('key=' + k) !== -1;
            });
            if (isWeatherKey && typeof updateWeatherBlock === 'function') {
                window._weatherJustChanged = Date.now();
                setTimeout(function () {
                    if (typeof updateWeatherBlock === 'function')
                        updateWeatherBlock();
                }, 500);
                setTimeout(function () {
                    fetch('/get_weather_settings').then(function (r) {
                        return r.json();
                    }).then(function (d) {
                        var nameEl = document.getElementById('custom_coord_name');
                        if (nameEl && d.custom_coord_name !== undefined)
                            nameEl.value = d.custom_coord_name;
                    }).catch(function () {});
                }, 1500);
            }
        }

        if (typeof parsedResponses === 'object' && parsedResponses !== null && parsedResponses.should_refresh) {
            setContent('edit');
        }
    }, true);
}

function send_request_edit(submit, server, filename, geturl, gethost) {
    var xhr = new XMLHttpRequest();
    var old_submit = submit.value;
    submit.value = 'Loading...';
    submit_disabled(true);
    var formData = new FormData();
    formData.append('data', new Blob([server], {
            type: 'text/json'
        }), '/' + filename);
    xhr.open('POST', (gethost ? 'http://' + gethost : '') + '/edit');
    xhr.onload = function () {
        submit.value = old_submit;
        submit_disabled(false);
        if (geturl)
            eval(geturl);
    };
    xhr.send(formData);
}

function submit_disabled(request) {
    var element = document.getElementsByTagName('input');
    for (var i = 0; i < element.length; i++) {
        if (element[i].type === 'button')
            element[i].disabled = request;
    }
}

/* ------------------------------- */

function loadConfigs(file_module, jr) {
    var element = elem(file_module.replace(/[^a-z0-9]/gi, '-'));
    element.innerHTML = '';
    ajax.get('/configs/' + file_module, {}, function (response) {
        response = renameBlock(jr, response);
        var configsLinePin;
        var configsLine = response.match(/^.*((\r\n|\n|\r)|$)/gm);
        for (var key in configsLine) {
            if (configsLine[key].substr(0, 2) === '//') {
                var configsLine2 = configsLine[key].split(' ');
                var configsLine3 = '';
                for (var i = 1; i < configsLine2.length; i++)
                    configsLine3 = configsLine3 + ' ' + configsLine2[i];
                element.innerHTML += '<hr style="margin:10px;"><label title="' + configsLine[key] + '"><input checked="" type="checkbox" style="display:none" disabled readonly>// ' + configsLine3.replace(/</gi, '<span class="label label-default">').replace(/>/gi, '</span>').replace(/\/n/gi, '<br>') + '</label></br>';
            } else {
                configsLinePin = configsLine[key].replace(/# /, '').split(' ');
                element.innerHTML += '<label><input type="checkbox" ' + (configsLine[key].substring(0, 2) !== '# ' ? 'checked' : '') + '> ' + configsLinePin[0] + '</label> ';
                for (var i2 = 1; i2 < configsLinePin.length; i2++) {
                    if (configsLinePin[0] === 'RELAY') {
                        element.innerHTML += (configsLinePin[i2] ? ' <input class="form-control' + (i2 === 1 ? ' pin-relay' : '') + '' + (i2 === 2 ? ' name-relay' : '') + '" ' + (i2 === 1 || i2 === 2 ? 'onkeyup="findError(\'' + (i2 === 1 ? 'pin' : 'name') + '-relay\',this.value)"' : '') + ' style="display:inline;width:' + Number(configsLinePin[i2].length + 3) + '0px;" pattern="[a-zA-Z0-9._а-яА-Я]{1,25}" value="' + configsLinePin[i2] + '"> ' : '');
                    } else if (configsLinePin[0] === 'TACH') {
                        element.innerHTML += (configsLinePin[i2] ? ' <input class="form-control' + (i2 === 2 ? ' name-tach' : '') + '" ' + (i2 === 2 ? 'onkeyup="findError(\'name-tach\',this.value)"' : '') + ' style="display:inline;width:' + Number(configsLinePin[i2].length + 3) + '0px;" pattern="[a-zA-Z0-9.]{1,25}" value="' + configsLinePin[i2] + '"> ' : '');
                    } else if (configsLinePin[0] === 'PINOUT') {
                        element.innerHTML += (configsLinePin[i2] ? ' <input class="form-control' + (i2 === 1 ? ' pin-pinout' : '') + '' + (i2 === 2 ? ' name-pinout' : '') + '" ' + (i2 === 1 || i2 === 2 ? 'onkeyup="findError(\'' + (i2 === 1 ? 'pin' : 'name') + '-pinout\',this.value)"' : '') + ' style="display:inline;width:' + Number(configsLinePin[i2].length + 3) + '0px;" pattern="[a-zA-Z0-9._а-яА-Я]{1,25}" value="' + configsLinePin[i2] + '"> ' : '');
                    } else {
                        element.innerHTML += (configsLinePin[i2] ? ' <input class="form-control" style="display:inline;width:' + Number(configsLinePin[i2].length + 3) + '0px;" pattern="[a-zA-Z0-9.]{1,25}" value="' + configsLinePin[i2] + '"> ' : '');
                    }
                }
                element.innerHTML += '</br>';
            }
        }
    }, true);
    element.innerHTML += '<textarea id="' + file_module.replace(/[^a-z0-9]/gi, '-') + '-edit" style="display:none" class="form-control"></textarea>';
}

function findError(className, valueName) {
    var id = document.getElementsByClassName(className);
    var dubleId = 0;
    for (var i = 0; i < id.length; i++) {
        id[i].classList.remove('btn-danger');
        if (valueName === id[i].value) {
            dubleId++;
            if (dubleId >= 2)
                id[i].classList.add('btn-danger');
        }
    }
}

function changeTextarea(state_val) {
    val(state_val.replace(/[^a-z0-9]/gi, '-') + '-edit', ' ');
    var area = document.querySelector('textarea');
    [].forEach.call(document.querySelectorAll('#' + state_val + '>*'), function (el) {
        if (el.matches('label')) {
            area.value += '\r\n' + (el.children[0].checked ? '' : '# ');
            if (el.textContent.substr(0, 2) === '//')
                area.value += el.title;
            else
                area.value += el.textContent.replace(/ /, '');
        }
        if (el.matches('input'))
            area.value += ' ' + el.value;
    });
    area.value = area.value.replace(/\n+/g, '\n').slice(1);
}

/* ------------------------------- */

function applyMultiMatrixVisibility() {
    var states = window.moduleStates || {};
    var isMultiMatrixCompiled = states.multi_matrix === '1';
    var cb = document.getElementById('multi_matrix_enable');
    var wrapperDiv = cb ? cb.closest('.multi_matrix_container') : null;
    if (wrapperDiv)
        wrapperDiv.classList.toggle('multi_matrix_on', isMultiMatrixCompiled);
    if (cb) {
        cb.classList.toggle('multi_matrix_on', isMultiMatrixCompiled);
        var label = cb.closest('label');
        if (label)
            label.classList.toggle('multi_matrix_on', isMultiMatrixCompiled);
    }
    var enabled = cb ? cb.checked : false;
    var showFields = isMultiMatrixCompiled && enabled;
    document.querySelectorAll('.multi_matrix_field').forEach(function (el) {
        el.classList.toggle('multi_matrix_on', showFields);
    });
    document.querySelectorAll('.multi_matrix_wrap').forEach(function (el) {
        el.classList.toggle('multi_matrix_on', showFields);
    });
}

function applyModuleVisibility() {
    var states = window.moduleStates || {};
    Object.entries(MODULE_CHECKBOX_MAP).forEach(function (entry) {
        var checkboxId = entry[0],
        feature = entry[1];
        var checkbox = document.getElementById(checkboxId);
        var isChecked = false;
        if (checkbox)
            isChecked = checkbox.checked || checkbox.value === '1';
        else if (states[checkboxId] !== undefined)
            isChecked = (states[checkboxId] === '1');
        var menuItem = document.querySelector('[data-feature="' + feature + '"]');
        if (menuItem)
            menuItem.style.display = isChecked ? '' : 'none';
    });
}

(function injectMultiMatrixStyle() {
    var style = document.createElement('style');
    style.textContent = '.multi_matrix_wrap:not(.multi_matrix_on){display:none!important}.multi_matrix_field:not(.multi_matrix_on){display:none!important}';
    document.head.appendChild(style);
})();

function loadModuleStates() {
    fetch('/get_module_states')
    .then(function (r) {
        return r.json();
    })
    .then(function (data) {
        window.moduleStates = data;
        state.moduleStates = data;
        Object.entries(data).forEach(function (e) {
            var checkbox = document.getElementById(e[0]);
            if (checkbox) {
                checkbox.checked = (e[1] === '1');
                checkbox.value = e[1];
            }
        });
        var cbMM = document.getElementById('multi_matrix_enable');
        if (cbMM) {
            cbMM.checked = (data.multi_matrix_enable === '1');
            cbMM.value = (data.multi_matrix_enable === '1') ? '1' : '0';
        }
        applyMultiMatrixVisibility();
        applyModuleVisibility();
        applySdVisibility(data);
    })
    .catch(function (err) {
        console.error('Ошибка загрузки состояний:', err);
    });

    fetch('/features')
    .then(function (r) {
        return r.json();
    })
    .then(function (data) {
        state.features = data;
        window.features = data;
    })
    .catch(function (err) {
        console.warn('Ошибка загрузки features:', err);
    });
}

function applySdTypeVisibility(states) {
    var sdEnabled = states && states.sd_enable === '1';
    var sdType = states && states.sd_type !== undefined ? String(states.sd_type) : '0';
    var sdTypeSel = document.getElementById('sd_type');
    if (sdTypeSel) {
        sdTypeSel.style.display = sdEnabled ? 'inline-flex' : 'none';
        sdTypeSel.value = sdType;
    }
}

function applySdVisibility(states) {
    var sdEnabled = states && states.sd_enable === '1';
    var outSel = document.getElementById('out_sel');
    if (outSel)
        outSel.classList.toggle('visible', sdEnabled);
    applySdTypeVisibility(states);
    if (sdEnabled) {
        loadOutFilesList();
        syncOutSel();
    }
}

/* ------------------------------- */

function updateStatusElement(id, text, type) {
    var spanEl = document.getElementById(id);
    if (!spanEl)
        return;
    var wrapper = spanEl.parentElement;
    if (!wrapper)
        return;
    var card = wrapper.closest ? wrapper.closest('.status-card') : null;
    if (!card)
        return;

    spanEl.textContent = text || 'НЕТ ДАННЫХ';
    card.classList.remove('status-ok', 'status-warning', 'status-error', 'status-disabled');

    var color = '#888888';
    if (statusColors[type]) {
        for (var status in statusColors[type]) {
            if (text.indexOf(status) !== -1) {
                color = statusColors[type][status];
                break;
            }
        }
    }
    if (type === 'weather' && text !== '—' && text.indexOf('°C') !== -1) {
        var match = text.match(/([+-]?\d+\.?\d*)\s*°C/);
        if (match) {
            var temp = parseFloat(match[1]);
            if (!isNaN(temp))
                color = temp <= -20 ? '#00ffff' : temp <= -10 ? '#0099ff' : temp < 0 ? '#0088ff' : temp >= 35 ? '#ff0000' : temp >= 25 ? '#ff8800' : '#00ff00';
        }
    }

    if (['#00ff00', '#00ff88', '#00cc00', '#0088ff', '#0099ff', '#00ffff'].indexOf(color) !== -1) {
        card.classList.add('status-ok');
        wrapper.className = 'status-value status-ok';
    } else if (['#ff0000', '#ff4444'].indexOf(color) !== -1) {
        card.classList.add('status-error');
        wrapper.className = 'status-value status-error';
    } else if (['#ffff00', '#ff8800', '#ffaa00'].indexOf(color) !== -1) {
        card.classList.add('status-warning');
        wrapper.className = 'status-value status-warning';
    } else {
        card.classList.add('status-disabled');
        wrapper.className = 'status-value status-disabled';
    }
}

function updateAllStatuses() {
    if (!features.status_modal)
        return;

    if (features.sd)
        fetch('/sd_status').then(function (r) {
            return r.json();
        }).then(function (d) {
            updateStatusElement('status-sd', d.sd_status, 'sd');
        }).catch(function () {});
    else
        updateStatusElement('status-sd', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'sd');

    if (features.mp3)
        fetch('/mp3_status').then(function (r) {
            return r.json();
        }).then(function (d) {
            updateStatusElement('status-mp3', d.mp3_status, 'mp3');
        }).catch(function () {});
    else
        updateStatusElement('status-mp3', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'mp3');

    if (features.radio) {
        fetch('/radio_status?t=' + Date.now()).then(function (r) {
            return r.json();
        }).then(function (d) {
            var text = '—';
            if (!d.enabled)
                text = 'ОТКЛЮЧЕНО В ПРОШИВКЕ';
            else if (d.playing) {
                text = 'ИГРАЕТ';
                if (d.station_name)
                    text += ': ' + d.station_name;
            } else if (d.paused)
                text = 'ПАУЗА';
            else if (d.ready)
                text = 'OK';
            else
                text = 'ОСТАНОВЛЕНО';
            updateStatusElement('status-radio', text, 'radio');
        }).catch(function () {
            updateStatusElement('status-radio', 'НЕТ СВЯЗИ', 'radio');
        });
    }

    if (features.tm1637)
        fetch('/tm1637_status').then(function (r) {
            return r.json();
        }).then(function (d) {
            updateStatusElement('status-tm1637', d.status, 'tm1637');
        }).catch(function () {});
    else
        updateStatusElement('status-tm1637', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'tm1637');

    if (features.st7789)
        fetch('/st7789_status').then(function (r) {
            return r.json();
        }).then(function (d) {
            updateStatusElement('status-st7789', d.status, 'st7789');
        }).catch(function () {});
    else
        updateStatusElement('status-st7789', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'st7789');

    if (features.button)
        fetch('/button_status?t=' + Date.now()).then(function (r) {
            return r.json();
        }).then(function (d) {
            updateStatusElement('status-button', d.button_status, 'button');
        }).catch(function () {});
    else
        updateStatusElement('status-button', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'button');

    if (features.ir || features.rf) {
        fetch('/ir_rf_status?t=' + Date.now()).then(function (r) {
            return r.json();
        }).then(function (d) {
            updateStatusElement('status-ir', d.ir, 'ir');
            updateStatusElement('status-rf', d.rf, 'rf');
            var remoteSpan = document.getElementById('status-ir-remote');
            if (remoteSpan) {
                if (d.ir_remote && d.ir_remote !== '—' && d.ir_remote !== 'Не выбран') {
                    remoteSpan.textContent = d.ir_remote;
                    remoteSpan.style.color = 'rgb(0 255 20)';
                } else {
                    remoteSpan.textContent = '—';
                    remoteSpan.style.color = '#666';
                }
            }
        }).catch(function () {});
    } else {
        updateStatusElement('status-ir', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'ir');
        updateStatusElement('status-rf', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'rf');
        var remoteSpan2 = document.getElementById('status-ir-remote');
        if (remoteSpan2) {
            remoteSpan2.textContent = '—';
            remoteSpan2.style.color = '#666';
        }
    }

    if (features.weather) {
        fetch('/get_weather?t=' + Date.now()).then(function (r) {
            return r.json();
        }).then(function (d) {
            var span = document.getElementById('status-weather');
            if (!span)
                return;
            if (d.enabled === false) {
                span.textContent = d.text || 'ОТКЛЮЧЕНО В ПРОШИВКЕ';
                var card0 = span.closest('.status-card');
                var wrapper0 = span.parentElement;
                card0.classList.remove('status-ok', 'status-warning', 'status-error', 'status-disabled');
                card0.classList.add('status-disabled');
                wrapper0.className = 'status-value status-disabled';
                return;
            }
            var displayText = '—';
            var realProvider = (d.provider === 'yandex') ? 'Яндекс' : 'OpenWeather';
            if (d.temp != null && d.temp > -999) {
                var temp = d.temp;
                var sign = temp > 0 ? '+' : '';
                var showCondition = (d.show_condition !== false);
                var condition = showCondition ? (d.condition || '').trim() : '';
                displayText = realProvider + ': ' + sign + temp.toFixed(0) + '°C';
                if (condition)
                    displayText += ', ' + condition;
            }
            span.textContent = displayText || '—';
            var card = span.closest('.status-card');
            var wrapper = span.parentElement;
            card.classList.remove('status-ok', 'status-warning', 'status-error', 'status-disabled');
            wrapper.className = 'status-value';
            if (displayText !== '—' && displayText.indexOf('°C') !== -1) {
                var m = displayText.match(/([+-]?\d+)/);
                if (m) {
                    var t = parseFloat(m[1]);
                    if (t <= -10) {
                        card.classList.add('status-ok');
                        wrapper.className = 'status-value status-ok';
                    } else if (t < 0) {
                        card.classList.add('status-ok');
                        wrapper.className = 'status-value status-ok';
                    } else if (t >= 35) {
                        card.classList.add('status-error');
                        wrapper.className = 'status-value status-error';
                    } else if (t >= 25) {
                        card.classList.add('status-warning');
                        wrapper.className = 'status-value status-warning';
                    } else {
                        card.classList.add('status-ok');
                        wrapper.className = 'status-value status-ok';
                    }
                }
            } else {
                card.classList.add('status-disabled');
                wrapper.className = 'status-value status-disabled';
            }
        }).catch(function () {
            var sp = document.getElementById('status-weather');
            if (sp)
                sp.textContent = 'Нет связи';
        });
    } else {
        var sp2 = document.getElementById('status-weather');
        if (sp2) {
            sp2.textContent = 'ОТКЛЮЧЕНО В ПРОШИВКЕ';
            var card2 = sp2.closest('.status-card');
            var wrapper2 = sp2.parentElement;
            card2.classList.remove('status-ok', 'status-warning', 'status-error', 'status-disabled');
            card2.classList.add('status-disabled');
            wrapper2.className = 'status-value status-disabled';
        }
    }

    if (features.ota) {
        fetch('/ota_status?t=' + Date.now()).then(function (r) {
            if (!r.ok)
                throw new Error('Ошибка сети');
            return r.json();
        }).then(function (d) {
            var text = 'ГОТОВ';
            if (!d.enabled)
                text = 'ОТКЛЮЧЕНО В ПРОШИВКЕ';
            else if (d.status)
                text = d.status;
            updateStatusElement('status-ota', text, 'ota');
        }).catch(function () {
            updateStatusElement('status-ota', 'ОШИБКА', 'ota');
        });
    } else
        updateStatusElement('status-ota', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'ota');

    if (features.mqtt) {
        fetch('/mqtt_status?t=' + Date.now() + '&_=' + Math.random().toString(36).substring(2)).then(function (r) {
            return r.json();
        }).then(function (d) {
            var text = d.status || 'НЕТ ДАННЫХ';
            if (!d.enabled)
                text = 'ОТКЛЮЧЕНО В ПРОШИВКЕ';
            else if (d.connected === true)
                text = 'ПОДКЛЮЧЕНО';
            else
                text = 'НЕ ПОДКЛЮЧЕНО';
            updateStatusElement('status-mqtt', text, 'mqtt');
            var mqttEl = document.querySelector('#status-mqtt');
            var mqttCard = mqttEl ? mqttEl.closest('.status-card') : null;
            if (mqttCard && text.indexOf('НЕ ПОДКЛЮЧЕНО') !== -1)
                mqttCard.className = 'status-card status-warning';
        }).catch(function () {
            updateStatusElement('status-mqtt', 'ОШИБКА СВЯЗИ', 'mqtt');
        });
    } else
        updateStatusElement('status-mqtt', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'mqtt');

    if (features.multilamp) {
        fetch('/multilamp_status?t=' + Date.now()).then(function (r) {
            return r.json();
        }).then(function (d) {
            var text = d.enabled ? 'ВКЛЮЧЕНО' : 'ОТКЛЮЧЕНО В ПРОШИВКЕ';
            updateStatusElement('status-multilamp', text, 'multilamp');
        }).catch(function () {
            updateStatusElement('status-multilamp', 'ОШИБКА', 'multilamp');
        });
    } else
        updateStatusElement('status-multilamp', 'ОТКЛЮЧЕНО В ПРОШИВКЕ', 'multilamp');

    fetch('/wifi_ip?t=' + Date.now()).then(function (r) {
        return r.json();
    }).then(function (d) {
        var text = '—';
        if (d.sta_ip && d.sta_ip !== 'Не подключён')
            text = d.sta_ip;
        else if (d.ip)
            text = d.ip;
        else if (!d.connected && d.ap_ip && d.ap_ip !== '0.0.0.0')
            text = d.ap_ip;
        var span = document.getElementById('status-wifi-ip');
        if (span) {
            var wrapper = span.parentElement;
            var card = wrapper.closest('.status-card');
            if (text.indexOf('192.168.') !== -1 || text.indexOf('10.') !== -1 || text.indexOf('172.') !== -1) {
                updateStatusElement('status-wifi-ip', text, 'wifi');
                card.classList.remove('status-error', 'status-warning', 'status-disabled');
                card.classList.add('status-ok');
                wrapper.className = 'status-value status-ok';
            } else
                updateStatusElement('status-wifi-ip', text, 'wifi');
        }
    }).catch(function () {
        updateStatusElement('status-wifi-ip', 'Нет связи', 'wifi');
    });
}

function showStatusInfo() {
    if (!document.querySelector('[data-feature="status_modal"]')) {
        console.warn('Статусы устройств отключены в прошивке');
        return;
    }
    document.getElementById('statusModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
    updateAllStatuses();
    updateSyncClock();
    if (features.memory_info)
        updateMemoryInfo();
}

function hideStatusInfo() {
    document.getElementById('statusModal').style.display = 'none';
    document.body.style.overflow = '';
}

function refreshAllStatuses() {
    updateAllStatuses();
}

/* ------------------------------- */

var cachedVersion = null,
cachedBuildDateTime = null,
cachedModAuthor = null;
var isVersionLoading = false;
var isUpdateCheckInProgress = false;

function getCachedVersion() {
    try {
        var c = localStorage.getItem(STORAGE_KEYS.VERSION_CACHE);
        return c ? JSON.parse(c) : null;
    } catch (e) {
        return null;
    }
}

function setCachedVersion(version, buildDateTime, author) {
    try {
        localStorage.setItem(STORAGE_KEYS.VERSION_CACHE, JSON.stringify({
                version: version,
                buildDateTime: buildDateTime,
                author: author || '',
                timestamp: Date.now()
            }));
    } catch (e) {}
}

function getCachedUpdateCheck() {
    try {
        var c = localStorage.getItem(STORAGE_KEYS.UPDATE_CHECK_CACHE);
        if (!c)
            return null;
        var data = JSON.parse(c);
        if (Date.now() - data.timestamp > CONFIG.UPDATE_CHECK_CACHE_TTL)
            return null;
        return data;
    } catch (e) {
        return null;
    }
}

function setCachedUpdateCheck(data) {
    try {
        var cacheData = Object.assign({}, data, {
            timestamp: Date.now()
        });
        localStorage.setItem(STORAGE_KEYS.UPDATE_CHECK_CACHE, JSON.stringify(cacheData));
    } catch (e) {}
}

function showUpdateBadge(version) {
    var badge = document.getElementById('update-badge');
    if (!badge)
        return;
    var txt = badge.querySelector('.update-text');
    if (txt)
        txt.style.willChange = 'transform';
    badge.style.display = 'inline-flex';
    badge.title = 'Доступно обновление: ' + (version || '');
}

function hideUpdateBadge() {
    var badge = document.getElementById('update-badge');
    if (!badge)
        return;
    var txt = badge.querySelector('.update-text');
    if (txt)
        txt.style.willChange = 'auto';
    badge.style.display = 'none';
}

function refreshUpdateBadge() {
    var data = window._updateData;
    if (!data || data.has_update !== true) {
        hideUpdateBadge();
        return;
    }
    var updates = Array.isArray(data.updates) ? data.updates : [];
    var buildDate = String((window._versionData && window._versionData.build_datetime) || '').trim();
    if (updates.length > 0 && buildDate) {
        var allInstalled = updates.every(function (u) {
            var d = String(u.datetime_iso || '').trim();
            return d && d <= buildDate;
        });
        if (allInstalled) {
            hideUpdateBadge();
            return;
        }
    }
    var firstFile = updates.length > 0 ? updates[0].file : '';
    showUpdateBadge(firstFile);
}

function loadVersionInfo() {
    return new Promise(function (resolve, reject) {
        var cached = getCachedVersion();
        if (cached && cached.version && (Date.now() - cached.timestamp < CONFIG.VERSION_CACHE_TTL)) {
            updateVersionDisplay(cached.version, cached.buildDateTime, cached.author);
            resolve(cached.version);
            return;
        }
        var verEl = document.getElementById('currentVer');
        if (verEl)
            verEl.innerText = 'Загрузка...';

        var controller = new AbortController();
        var timeoutId = setTimeout(function () {
            controller.abort();
            if (verEl)
                verEl.innerText = 'Таймаут';
            var oldCache = getCachedVersion();
            if (oldCache && oldCache.version) {
                updateVersionDisplay(oldCache.version, oldCache.buildDateTime, oldCache.author);
                resolve(oldCache.version);
            } else
                reject(new Error('Timeout'));
        }, 5000);

        fetch('/get_version?t=' + Date.now(), {
            signal: controller.signal
        })
        .then(function (r) {
            clearTimeout(timeoutId);
            if (!r.ok)
                throw new Error('HTTP ' + r.status);
            return r.json();
        })
        .then(function (data) {
            var version = data.current_version || 'v1.0.0';
            var buildDateTime = data.build_datetime || '';
            var author = data.mod_author || '';
            setCachedVersion(version, buildDateTime, author);
            updateVersionDisplay(version, buildDateTime, author);
            window._versionData = data;
            cachedVersion = version;
            cachedBuildDateTime = buildDateTime;
            cachedModAuthor = author;
            refreshUpdateBadge();
            var downloadBtn = document.getElementById('downloadCurrentBtn');
            if (downloadBtn) {
                downloadBtn.href = 'https://github.com/an-core/FieryLedLamp_mod/tree/main/FieryLedLamp';
                downloadBtn.target = '_blank';
                downloadBtn.rel = 'noopener noreferrer';
                downloadBtn.innerHTML = 'Скачать архив';
            }
            resolve(version);
        })
        .catch(function (error) {
            clearTimeout(timeoutId);
            console.error('Version load error:', error);
            if (verEl)
                verEl.innerText = 'Ошибка';
            var oldCache = getCachedVersion();
            if (oldCache && oldCache.version) {
                updateVersionDisplay(oldCache.version, oldCache.buildDateTime, oldCache.author);
                resolve(oldCache.version);
            } else
                reject(error);
        });
    });
}

function updateVersionDisplay(version, buildDateTime, author) {
    var verEl = document.getElementById('currentVer');
    if (verEl)
        verEl.innerText = version || 'v1.0.0';
    var buildEl = document.getElementById('buildDateTime');
    if (buildEl && buildDateTime)
        buildEl.textContent = formatBuildDateTime(buildDateTime);
    else if (buildEl)
        buildEl.textContent = 'Сборка: не указана';
    var authorEl = document.getElementById('modAuthor');
    if (authorEl && author)
        authorEl.textContent = author;
}

function refreshVersionInfo() {
    fetch('/get_version?t=' + Date.now())
    .then(function (r) {
        if (!r.ok)
            throw new Error('HTTP ' + r.status);
        return r.json();
    })
    .then(function (data) {
        var cacheData = {
            version: data.current_version || 'v1.0.0',
            buildDateTime: data.build_datetime || '',
            author: data.mod_author || '',
            timestamp: Date.now()
        };
        localStorage.setItem(STORAGE_KEYS.VERSION_CACHE, JSON.stringify(cacheData));
        updateVersionDisplay(cacheData.version, cacheData.buildDateTime, cacheData.author);
        refreshUpdateBadge();
    })
    .catch(function (err) {
        console.error('Error refreshing version:', err);
        try {
            var cached = localStorage.getItem(STORAGE_KEYS.VERSION_CACHE);
            if (cached) {
                var data = JSON.parse(cached);
                updateVersionDisplay(data.version, data.buildDateTime, data.author);
                refreshUpdateBadge();
            }
        } catch (e) {}
    });
}

function checkForUpdate(forceCheck) {
    if (window.features && window.features.update_check === false) {
        return;
    }

    if (isUpdateCheckInProgress) {
        console.log('Проверка обновлений уже выполняется');
        return;
    }

    if (!forceCheck) {
        var cached = getCachedUpdateCheck();
        if (cached) {
            if (cached.has_update) {
                showUpdateAvailable(cached);
                showUpdateStatus(cached);
            } else {
                var ub = document.getElementById('updateAvailable');
                if (ub)
                    ub.style.display = 'none';
                showUpdateStatus({
                    has_update: false
                });
            }
            updateLastCheckDisplay(cached.timestamp);
            return;
        }
    }

    isUpdateCheckInProgress = true;
    var loadingEl = document.getElementById('updateLoading');
    if (loadingEl) {
        loadingEl.style.display = 'inline-block';
        loadingEl.textContent = '';
    }

    var statusContainer = document.getElementById('updateStatusContainer');
    if (statusContainer) {
        var statusDiv = statusContainer.querySelector('.update-status');
        if (!statusDiv) {
            statusDiv = document.createElement('div');
            statusDiv.className = 'update-status';
            statusContainer.appendChild(statusDiv);
        }
        statusDiv.style.cssText = 'background: rgba(255,255,255,0.05); border-radius: 12px; padding: 12px 16px; margin-top: 8px; display: flex; align-items: center; gap: 10px;';
        statusDiv.innerHTML = '<span style="font-size: 20px;">⏳</span><div><div style="color: #90a4ae; font-weight: 500; font-size: 14px;">Проверка обновлений...</div></div>';
    }

    var controller = new AbortController();
    var timeoutId = setTimeout(function () {
        controller.abort();
        console.warn('Таймаут проверки обновлений');
        isUpdateCheckInProgress = false;
        if (loadingEl)
            loadingEl.style.display = 'none';
        var sc = document.getElementById('updateStatusContainer');
        if (sc) {
            var sd = sc.querySelector('.update-status');
            if (sd) {
                sd.style.cssText = NOTIFICATION_STYLES.ERROR;
                sd.innerHTML = '<span style="font-size: 20px;">⏱️</span><div><div style="color: #ef5350; font-weight: bold; font-size: 14px;">Таймаут проверки</div><div style="color: #90a4ae; font-size: 12px;">Сервер не отвечает</div></div>';
                setTimeout(function () {
                    hideStatusWithAnimation(sd);
                }, 5000);
            }
        }
    }, 15000);

    fetch('/check_update?t=' + Date.now(), {
        signal: controller.signal
    })
    .then(function (r) {
        clearTimeout(timeoutId);
        if (!r.ok)
            throw new Error('HTTP ' + r.status);
        return r.json();
    })
    .then(function (data) {
        if (loadingEl)
            loadingEl.style.display = 'none';
        setCachedUpdateCheck(data);
        window._updateData = data;
        if (data.has_update === true) {
            showUpdateStatus(data);
            showUpdateAvailable(data);
            refreshUpdateBadge();
        } else {
            var ub = document.getElementById('updateAvailable');
            if (ub)
                ub.style.display = 'none';
            showUpdateStatus({
                has_update: false
            });
            hideUpdateBadge();
        }
        updateLastCheckDisplay(Date.now());
        isUpdateCheckInProgress = false;
    })
    .catch(function (error) {
        clearTimeout(timeoutId);
        if (loadingEl)
            loadingEl.style.display = 'none';
        console.error('Ошибка проверки обновлений:', error);
        var ub = document.getElementById('updateAvailable');
        if (ub)
            ub.style.display = 'none';
        var sc = document.getElementById('updateStatusContainer');
        if (sc) {
            var sd = sc.querySelector('.update-status');
            if (!sd) {
                sd = document.createElement('div');
                sd.className = 'update-status';
                sc.appendChild(sd);
            }
            sd.style.cssText = NOTIFICATION_STYLES.ERROR;
            sd.innerHTML = '<span style="font-size: 20px;">❌</span><div><div style="color: #ef5350; font-weight: bold; font-size: 14px;">Ошибка проверки</div><div style="color: #90a4ae; font-size: 12px;">' + (error.message || 'Проверьте подключение') + '</div></div>';
            setTimeout(function () {
                hideStatusWithAnimation(sd);
            }, 5000);
        }
        isUpdateCheckInProgress = false;
    });
}

function manualCheckUpdate(event) {
    if (event)
        event.stopPropagation();
    checkForUpdate(true);
}

function showUpdateAvailable(data) {
    var updateBlock = document.getElementById('updateAvailable');
    if (!updateBlock)
        return;
    updateBlock.style.display = 'block';
    updateBlock.style.background = 'linear-gradient(130deg, #7b0000,#4d24242b,#0d0d0f59, #280707,#4f0505)';
    updateBlock.classList.add('has-update');
    var updateLabel = document.getElementById('updateLabel');
    if (updateLabel)
        updateLabel.innerHTML = 'Вышло обновление мода';
    var listEl = document.getElementById('updateFilesList');
    if (!listEl)
        return;
    listEl.innerHTML = '';
    var updates = Array.isArray(data.updates) ? data.updates : [];
    if (updates.length === 0 && data.update_version) {
        updates.push({
            file: data.update_version,
            datetime: data.update_datetime || '',
            download_url: data.update_folder_url || 'https://github.com/an-core/FieryLedLamp_mod/tree/main/update'
        });
    }
    updates.forEach(function (item) {
        var file = String(item.file || '').trim();
        if (!file)
            return;
        var dateStr = String(item.datetime || '').trim();
        var url = String(item.download_url || '').trim();
        var row = document.createElement('div');
        row.className = 'update-file-row';
        var link = document.createElement('a');
        link.href = url;
        link.download = file;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.className = 'update-file-link';
        link.textContent = file;
        row.appendChild(link);
        if (dateStr) {
            var ds = document.createElement('span');
            ds.className = 'update-file-date';
            ds.textContent = ' от ' + dateStr;
            row.appendChild(ds);
        }
        listEl.appendChild(row);
    });
}

function showUpdateStatus(data) {
    var container = document.getElementById('updateStatusContainer');
    if (!container)
        return;
    var statusDiv = container.querySelector('.update-status');
    if (!statusDiv) {
        statusDiv = document.createElement('div');
        statusDiv.className = 'update-status';
        container.appendChild(statusDiv);
    }

    var currentVersion = data.update_version || 'unknown';
    if (data.has_update === true) {
        var shownVersion = localStorage.getItem(STORAGE_KEYS.UPDATE_NOTIFICATION);
        if (shownVersion === currentVersion) {
            statusDiv.style.display = 'none';
            return;
        }
    }
    if (statusDiv._hideTimer) {
        clearTimeout(statusDiv._hideTimer);
        statusDiv._hideTimer = null;
    }
    statusDiv.classList.remove('hiding', 'hidden-status');
    statusDiv.style.display = 'flex';
    statusDiv.style.opacity = '1';

    var displayTime = 3000;
    if (data.has_update === true) {
        displayTime = 5000;
        statusDiv.style.cssText = NOTIFICATION_STYLES.UPDATE_AVAILABLE + ' opacity: 1; transform: translateY(0); transition: opacity 0.5s ease-in-out, transform 0.3s ease-in-out;';
        statusDiv.innerHTML = '<div><div style="color: #4caf50; font-weight: bold; font-size: 15px;">Доступно новое обновление!</div></div>';
        localStorage.setItem(STORAGE_KEYS.UPDATE_NOTIFICATION, currentVersion);
    } else if (data.has_update === false || data.has_update === undefined) {
        localStorage.removeItem(STORAGE_KEYS.UPDATE_NOTIFICATION);
        if (data.error) {
            displayTime = 6000;
            statusDiv.style.cssText = NOTIFICATION_STYLES.ERROR + ' opacity: 1; transform: translateY(0); transition: opacity 0.5s ease-in-out, transform 0.3s ease-in-out;';
            statusDiv.innerHTML = '<span style="font-size: 24px;">⚠️</span><div><div style="color: #ef5350; font-weight: bold; font-size: 15px;">Ошибка проверки обновлений</div><div style="color: #90a4ae; font-size: 13px; margin-top: 2px;">' + data.error + '</div></div>';
        } else {
            statusDiv.style.cssText = NOTIFICATION_STYLES.NO_UPDATE + ' opacity: 1; transform: translateY(0); transition: opacity 0.5s ease-in-out, transform 0.3s ease-in-out;';
            statusDiv.innerHTML = '<div><div style="color: #64b5f6; font-weight: bold; font-size: 15px;">У вас установлена последняя версия</div></div>';
        }
    }
    statusDiv._hideTimer = setTimeout(function () {
        hideStatusWithAnimation(statusDiv);
    }, displayTime);
}

function hideStatusWithAnimation(statusDiv) {
    if (!statusDiv)
        return;
    if (statusDiv._hideTimer) {
        clearTimeout(statusDiv._hideTimer);
        statusDiv._hideTimer = null;
    }
    statusDiv.classList.add('hiding');
    statusDiv._hideTimer = setTimeout(function () {
        statusDiv.classList.add('hidden-status');
        statusDiv.style.display = 'none';
        statusDiv.classList.remove('hiding');
    }, 500);
}

function updateLastCheckDisplay(timestamp) {
    var container = document.getElementById('lastCheckContainer');
    if (!container)
        return;
    var time = timestamp ? new Date(timestamp) : new Date();
    var dateStr = time.toLocaleString('ru-RU', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
    container.innerHTML = '<div style="font-size: 0.8em; color: #78909c; margin-top: 6px; padding-top: 6px; border-top: 1px solid rgba(255,255,255,0.06); display: flex; align-items: center; gap: 6px;"><span style="opacity:0.6; cursor: pointer; transition: transform 0.2s; display: inline-block;" onclick="manualCheckUpdate(event)" onmouseover="this.style.transform=\'rotate(180deg)\'" onmouseout="this.style.transform=\'rotate(0deg)\'" title="Нажмите для ручной проверки обновлений">🔄</span><span>Время проверки: </span><span style="color: #a0b4c4; font-weight: 500;">' + dateStr + '</span></div>';
    container.style.display = 'block';
}

function showSoftwareInfo() {
    if (!document.querySelector('[data-feature="software_modal"]')) {
        console.warn('Информация о ПО отключена в прошивке');
        return;
    }
    if (window._memoryUpdateInterval) {
        clearInterval(window._memoryUpdateInterval);
        window._memoryUpdateInterval = null;
    }
    document.getElementById('softwareModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
    loadVersionInfo()
    .then(function () {
        setTimeout(function () {
            if (!window.features || window.features.update_check !== false) {
                checkForUpdate(false);
            }
        }, 300);
    })
    .catch(function (error) {
        console.error('Ошибка загрузки информации о ПО:', error);
    });
}

function hideSoftwareInfo() {
    document.getElementById('softwareModal').style.display = 'none';
    document.body.style.overflow = '';
    var statusDiv = document.querySelector('.update-status');
    if (statusDiv && statusDiv._hideTimer) {
        clearTimeout(statusDiv._hideTimer);
        statusDiv._hideTimer = null;
    }
    if (!window._memoryUpdateInterval && features && features.memory_info) {
    }
}

/* ------------------------------- */

function showChangelogModal() {
    var modal = document.getElementById('changelogModal');
    if (!modal)
        return;
    modal.style.display = 'block';
    var content = document.getElementById('changelogContent');
    if (!content)
        return;
    if (window._updateData && window._updateData.changelog) {
        renderChangelog(content);
        return;
    }
    content.innerHTML = '<div style="text-align: center; padding: 20px; color: #666;"><span class="loader-bar" style="display: inline-block; margin: 0 3px;"></span><span class="loader-bar" style="display: inline-block; margin: 0 3px; animation-delay: -1.1s;"></span><span class="loader-bar" style="display: inline-block; margin: 0 3px; animation-delay: -1.0s;"></span><br><br><span style="color: #888;">Загрузка списка изменений...</span></div>';
    fetch('/check_update?t=' + Date.now()).then(function (r) {
        return r.json();
    }).then(function (data) {
        window._updateData = data;
        if (data && data.changelog && data.changelog.length > 0)
            renderChangelog(content);
        else
            content.innerHTML = '<div style="text-align:center;padding:20px;color:#ff9800;">Список изменений пока пуст</div>';
    }).catch(function () {
        content.innerHTML = '<div style="text-align:center;padding:20px;color:#ef5350;">Ошибка загрузки данных</div>';
    });
}

function showPlannedUpdates() {
    var content = document.getElementById('changelogContent');
    if (!content)
        return;
    content.innerHTML = '<div style="text-align: center; padding: 20px; color: #666;"><span class="loader-bar" style="display: inline-block; margin: 0 3px;"></span><span class="loader-bar" style="display: inline-block; margin: 0 3px; animation-delay: -1.1s;"></span><span class="loader-bar" style="display: inline-block; margin: 0 3px; animation-delay: -1.0s;"></span><br><br><span style="color: #888;">Загрузка планируемых обновлений...</span></div>';
    fetch('/check_update?t=' + Date.now()).then(function (r) {
        return r.json();
    }).then(function (data) {
        window._updateData = data;
        if (data && data.planned && data.planned.length > 0) {
            var tempData = {
                update_version: 'Планы на будущее',
                changelog: data.planned
            };
            var currentData = window._updateData;
            window._updateData = tempData;
            renderChangelog(content);
            window._updateData = currentData;
        } else
            content.innerHTML = '<div style="text-align:center;padding:20px;color:#ff9800;">Список планируемых обновлений пока пуст</div>';
    }).catch(function (error) {
        console.error('Ошибка загрузки planned:', error);
        content.innerHTML = '<div style="text-align:center;padding:20px;color:#ef5350;">Ошибка загрузки данных</div>';
    });
}

function showCurrentChangelog() {
    var content = document.getElementById('changelogContent');
    if (!content)
        return;
    content.innerHTML = '<div style="text-align: center; padding: 20px; color: #666;"><span class="loader-bar" style="display: inline-block; margin: 0 3px;"></span><span class="loader-bar" style="display: inline-block; margin: 0 3px; animation-delay: -1.1s;"></span><span class="loader-bar" style="display: inline-block; margin: 0 3px; animation-delay: -1.0s;"></span><br><br><span style="color: #888;">Загрузка...</span></div>';
    fetch('/check_update?t=' + Date.now()).then(function (r) {
        return r.json();
    }).then(function (data) {
        window._updateData = data;
        if (data && data.changelog && data.changelog.length > 0)
            renderChangelog(content);
        else
            content.innerHTML = '<div style="text-align:center;padding:20px;color:#ff9800;">Список изменений пока пуст</div>';
    }).catch(function () {
        content.innerHTML = '<div style="text-align:center;padding:20px;color:#ef5350;">Ошибка загрузки данных</div>';
    });
}

function renderChangelog(content) {
    var data = window._updateData;
    var version = data && data.update_version ? data.update_version : 'Обновление';
    var dateTime = data && (data.update_datetime || data.update_date) ? (data.update_datetime || data.update_date) : '';
    var isPlanned = version === 'Планы на будущее';
    var htmlStr = '<div style="margin-bottom: 16px; padding-bottom: 16px; border-bottom: 1px solid rgba(255,255,255,0.08);"><div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;"><div><span style="color: #64b5f6; font-weight: bold;">' + version + '</span><span style="color: #90a4ae; font-size: 13px; margin-left: 12px;">' + (dateTime ? 'от ' + dateTime : '') + '</span></div><div style="display: flex; gap: 8px;"><button onclick="' + (isPlanned ? 'showCurrentChangelog()' : 'showPlannedUpdates()') + '" style="background: ' + (isPlanned ? 'rgba(100, 181, 246, 0.2)' : 'rgb(43 41 58 / 75%)') + ';color: ' + (isPlanned ? '#64b5f6' : 'rgb(238 243 242 / 68%)') + ';border: 1px solid ' + (isPlanned ? 'rgba(100, 181, 246, 0.3)' : 'rgba(255, 152, 0, 0.3)') + ';padding: 4px 10px; border-radius: 6px; cursor: pointer; font-size: 11px; transition: all 0.3s ease; display: inline-flex; align-items: center; gap: 4px;" onmouseover="this.style.transform=\'scale(1.05)\'" onmouseout="this.style.transform=\'scale(1)\'">' + (isPlanned ? 'Текущие изменения' : 'Планы') + '</button></div></div></div><ul style="list-style: none; padding: 0; margin: 0;">';

    if (data && data.changelog && data.changelog.length > 0) {
        var prevUpdateCounter = 0;
        var currentSection = 'new';
        data.changelog.forEach(function (item) {
            var type = 'item';
            var text = '';
            if (typeof item === 'object' && item !== null) {
                type = item.type || 'item';
                text = item.text || '';
            } else if (typeof item === 'string') {
                text = item;
            } else
                return;
            var safeText = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            var style = '';
            if (type === 'header') {
                if (safeText.indexOf('ВНИМАНИЕ!') !== -1) {
                    currentSection = 'attention';
                    style = HEADER_STYLES.ATTENTION;
                } else if (safeText.indexOf('ПРЕДЫДУЩЕЕ ОБНОВЛЕНИЕ') !== -1 || safeText.indexOf('ПРОШЛОЕ ОБНОВЛЕНИЕ') !== -1) {
                    currentSection = 'previous';
                    prevUpdateCounter++;
                    if (prevUpdateCounter === 1)
                        style = HEADER_STYLES.PREVIOUS_1;
                    else if (prevUpdateCounter === 2)
                        style = HEADER_STYLES.PREVIOUS_2;
                    else
                        style = HEADER_STYLES.PREVIOUS_OTHER;
                } else if (safeText.indexOf('ОБНОВЛЕНИЕ FIRMWARE и FS') !== -1) {
                    currentSection = 'firmware_fs';
                    style = HEADER_STYLES.FIRMWARE_FS;
                } else if (safeText.indexOf('ОБНОВЛЕНИЕ FIRMWARE') !== -1) {
                    currentSection = 'firmware';
                    style = HEADER_STYLES.FIRMWARE;
                } else if (safeText.indexOf('НОВОЕ ОБНОВЛЕНИЕ') !== -1) {
                    currentSection = 'new';
                    style = HEADER_STYLES.NEW;
                } else if (safeText.indexOf('ПЛАНИРУЕМЫЕ ОБНОВЛЕНИЯ') !== -1) {
                    currentSection = 'planned';
                    style = 'color: #ff6f00; font-weight: bold; font-size: 15px; padding-left:4px; border-radius:8px; background: rgba(255, 111, 0, 0.2); border: 1px dashed rgba(255, 111, 0, 0.3);';
                } else if (safeText.indexOf('ИДЕИ ДЛЯ ОБНОВЛЕНИЙ') !== -1) {
                    currentSection = 'ideas';
                    style = 'color: #7c4dff; font-weight: bold; font-size: 15px; padding-left:10px; border-radius:8px; background: rgb(109 69 207 / 44%); border: 1px dashed rgba(124, 77, 255, 0.2);';
                } else {
                    currentSection = 'default';
                    style = HEADER_STYLES.DEFAULT;
                }
            } else if (type === 'item') {
                if (safeText.indexOf('  ') === 0)
                    style = ITEM_STYLES.INDENT;
                else {
                    switch (currentSection) {
                    case 'attention':
                        style = ITEM_STYLES.ATTENTION;
                        break;
                    case 'new':
                        style = ITEM_STYLES.NEW;
                        break;
                    case 'previous':
                        style = ITEM_STYLES.PREVIOUS;
                        break;
                    case 'firmware':
                        style = 'padding: 8px 14px; margin-bottom: 4px; background: rgba(41, 182, 246, 0.06); border-radius: 8px; border-left: 3px solid #29b6f6;';
                        break;
                    case 'firmware_fs':
                        style = 'padding: 8px 14px; margin-bottom: 4px; background: rgba(171, 71, 188, 0.06); border-radius: 8px; border-left: 3px solid #ab47bc;';
                        break;
                    case 'planned':
                        style = 'padding: 8px 14px; margin-bottom: 4px; background: rgba(255, 111, 0, 0.05); border-radius: 8px; border-left: 3px solid #ff6f00;';
                        break;
                    case 'ideas':
                        style = 'padding: 8px 14px; margin-bottom: 4px; background: rgba(124, 77, 255, 0.05); border-radius: 8px; border-left: 3px solid #720ce7;';
                        break;
                    default:
                        style = ITEM_STYLES.NEW;
                        break;
                    }
                }
            }
            if (safeText.trim() === '') {
                htmlStr += '<li style="height: 8px; list-style: none;"></li>';
                return;
            }
            var displayText = safeText.replace(/^  /, '');
            htmlStr += '<li style="display: flex; align-items: flex-start; gap: 10px; ' + style + '"><span style="color: #e0e0e0; line-height: 1.5;">' + displayText + '</span></li>';
        });
    } else {
        htmlStr += '<li style="padding: 10px 14px; color: #888; text-align: center; list-style: none;">Список изменений будет добавлен в следующем обновлении</li>';
    }
    htmlStr += '</ul>';
    content.innerHTML = htmlStr;
}

function closeChangelogModal() {
    var modal = document.getElementById('changelogModal');
    if (modal)
        modal.style.display = 'none';
}

/* ------------------------------- */

var memoryInfoAbortController = null;
var memoryInfoTimeoutId = null;
var isMemoryInfoLoading = false;

function updateMemoryInfo() {
    var memInfoEl = document.getElementById('mem-info');
    if (!memInfoEl)
        return;

    if (!features.memory_info) {
        memInfoEl.textContent = 'Память: отключено';
        memInfoEl.classList.add('mem-disabled');
        return;
    }

    if (isMemoryInfoLoading)
        return;

    if (memoryInfoTimeoutId) {
        clearTimeout(memoryInfoTimeoutId);
        memoryInfoTimeoutId = null;
    }
    if (memoryInfoAbortController) {
        memoryInfoAbortController.abort();
        memoryInfoAbortController = null;
    }

    isMemoryInfoLoading = true;

    var controller = new AbortController();
    memoryInfoAbortController = controller;

    var timeoutId = setTimeout(function () {
        controller.abort();
        var el = document.getElementById('mem-info');
        if (el) {
            el.textContent = 'Память: таймаут';
            el.classList.remove('mem-critical', 'mem-warning', 'mem-good', 'mem-disabled');
            el.classList.add('mem-disabled');
        }
        isMemoryInfoLoading = false;
        memoryInfoTimeoutId = null;
        memoryInfoAbortController = null;
    }, 3000);

    memoryInfoTimeoutId = timeoutId;

    fetch('/heap?t=' + Date.now(), {
        signal: controller.signal
    })
    .then(function (r) {
        if (memoryInfoTimeoutId) {
            clearTimeout(memoryInfoTimeoutId);
            memoryInfoTimeoutId = null;
        }
        if (!r.ok)
            throw new Error('HTTP ' + r.status);
        return r.json();
    })
    .then(function (data) {
        var el = document.getElementById('mem-info');
        if (!el)
            return;

        el.classList.remove('mem-critical', 'mem-warning', 'mem-good', 'mem-disabled');

        var freeDram = data.free || 0;
        var totalDram = data.total_dram || 0;
        var freePsram = data.free_psram || 0;
        var totalPsram = data.total_psram || 0;
        var hasPsram = data.psram === true && totalPsram > 0;
        var dramPct = totalDram > 0 ? (freeDram / totalDram) * 100 : 0;
        var psramPct = totalPsram > 0 ? (freePsram / totalPsram) * 100 : 0;
        var totalFree = freeDram + freePsram;
        var totalAll = totalDram + totalPsram;
        var totalPct = totalAll > 0 ? (totalFree / totalAll) * 100 : 0;

        function fmtKb(bytes) {
            var kb = bytes / 1024;
            return kb >= 100 ? kb.toFixed(0) : kb.toFixed(1);
        }

        function fmtMb(bytes) {
            return (bytes / 1024 / 1024).toFixed(2);
        }

        function fmtPct(pct, showDecimal) {
            if (pct >= 99.95)
                return '100';
            if (showDecimal)
                return pct.toFixed(1);
            return pct.toFixed(0);
        }

        var text = '';

        text += 'DRAM ' + fmtKb(freeDram) + '/' + fmtKb(totalDram) + 'K (' + fmtPct(dramPct, true) + '%)';

        if (hasPsram) {
            text += ' · PSRAM ' + fmtMb(freePsram) + '/' + fmtMb(totalPsram) + 'M (' + fmtPct(psramPct, true) + '%)';
            text += ' · всего ' + fmtPct(totalPct, false) + '%';
        }

        if (data.chip)
            text = data.chip + ': ' + text;

        if (dramPct < 20)
            text = ' ' + text;
        else if (dramPct < 40)
            text = ' ' + text;
        else
            text = '✔️' + text;

        el.textContent = text;

        if (totalPct < 20) {
            el.classList.add('mem-critical');
        } else if (totalPct < 40) {
            el.classList.add('mem-warning');
        } else {
            el.classList.add('mem-good');
        }

        if (dramPct < 20 && totalPct >= 40) {
            el.classList.add('mem-warning');
        }

        isMemoryInfoLoading = false;
        memoryInfoAbortController = null;
    })
    .catch(function (err) {
        if (memoryInfoTimeoutId) {
            clearTimeout(memoryInfoTimeoutId);
            memoryInfoTimeoutId = null;
        }
        if (err.name !== 'AbortError')
            console.error('Ошибка получения информации о памяти:', err);
        var el = document.getElementById('mem-info');
        if (el) {
            el.textContent = '';
            el.classList.remove('mem-critical', 'mem-warning', 'mem-good', 'mem-disabled');
        }
        isMemoryInfoLoading = false;
        memoryInfoAbortController = null;
    });
}

function showMemoryDetails() {
    var memEl = document.getElementById('mem-info');
    if (!memEl)
        return;

    var currentText = memEl.textContent;
    if (currentText === 'Память: отключено' ||
        currentText === 'Память: таймаут' ||
        currentText === 'Память: загрузка...' ||
        currentText === '') {
        alert(currentText || 'Нет данных о памяти');
        return;
    }

    fetch('/heap?t=' + Date.now())
    .then(function (r) {
        return r.ok ? r.json() : Promise.reject();
    })
    .then(function (data) {
        var freeDram = data.free || 0;
        var totalDram = data.total_dram || 0;
        var freePsram = data.free_psram || 0;
        var totalPsram = data.total_psram || 0;
        var hasPsram = data.psram === true && totalPsram > 0;
        var dramPct = totalDram > 0 ? (freeDram / totalDram) * 100 : 0;
        var psramPct = totalPsram > 0 ? (freePsram / totalPsram) * 100 : 0;
        var totalFree = freeDram + freePsram;
        var totalAll = totalDram + totalPsram;
        var totalPct = totalAll > 0 ? (totalFree / totalAll) * 100 : 0;

        function fmtKb(bytes) {
            return (bytes / 1024).toFixed(1);
        }

        function fmtMb(bytes) {
            return (bytes / 1024 / 1024).toFixed(2);
        }

        var msg = 'Чип: ' + (data.chip || 'ESP32') + '\n\n';

        // DRAM
        msg += 'DRAM: ' + fmtKb(freeDram) + ' КБ свободно из ' + fmtKb(totalDram) + ' КБ (' + dramPct.toFixed(1) + '%)\n';
        if (dramPct < 10)
            msg += '  ⚠️ КРИТИЧНО: возможны сбои WiFi/WebServer/OTA\n';
        else if (dramPct < 20)
            msg += '  ⚠️ Мало DRAM - следите за утечками\n';
        else if (dramPct < 40)
            msg += '   DRAM на грани - не критично\n';

        // PSRAM
        if (hasPsram) {
            msg += 'PSRAM: ' + fmtMb(freePsram) + ' МБ свободно из ' + fmtMb(totalPsram) + ' МБ (' + psramPct.toFixed(1) + '%)\n';
            if (psramPct < 10)
                msg += '  ⚠️ КРИТИЧНО: PSRAM почти занята\n';
            else if (psramPct < 20)
                msg += '  ⚠️ Мало PSRAM\n';
        } else {
            msg += 'PSRAM: не обнаружена\n';
        }

        // Итог
        msg += '\nВсего свободно: ' + fmtKb(totalFree) + ' КБ из ' + fmtKb(totalAll) + ' КБ (' + totalPct.toFixed(1) + '%)\n\n';

        if (dramPct < 10) {
            msg += '❌ DRAM критически мало - рекомендуется перезагрузка.\n';
        } else if (dramPct < 20) {
            msg += '⚠️ DRAM мало, но система работает. Следите за free DRAM.\n';
        } else if (dramPct < 40) {
            msg += ' DRAM на грани - не критично.\n';
        } else {
            msg += '✔️ DRAM в норме.\n';
        }

        if (hasPsram) {
            if (psramPct < 10)
                msg += '❌ PSRAM критически мало.\n';
            else if (psramPct < 20)
                msg += '⚠️ PSRAM мало.\n';
            else
                msg += '✔️ PSRAM в норме.\n';
        }

        if (data.max_alloc !== undefined) {
            var maxAllocKb = data.max_alloc / 1024;
            msg += '\nMax непрерывный блок: ' + maxAllocKb.toFixed(1) + ' КБ';
            if (maxAllocKb < 10)
                msg += ' ⚠️ фрагментация!';
            msg += '\n';
        }

        alert(msg);
    })
    .catch(function () {
        alert('Не удалось получить детальную информацию о памяти');
    });
}

/* ------------------------------- */

var _weatherBlockTimer = null;

function updateWeatherBlock() {
    fetch('/get_weather?t=' + Date.now()).then(function (r) {
        return r.json();
    }).then(function (d) {
        var el = document.getElementById('weatherNowDisplay');
        if (el) {
            var city = d.city || '';
            var showCondition = (d.show_condition !== false);
            var justChanged = window._weatherJustChanged && (Date.now() - window._weatherJustChanged < 15000);
            if (justChanged || d.temp === null || d.temp === undefined || isNaN(d.temp)) {
                el.innerHTML = (city ? city + ': ' : '') + 'Обновление...';
                if (justChanged)
                    setTimeout(updateWeatherBlock, 3000);
            } else {
                var temp = Math.round(d.temp);
                var tempStr = (temp > 0 ? '+' : '') + temp + '°C';
                var condStr = (showCondition && d.condition) ? ', ' + d.condition : '';
                el.innerHTML = (city ? city + ': ' : '') + tempStr + condStr;
            }
        }
        var badgesEl = document.getElementById('weather_badges');
        if (badgesEl) {
            var method = d.method || '';
            var provider = d.provider || '';
            var providerBadge = '';
            if (provider === 'yandex')
                providerBadge = '<span class="weather-badge badge-yandex">Яндекс</span>';
            else if (provider === 'openweather')
                providerBadge = '<span class="weather-badge badge-openweather">OpenWeather</span>';
            var methodBadge = '';
            if (method === 'graphql')
                methodBadge = '<span class="weather-badge badge-graphql">API</span>';
            else if (method === 'sync')
                methodBadge = '<span class="weather-badge badge-sync">Geo-id</span>';
            badgesEl.innerHTML = providerBadge + (methodBadge ? ' ' + methodBadge : '');
        }
    }).catch(function () {
        var el = document.getElementById('weatherNowDisplay');
        if (el)
            el.innerHTML = '--°C';
        var badgesEl = document.getElementById('weather_badges');
        if (badgesEl)
            badgesEl.innerHTML = '';
    });
}

function initWeatherBlock() {
    if (_weatherBlockTimer)
        clearInterval(_weatherBlockTimer);
    updateWeatherBlock();
    _weatherBlockTimer = setInterval(updateWeatherBlock, CONFIG.WEATHER_REFRESH_INTERVAL);
}

function resolveCityGeneric(latId, lonId, nameId, btn) {
    var latEl = document.getElementById(latId),
    lonEl = document.getElementById(lonId),
    nameEl = document.getElementById(nameId);
    if (!latEl || !lonEl || !nameEl)
        return;
    var lat = latEl.value.trim(),
    lon = lonEl.value.trim();
    if (!lat || !lon) {
        alert('Сначала введите координаты');
        return;
    }
    var oldText = btn ? btn.value : '';
    if (btn) {
        btn.disabled = true;
        btn.value = '...';
    }
    fetch('/resolve_city?lat=' + encodeURIComponent(lat) + '&lon=' + encodeURIComponent(lon))
    .then(function (r) {
        return r.text();
    })
    .then(function (city) {
        if (city && city.length > 0)
            nameEl.value = city;
        else
            alert('Не удалось определить город');
    })
    .catch(function () {
        alert('Ошибка запроса');
    })
    .finally(function () {
        if (btn) {
            btn.disabled = false;
            btn.value = oldText;
        }
    });
}

function resolveCity() {
    resolveCityGeneric('geo_tz_lat', 'geo_tz_lon', 'geo_tz_name');
}

var _weatherSaveInProgress = false;

function saveWeatherParamsWithResolve() {
    if (_weatherSaveInProgress)
        return;
    _weatherSaveInProgress = true;
    window._weatherJustChanged = Date.now();
    var el = document.getElementById('weatherNowDisplay');
    if (el)
        el.innerHTML = 'Обновление...';
    fetch(buildWeatherSaveUrl()).then(function (r) {
        return r.text();
    }).then(function () {
        setTimeout(function () {
            fetch('/get_weather_settings').then(function (r) {
                return r.json();
            }).then(function (d) {
                var nameEl = document.getElementById('custom_coord_name');
                if (nameEl && d.custom_coord_name !== undefined)
                    nameEl.value = d.custom_coord_name;
                if (typeof updateWeatherBlock === 'function')
                    updateWeatherBlock();
            }).catch(function () {
                if (typeof updateWeatherBlock === 'function')
                    updateWeatherBlock();
            });
        }, 1500);
    }).catch(function (err) {
        console.warn('save_weather_params failed:', err);
    })
    .finally(function () {
        _weatherSaveInProgress = false;
    });
}

function buildWeatherSaveUrl() {
    function v(id) {
        var el = document.getElementById(id);
        return el ? encodeURIComponent(el.value) : '';
    }
    return 'save_weather_params' + '?weather_source=' + v('weather_source') + '&yandex_geo=' + v('yandex_geo') + '&custom_yandex_geo=' + v('custom_yandex_geo') + '&city=' + v('city') + '&custom_city=' + v('custom_city') + '&custom_lat=' + v('custom_lat') + '&custom_lon=' + v('custom_lon') + '&custom_coord_name=' + v('custom_coord_name');
}

/* ------------------------------- */

function syncClientTime() {
    var now = new Date();
    var unixTime = Math.floor(now.getTime() / 1000);
    var offsetSeconds = now.getTimezoneOffset() * 60;
    var tzName = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (!tzName || tzName === 'undefined')
        return;
    fetch('/set_client_time?time=' + unixTime + '&offset=' + offsetSeconds + '&tz=' + encodeURIComponent(tzName))
    .then(function (r) {
        return r.text();
    })
    .then(function (response) {
        console.log('Client time sync:', response);
    })
    .catch(function (err) {
        console.warn('Client time sync failed:', err);
    });
}

function updateSyncClock() {
    var now = new Date();
    var hours = String(now.getHours()).padStart(2, '0');
    var minutes = String(now.getMinutes()).padStart(2, '0');
    var seconds = String(now.getSeconds()).padStart(2, '0');
    var clockEl = document.getElementById('sync-clock');
    if (clockEl)
        clockEl.textContent = hours + ':' + minutes + ':' + seconds;

    var tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    var tzMap = {
        'EET-2': 'Калининград (UTC+2)',
        'MSK-3': 'Москва (UTC+3)',
        'MSK-3_SPB': 'Санкт-Петербург (UTC+3)',
        'MSK-3_RND': 'Ростов-на-Дону (UTC+3)',
        'MSK-3_NN': 'Нижний Новгород (UTC+3)',
        'MSK-3_Kazan': 'Казань (UTC+3)',
        'MSK-3_Voronezh': 'Воронеж (UTC+3)',
        'MSK-3_Krasnodar': 'Краснодар (UTC+3)',
        'MSK-3_Sochi': 'Сочи (UTC+3)',
        'MSK-3_Kirov': 'Киров (UTC+3)',
        'MSK-3_Tula': 'Тула (UTC+3)',
        'MSK-3_Tver': 'Тверь (UTC+3)',
        'MSK-3_Ryazan': 'Рязань (UTC+3)',
        'MSK-3_Yaroslavl': 'Ярославль (UTC+3)',
        'MSK-3_Vladimir': 'Владимир (UTC+3)',
        'MSK-3_Bryansk': 'Брянск (UTC+3)',
        'MSK-3_Belgorod': 'Белгород (UTC+3)',
        'MSK-3_Kursk': 'Курск (UTC+3)',
        'MSK-3_Lipetsk': 'Липецк (UTC+3)',
        'MSK-3_Orel': 'Орёл (UTC+3)',
        'MSK-3_Smolensk': 'Смоленск (UTC+3)',
        'MSK-3_Tambov': 'Тамбов (UTC+3)',
        'MSK-3_Ivanovo': 'Иваново (UTC+3)',
        'MSK-3_Kostroma': 'Кострома (UTC+3)',
        'MSK-3_Arkhangelsk': 'Архангельск (UTC+3)',
        'MSK-3_Vologda': 'Вологда (UTC+3)',
        'MSK-3_Murmansk': 'Мурманск (UTC+3)',
        'MSK-3_VelikyNovgorod': 'Великий Новгород (UTC+3)',
        'MSK-3_Pskov': 'Псков (UTC+3)',
        'MSK-3_Makhachkala': 'Махачкала (UTC+3)',
        'MSK-3_Nalchik': 'Нальчик (UTC+3)',
        'MSK-3_Vladikavkaz': 'Владикавказ (UTC+3)',
        'MSK-3_Stavropol': 'Ставрополь (UTC+3)',
        'MSK-3_Volgograd': 'Волгоград (UTC+3)',
        'MSK-3_YoshkarOla': 'Йошкар-Ола (UTC+3)',
        'MSK-3_Saransk': 'Саранск (UTC+3)',
        'MSK-3_Cheboksary': 'Чебоксары (UTC+3)',
        'MSK-3_Penza': 'Пенза (UTC+3)',
        'MSK-3_Simferopol': 'Симферополь (UTC+3)',
        'MSK-3_Minsk': 'Минск (UTC+3)',
        'MSK-3_Zelenodolsk': 'Зеленодольск (UTC+3)',
        'MSK-3_Podolsk': 'Подольск (UTC+3)',
        'MSK-3_Lubertsy': 'Люберцы (UTC+3)',
        'MSK-3_Mytishchi': 'Мытищи (UTC+3)',
        'MSK-3_Balashikha': 'Балашиха (UTC+3)',
        'MSK-3_Khimki': 'Химки (UTC+3)',
        'MSK-3_Korolev': 'Королёв (UTC+3)',
        'MSK-3_Elektrostal': 'Электросталь (UTC+3)',
        'MSK-3_Kolomna': 'Коломна (UTC+3)',
        'MSK-3_Odintsovo': 'Одинцово (UTC+3)',
        'MSK-3_Domodedovo': 'Домодедово (UTC+3)',
        'MSK-3_SergievPosad': 'Сергиев Посад (UTC+3)',
        'MSK-3_Pushkino': 'Пушкино (UTC+3)',
        'MSK-3_Zhukovsky': 'Жуковский (UTC+3)',
        'MSK-3_Reutov': 'Реутов (UTC+3)',
        'MSK-3_Dolgoprudny': 'Долгопрудный (UTC+3)',
        'MSK-3_Shchelkovo': 'Щёлково (UTC+3)',
        'MSK-3_OrekhovoZuevo': 'Орехово-Зуево (UTC+3)',
        'MSK-3_Serpukhov': 'Серпухов (UTC+3)',
        'MSK-3_Voskresensk': 'Воскресенск (UTC+3)',
        'MSK-3_Lobnya': 'Лобня (UTC+3)',
        'MSK-3_Ivanteevka': 'Ивантеевка (UTC+3)',
        'MSK-3_Dubna': 'Дубна (UTC+3)',
        'MSK-3_Egoryevsk': 'Егорьевск (UTC+3)',
        'MSK-3_Chekhov': 'Чехов (UTC+3)',
        'MSK-3_Stupino': 'Ступино (UTC+3)',
        'MSK-3_PavlovskyPosad': 'Павловский Посад (UTC+3)',
        'MSK-3_NaroFominsk': 'Наро-Фоминск (UTC+3)',
        'MSK-3_Klin': 'Клин (UTC+3)',
        'MSK-3_Krasnogorsk': 'Красногорск (UTC+3)',
        'SAMT-4': 'Самара (UTC+4)',
        'SAMT-4_Astrakhan': 'Астрахань (UTC+4)',
        'SAMT-4_Saratov': 'Саратов (UTC+4)',
        'SAMT-4_Tolyatti': 'Тольятти (UTC+4)',
        'SAMT-4_Ulyanovsk': 'Ульяновск (UTC+4)',
        'YEKT-5': 'Екатеринбург (UTC+5)',
        'YEKT-5_Chelyabinsk': 'Челябинск (UTC+5)',
        'YEKT-5_Perm': 'Пермь (UTC+5)',
        'YEKT-5_Ufa': 'Уфа (UTC+5)',
        'YEKT-5_Orenburg': 'Оренбург (UTC+5)',
        'YEKT-5_Kurgan': 'Курган (UTC+5)',
        'YEKT-5_Tyumen': 'Тюмень (UTC+5)',
        'OMST-6': 'Омск (UTC+6)',
        'KRAT-7': 'Красноярск (UTC+7)',
        'KRAT-7_Novosibirsk': 'Новосибирск (UTC+7)',
        'KRAT-7_Tomsk': 'Томск (UTC+7)',
        'KRAT-7_Barnaul': 'Барнаул (UTC+7)',
        'KRAT-7_Kemerovo': 'Кемерово (UTC+7)',
        'KRAT-7_Novokuznetsk': 'Новокузнецк (UTC+7)',
        'KRAT-7_Sayanogorsk': 'Саяногорск (UTC+7)',
        'IRKT-8': 'Иркутск (UTC+8)',
        'IRKT-8_UlanUde': 'Улан-Удэ (UTC+8)',
        'YAKT-9': 'Якутск (UTC+9)',
        'YAKT-9_Chita': 'Чита (UTC+9)',
        'YAKT-9_Blagoveshchensk': 'Благовещенск (UTC+9)',
        'VLAT-10': 'Владивосток (UTC+10)',
        'VLAT-10_Khabarovsk': 'Хабаровск (UTC+10)',
        'VLAT-10_Ussuriysk': 'Уссурийск (UTC+10)',
        'VLAT-10_Komsomolsk': 'Комсомольск-на-Амуре (UTC+10)',
        'MAGT-11': 'Магадан (UTC+11)',
        'MAGT-11_Sakhalin': 'Сахалин (UTC+11)',
        'MAGT-11_YuzhnoSakhalinsk': 'Южно-Сахалинск (UTC+11)',
        'PETT-12': 'Камчатка (UTC+12)',
        'PETT-12_Anadyr': 'Анадырь (UTC+12)',
        'PETT-12_Petropavlovsk': 'Петропавловск-Камчатский (UTC+12)',
        'ALMT-5': 'Алматы (UTC+5)',
        'ALMT-5_Astana': 'Астана (UTC+5)',
        'ALMT-5_Karaganda': 'Караганда (UTC+5)',
        'ALMT-5_Shymkent': 'Шымкент (UTC+5)',
        'ALMT-5_Pavlodar': 'Павлодар (UTC+5)',
        'ALMT-5_Prz': 'Приозёрск (UTC+5)',
        'Europe/Moscow': 'Москва (UTC+3)',
        'Europe/Samara': 'Самара (UTC+4)',
        'Asia/Yekaterinburg': 'Екатеринбург (UTC+5)',
        'Asia/Novosibirsk': 'Новосибирск (UTC+7)',
        'Asia/Krasnoyarsk': 'Красноярск (UTC+7)',
        'Asia/Irkutsk': 'Иркутск (UTC+8)',
        'Asia/Vladivostok': 'Владивосток (UTC+10)',
        'Asia/Kamchatka': 'Камчатка (UTC+12)'
    };
    var displayText = tzMap[tz] || tz.replace(/_/g, ' ');
    if (displayText.indexOf('(UTC') === -1) {
        var offsetHours = -now.getTimezoneOffset() / 60;
        var sign = offsetHours >= 0 ? '+' : '';
        displayText += ' (UTC' + sign + offsetHours + ')';
    }
    var tzDisplayEl = document.getElementById('timezone-display');
    if (tzDisplayEl)
        tzDisplayEl.textContent = displayText;
}

function syncTimeFromBrowser() {
    var now = Math.floor(Date.now() / 1000);
    var tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    fetch('/set_client_time?time=' + now + '&tz=' + encodeURIComponent(tz))
    .then(function (response) {
        return response.text();
    })
    .then(function (text) {
        if (text === 'OK_TIME_SET') {
            alert('Время успешно синхронизировано с устройством');
            setTimeout(function () {
                location.reload();
            }, 500);
        } else
            alert('Ошибка синхронизации: ' + text);
    })
    .catch(function (err) {
        alert('Ошибка запроса: ' + err);
    });
}

function applyCustomTimezone() {
    var tzInput = document.getElementById('custom_tz_input');
    if (!tzInput)
        return;
    var tzValue = tzInput.value.trim();
    if (tzValue.length === 0) {
        showNotification('Введите часовой пояс', 'warning');
        return;
    }
    showLoading(true);
    fetch('/set_custom_tz?tz=' + encodeURIComponent(tzValue))
    .then(function (response) {
        return response.text();
    })
    .then(function (data) {
        showLoading(false);
        if (data === 'OK_TZ_SET') {
            showNotification('Часовой пояс успешно установлен', 'success');
            updateTimezoneInfo();
            updateSelectState(tzValue);
        } else
            showNotification('Ошибка: ' + data, 'error');
    })
    .catch(function (error) {
        showLoading(false);
        showNotification('Ошибка соединения', 'error');
        console.error('Error:', error);
    });
}

function updateTimezoneInfo() {
    fetch('/get_tz_info').then(function (response) {
        return response.json();
    }).then(function (data) {
        var infoElement = document.getElementById('current_tz_info');
        if (infoElement)
            infoElement.textContent = 'Текущий часовой пояс: ' + data.display_name;
        var customInput = document.getElementById('custom_tz_input');
        if (customInput && data.is_custom)
            customInput.value = data.custom || data.current;
        var select = document.getElementById('tz_select');
        if (select && !data.is_custom)
            select.value = data.current;
    }).catch(function (error) {
        console.error('Error fetching TZ info:', error);
    });
}

function updateSelectState(value) {
    var select = document.getElementById('tz_select');
    if (select) {
        var options = Array.from(select.options);
        select.value = options.some(function (opt) {
            return opt.value === value;
        }) ? value : '';
    }
}

function autoDetectTimezone() {
    showLoading(true);
    fetch('/auto_tz').then(function (response) {
        return response.text();
    }).then(function (data) {
        showLoading(false);
        if (data === 'AUTO_OK') {
            showNotification('Часовой пояс автоматически определён', 'success');
            setTimeout(function () {
                updateTimezoneInfo();
                fetch('/get_tz_info').then(function (r) {
                    return r.json();
                }).then(function (info) {
                    if (!info.is_custom) {
                        var select = document.getElementById('tz_select');
                        if (select)
                            select.value = info.current;
                    }
                });
            }, 500);
        } else
            showNotification('Не удалось определить часовой пояс', 'error');
    }).catch(function (error) {
        showLoading(false);
        showNotification('Ошибка соединения', 'error');
        console.error('Error:', error);
    });
}

/* ------------------------------- */

function updateAnimBlock() {
    var animSel = document.getElementById('anim_sel');
    if (animSel)
        animSel.style.display = (jsonResponse.use_animations == '1') ? '' : 'none';
}

function loadAnimationsList() {
    var sel = document.getElementById('anim_sel');
    if (!sel)
        return;
    fetch('/get_anim_list').then(function (r) {
        return r.text();
    }).then(function (text) {
        var data = JSON.parse(text);
        sel.innerHTML = '';
        var opt0 = document.createElement('option');
        opt0.value = '0';
        opt0.textContent = 'ВЫБЕРИТЕ АНИМАЦИЮ';
        sel.appendChild(opt0);
        data.forEach(function (name, idx) {
            var opt = document.createElement('option');
            opt.value = idx + 1;
            opt.textContent = name;
            sel.appendChild(opt);
        });
        if (jsonResponse.anim_sel !== undefined)
            sel.value = jsonResponse.anim_sel;
    }).catch(function (err) {
        console.error('Ошибка загрузки списка анимаций:', err);
    });
}

var effSdIndex = null;
var _effSdIndexPromise = null;

function ensureEffSdIndex() {
    if (_effSdIndexPromise)
        return _effSdIndexPromise;
    _effSdIndexPromise = fetch('/get_eff_sd_index').then(function (r) {
        return r.text();
    }).then(function (text) {
        effSdIndex = text.trim();
        console.log('EFF_SD index:', effSdIndex);
        return effSdIndex;
    }).catch(function () {
        effSdIndex = null;
        return null;
    });
    return _effSdIndexPromise;
}

function syncAnimSel() {
    var animSel = document.getElementById('anim_sel');
    var effSel = document.getElementById('eff_sel');
    if (animSel && effSel) {
        animSel.onchange = function () {
            var v = animSel.value;
            if (v === '0') {
                var lastNonAnim = jsonResponse.lastNonAnimSel || 1;
                window.location = '/eff_sel?eff_sel=' + lastNonAnim;
            } else {
                window.location = '/set_anim?anim=' + v;
            }
        };
    }
}

function loadOutFilesList() {
    var sel = document.getElementById('out_sel');
    if (!sel)
        return;
    var sdEnabled = window.moduleStates && window.moduleStates.sd_enable === '1';
    if (!sdEnabled) {
        sel.innerHTML = '';
        return;
    }
    ensureEffSdIndex().then(function () {
        fetch('/list_out_files').then(function (r) {
            return r.text();
        }).then(function (text) {
            var data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error('Некорректный ответ /list_out_files:', text);
                sel.innerHTML = '';
                return;
            }
            if (!Array.isArray(data))
                data = [];
            sel.innerHTML = '';
            var opt0 = document.createElement('option');
            opt0.value = '';
            opt0.textContent = 'ВЫБЕРИТЕ ЭФФЕКТ .out';
            sel.appendChild(opt0);
            data.forEach(function (name) {
                var opt = document.createElement('option');
                opt.value = name;
                opt.textContent = name;
                sel.appendChild(opt);
            });
            if (effSdIndex !== null && jsonResponse.eff_sel == effSdIndex && jsonResponse.out_sel !== undefined && jsonResponse.out_sel !== '')
                sel.value = jsonResponse.out_sel;
            else
                sel.value = '';
        }).catch(function (err) {
            console.error('Ошибка загрузки списка .out файлов:', err);
        });
    });
}

function syncOutSel() {
    var outSel = document.getElementById('out_sel');
    var effSel = document.getElementById('eff_sel');
    if (!outSel || !effSel)
        return;
    var sdEnabled = window.moduleStates && window.moduleStates.sd_enable === '1';
    if (!sdEnabled) {
        outSel.disabled = true;
        return;
    }
    outSel.disabled = false;
    outSel.onchange = function () {
        if (this.value) {
            fetch('/set_out_effect?file=' + encodeURIComponent(this.value)).then(function (r) {
                return r.text();
            }).then(function (text) {
                console.log('Ответ от сервера:', text);
            }).catch(function (err) {
                console.error('Ошибка выбора .out файла:', err);
            });
        }
    };
    effSel.onchange = function () {
        send_request(this, 'eff_sel?eff_sel=' + this.value, '');
        if (effSdIndex === null)
            return;
        if (this.value !== effSdIndex)
            outSel.value = '';
        else if (jsonResponse.out_sel !== undefined && jsonResponse.out_sel !== '')
            outSel.value = jsonResponse.out_sel;
    };
}

function showRebootOverlay(targetUrl) {
    var overlay = document.getElementById('reboot-overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'reboot-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.85);color:#fff;display:flex;align-items:center;justify-content:center;z-index:99999;flex-direction:column;gap:16px;font-size:16px;';
        overlay.innerHTML = '<div class="loader"></div><div>Устройство перезагружается…</div>';
        document.body.appendChild(overlay);
    }
    overlay.style.display = 'flex';
    var poll = setInterval(function () {
        fetch('/get_module_states?t=' + Date.now()).then(function (r) {
            return r.ok ? r.json() : Promise.reject();
        }).then(function () {
            clearInterval(poll);
            location.href = targetUrl || '/';
        }).catch(function () {});
    }, 1500);
}

/* ------------------------------- */

var radioStations = [];
var radioMap = {};
var radioEffList = [];
var radioCurrentEffect = null;
var radioCurrentStation = null;
var RADIO_MODE_AMOUNT_JS = CONFIG.RADIO_MODE_AMOUNT;
var RADIO_MAX_STATIONS = CONFIG.RADIO_MAX_STATIONS;

function radioLoadAll() {
    fetch('/effect.ru.json?t=' + Date.now())
    .then(function (r) {
        if (!r.ok)
            throw new Error('HTTP ' + r.status);
        return r.json();
    })
    .then(function (names) {
        var keys = Object.keys(names).map(function (k) {
            return parseInt(k, 10);
        }).filter(function (k) {
            return !isNaN(k);
        }).sort(function (a, b) {
            return a - b;
        });
        radioEffList = keys.map(function (k) {
            return {
                id: k - 1,
                name: names[String(k)]
            };
        });
    })
    .catch(function (e) {
        console.warn('radioLoadAll: effect.ru.json:', e.message);
        radioEffList = Array.from({
            length: RADIO_MODE_AMOUNT_JS
        }, function (_, i) {
            return {
                id: i,
                name: 'Эффект #' + (i + 1)
            };
        });
    })
    .finally(function () {
        fetch('/get_radio_stations?t=' + Date.now())
        .then(function (r2) {
            return r2.ok ? r2.json() : null;
        })
        .then(function (data) {
            if (!data)
                return;
            radioStations = data.stations || [];
            radioMap = data.map || {};

            radioCurrentEffect = (data.current_effect !== undefined && data.current_effect !== null) ? parseInt(data.current_effect, 10) : null;
            radioCurrentStation = (data.current_station !== undefined && data.current_station !== null) ? parseInt(data.current_station, 10) : null;

            if (typeof data.volume === 'number') {
                var vol = document.getElementById('radio_volume');
                if (vol) {
                    vol.value = data.volume;
                    var label = vol.closest('label');
                    var h4 = label ? label.querySelector('h4') : null;
                    radioUpdateVolumeLabel(data.volume);
                }
            }
        })
        .catch(function (e) {
            radioShowMsg('radio_msg_stations', 'Ошибка загрузки: ' + e.message, 'error');
        })
        .finally(function () {
            radioRenderStations();
            radioRenderMapAddRow();
            radioRenderMap();
        });
    });
}

function radioUpdateVolumeLabel(v) {
    var slider = document.getElementById('radio_volume');
    if (!slider)
        return;
    var label = slider.closest('label');
    if (!label)
        return;
    var h4 = label.querySelector('h4');
    if (h4)
        h4.innerHTML = 'Громкость: ' + v;
}

function radioRenderStations() {
    var box = document.getElementById('radio_stations_container');
    if (!box)
        return;
    box.innerHTML = '';
    if (radioStations.length === 0) {
        box.innerHTML = '<div style="color:#666;text-align:center;padding:12px;font-size:14px;font-style:italic">Нет станций. Нажмите «+ Добавить станцию».</div>';
        return;
    }
    radioStations.forEach(function (st, i) {
        var row = document.createElement('div');
        row.style.cssText = 'display:flex;gap:8px;margin-bottom:8px;align-items:center;padding:8px;background:rgba(0,0,0,0.2);border-radius:8px;border:1px solid rgba(255,255,255,0.05)';
        row.innerHTML = '<input class="radio-st-name" type="text" placeholder="Название" value="' + radioEsc(st.name || '') + '" style="padding:10px 12px;background:rgba(0,0,0,0.4);color:#e0e0e0;border:1px solid rgba(255,255,255,0.1);border-radius:8px;font-size:14px;flex:1;min-width:0">' +
            '<input class="radio-st-url" type="text" placeholder="URL потока" value="' + radioEsc(st.url || '') + '" style="padding:10px 12px;background:rgba(0,0,0,0.4);color:#e0e0e0;border:1px solid rgba(255,255,255,0.1);border-radius:8px;font-size:14px;flex:3;min-width:0">' +
            '<button type="button" onclick="radioRemoveStation(' + i + ')" style="background:linear-gradient(135deg,#a32525 0%,#f5576c 100%);color:white;border:none;width:36px;height:36px;border-radius:8px;font-size:18px;font-weight:bold;cursor:pointer;flex-shrink:0">✕</button>';
        row.querySelector('.radio-st-name').addEventListener('input', function (e) {
            radioStations[i].name = e.target.value;
        });
        row.querySelector('.radio-st-url').addEventListener('input', function (e) {
            radioStations[i].url = e.target.value;
        });
        box.appendChild(row);
    });
}

function radioAddStation() {
    if (radioStations.length >= RADIO_MAX_STATIONS) {
        radioShowMsg('radio_msg_stations', 'Достигнут максимум: ' + RADIO_MAX_STATIONS + ' станций', 'error');
        return;
    }
    radioStations.push({
        name: '',
        url: ''
    });
    radioRenderStations();
}

function radioRemoveStation(i) {
    var removedId = i + 1;
    radioStations.splice(i, 1);
    Object.keys(radioMap).forEach(function (k) {
        if (radioMap[k] === removedId)
            delete radioMap[k];
        else if (radioMap[k] > removedId)
            radioMap[k]--;
    });
    radioRenderStations();
    radioRenderMapAddRow();
    radioRenderMap();
}

function radioSaveStations() {
    var clean = radioStations.filter(function (s) {
        return (s.url || '').trim().length > 0;
    });
    if (clean.length === 0) {
        radioShowMsg('radio_msg_stations', 'Добавьте хотя бы одну станцию с URL', 'error');
        return;
    }
    fetch('/save_radio_stations', {
        method: 'POST',
        headers: {
            'Content-Type': 'text/plain'
        },
        body: JSON.stringify({
            stations: clean
        })
    })
    .then(function (r) {
        return r.text().then(function (text) {
            return {
                ok: r.ok,
                text: text
            };
        });
    })
    .then(function (result) {
        if (result.ok) {
            radioStations = clean;
            Object.keys(radioMap).forEach(function (k) {
                if (radioMap[k] > radioStations.length)
                    delete radioMap[k];
            });
            radioShowMsg('radio_msg_stations', 'Станции сохранены', 'success');
            radioRenderStations();
            radioRenderMapAddRow();
            radioRenderMap();
        } else
            radioShowMsg('radio_msg_stations', 'Ошибка: ' + result.text, 'error');
    })
    .catch(function (e) {
        radioShowMsg('radio_msg_stations', 'Ошибка соединения: ' + e.message, 'error');
    });
}

function radioRenderMapAddRow() {
    var box = document.getElementById('radio_map_add_row');
    if (!box)
        return;

    var effOptions = radioEffList.map(function (e) {
        return '<option value="' + e.id + '">' + radioEsc(e.name) + '</option>';
    }).join('');

    var stOptions = ['<option value="0">-- Не играть --</option>']
    .concat(radioStations.map(function (st, i) {
            return '<option value="' + (i + 1) + '">' + radioEsc(st.name || ('Станция ' + (i + 1))) + '</option>';
        })).join('');

    box.innerHTML =
        '<div style="display:flex;gap:10px;flex-wrap:nowrap;align-items:end;margin-bottom:10px">' +
        '<label style="flex:1 1 0;min-width:0">' +
        '<span style="color:#aaa;font-size:13px;display:block;margin-bottom:6px">Эффект</span>' +
        '<select id="radio_map_eff" class="form-control" style="width:100%;border-radius: 8px;background: #181818 !important;color: white;border:1px solid #68686875;">' + effOptions + '</select>' +
        '</label>' +
        '<label style="flex:1 1 0;min-width:0">' +
        '<span style="color:#aaa;font-size:13px;display:block;margin-bottom:6px">Станция</span>' +
        '<select id="radio_map_st" class="form-control" style="width:100%;border-radius: 8px;background: #181818 !important;color: white;border:1px solid #68686875;">' + stOptions + '</select>' +
        '</label>' +
        '</div>' +
        '<button type="button" onclick="radioAddMap()" class="btn btn-success" style="width:100%;box-sizing:border-box;min-width:0;margin-top:0;box-shadow: none;border-radius: 10px;background: #37449d;">Привязать</button>';

    var effSel = document.getElementById('radio_map_eff');
    var stSel = document.getElementById('radio_map_st');

    if (effSel && radioCurrentEffect !== null && !isNaN(radioCurrentEffect)) {
        effSel.value = radioCurrentEffect;

        var effKey = String(radioCurrentEffect);
        var stId = (radioMap && radioMap[effKey] !== undefined) ? radioMap[effKey] : 0;
        if (stSel && stId > 0) {
            stSel.value = stId;
        }
    }
}

function radioAddMap() {
    var eff = document.getElementById('radio_map_eff').value;
    var st = parseInt(document.getElementById('radio_map_st').value, 10);
    if (st === 0)
        delete radioMap[eff];
    else
        radioMap[eff] = st;
    radioRenderMap();
}

function radioRenderMap() {
    var box = document.getElementById('radio_map_container');
    if (!box)
        return;
    box.innerHTML = '';
    var entries = Object.entries(radioMap).filter(function (e) {
        return e[1] > 0;
    });
    if (entries.length === 0) {
        box.innerHTML = '<div style="color:#666;text-align:center;padding:12px;font-size:14px;font-style:italic">Нет привязок</div>';
        return;
    }
    entries.sort(function (a, b) {
        return parseInt(a[0], 10) - parseInt(b[0], 10);
    });
    entries.forEach(function (entry) {
        var eff = entry[0],
        st = entry[1];
        var stationName = radioStations[st - 1] ? (radioStations[st - 1].name || ('Станция ' + st)) : '—';
        var effObj = radioEffList.find(function (x) {
            return x.id === parseInt(eff, 10);
        });
        var effName = (effObj || {}).name || ('Эффект #' + eff);
        var row = document.createElement('div');
        row.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:10px 14px;margin-bottom:6px;background:#3a3a3a;border:1px solid #68686875;border-radius:8px;gap:10px';
        row.innerHTML = '<span style="font-size:14px;color:#e0e0e0;word-break:break-word"><span style="color:#00e5ff;font-weight:bold">' + radioEsc(effName) + '</span> > <span style="color:#ffd93d">' + radioEsc(stationName) + '</span></span><button type="button" onclick="radioRemoveMap(\'' + eff + '\')" style="background:linear-gradient(135deg,#a32525 0%,#f5576c 100%);color:white;border:none;width:20px;height:20px;border-radius:8px;font-size:10px;font-weight:bold;cursor:pointer;flex-shrink:0">✕</button>';
        box.appendChild(row);

        if (radioCurrentEffect !== null && String(eff) === String(radioCurrentEffect)) {}
    });
}

function radioRemoveMap(eff) {
    delete radioMap[eff];
    radioRenderMap();
}

function radioSaveMap() {
    var cleanMap = {};
    Object.entries(radioMap).forEach(function (e) {
        if (e[1] > 0)
            cleanMap[e[0]] = e[1];
    });
    fetch('/radio_map_batch', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(cleanMap)
    })
    .then(function (r) {
        return r.text().then(function (t) {
            return {
                ok: r.ok,
                text: t
            };
        });
    })
    .then(function (res) {
        if (res.ok)
            radioShowMsg('radio_msg_map', 'Привязки сохранены', 'success');
        else
            radioShowMsg('radio_msg_map', 'Ошибка: ' + res.text, 'error');
    })
    .catch(function (e) {
        radioShowMsg('radio_msg_map', 'Ошибка соединения: ' + e.message, 'error');
    });
}

function radioShowMsg(id, text, type) {
    var el = document.getElementById(id);
    if (!el)
        return;

    if (el._hideTimer) {
        clearTimeout(el._hideTimer);
        el._hideTimer = null;
    }

    var colors = {
        success: 'rgba(0,255,0,0.15)',
        error: 'rgba(255,0,0,0.15)',
        info: 'rgba(102,126,234,0.15)'
    };
    var borders = {
        success: '#00cc66',
        error: '#f44336',
        info: '#667eea'
    };
    el.innerHTML = text;
    el.style.cssText = 'padding:5px 16px;border-radius:10px;margin-top:15px;font-size:14px;line-height:1.6;background:' + (colors[type] || colors.info) + ';border:1px solid ' + (borders[type] || borders.info) + ';color:#eee';

    el._hideTimer = setTimeout(function () {
        el.innerHTML = '';
        el.style.cssText = '';
        el._hideTimer = null;
    }, 5000);
}

function radioEsc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
        return {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }
        [c];
    });
}

(function radioBindButtons() {
    var MAP = {
        radioAddStation: radioAddStation,
        radioSaveStations: radioSaveStations,
        radioSaveMap: radioSaveMap
    };

    function bind() {
        document.querySelectorAll('input[type="button"], button, a.btn').forEach(function (el) {
            if (el.dataset.radioBound === '1')
                return;
            var oc = el.getAttribute('onclick') || '';
            var v = (el.value || '').trim().toUpperCase();
            var t = (el.textContent || '').trim().toUpperCase();
            var hay = v + ' ' + t;
            var m = oc.match(/javascript:(radio[A-Za-z0-9_]+)\(\)/);
            var fn = m ? MAP[m[1]] : null;
            if (!fn) {
                if (hay.indexOf('ДОБАВИТЬ СТАНЦИЮ') !== -1)
                    fn = radioAddStation;
                else if (hay.indexOf('СОХРАНИТЬ СПИСОК') !== -1)
                    fn = radioSaveStations;
                else if (hay.indexOf('СОХРАНИТЬ ПРИВЯЗКИ') !== -1)
                    fn = radioSaveMap;
                else if (hay.indexOf('ПРИВЯЗАТЬ') !== -1 && t === 'ПРИВЯЗАТЬ')
                    fn = null;
            }
            if (typeof fn !== 'function')
                return;
            el.dataset.radioBound = '1';
            if (oc)
                el.removeAttribute('onclick');
            el.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                fn();
            }, true);
        });
    }
    if (document.readyState === 'loading')
        document.addEventListener('DOMContentLoaded', function () {
            setTimeout(bind, 500);
        });
    else
        setTimeout(bind, 500);
    var mo = new MutationObserver(bind);
    mo.observe(document.body, {
        childList: true,
        subtree: true
    });
})();

/* ------------------------------- */

function initTooltip(headerId, tooltipId) {
    var header = document.getElementById(headerId);
    var tooltip = document.getElementById(tooltipId);
    if (!header || !tooltip)
        return false;
    if (header._tooltip_initialized)
        return true;
    header._tooltip_initialized = true;
    header.onclick = function (e) {
        e.stopPropagation();
        e.preventDefault();
        var tip = document.getElementById(tooltipId);
        if (tip)
            tip.style.display = (tip.style.display === 'none' || tip.style.display === '') ? 'block' : 'none';
    };
    _allTooltips.push({
        header: headerId,
        tooltip: tooltipId
    });
    return true;
}

function initAllTooltips(attempt) {
    attempt = attempt || 0;
    var tooltips = [
        ['tz_header', 'tz_tooltip'],
        ['weather_header', 'weather_tooltip'],
        ['schedule_header', 'schedule_tooltip'],
        ['logs_header', 'logs_tooltip'],
        ['wifi_header', 'wifi_tooltip'],
        ['hardware_header', 'hardware_tooltip'],
        ['sound_header', 'sound_tooltip'],
        ['brightness_header', 'brightness_tooltip']
    ];
    var found = 0,
    total = 0;
    tooltips.forEach(function (pair) {
        if (initTooltip(pair[0], pair[1]))
            found++;
        if (document.getElementById(pair[0]))
            total++;
    });
    if (total > 0 && found < total && attempt < CONFIG.TOOLTIP_RETRY_LIMIT) {
        setTimeout(function () {
            initAllTooltips(attempt + 1);
        }, CONFIG.TOOLTIP_RETRY_DELAY);
    }
}

/* ------------------------------- */

function updateNightClockButton(stateVal) {
    var btn = document.querySelector('.night-clock-off, .night-clock-on');
    if (!btn)
        return;
    if (stateVal === '1') {
        btn.className = 'btn btn-block night-clock-on';
        btn.value = 'Ночные часы ВКЛЮЧЕНЫ';
        btn.setAttribute('data-state', '1');
    } else {
        btn.className = 'btn btn-block night-clock-off';
        btn.value = 'Включить ночные часы';
        btn.setAttribute('data-state', '0');
    }
}

function toggleNightClock(btn) {
    var currentState = btn.getAttribute('data-state') || '0';
    var newState = currentState === '1' ? '0' : '1';
    if (newState === '1') {
        btn.classList.add('active');
        btn.classList.add('pulse');
        btn.innerHTML = 'Ночные часы ВКЛЮЧЕНЫ';
        btn.setAttribute('data-state', '1');
    } else {
        btn.classList.remove('active');
        btn.classList.remove('pulse');
        btn.innerHTML = 'Включить ночные часы';
        btn.setAttribute('data-state', '0');
    }
    ajax.get('/night_clock_enabled', {
        value: newState
    }, function (response) {
        if (response === '1' || response === '0') {
            if (response === '1') {
                btn.classList.add('active');
                btn.classList.add('pulse');
                btn.innerHTML = 'Ночные часы ВКЛЮЧЕНЫ';
                btn.setAttribute('data-state', '1');
            } else {
                btn.classList.remove('active');
                btn.classList.remove('pulse');
                btn.innerHTML = 'Включить ночные часы';
                btn.setAttribute('data-state', '0');
            }
            jsonResponse.night_clock_enabled = response;
        }
    }, true);
}

/* ------------------------------- */

/* hide / show */
function hide(id, btn) {
    var el = document.getElementById(id);
    if (el)
        el.classList.add('hidden');
    if (btn) {
        var card = btn.closest('.chart-card') || btn.parentElement;
        if (card)
            card.classList.add('hidden');
    }
}

/* isValidJson */
function isValidJson(str, errorId) {
    var errEl = document.getElementById(errorId);
    try {
        JSON.parse(str);
        if (errEl)
            errEl.innerHTML = '';
        return true;
    } catch (e) {
        if (errEl)
            errEl.innerHTML = '<div class="alert alert-danger">' + e.message + '</div>';
        return false;
    }
}

/* showNotification / showLoading */
function showNotification(text, type) {
    var container = document.getElementById('notification-container');
    if (!container) {
        alert(text);
        return;
    }
    var div = document.createElement('div');
    div.className = 'notification notification-' + (type || 'info');
    div.textContent = text;
    container.appendChild(div);
    setTimeout(function () {
        div.remove();
    }, 4000);
}

function showLoading(show) {
    var overlay = document.getElementById('loading-overlay');
    if (overlay)
        overlay.style.display = show ? 'flex' : 'none';
    document.querySelectorAll('button, input[type="button"]').forEach(function (b) {
        if (b._wasDisabled === undefined)
            b._wasDisabled = b.disabled;
        b.disabled = show ? true : b._wasDisabled;
    });
}

/* file manager */
function delCb(path) {
    return function () {
        if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
            var treeRoot = document.getElementById('tree-root');
            if (!treeRoot)
                return;
            if (path.lastIndexOf('/') < 1) {
                path = '/';
                treeRoot.removeChild(treeRoot.childNodes[0]);
                httpGet(treeRoot, '/');
            } else {
                path = path.substring(0, path.lastIndexOf('/'));
                var leaf = elem(path).parentNode;
                if (leaf.childNodes.length === 3)
                    leaf.removeChild(leaf.childNodes[2]);
                httpGet(leaf, path);
            }
        }
    };
}

function httpDelete(file) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            try {
                delCb(file)();
            } catch (e) {
                /* file-manager not on this page */
            }
        }
    };
    var fd = new FormData();
    fd.append('path', file);
    xhr.open('DELETE', '/edit');
    xhr.send(fd);
}

/* ---------------------------------------------------------------- sockets */
function send_socket(el, type, socket) {
    var value = (el && typeof el.value !== 'undefined') ? el.value : '';
    var socketId = socket || type || '';
    if (!socketId)
        return;
    ajax.get(socketId + '?value=' + encodeURIComponent(value), {}, function (response) {
        log('<li class="alert alert-info animated tdFadeInRight" style="margin:5px 0;">' +
            'SOCKET <b>' + socketId + '</b> = ' + value + ' → ' + response.replace(/</g, '&lt;') + '</li>');
    }, true);
}

function run_socket(socketSpec) {
    var m = String(socketSpec).match(/socket\s+(\S+)/);
    if (!m)
        return;
    var url = m[1];
    try {
        var ws = new WebSocket(url);
        ws.onmessage = function (ev) {
            log('<li class="alert alert-info animated tdFadeInRight" style="margin:5px 0;">WS <b>' + url + '</b>: ' + String(ev.data).replace(/</g, '&lt;') + '</li>');
        };
        ws.onerror = function () {
            log('<li class="alert alert-danger" style="margin:5px 0;">WS error: ' + url + '</li>');
        };
        ws.onclose = function () {
            log('<li class="alert alert-warning" style="margin:5px 0;">WS closed: ' + url + '</li>');
        };
    } catch (e) {
        console.log('WS error', e);
    }
}

/* charts / issues / commits */
function loadIssues(repo, limit) {
    var target = document.getElementById('issues-list');
    if (!target)
        return;
    fetch('https://api.github.com/repos/' + repo + '/issues?state=open&per_page=' + (limit || 10))
    .then(function (r) {
        return r.json();
    })
    .then(function (data) {
        if (!Array.isArray(data) || data.length === 0) {
            target.innerHTML = '<div style="padding:10px;color:#888">Нет открытых issues</div>';
            return;
        }
        var htmlStr = '';
        data.forEach(function (issue) {
            htmlStr += '<div class="issue-row" style="padding:8px 12px;border-bottom:1px solid rgba(255,255,255,0.06)">' +
            '<a href="' + issue.html_url + '" target="_blank" rel="noopener" style="color:#64b5f6">#' + issue.number + '</a> ' +
            '<span style="color:#e0e0e0">' + (issue.title || '').replace(/</g, '&lt;') + '</span>' +
            '</div>';
        });
        target.innerHTML = htmlStr;
    })
    .catch(function () {
        target.innerHTML = '<div style="padding:10px;color:#f44336">Ошибка загрузки</div>';
    });
}

function loadCommits(repo, limit) {
    var target = document.getElementById('commits-list');
    if (!target)
        return;
    fetch('https://api.github.com/repos/' + repo + '/commits?per_page=' + (limit || 10))
    .then(function (r) {
        return r.json();
    })
    .then(function (data) {
        if (!Array.isArray(data) || data.length === 0) {
            target.innerHTML = '<div style="padding:10px;color:#888">Нет коммитов</div>';
            return;
        }
        var htmlStr = '';
        data.forEach(function (c) {
            htmlStr += '<div class="commit-row" style="padding:8px 12px;border-bottom:1px solid rgba(255,255,255,0.06)">' +
            '<a href="' + c.html_url + '" target="_blank" rel="noopener" style="color:#64b5f6;font-family:monospace">' + c.sha.slice(0, 7) + '</a> ' +
            '<span style="color:#e0e0e0">' + (c.commit && c.commit.message ? c.commit.message.split('\n')[0].replace(/</g, '&lt;') : '') + '</span>' +
            '</div>';
        });
        target.innerHTML = htmlStr;
    })
    .catch(function () {
        target.innerHTML = '<div style="padding:10px;color:#f44336">Ошибка загрузки</div>';
    });
}

/* build / cloud */
function loadBuild(project, branch, current) {
    var target = document.getElementById('sonoff-' + branch);
    if (!target)
        return;
    fetch('https://api.github.com/repos/tretyakovsa/Sonoff_WiFi_switch/commits?sha=' + branch + '&per_page=10')
    .then(function (r) {
        return r.json();
    })
    .then(function (data) {
        if (!Array.isArray(data) || data.length === 0) {
            target.innerHTML = '<li><a href="#">Нет сборок</a></li>';
            return;
        }
        var htmlStr = '';
        data.forEach(function (c) {
            htmlStr += '<li><a href="' + c.html_url + '" target="_blank" rel="noopener" style="font-size:11px;color:#90a4ae">' +
            c.sha.slice(0, 7) + ' — ' + (c.commit.message.split('\n')[0]).replace(/</g, '&lt;').slice(0, 50) +
            '</a></li>';
        });
        target.innerHTML = htmlStr;
    })
    .catch(function () {
        target.innerHTML = '<li><a href="#">Ошибка</a></li>';
    });
}

function cloudUpload(mac, configs) {
    alert('Cloud upload: mac=' + mac + ', configs=' + configs + '\n(функция cloudUpload была в старом function.js — восстановите из бэкапа)');
}

function cloudDownload(mac, file) {
    alert('Cloud download: mac=' + mac + ', file=' + file + '\n(функция cloudDownload была в старом function.js — восстановите из бэкапа)');
}

/* wifi */
function loadWifi(targetId, inputId) {
    ajax.get('/ssid', {}, function (response) {
        var select = document.getElementById(targetId);
        if (!select)
            return;
        try {
            var list = JSON.parse(response);
            if (!Array.isArray(list))
                list = [];
            select.innerHTML = '';
            if (list.length === 0) {
                select.innerHTML = '<li><a href="#">Нет сетей</a></li>';
                return;
            }
            list.forEach(function (ssid) {
                var li = document.createElement('li');
                var a = document.createElement('a');
                a.href = '#';
                a.textContent = ssid;
                a.onclick = function (e) {
                    e.preventDefault();
                    var input = document.getElementById(inputId);
                    var nameEl = document.getElementById('ssid-name');
                    if (input)
                        input.value = ssid;
                    if (nameEl)
                        nameEl.textContent = ssid;
                    toggle(targetId);
                };
                li.appendChild(a);
                select.appendChild(li);
            });
        } catch (e) {
            select.innerHTML = '<li><a href="#">Ошибка</a></li>';
        }
    }, true);
}

/* RGB picker */
function createRGB(inputId, action, module, response) {
    var canvas = document.getElementById(inputId + '-cs');
    var input = document.getElementById(inputId);
    if (!canvas || !input)
        return;

    var ctx = canvas.getContext('2d');
    var size = 200;
    canvas.width = size;
    canvas.height = size;

    // HSL-круг
    var cx = size / 2,
    cy = size / 2,
    r = size / 2 - 1;
    for (var angle = 0; angle < 360; angle++) {
        var start = (angle - 1) * Math.PI / 180;
        var end = angle * Math.PI / 180;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.arc(cx, cy, r, start, end);
        ctx.closePath();
        ctx.fillStyle = 'hsl(' + angle + ', 100%, 50%)';
        ctx.fill();
    }
    // затемнение к центру (насыщенность)
    var gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
    gradient.addColorStop(0, 'rgba(255,255,255,1)');
    gradient.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill();

    // клик по кругу
    var wrapper = canvas.parentElement;
    wrapper.style.position = 'relative';
    canvas.style.position = 'absolute';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.cursor = 'crosshair';

    wrapper.onclick = function (e) {
        var rect = wrapper.getBoundingClientRect();
        var x = e.clientX - rect.left - rect.width / 2;
        var y = e.clientY - rect.top - rect.height / 2;
        var dist = Math.sqrt(x * x + y * y);
        var radius = Math.min(rect.width, rect.height) / 2;
        if (dist > radius)
            return;
        var angle = Math.atan2(y, x) * 180 / Math.PI;
        if (angle < 0)
            angle += 360;
        var sat = Math.round(dist / radius * 100);
        input.value = 'hsv(' + Math.round(angle) + ',' + sat + ',100)';
        var preview = wrapper.querySelector('.' + inputId + '-preview');
        if (preview)
            preview.style.background = 'hsl(' + angle + ', 100%, 50%)';
        if (action) {
            send_request(input, action.replace(/\[\[([^\]]+)\]\]/g, function (_, id) {
                    var el = document.getElementById(id);
                    return el ? encodeURIComponent(el.value) : '';
                }), response || '');
        }
    };
}

/* timeline / scenary / timers */
function loadTime(jsonResponseObj) {
    var tbody = document.getElementById('time-list');
    if (!tbody)
        return;
    ajax.get('/config_alarm.json', {}, function (response) {
        try {
            var data = JSON.parse(response);
            var htmlStr = '';
            for (var i = 1; i <= 7; i++) {
                var h = data['h' + i] || '--';
                var m = data['m' + i] || '--';
                var a = data['a' + i] === '1' ? '✓' : '✗';
                htmlStr += '<tr><td>День ' + i + '</td><td>' + h + ':' + m + '</td><td>' + a + '</td></tr>';
            }
            tbody.innerHTML = htmlStr;
        } catch (e) {
            tbody.innerHTML = '<tr><td>Ошибка</td></tr>';
        }
    }, true);
}

function loadNewThen(targetId, mode) {
    var container = document.getElementById(targetId);
    if (!container)
        return;
    if (mode === ' ') {
        container.innerHTML = '';
        return;
    }
    var hidden = document.getElementById('hidden-val-then');
    var idx = hidden ? parseInt(hidden.value, 10) || 1 : 1;
    var htmlStr = '<div class="form-group"><label>Then #' + idx + '</label>' +
        '<input class="form-control" placeholder="Действие" onkeyup="pattern(this.value, \'' + targetId + '-pat\')" ' +
        'id="then-' + idx + '" value=""></div>';
    container.insertAdjacentHTML('beforeend', htmlStr);
    if (hidden)
        hidden.value = idx + 1;
}

function loadNewAnd(targetId) {
    var container = document.getElementById(targetId);
    if (!container)
        return;
    var hidden = document.getElementById('hidden-val-and');
    var idx = hidden ? parseInt(hidden.value, 10) || 1 : 1;
    container.insertAdjacentHTML('beforeend',
        '<div class="form-group"><label>AND #' + idx + '</label>' +
        '<input class="form-control" placeholder="Условие" id="and-' + idx + '"></div>');
    if (hidden)
        hidden.value = idx + 1;
}

function loadNewOr(targetId) {
    var container = document.getElementById(targetId);
    if (!container)
        return;
    var hidden = document.getElementById('hidden-val-or');
    var idx = hidden ? parseInt(hidden.value, 10) || 1 : 1;
    container.insertAdjacentHTML('beforeend',
        '<div class="form-group"><label>OR #' + idx + '</label>' +
        '<input class="form-control" placeholder="Условие" id="or-' + idx + '"></div>');
    if (hidden)
        hidden.value = idx + 1;
}

function pattern(source, target) {
    var val = (typeof source === 'string') ? source : (source && source.value) || '';
    var el = document.getElementById(target);
    if (!el)
        return;
    var pat = val.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    if (el.tagName === 'INPUT')
        el.setAttribute('pattern', '');
    else
        el.innerHTML = pat;
}

function toggleCheckbox(cb) {
    var name = cb.parentElement ? cb.parentElement.textContent : '';
    var checkboxes = document.querySelectorAll('input[name^="day-"]');
    checkboxes.forEach(function (d) {
        d.checked = cb.checked;
    });
}

function addTimer() {
    var setTime = document.getElementById('set-time');
    var time = setTime ? setTime.value : '';
    if (!time || !/^\d{2}:\d{2}:\d{2}$/.test(time)) {
        alert('Введите время в формате ЧЧ:ММ:СС');
        return;
    }
    var days = [];
    for (var i = 0; i < 7; i++) {
        var d = document.getElementById('day-' + i);
        if (d && d.checked)
            days.push(i);
    }
    if (days.length === 0) {
        alert('Выберите хотя бы один день');
        return;
    }
    var run1 = document.getElementById('run-1');
    var runMode = run1 && run1.checked ? 1 : 0;

    send_request_edit(null, JSON.stringify({
            time: time,
            days: days,
            run_once: runMode
        }), 'config_alarm.json', 'loadTime(jsonResponse);');
    alert('Таймер сохранён: ' + time + ', дни: ' + days.join(','));
}

function loadScenary(jsonResponseObj, mode) {
    var tbody = document.getElementById('scenary-list');
    if (!tbody)
        return;
    ajax.get('/scenary.save.txt?' + Math.random(), {}, function (response) {
        if (response === 'FileNotFound' || !response) {
            tbody.innerHTML = '<tr><td colspan="2" style="padding:10px;color:#888">Сценарии не найдены</td></tr>';
            return;
        }
        var lines = response.split('\n').filter(function (l) {
            return l.trim().length > 0;
        });
        var htmlStr = '';
        lines.forEach(function (line, i) {
            htmlStr += '<tr><td>' + (i + 1) + '</td><td><code>' + line.replace(/</g, '&lt;') + '</code></td></tr>';
        });
        tbody.innerHTML = htmlStr;
    }, true);
}

function loadScenaryList(index, mode, host) {
    if (mode === 'loadInTextarea') {
        var ta = document.getElementById('scenary-list-edit');
        if (!ta)
            return;
        ajax.get('http://' + host + '/scenary.save.txt?' + Math.random(), {}, function (r) {
            ta.value = r === 'FileNotFound' ? '' : r;
        }, true);
    }
}

function loadLive(host, file, targetId) {
    var target = document.getElementById(targetId);
    if (!target)
        return;
    ajax.get('http://' + host + '/' + file, {}, function (response) {
        try {
            var data = JSON.parse(response);
            target.innerHTML = '';
            if (data.live && typeof data.live === 'object') {
                Object.keys(data.live).forEach(function (k) {
                    var opt = document.createElement('option');
                    opt.value = k;
                    opt.textContent = k + ' = ' + data.live[k];
                    opt.setAttribute('title', k);
                    target.appendChild(opt);
                });
            }
        } catch (e) {
            /* ignore */
        }
    }, true);
}

function loadLive2(listId, moduleId, targetId) {
    var list = document.getElementById(listId);
    var module = document.getElementById(moduleId);
    var target = document.getElementById(targetId);
    if (!list || !module || !target)
        return;
    var host = list.options[list.selectedIndex].value;
    if (!host)
        return;
    ajax.get('http://' + host + '/config.live.json?' + Math.random(), {}, function (r) {
        try {
            var data = JSON.parse(r);
            target.value = data[module.value] !== undefined ? data[module.value] : '';
        } catch (e) {
            /* ignore */
        }
    }, true);
}

function loadCommand(ip, file, where) {
    var target = document.getElementById(where);
    if (!target)
        return;
    target.innerHTML = '<option value="">Loading...</option>';
    ajax.get('http://' + ip + '/' + file, {}, function (response) {
        try {
            var data = JSON.parse(response);
            target.innerHTML = '<option value="">Выберите</option>';
            if (data.command) {
                Object.keys(data.command).forEach(function (k) {
                    var opt = document.createElement('option');
                    opt.value = data.command[k];
                    opt.textContent = data.command[k];
                    target.appendChild(opt);
                });
            }
        } catch (e) {
            target.innerHTML = '<option value="">Ошибка</option>';
        }
    }, true);
}

function loadCommandHelp(value, helpId, otherId) {
    var help = document.getElementById(helpId);
    if (help)
        help.innerHTML = 'Команда: <b>' + value + '</b>';
}

function loadMacros(jsonResponseObj, targetId) {
    var target = document.getElementById(targetId);
    if (!target)
        return;
    ajax.get('/macros.json', {}, function (r) {
        try {
            var data = JSON.parse(r);
            var htmlStr = '<h4>Макросы</h4>';
            Object.keys(data).forEach(function (k) {
                htmlStr += '<div class="macro-row" style="padding:6px 10px"><b>' + k + '</b>: ' + data[k] + '</div>';
            });
            target.innerHTML = htmlStr;
        } catch (e) {
            target.innerHTML = '<div style="color:#888;padding:10px">Макросы не найдены</div>';
        }
    }, true);
}

function saveScenary(jsonResponseObj, host) {
    var ta = document.getElementById('scenary-list-edit');
    if (!ta)
        return;
    var data = ta.value;
    send_request_edit(null, data, 'scenary.save.txt', 'loadScenary(jsonResponse, "loadList");');
    alert('Сценарий сохранён');
}

/* ------------------------------- */

function bindGlobalEvents() {
    document.addEventListener('keydown', function (e) {
        var evtobj = window.event ? event : e;
        var element = elem('edit-content');
        var charCode = String.fromCharCode(evtobj.which).toLowerCase();
        if (charCode === 'e' && evtobj.ctrlKey && element)
            window.open('/edit', '_blank');
        if (charCode === 'm' && evtobj.ctrlKey && element) {
            toggle('edit-content');
            toggle('url-content');
            activeDragDrop(true);
        }
        if (charCode === 's' && evtobj.ctrlKey && element) {
            evtobj.preventDefault();
            send_request_edit(this, val('edit-json'), window.location.search.substring(1).split('&')[0] + '.json');
            toggle('edit-content');
            toggle('url-content');
            activeDragDrop(true);
        }
        if (e.key === 'Escape') {
            var statusModal = document.getElementById('statusModal');
            if (statusModal && statusModal.style.display === 'block')
                hideStatusInfo();
            var softwareModal = document.getElementById('softwareModal');
            if (softwareModal && softwareModal.style.display === 'block')
                hideSoftwareInfo();
            var changelogModal = document.getElementById('changelogModal');
            if (changelogModal && changelogModal.style.display === 'block')
                closeChangelogModal();
        }
    });

    document.addEventListener('click', function (e) {
        if (e.target.id === 'statusModal')
            hideStatusInfo();
        if (e.target.id === 'softwareModal')
            hideSoftwareInfo();
        if (e.target.id === 'changelogModal')
            closeChangelogModal();
        _allTooltips.forEach(function (pair) {
            var tip = document.getElementById(pair.tooltip);
            var hdr = document.getElementById(pair.header);
            if (tip && tip.style.display === 'block' && hdr && !hdr.contains(e.target) && !tip.contains(e.target))
                tip.style.display = 'none';
        });
    });

    document.addEventListener('change', function (e) {
        var target = e.target;
        if (target.type === 'checkbox' && target.id && MODULE_CHECKBOX_MAP[target.id]) {
            setTimeout(applyModuleVisibility, 200);
            if (target.id === 'sd_enable') {
                var fakeStates = Object.assign({
                    sd_type: '0'
                }, window.moduleStates || {}, {
                    sd_enable: target.checked ? '1' : '0'
                });
                applySdVisibility(fakeStates);
                setTimeout(loadModuleStates, 300);
            }
        }
        if (target.id === 'multi_matrix_enable')
            applyMultiMatrixVisibility();
        if (target.id === 'sd_type')
            console.log('sd_type change ->', target.value);
        if (target.id === 'show_weather_condition' && typeof updateWeatherBlock === 'function')
            setTimeout(updateWeatherBlock, 300);
    });

    document.addEventListener('input', function (e) {
        var slider = e.target;
        if (!slider || slider.tagName !== 'INPUT' || slider.type !== 'range')
            return;
        var label = slider.closest('label');
        if (!label)
            return;
        var h4 = label.querySelector('h4');
        if (!h4)
            return;
        if (!h4.dataset.originalTitle)
            h4.dataset.originalTitle = h4.innerHTML;
        var originalTitle = h4.dataset.originalTitle;
        var v = slider.value;
        if (/\{\{.*?\}\}/.test(originalTitle))
            h4.innerHTML = originalTitle.replace(/\{\{.*?\}\}/, v);
        else
            h4.innerHTML = originalTitle.replace(/\d+(?!.*\d)/, v);
        if (slider._sendTimer)
            clearTimeout(slider._sendTimer);
        slider._sendTimer = setTimeout(function () {
            var action = slider.dataset.action;
            if (!action)
                return;
            var url = action.replace(/\[\[([^\]]+)\]\]/g, function (_, id) {
                var el = document.getElementById(id);
                return el ? encodeURIComponent(el.value) : '';
            });
            send_request(slider, url, '');
        }, 300);
    });
}

function initApp() {
    bindGlobalEvents();
    loadModuleStates();
    setTimeout(initAllTooltips, 200);
    setTimeout(function () {
        if (!window.features || window.features.update_check !== false) {
            checkForUpdate(true);
        }
    }, 10000);

    /*managedSetInterval('auto-update-check', function () {
    checkForUpdate(true);
    }, CONFIG.AUTO_UPDATE_CHECK_INTERVAL);
    setTimeout(updateMemoryInfo, 300);*/

    if (!sessionStorage.getItem(STORAGE_KEYS.TIME_SENT)) {
        var now = Math.floor(Date.now() / 1000);
        fetch('/set_client_time?time=' + now)
        .then(function (response) {
            return response.ok ? response.text() : Promise.reject();
        })
        .then(function (txt) {
            console.log('Время успешно передано:', txt);
            sessionStorage.setItem(STORAGE_KEYS.TIME_SENT, 'true');
        })
        .catch(function (err) {
            console.warn('Ошибка передачи времени:', err);
        });
    }

    managedSetInterval('sync-clock', updateSyncClock, 1000);

    if (document.getElementById('weatherNowDisplay'))
        initWeatherBlock();

    updateLastCheckDisplay();
    var lastCheck = getCachedUpdateCheck();
    if (lastCheck) {
        if (lastCheck.has_update) {
            showUpdateAvailable(lastCheck);
            showUpdateStatus(lastCheck);
            refreshUpdateBadge();
        } else
            showUpdateStatus({
                has_update: false
            });
        updateLastCheckDisplay(lastCheck.timestamp);
    }

    // weather save button binding
    var applyBtn = document.getElementById('apply_custom_tz');
    if (applyBtn)
        applyBtn.addEventListener('click', applyCustomTimezone);
    var autoBtn = document.getElementById('auto_tz_btn');
    if (autoBtn)
        autoBtn.addEventListener('click', autoDetectTimezone);
    var customInput = document.getElementById('custom_tz_input');
    if (customInput)
        customInput.addEventListener('keypress', function (e) {
            if (e.key === 'Enter')
                applyCustomTimezone();
        });
    updateTimezoneInfo();

    var effSel = document.getElementById('eff_sel');
    if (effSel) {
        effSel.addEventListener('change', updateAnimBlock);
        setTimeout(updateAnimBlock, 100);
        syncAnimSel();
        loadAnimationsList();
    }

    var memInfo = document.getElementById('mem-info');
    if (memInfo) {
        memInfo.style.cursor = 'pointer';
        memInfo.addEventListener('click', showMemoryDetails);
    }
}

/* ------------------------------- */

Object.assign(window, {
    // Ajax
    ajax: ajax,
    // DOM
    elem: elem,
    val: val,
    html: html,
    toggle: toggle,
    log: log,
    togglePasswordVisibility: togglePasswordVisibility,
    // template
    viewTemplate: viewTemplate,
    renameBlock: renameBlock,
    renameGet: renameGet,
    // loaders
    loadJson: loadJson,
    loadSelect: loadSelect,
    loadFile: loadFile,
    loadCSV: loadCSV,
    loadTable: loadTable,
    html_to_csv: html_to_csv,
    // set content
    setContent: setContent,
    // edit
    activeDragDrop: activeDragDrop,
    create_new_element: create_new_element,
    create_new_element_show: create_new_element_show,
    // requests
    send_request: send_request,
    send_request_edit: send_request_edit,
    submit_disabled: submit_disabled,
    // configs
    loadConfigs: loadConfigs,
    findError: findError,
    changeTextarea: changeTextarea,
    // modules
    loadModuleStates: loadModuleStates,
    applyModuleVisibility: applyModuleVisibility,
    applyMultiMatrixVisibility: applyMultiMatrixVisibility,
    // statuses
    showStatusInfo: showStatusInfo,
    hideStatusInfo: hideStatusInfo,
    refreshAllStatuses: refreshAllStatuses,
    updateAllStatuses: updateAllStatuses,
    // software
    showSoftwareInfo: showSoftwareInfo,
    hideSoftwareInfo: hideSoftwareInfo,
    loadVersionInfo: loadVersionInfo,
    refreshVersionInfo: refreshVersionInfo,
    checkForUpdate: checkForUpdate,
    manualCheckUpdate: manualCheckUpdate,
    showUpdateAvailable: showUpdateAvailable,
    showUpdateStatus: showUpdateStatus,
    updateLastCheckDisplay: updateLastCheckDisplay,
    // changelog
    showChangelogModal: showChangelogModal,
    showPlannedUpdates: showPlannedUpdates,
    showCurrentChangelog: showCurrentChangelog,
    closeChangelogModal: closeChangelogModal,
    // memory
    updateMemoryInfo: updateMemoryInfo,
    showMemoryDetails: showMemoryDetails,
    // weather
    updateWeatherBlock: updateWeatherBlock,
    initWeatherBlock: initWeatherBlock,
    resolveCity: resolveCity,
    resolveCityGeneric: resolveCityGeneric,
    saveWeatherParamsWithResolve: saveWeatherParamsWithResolve,
    // timezone
    syncClientTime: syncClientTime,
    updateSyncClock: updateSyncClock,
    syncTimeFromBrowser: syncTimeFromBrowser,
    applyCustomTimezone: applyCustomTimezone,
    updateTimezoneInfo: updateTimezoneInfo,
    autoDetectTimezone: autoDetectTimezone,
    // animations
    updateAnimBlock: updateAnimBlock,
    loadAnimationsList: loadAnimationsList,
    syncAnimSel: syncAnimSel,
    loadOutFilesList: loadOutFilesList,
    syncOutSel: syncOutSel,
    ensureEffSdIndex: ensureEffSdIndex,
    // reboot
    showRebootOverlay: showRebootOverlay,
    // radio
    radioLoadAll: radioLoadAll,
    radioAddStation: radioAddStation,
    radioRemoveStation: radioRemoveStation,
    radioSaveStations: radioSaveStations,
    radioAddMap: radioAddMap,
    radioRemoveMap: radioRemoveMap,
    radioSaveMap: radioSaveMap,
    radioShowMsg: radioShowMsg,
    radioEsc: radioEsc,
    radioUpdateVolumeLabel: radioUpdateVolumeLabel,
    radioRenderStations: radioRenderStations,
    radioRenderMap: radioRenderMap,
    radioRenderMapAddRow: radioRenderMapAddRow,
    // tooltips
    initTooltip: initTooltip,
    initAllTooltips: initAllTooltips,
    initBrightnessSliders: initBrightnessSliders,
    // night clock
    updateNightClockButton: updateNightClockButton,
    toggleNightClock: toggleNightClock,
    // recovered helpers
    loadTime: loadTime,
    loadNewThen: loadNewThen,
    loadScenary: loadScenary,
    loadScenaryList: loadScenaryList,
    loadLive: loadLive,
    loadLive2: loadLive2,
    loadNewAnd: loadNewAnd,
    loadNewOr: loadNewOr,
    saveScenary: saveScenary,
    addTimer: addTimer,
    pattern: pattern,
    toggleCheckbox: toggleCheckbox,
    loadCommand: loadCommand,
    loadCommandHelp: loadCommandHelp,
    loadMacros: loadMacros,
    loadIssues: loadIssues,
    loadCommits: loadCommits,
    createRGB: createRGB,
    loadWifi: loadWifi,
    loadBuild: loadBuild,
    cloudUpload: cloudUpload,
    cloudDownload: cloudDownload,
    send_socket: send_socket,
    run_socket: run_socket,
    hide: hide,
    showNotification: showNotification,
    showLoading: showLoading,
    isValidJson: isValidJson,
    httpDelete: httpDelete,
    delCb: delCb
});

// Debug-доступ к состоянию радио (без рекурсии)
window.getRadioState = function () {
    return {
        effList: radioEffList,
        stations: radioStations,
        map: radioMap,
        currentEffect: radioCurrentEffect,
        currentStation: radioCurrentStation
    };
};
